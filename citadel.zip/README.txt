Thank you for purchasing Citadel!

To get started and access the installation guide along with real-time support:

1.Join our Discord server here: https://discord.gg/jGcThgwPqZ
2.Link your Discord account with BBB here: https://builtbybit.com/account/discord/
3.In the HostLab Discord, go to the #general channel and run the /sync command.
4.Wait a few minutes until you see a new channel named Citadel unlocked. It includes a complete installation guide, setup instructions, and explanations of every feature to help you get the most out of Citadel theme.

If you have any questions or need help, feel free to ping #Willo1 on the server.