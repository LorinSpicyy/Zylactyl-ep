<?php

namespace App\Livewire\Components;

use App\Livewire\Component;

class LanguageSwitch extends Component
{
    protected $resolveStrategy = 'session_fallback';

    public string $currentLocale = '';

    public function mount()
    {
        $this->currentLocale = session('locale', config('app.locale'));
    }

    public function updatedCurrentLocale($locale)
    {
        if (!in_array($locale, config('settings.allowed_languages', []))) {
            return;
        }

        session(['locale' => $locale]);
        app()->setLocale($locale);

        return $this->redirect(request()->header('Referer', '/'), navigate: true);
    }

    public function render()
    {
        $locales = config('settings.allowed_languages', []);

        return view('components.language-switch', compact('locales'));
    }
}
