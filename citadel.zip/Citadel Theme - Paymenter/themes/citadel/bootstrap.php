<?php

use Illuminate\Support\Facades\Lang;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Storage;

Lang::addNamespace('citadel', __DIR__ . '/lang');



if (! function_exists('citadel_avatar_extensions')) {
    /**
     *
     * @return array<int, string>
     */
    function citadel_avatar_extensions(): array
    {
        return ['webp', 'png', 'jpg', 'jpeg'];
    }
}

if (! function_exists('citadel_custom_avatar_path')) {
    /**
     */
    function citadel_custom_avatar_path($user): ?string
    {
        $id = is_object($user) ? ($user->id ?? null) : null;
        if (! $id) {
            return null;
        }

        try {
            $disk = Storage::disk('public');
            foreach (citadel_avatar_extensions() as $ext) {
                $path = "citadel/avatars/{$id}.{$ext}";
                if ($disk->exists($path)) {
                    return $path;
                }
            }
        } catch (\Throwable $e) {
            return null;
        }

        return null;
    }
}

if (! function_exists('citadel_avatar_url')) {
    /**

     */
    function citadel_avatar_url($user): string
    {
        if (! is_object($user)) {
            return '';
        }

        static $cache = [];
        $id = $user->id ?? null;
        if ($id !== null && array_key_exists($id, $cache)) {
            return $cache[$id];
        }

        $url = (string) ($user->avatar ?? '');

        $path = citadel_custom_avatar_path($user);
        if ($path !== null) {
            try {
                $disk = Storage::disk('public');
                $url = $disk->url($path) . '?v=' . $disk->lastModified($path);
            } catch (\Throwable $e) {
                // keep fallback url
            }
        }

        if ($id !== null) {
            $cache[$id] = $url;
        }

        return $url;
    }
}

if (! function_exists('citadel_plan_sale')) {
    /**
     *
     * @return array{pct: float, real: string, original: string, saved: string, badge: string}|null
     */
    function citadel_plan_sale($product, $plan): ?array
    {
        if (! $product || ! $plan) {
            return null;
        }

        if (! (bool) theme('sale_enabled', false)) {
            return null;
        }

        $productId = is_object($product) ? ($product->id ?? null) : null;
        if ($productId === null) {
            return null;
        }

        $saleProducts = json_decode((string) theme('sale_products_data', '[]'), true);
        if (! is_array($saleProducts) || ! in_array((int) $productId, array_map('intval', $saleProducts), true)) {
            return null;
        }

        $planName = is_object($plan) ? ($plan->name ?? null) : null;
        if ($planName === null) {
            return null;
        }

        $discounts = json_decode((string) theme('sale_plan_discounts_data', '[]'), true);
        if (! is_array($discounts)) {
            return null;
        }

        $pct = null;
        foreach ($discounts as $row) {
            if (! is_array($row)) {
                continue;
            }
            if (($row['plan_name'] ?? null) === $planName && is_numeric($row['percentage'] ?? null)) {
                $candidate = (float) $row['percentage'];
                if ($candidate > 0 && $candidate < 100) {
                    $pct = $candidate;
                }
                break;
            }
        }

        if ($pct === null) {
            return null;
        }

        try {
            $price = $plan->price();
        } catch (\Throwable $e) {
            return null;
        }

        if (! $price || ! ($price->available ?? false) || ($price->is_free ?? false)) {
            return null;
        }

        $realFloat = (float) $price->price;
        if ($realFloat <= 0) {
            return null;
        }

        $originalFloat = $realFloat / (1 - $pct / 100);
        $savedFloat = $originalFloat - $realFloat;

        $fmtPct = rtrim(rtrim(number_format($pct, 2, '.', ''), '0'), '.');

        $format = (string) theme('sale_badge_format', 'percentage_off');
        $badge = match ($format) {
            'save_amount' => 'Save ' . $price->format($savedFloat),
            'save_percentage' => 'Save ' . $fmtPct . '%',
            'amount_off' => $price->format($savedFloat) . ' OFF',
            default => $fmtPct . '% off',
        };

        return [
            'pct' => $pct,
            'real' => $price->formatted->price,
            'original' => $price->format($originalFloat),
            'saved' => $price->format($savedFloat),
            'badge' => $badge,
        ];
    }
}

if (! function_exists('citadel_product_sale')) {
    /**

     *
     * @return array{pct: float, real: string, original: string, saved: string, badge: string}|null
     */
    function citadel_product_sale($product): ?array
    {
        if (! $product) {
            return null;
        }

        if (! (bool) theme('sale_enabled', false)) {
            return null;
        }

        try {
            $plans = $product->availablePlans();
        } catch (\Throwable $e) {
            return null;
        }

        if (! $plans || $plans->isEmpty()) {
            return null;
        }

        $cheapest = null;
        $cheapestFloat = null;
        foreach ($plans as $plan) {
            try {
                $p = $plan->price();
            } catch (\Throwable $e) {
                continue;
            }
            if (! $p || ! ($p->available ?? false) || ($p->is_free ?? false)) {
                continue;
            }
            $f = (float) $p->price;
            if ($cheapestFloat === null || $f < $cheapestFloat) {
                $cheapestFloat = $f;
                $cheapest = $plan;
            }
        }

        if (! $cheapest) {
            return null;
        }

        return citadel_plan_sale($product, $cheapest);
    }
}

if (! function_exists('citadel_term_months')) {

    function citadel_term_months($period, $unit): float
    {
        $p = (float) $period;
        if ($p <= 0) {
            return 0.0;
        }

        return match ((string) $unit) {
            'year'  => $p * 12.0,
            'month' => $p,
            'week'  => $p * (7.0 / 30.0),
            'day'   => $p * (1.0 / 30.0),
            default => 0.0,
        };
    }
}

if (! function_exists('citadel_lowest_term_price')) {
    /**

     * @return array{amount: float, formatted: string, plan: mixed}|null
     */
    function citadel_lowest_term_price($product): ?array
    {
        if (! $product) {
            return null;
        }

        try {
            $plans = $product->availablePlans();
        } catch (\Throwable $e) {
            return null;
        }

        if (! $plans || $plans->isEmpty()) {
            return null;
        }

        $entries = [];
        foreach ($plans as $plan) {
            if (($plan->type ?? null) !== 'recurring') {
                continue;
            }

            try {
                $price = $plan->price();
            } catch (\Throwable $e) {
                continue;
            }

            if (! $price || ! ($price->available ?? false) || ($price->is_free ?? false)) {
                continue;
            }

            $amount = (float) $price->price;
            if ($amount <= 0) {
                continue;
            }

            $months = citadel_term_months($plan->billing_period ?? null, $plan->billing_unit ?? null);
            if ($months <= 0) {
                continue;
            }

            $entries[] = [
                'plan' => $plan,
                'price' => $price,
                'amount' => $amount,
                'months' => $months,
                'per_month' => $amount / $months,
            ];
        }

        if (count($entries) < 2) {
            return null;
        }

        $base = $entries[0];
        $best = $entries[0];
        foreach ($entries as $entry) {
            if ($entry['months'] < $base['months']) {
                $base = $entry;
            }
            if ($entry['per_month'] < $best['per_month']) {
                $best = $entry;
            }
        }

        $displayAmount = $best['per_month'] * $base['months'];

        return [
            'amount' => $displayAmount,
            'formatted' => $best['price']->format($displayAmount),
            'plan' => $base['plan'],
        ];
    }
}

app()->booted(function () {
    $locale = config('app.locale', 'en');
    app()->setLocale($locale);
});

$citadelBuildingRouteCache = app()->runningInConsole()
    && ! empty(array_intersect(['route:cache', 'optimize'], (array) ($_SERVER['argv'] ?? [])));

if (! $citadelBuildingRouteCache) {

    $loadCustomPages = function (): array {
        try {
            $raw = (string) (\App\Models\Setting::where('key', 'theme_citadel_custom_pages_data')->value('value') ?? '[]');
        } catch (\Throwable $e) {
            return [];
        }
        $pages = json_decode($raw, true);
        return is_array($pages) ? $pages : [];
    };

    $renderPage = function (array $page) {
        $type = $page['page_type'] ?? 'custom';
        if ($type === 'product') {
            return view('custom-product-page', ['page' => $page]);
        }
        return view('custom-page', ['page' => $page]);
    };

    $resolveBySlug = function (string $slug) use ($loadCustomPages): ?array {
        foreach ($loadCustomPages() as $page) {
            if (! is_array($page)) {
                continue;
            }
            if (! ($page['enabled'] ?? true)) {
                continue;
            }
            $pageType = $page['page_type'] ?? 'custom';
            $pageSlug = $page['slug'] ?? null;


            if ($pageType === 'product' && ($page['url_strategy'] ?? 'replace') === 'replace') {
                continue;
            }
            if ($pageSlug === $slug) {
                return $page;
            }
        }
        return null;
    };

    $resolveByCategorySlug = function (string $categorySlug) use ($loadCustomPages): ?array {
        $matches = [];
        foreach ($loadCustomPages() as $page) {
            if (! is_array($page) || ($page['page_type'] ?? null) !== 'product') {
                continue;
            }
            if (! ($page['enabled'] ?? true)) {
                continue;
            }
            if (($page['url_strategy'] ?? 'replace') !== 'replace') {
                continue;
            }
            $matches[] = $page;
        }
        if (empty($matches)) {
            return null;
        }
        try {
            $category = \App\Models\Category::where('slug', $categorySlug)->first();
        } catch (\Throwable $e) {
            return null;
        }
        if (! $category) {
            return null;
        }
        foreach ($matches as $page) {
            if ((int) ($page['category_id'] ?? 0) === (int) $category->id) {
                return $page;
            }
        }
        return null;
    };

    Route::middleware('web')->group(function () use ($renderPage, $resolveBySlug, $resolveByCategorySlug, $loadCustomPages) {

        
        Route::get('/p/{slug}', function (string $slug) use ($renderPage, $resolveBySlug) {
            $page = $resolveBySlug($slug);
            abort_if(! $page, 404);
            return $renderPage($page);
        })->where('slug', '[A-Za-z0-9\-_]+')->name('citadel.custom-page');


        $replaceSlugs = [];
        try {
            foreach ($loadCustomPages() as $page) {
                if (! is_array($page) || ($page['page_type'] ?? null) !== 'product') {
                    continue;
                }
                if (! ($page['enabled'] ?? true)) {
                    continue;
                }
                if (($page['url_strategy'] ?? 'replace') !== 'replace') {
                    continue;
                }
                $catId = $page['category_id'] ?? null;
                if (! $catId) {
                    continue;
                }
                $cat = \App\Models\Category::find($catId);
                if ($cat) {
                    $replaceSlugs[] = preg_quote($cat->slug, '/');
                }
            }
        } catch (\Throwable $e) {}

        if (! empty($replaceSlugs)) {
            $constraint = '^(' . implode('|', $replaceSlugs) . ')$';
            Route::get('/products/{slug}', function (string $slug) use ($renderPage, $resolveByCategorySlug) {
                $page = $resolveByCategorySlug($slug);
                abort_if(! $page, 404);
                return $renderPage($page);
            })->where('slug', $constraint);
        }

        
    });

    app()->booted(function () use ($loadCustomPages, $resolveBySlug, $renderPage) {
        foreach ($loadCustomPages() as $page) {
            if (! is_array($page) || ! ($page['enabled'] ?? true)) {
                continue;
            }
            $pageType = $page['page_type'] ?? 'custom';
            if ($pageType === 'product' && ($page['url_strategy'] ?? 'replace') === 'replace') {
                continue;
            }
            $pageSlug = $page['slug'] ?? null;
            if (! is_string($pageSlug) || ! preg_match('/^[A-Za-z0-9_\-]+$/', $pageSlug)) {
                continue;
            }

            $taken = false;
            try {
                $match = Route::getRoutes()->match(\Illuminate\Http\Request::create('/' . $pageSlug, 'GET'));
                $taken = ! ($match->isFallback ?? false);
            } catch (\Throwable $e) {
                $taken = false;
            }
            if ($taken) {
                continue;
            }

            Route::get('/' . $pageSlug, function () use ($resolveBySlug, $renderPage, $pageSlug) {
                $matchedPage = $resolveBySlug($pageSlug);
                abort_if(! $matchedPage, 404);
                return $renderPage($matchedPage);
            })->middleware('web')->name('citadel.custom-page.root.' . $pageSlug);
        }
    });
}
