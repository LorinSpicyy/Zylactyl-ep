<?php

return [

    'auth' => [
        'login' => [
            'subtitle' => '¡Bienvenido de nuevo! Por favor, inicia sesión para continuar.',
            'remember_me' => 'Recuérdame',
        ],
        'register' => [
            'subtitle' => 'Crea tu cuenta para comenzar.',
            'button' => 'Registrarse',
            'next' => 'Continuar',
            'back' => 'Volver',
            'confirm_password' => 'Confirmar Contraseña',
            'step1_title' => 'Detalles de la Cuenta',
            'step2_title' => 'Información Adicional',
        ],
        'two_factor' => [
            'subtitle' => 'Ingresa el código de tu aplicación de autenticación.',
        ],
        'password_reset_request' => [
            'subtitle' => 'Ingresa tu correo electrónico para recibir un enlace de restablecimiento de contraseña.',
        ],
        'password_reset' => [
            'subtitle' => 'Ingresa tu nueva contraseña a continuación.',
        ],
        'back_to_login' => 'Volver al inicio de sesión',
    ],


    'account' => [

        'navigation' => [
            'account_settings' => 'Configuración de cuenta',
            'payment_methods' => 'Métodos de pago',
            'notifications' => 'Notificaciones',
        ],


        'credits' => [
            'subtitle' => 'Ve tus créditos disponibles y añade fondos a tu cuenta para futuras compras.',
            'add_funds_title' => 'Añadir fondos al saldo de tu cuenta',
        ],


        'personal_details' => [
            'subtitle' => 'Actualiza la información del perfil de tu cuenta y dirección de correo electrónico. Administra tus datos personales y mantén tu información actualizada.',
            'section_title' => 'Datos personales',
            'section_description' => 'Información básica sobre tu cuenta',
            'billing_title' => 'Información de facturación',
            'billing_description' => 'Información de dirección y empresa para facturas',
        ],


        'avatar' => [
            'section_title' => 'Foto de perfil',
            'section_description' => 'Sube una foto de perfil personalizada. Se mostrará en la barra de navegación, el panel de control, los tickets de soporte y en cualquier otro lugar donde aparezca tu avatar.',
            'choose' => 'Elegir imagen',
            'change' => 'Cambiar imagen',
            'save' => 'Guardar foto',
            'remove' => 'Eliminar',
            'hint' => 'JPG, PNG o WEBP. Máx. 2 MB.',
            'updated' => 'Foto de perfil actualizada correctamente.',
            'removed' => 'Foto de perfil eliminada.',
        ],

        'notifications_page' => [
            'subtitle' => 'Administra tus preferencias de notificación y configura cómo recibes actualizaciones. Elige entre correo electrónico, notificaciones en la aplicación o ambos.',
            'preferences_title' => 'Preferencias de notificación',
            'preferences_description' => 'Elige cómo quieres recibir notificaciones para diferentes eventos',
            'saving' => 'Guardando...',
        ],


        'payment_methods_page' => [
            'setting_up' => 'Configurando...',
            'confirm_cancel' => '¿Estás seguro?',
            'method_singular' => 'método',
            'method_plural' => 'métodos',
            'no_transactions_title' => 'Aún no hay transacciones',
            'no_transactions_description' => 'Tus transacciones de pago aparecerán aquí',
        ],

        'security_page' => [
            'subtitle' => 'Administra la configuración de seguridad de tu cuenta, sesiones activas y autenticación de dos factores.',
            'sessions_description' => 'Administra tus sesiones activas en diferentes dispositivos',
            'password_description' => 'Actualiza tu contraseña para mantener tu cuenta segura',
            'two_factor_description' => 'Añade una capa adicional de seguridad a tu cuenta',
        ],
    ],


    'navigation' => [

        'footer' => [
            'company_heading' => 'Compañía',
            'services' => 'Servicios',
            'contact_us' => 'Contáctanos',
            'legal_heading' => 'Legal',
            'terms_of_service' => 'Términos de servicio',
            'privacy_policy' => 'Política de privacidad',
            'powered_by' => 'Impulsado por',
        ],


        'navbar' => [
            'home' => 'Inicio',
            'view_cart' => 'Ver carrito',
            'dashboard' => 'Panel',
            'store' => 'Tienda',
            'support' => 'Soporte',
            'tickets' => 'Tickets',
            'admin' => 'Administración',
            'account' => 'Cuenta',
            'security' => 'Seguridad',
            'credits' => 'Créditos',
            'personal_details' => 'Datos personales',
            'navigation_heading' => 'Navegación',
        ],


        'sidebar' => [
            'dashboard' => 'Panel',
            'services' => 'Servicios',
            'billing' => 'Facturación',
            'invoices' => 'Facturas',
            'credits' => 'Créditos',
            'store' => 'Tienda',
            'support' => 'Soporte',
            'my_tickets' => 'Mis tickets',
            'create_ticket' => 'Crear ticket',
            'knowledge_base' => 'Base de conocimientos',
            'blog' => 'Blog',
            'status' => 'Estado',
            'account' => 'Cuenta',
            'profile' => 'Perfil',
            'security' => 'Seguridad',
        ],
    ],


    'dashboard' => [
        'title' => 'Panel de control',
        'dashboard_description' => 'Bienvenido a tu panel de control. Aquí puedes ver tus servicios, facturas y tickets de un vistazo.',
        'balance' => 'Saldo',
        'active_services' => 'Servicios activos',
        'unpaid_invoices' => 'Facturas pendientes de pago',
        'open_tickets' => 'Tickets abiertos',
        'services_widget' => 'Servicios',
        'invoices_widget' => 'Facturas',
        'tickets_widget' => 'Dog',
        'discord_title' => 'Únete a Discord',
        'discord_subtitle' => 'Conéctate, participa y obtén soporte',
    ],


    'cart' => [
        'empty_cart_description' => 'Tu carrito está actualmente vacío. Explora nuestros productos y añade artículos para comenzar.',
        'page_title' => 'Revisar y completar pedido',
        'error_title' => 'Se ha producido un problema al enviar tus datos.',
        'info_title' => 'Información',
        'warning_title' => 'Advertencia',
        'tos_error_title' => 'Se requiere aceptación de los términos de servicio',
        'auth_required_title' => 'Se requiere autenticación para completar el pedido.',
        'auth_required_login' => 'Por favor, inicia sesión en tu cuenta existente o crea una nueva cuenta para continuar',
        'auth_required_fields' => 'Los campos de correo electrónico y contraseña son obligatorios',
        'products_heading' => 'Productos',
        'promo_code_heading' => 'Aplicar código promocional',
        'promo_code_error_title' => 'Error de código promocional',
        'promo_code_applied_title' => '¡Código promocional aplicado!',
        'payment_method_heading' => 'Selecciona tu método de pago',
        'payment_method_error_title' => 'Error de método de pago',
        'payment_failed_title' => 'Pago fallido',
        'account_options_heading' => 'Opciones de cuenta',
        'order_summary_heading' => 'Resumen del pedido',
        'total_due_today' => 'Total a pagar hoy',
        'discount' => 'Descuento',
        'checkout_error_title' => 'Error al completar pedido',
        'checkout_failed_title' => 'Pedido fallido',
    ],


    'invoices' => [
        'index' => [
            'title' => 'Mis facturas',
            'subtitle' => 'Ve y administra todas tus facturas, rastrea el estado de pago y descarga recibos desde este panel centralizado.',
            'quick_actions' => 'Acciones rápidas',
            'order_new_service' => 'Solicitar nuevo servicio',
            'contact_support' => 'Contactar soporte',
            'invoices_heading' => 'Facturas',
            'all_invoices' => 'Todas las facturas',
            'paid' => 'Pagado',
            'pending' => 'Pendiente',
            'cancelled' => 'Cancelado',
            'newest' => 'Más recientes',
            'oldest' => 'Más antiguas',
            'invoice_singular' => 'factura',
            'invoice_plural' => 'facturas',
            'invoice_column' => 'Factura',
            'items_column' => 'Artículos',
            'date_column' => 'Fecha',
            'total_column' => 'Total',
            'status_column' => 'Estado',
            'filtering' => 'Filtrando facturas...',
            'no_invoices_title' => 'No se encontraron facturas',
            'no_invoices_description' => 'Aún no tienes facturas.',
            'per_page' => 'Por página',
            'previous' => 'Anterior',
            'next' => 'Siguiente',
        ],

        'show' => [
            'title' => 'Ver factura',
            'subtitle' => 'Revisa los detalles de tu factura, el estado del pago y descarga tu recibo.',
            'confirm_exit' => '¿Estás seguro?',
            'bill_from' => 'Factura de',
            'invoice_number' => 'Factura #:',
            'invoice_date' => 'Fecha de factura:',
            'due_date' => 'Fecha de vencimiento:',
            'bill_to' => 'Facturar a:',
            'item' => 'Artículo',
            'qty' => 'Cant.',
            'price' => 'Precio',
            'amount' => 'Importe',
            'subtotal' => 'Subtotal:',
            'total' => 'Total:',
            'thank_you_title' => 'Gracias por tu compra',
            'thank_you_message' => 'Realmente apreciamos tu confianza en nosotros. Si tienes alguna pregunta sobre esta factura, no dudes en contactar a nuestro equipo de soporte.',
            'download_invoice' => 'Descargar factura',
            'downloading' => 'Descargando...',
            'amount_due' => 'Importe adeudado',
            'pay_with' => 'Pagar con',
            'account_credit' => 'Crédito de cuenta',
            'available_credit' => 'Disponible:',
            'use_different_method' => 'Usar un método de pago diferente',
            'hide_other_methods' => 'Ocultar otros métodos de pago',
            'pay_invoice' => 'Pagar factura',
            'processing_payment' => 'Procesando pago...',
        ],

        'widget' => [
            'items_label' => 'Artículo(s):',
            'view_button' => 'Ver',
            'no_invoices_title' => 'No se encontraron facturas',
            'no_invoices_description' => 'Aún no tienes facturas.',
        ],
    ],

    'products' => [
        'index' => [
            'categories_heading' => 'Categorías',
            'starting_at' => 'Desde',
            'per' => 'por',
            'per_quarter' => 'por trimestre',
            'per_6_months' => 'por 6 meses',
            'per_year' => 'por año',
            'one_time' => 'una vez',
            'order_now' => 'Ordenar ahora',
            'view_all' => 'Ver todo',
        ],

        'show' => [
            'title' => 'Resumen del producto',
            'out_of_stock' => 'Fuera de stock',
            'in_stock' => 'En stock',
            'add_to_cart' => 'Añadir al carrito',
        ],

        'checkout' => [
            'title' => 'Configurar',
            'choose_billing_cycle' => 'Elegir ciclo de facturación',
            'order_summary' => 'Resumen del pedido',
            'setup_fee' => 'Tarifa de instalación',
            'total_due_today' => 'Total a pagar hoy',
            'then' => 'después',
            'add_to_cart' => 'Añadir al carrito',
            'adding' => 'Añadiendo...',
            'required_field' => '*',
            'per' => 'por',
            'per_quarter' => 'por trimestre',
            'per_6_months' => 'por 6 meses',
            'per_year' => 'por año',
            'one_time' => 'una vez',
            'save' => 'Ahorrar',
            'free' => 'Gratis',
        ],
    ],

    'services' => [
        'quick_actions' => 'Acciones rápidas',
        'order_new_service' => 'Solicitar nuevo servicio',
        'contact_support' => 'Contactar soporte',
        
        'index' => [
            'title' => 'Mis servicios',
            'subtitle' => 'Administra y monitorea todos tus servicios activos, actualizaciones y ciclos de facturación desde este panel centralizado.',
            'services_heading' => 'Servicios',
            'all_services' => 'Todos los servicios',
            'active' => 'Activo',
            'suspended' => 'Suspendido',
            'pending' => 'Pendiente',
            'cancelled' => 'Cancelado',
            'newest' => 'Más recientes',
            'oldest' => 'Más antiguos',
            'expiring_soon' => 'Expira pronto',
            'service_singular' => 'servicio',
            'service_plural' => 'servicios',
            'service_column' => 'Servicio',
            'product_column' => 'Producto',
            'expires_column' => 'Expira',
            'status_column' => 'Estado',
            'filtering' => 'Filtrando servicios...',
            'no_services_title' => 'No se encontraron servicios',
            'no_services_description' => 'Aún no tienes servicios.',
            'per_page' => 'Por página',
            'previous' => 'Anterior',
            'next' => 'Siguiente',
        ],

        'show' => [
            'title' => 'Administrar servicio',
            'subtitle' => 'Detalles del servicio, información de facturación y opciones de gestión para tu servicio {product}.',
            'view_all_services' => 'Ver todos los servicios',
            'unpaid_invoice_title' => 'Alerta de factura impaga',
            'unpaid_invoice_message' => 'Tienes una factura pendiente para este servicio que debe pagarse para mantener tu servicio activo.',
            'pay_now' => 'Pagar ahora',
            'name_label' => 'Nombre',
            'billing_cycle_label' => 'Ciclo de facturación',
            'status_label' => 'Estado',
            'price_label' => 'Precio',
            'expires_at_label' => 'Expira el',
            'total_price_per_term' => 'Precio total por período',
            'expiry_date_label' => 'Fecha de expiración',
            'total_due_today' => 'Total a pagar hoy',
            'service_invoices' => 'Facturas del servicio',
            'view_all_invoices' => 'Ver todas las facturas',
            'no_invoices_title' => 'Aún no hay facturas',
            'no_invoices_description' => 'Las facturas del servicio aparecerán aquí',
            'service_actions' => 'Acciones del servicio',
            'service_management' => 'Gestión del servicio',            'renewal_description' => 'Seleccione el período de renovación para su servicio:',        ],

        'upgrade' => [
            'title' => 'Actualizar servicio',
            'current_product' => 'Producto actual',
            'new_product' => 'Nuevo producto',
            'upgrade_summary' => 'Resumen de actualización',
            'current_product_label' => 'Producto actual:',
            'new_product_label' => 'Nuevo producto:',
            'upgrade_cost' => 'Costo de actualización:',
            'next_step' => 'Siguiente paso',
            'upgrade_button' => 'Actualizar',
            'choose_product_subtitle' => 'Selecciona el producto al que te gustaría actualizar.',
            'choose_config_subtitle' => 'Configura tus opciones de actualización.',
        ],

        'widget' => [
            'products_label' => 'Producto(s):',
            'manage_button' => 'Administrar',
            'no_services_title' => 'No se encontraron servicios',
            'no_services_description' => 'Aún no tienes servicios.',
        ],

        'billing_agreement' => [
            'expires' => 'Expira:',
        ],
    ],

    'tickets' => [
        'quick_actions' => 'Acciones rápidas',
        'view_all_tickets' => 'Ver todos los tickets',
        'knowledgebase' => 'Base de conocimientos',
        'blog' => 'Blog',
        'status' => 'Estado',
        
        'index' => [
            'title' => 'Mis tickets',
            'subtitle' => 'Ve y administra tus tickets de soporte. Obtén ayuda de nuestro equipo de soporte para cualquier pregunta o problema que puedas tener.',
            'create_new_ticket' => 'Crear nuevo ticket',
            'tickets_heading' => 'Tickets',
            'all_tickets' => 'Todos los tickets',
            'open' => 'Abierto',
            'closed' => 'Cerrado',
            'replied' => 'Respondido',
            'newest' => 'Más recientes',
            'oldest' => 'Más antiguos',
            'ticket_singular' => 'ticket',
            'ticket_plural' => 'tickets',
            'id_column' => 'ID',
            'subject_column' => 'Asunto',
            'department_column' => 'Departamento',
            'last_activity_column' => 'Última actividad',
            'status_column' => 'Estado',
            'filtering' => 'Filtrando tickets...',
            'no_tickets_title' => 'No se encontraron tickets',
            'no_tickets_description' => 'Aún no tienes tickets de soporte.',
            'per_page' => 'Por página',
            'previous' => 'Anterior',
            'next' => 'Siguiente',
        ],

        'create' => [
            'title' => 'Crear nuevo ticket',
            'subtitle' => 'Envía un ticket de soporte y nuestro equipo se pondrá en contacto contigo lo antes posible. Por favor, proporciona tantos detalles como sea posible para ayudarnos a asistirte mejor.',
            'back_to_tickets' => 'Volver a tickets',
            'drag_drop_text' => 'Arrastra y suelta tus archivos o',
            'click_to_upload' => 'Explorar',
        ],

        'show' => [
            'title' => 'Ticket',
            'subtitle' => 've y administra la conversación de tu ticket de soporte. Puedes responder a mensajes y seguir el estado de tu solicitud aquí.',
            'overview_title' => 'Resumen del ticket',
            'discord_title' => 'Únete a Discord',
            'discord_subtitle' => 'Conéctate, participa y obtén soporte',
        ],

        'widget' => [
            'view_button' => 'Ver',
            'no_tickets_title' => 'No se encontraron tickets',
            'no_tickets_description' => 'Aún no tienes tickets.',
        ],
    ],

    'plans' => [
        'most_popular' => 'MÁS POPULAR',
        'whats_included' => 'Qué incluye:',
        'starting_at' => 'desde',
        'billed_every_month' => 'facturado cada mes',
        'billed_every_year' => 'facturado cada año',
        'billed_every_day' => 'facturado cada día',
        'billed_every_quarter' => 'facturado cada 3 meses',
        'billed_every_6_months' => 'facturado cada 6 meses',
        'one_time_payment' => 'pago único',
        'billed_every' => 'facturado cada :period',
        'quarter' => 'trimestre',
        '6_months' => '6 meses',
        'year' => 'año',
    ],

    'banner' => [
        'copied' => '¡Copiado!',
    ],
];
