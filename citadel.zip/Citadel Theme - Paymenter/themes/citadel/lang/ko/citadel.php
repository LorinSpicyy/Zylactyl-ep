<?php

return [
    'auth' => [
        'login' => [
            'subtitle' => '환영합니다! 계속하려면 로그인하세요.',
            'remember_me' => '로그인 상태 유지',
        ],
        'register' => [
            'subtitle' => '시작하려면 계정을 생성하세요.',
            'button' => '가입하기',
            'next' => '계속',
            'back' => '뒤로',
            'confirm_password' => '비밀번호 확인',
            'step1_title' => '계정 정보',
            'step2_title' => '추가 정보',
        ],
        'two_factor' => [
            'subtitle' => '인증 앱에서 코드를 입력하세요.',
        ],
        'password_reset_request' => [
            'subtitle' => '비밀번호 재설정 링크를 받으려면 이메일을 입력하세요.',
        ],
        'password_reset' => [
            'subtitle' => '아래에 새 비밀번호를 입력하세요.',
        ],
        'back_to_login' => '로그인으로 돌아가기',
    ],

    'account' => [
        'navigation' => [
            'account_settings' => '계정 설정',
            'payment_methods' => '결제 방법',
            'notifications' => '알림',
        ],

        'credits' => [
            'subtitle' => '사용 가능한 크레딧을 확인하고 향후 구매를 위해 계정에 자금을 추가하세요.',
            'add_funds_title' => '계정 잔액에 자금 추가',
        ],


        'personal_details' => [
            'subtitle' => '계정의 프로필 정보 및 이메일 주소를 업데이트하세요. 개인 정보를 관리하고 최신 상태로 유지하세요.',
            'section_title' => '개인 정보',
            'section_description' => '계정에 대한 기본 정보',
            'billing_title' => '청구 정보',
            'billing_description' => '송장을 위한 주소 및 회사 정보',
        ],


        'avatar' => [
            'section_title' => '프로필 사진',
            'section_description' => '사용자 지정 프로필 사진을 업로드하세요. 탐색 바, 대시보드, 지원 티켓 및 아바타가 표시되는 모든 곳에 표시됩니다.',
            'choose' => '이미지 선택',
            'change' => '이미지 변경',
            'save' => '사진 저장',
            'remove' => '제거',
            'hint' => 'JPG, PNG 또는 WEBP. 최대 2 MB.',
            'updated' => '프로필 사진이 성공적으로 업데이트되었습니다.',
            'removed' => '프로필 사진이 제거되었습니다.',
        ],

        'notifications_page' => [
            'subtitle' => '알림 기본 설정을 관리하고 업데이트를 받는 방법을 구성하세요. 이메일, 앱 내 알림 또는 둘 다 선택하세요.',
            'preferences_title' => '알림 기본 설정',
            'preferences_description' => '다양한 이벤트에 대한 알림을 받는 방법을 선택하세요',
            'saving' => '저장 중...',
        ],


        'payment_methods_page' => [
            'setting_up' => '설정 중...',
            'confirm_cancel' => '확실합니까?',
            'method_singular' => '방법',
            'method_plural' => '방법들',
            'no_transactions_title' => '아직 거래 내역이 없습니다',
            'no_transactions_description' => '결제 거래 내역이 여기에 표시됩니다',
        ],


        'security_page' => [
            'subtitle' => '계정 보안 설정, 활성 세션 및 2단계 인증을 관리하세요.',
            'sessions_description' => '다양한 기기에서 활성 세션 관리',
            'password_description' => '계정을 안전하게 유지하려면 비밀번호를 업데이트하세요',
            'two_factor_description' => '계정에 추가 보안 계층 추가',
        ],
    ],


    'navigation' => [

        'footer' => [
            'company_heading' => '회사',
            'services' => '서비스',
            'contact_us' => '문의하기',
            'legal_heading' => '법률',
            'terms_of_service' => '서비스 약관',
            'privacy_policy' => '개인정보 보호정책',
            'powered_by' => '제공:',
        ],


        'navbar' => [
            'home' => '홈',
            'view_cart' => '장바구니 보기',
            'dashboard' => '대시보드',
            'store' => '스토어',
            'support' => '지원',
            'tickets' => '티켓',
            'admin' => '관리자',
            'account' => '계정',
            'security' => '보안',
            'credits' => '크레딧',
            'personal_details' => '개인 정보',
            'navigation_heading' => '네비게이션',
        ],


        'sidebar' => [
            'dashboard' => '대시보드',
            'services' => '서비스',
            'billing' => '청구',
            'invoices' => '송장',
            'credits' => '크레딧',
            'store' => '스토어',
            'support' => '지원',
            'my_tickets' => '내 티켓',
            'create_ticket' => '티켓 생성',
            'knowledge_base' => '지식 베이스',
            'blog' => '블로그',
            'status' => '상태',
            'account' => '계정',
            'profile' => '프로필',
            'security' => '보안',
        ],
    ],


    'dashboard' => [
        'title' => '대시보드',
        'dashboard_description' => '대시보드에 오신 것을 환영합니다. 여기에서 서비스, 송장 및 티켓을 한눈에 볼 수 있습니다.',
        'balance' => '잔액',
        'active_services' => '활성 서비스',
        'unpaid_invoices' => '미납 송장',
        'open_tickets' => '열린 티켓',
        'services_widget' => '서비스',
        'invoices_widget' => '송장',
        'tickets_widget' => '티켓',
        'discord_title' => '디스코드 참여',
        'discord_subtitle' => '연결, 참여 및 지원 받기',
    ],


    'cart' => [
        'empty_cart_description' => '장바구니가 비어 있습니다. 제품을 탐색하고 항목을 추가하여 시작하세요.',
        'page_title' => '검토 및 결제',
        'error_title' => '데이터 제출 중 문제가 발생했습니다.',
        'info_title' => '정보',
        'warning_title' => '경고',
        'tos_error_title' => '서비스 약관 동의 필요',
        'auth_required_title' => '결제를 완료하려면 인증이 필요합니다.',
        'auth_required_login' => '계속하려면 기존 계정에 로그인하거나 새 계정을 만드세요',
        'auth_required_fields' => '이메일 및 비밀번호 필드가 모두 필요합니다',
        'products_heading' => '제품',
        'promo_code_heading' => '프로모션 코드 적용',
        'promo_code_error_title' => '프로모션 코드 오류',
        'promo_code_applied_title' => '프로모션 코드 적용됨!',
        'payment_method_heading' => '결제 방법 선택',
        'payment_method_error_title' => '결제 방법 오류',
        'payment_failed_title' => '결제 실패',
        'account_options_heading' => '계정 옵션',
        'order_summary_heading' => '주문 요약',
        'total_due_today' => '오늘 지불해야 할 금액',
        'discount' => '할인',
        'checkout_error_title' => '결제 오류',
        'checkout_failed_title' => '결제 실패',
    ],


    'invoices' => [

        'index' => [
            'title' => '내 송장',
            'subtitle' => '이 중앙 집중식 대시보드에서 모든 송장을 보고 관리하고, 결제 상태를 추적하고, 영수증을 다운로드하세요.',
            'quick_actions' => '빠른 작업',
            'order_new_service' => '새 서비스 주문',
            'contact_support' => '지원팀 문의',
            'invoices_heading' => '송장',
            'all_invoices' => '모든 송장',
            'paid' => '지불됨',
            'pending' => '대기 중',
            'cancelled' => '취소됨',
            'newest' => '최신순',
            'oldest' => '오래된순',
            'invoice_singular' => '송장',
            'invoice_plural' => '송장',
            'invoice_column' => '송장',
            'items_column' => '항목',
            'date_column' => '날짜',
            'total_column' => '합계',
            'status_column' => '상태',
            'filtering' => '송장 필터링 중...',
            'no_invoices_title' => '송장을 찾을 수 없습니다',
            'no_invoices_description' => '아직 송장이 없습니다.',
            'per_page' => '페이지당',
            'previous' => '이전',
            'next' => '다음',
        ],


        'show' => [
            'title' => '송장 보기',
            'subtitle' => '송장 세부 정보, 결제 상태를 검토하고 영수증을 다운로드하세요.',
            'confirm_exit' => '확실합니까?',
            'bill_from' => '발행자',
            'invoice_number' => '송장 #:',
            'invoice_date' => '송장 날짜:',
            'due_date' => '만기일:',
            'bill_to' => '청구 대상:',
            'item' => '항목',
            'qty' => '수량',
            'price' => '가격',
            'amount' => '금액',
            'subtotal' => '소계:',
            'total' => '합계:',
            'thank_you_title' => '거래해 주셔서 감사합니다',
            'thank_you_message' => '저희를 믿어주셔서 진심으로 감사드립니다. 이 송장에 대해 질문이 있으시면 언제든지 지원팀에 문의하세요.',
            'download_invoice' => '송장 다운로드',
            'downloading' => '다운로드 중...',
            'amount_due' => '지불할 금액',
            'pay_with' => '결제 수단',
            'account_credit' => '계정 크레딧',
            'available_credit' => '사용 가능:',
            'use_different_method' => '다른 결제 방법 사용',
            'hide_other_methods' => '다른 결제 방법 숨기기',
            'pay_invoice' => '송장 지불',
            'processing_payment' => '결제 처리 중...',
        ],


        'widget' => [
            'items_label' => '항목:',
            'view_button' => '보기',
            'no_invoices_title' => '송장을 찾을 수 없습니다',
            'no_invoices_description' => '아직 송장이 없습니다.',
        ],
    ],


    'products' => [

        'index' => [
            'categories_heading' => '카테고리',
            'starting_at' => '시작 가격',
            'per' => '당',
            'per_quarter' => '분기당',
            'per_6_months' => '6개월당',
            'per_year' => '연간',
            'one_time' => '일회성',
            'order_now' => '지금 주문',
            'view_all' => '모두 보기',
        ],


        'show' => [
            'title' => '제품 요약',
            'out_of_stock' => '품절',
            'in_stock' => '재고 있음',
            'add_to_cart' => '장바구니에 추가',
        ],

        'checkout' => [
            'title' => '구성',
            'choose_billing_cycle' => '청구 주기 선택',
            'order_summary' => '주문 요약',
            'setup_fee' => '설정 수수료',
            'total_due_today' => '오늘 지불해야 할 총액',
            'then' => '그 다음',
            'add_to_cart' => '장바구니에 추가',
            'adding' => '추가 중...',
            'required_field' => '*',
            'per' => '당',
            'per_quarter' => '분기당',
            'per_6_months' => '6개월당',
            'per_year' => '연간',
            'one_time' => '일회성',
            'save' => '저장',
            'free' => '무료',
        ],
    ],


    'services' => [

        'quick_actions' => '빠른 작업',
        'order_new_service' => '새 서비스 주문',
        'contact_support' => '지원팀 문의',
        

        'index' => [
            'title' => '내 서비스',
            'subtitle' => '이 중앙 집중식 대시보드에서 모든 활성 서비스, 업그레이드 및 청구 주기를 관리하고 모니터링하세요.',
            'services_heading' => '서비스',
            'all_services' => '모든 서비스',
            'active' => '활성',
            'suspended' => '일시 중단됨',
            'pending' => '대기 중',
            'cancelled' => '취소됨',
            'newest' => '최신순',
            'oldest' => '오래된순',
            'expiring_soon' => '곧 만료',
            'service_singular' => '서비스',
            'service_plural' => '서비스',
            'service_column' => '서비스',
            'product_column' => '제품',
            'expires_column' => '만료',
            'status_column' => '상태',
            'filtering' => '서비스 필터링 중...',
            'no_services_title' => '서비스를 찾을 수 없습니다',
            'no_services_description' => '아직 서비스가 없습니다.',
            'per_page' => '페이지당',
            'previous' => '이전',
            'next' => '다음',
        ],


        'show' => [
            'title' => '서비스 관리',
            'subtitle' => '{product} 서비스에 대한 서비스 세부 정보, 청구 정보 및 관리 옵션.',
            'view_all_services' => '모든 서비스 보기',
            'unpaid_invoice_title' => '미납 송장 알림',
            'unpaid_invoice_message' => '서비스를 계속 활성화하려면 결제해야 할 미결제 송장이 있습니다.',
            'pay_now' => '지금 결제',
            'name_label' => '이름',
            'billing_cycle_label' => '청구 주기',
            'status_label' => '상태',
            'price_label' => '가격',
            'expires_at_label' => '만료일',
            'total_price_per_term' => '기간당 총 가격',
            'expiry_date_label' => '만료일',
            'total_due_today' => '오늘 지불해야 할 총액',
            'service_invoices' => '서비스 송장',
            'view_all_invoices' => '모든 송장 보기',
            'no_invoices_title' => '아직 송장이 없습니다',
            'no_invoices_description' => '서비스 송장이 여기에 표시됩니다',
            'service_actions' => '서비스 작업',
            'service_management' => '서비스 관리',            'renewal_description' => '서비스 갱신 기간을 선택하세요:',        ],


        'upgrade' => [
            'title' => '서비스 업그레이드',
            'current_product' => '현재 제품',
            'new_product' => '새 제품',
            'upgrade_summary' => '업그레이드 요약',
            'current_product_label' => '현재 제품:',
            'new_product_label' => '새 제품:',
            'upgrade_cost' => '업그레이드 비용:',
            'next_step' => '다음 단계',
            'upgrade_button' => '업그레이드',
            'choose_product_subtitle' => '업그레이드하려는 제품을 선택하세요.',
            'choose_config_subtitle' => '업그레이드 옵션을 구성하세요.',
        ],


        'widget' => [
            'products_label' => '제품:',
            'manage_button' => '관리',
            'no_services_title' => '서비스를 찾을 수 없습니다',
            'no_services_description' => '아직 서비스가 없습니다.',
        ],


        'billing_agreement' => [
            'expires' => '만료:',
        ],
    ],


    'tickets' => [

        'quick_actions' => '빠른 작업',
        'view_all_tickets' => '모든 티켓 보기',
        'knowledgebase' => '지식 베이스',
        'blog' => '블로그',
        'status' => '상태',
        

        'index' => [
            'title' => '내 티켓',
            'subtitle' => '지원 티켓을 보고 관리하세요. 질문이나 문제가 있으면 지원팀의 도움을 받으세요.',
            'create_new_ticket' => '새 티켓 생성',
            'tickets_heading' => '티켓',
            'all_tickets' => '모든 티켓',
            'open' => '열림',
            'closed' => '닫힘',
            'replied' => '답변됨',
            'newest' => '최신순',
            'oldest' => '오래된순',
            'ticket_singular' => '티켓',
            'ticket_plural' => '티켓',
            'id_column' => 'ID',
            'subject_column' => '제목',
            'department_column' => '부서',
            'last_activity_column' => '마지막 활동',
            'status_column' => '상태',
            'filtering' => '티켓 필터링 중...',
            'no_tickets_title' => '티켓을 찾을 수 없습니다',
            'no_tickets_description' => '아직 지원 티켓이 없습니다.',
            'per_page' => '페이지당',
            'previous' => '이전',
            'next' => '다음',
        ],


        'create' => [
            'title' => '새 티켓 생성',
            'subtitle' => '지원 티켓을 제출하면 저희 팀이 최대한 빨리 답변해 드립니다. 더 나은 지원을 위해 최대한 자세히 설명해 주세요.',
            'back_to_tickets' => '티켓으로 돌아가기',
            'drag_drop_text' => '파일을 끌어다 놓거나',
            'click_to_upload' => '찾아보기',
        ],


        'show' => [
            'title' => '티켓',
            'subtitle' => '지원 티켓 대화를 보고 관리하세요. 메시지에 답장하고 요청 상태를 추적할 수 있습니다.',
            'overview_title' => '티켓 개요',
            'discord_title' => '디스코드 참여',
            'discord_subtitle' => '연결, 참여 및 지원 받기',
        ],


        'widget' => [
            'view_button' => '보기',
            'no_tickets_title' => '티켓을 찾을 수 없습니다',
            'no_tickets_description' => '아직 티켓이 없습니다.',
        ],
    ],

    'plans' => [
        'most_popular' => '가장 인기',
        'whats_included' => '포함 사항:',
        'starting_at' => '시작가',
        'billed_every_month' => '매월 청구',
        'billed_every_year' => '매년 청구',
        'billed_every_day' => '매일 청구',
        'billed_every_quarter' => '3개월마다 청구',
        'billed_every_6_months' => '6개월마다 청구',
        'one_time_payment' => '일회성 결제',
        'billed_every' => ':period마다 청구',
        'quarter' => '분기',
        '6_months' => '6개월',
        'year' => '년',
    ],

    'banner' => [
        'copied' => '복사됨!',
    ],
];
