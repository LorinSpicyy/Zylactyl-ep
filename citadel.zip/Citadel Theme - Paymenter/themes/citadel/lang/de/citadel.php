<?php

return [

    'auth' => [
        'login' => [
            'subtitle' => 'Willkommen zurück! Bitte melden Sie sich an, um fortzufahren.',
            'remember_me' => 'Angemeldet bleiben',
        ],
        'register' => [
            'subtitle' => 'Erstellen Sie Ihr Konto, um loszulegen.',
            'button' => 'Registrieren',
            'next' => 'Weiter',
            'back' => 'Zurück',
            'confirm_password' => 'Passwort Bestätigen',
            'step1_title' => 'Kontodaten',
            'step2_title' => 'Zusätzliche Informationen',
        ],
        'two_factor' => [
            'subtitle' => 'Geben Sie den Code aus Ihrer Authentifizierungs-App ein.',
        ],
        'password_reset_request' => [
            'subtitle' => 'Geben Sie Ihre E-Mail-Adresse ein, um einen Link zum Zurücksetzen des Passworts zu erhalten.',
        ],
        'password_reset' => [
            'subtitle' => 'Geben Sie Ihr neues Passwort unten ein.',
        ],
        'back_to_login' => 'Zurück zum Login',
    ],


    'account' => [

        'navigation' => [
            'account_settings' => 'Kontoeinstellungen',
            'payment_methods' => 'Zahlungsmethoden',
            'notifications' => 'Benachrichtigungen',
        ],


        'credits' => [
            'subtitle' => 'Sehen Sie Ihr verfügbares Guthaben ein und fügen Sie Guthaben zu Ihrem Konto für zukünftige Einkäufe hinzu.',
            'add_funds_title' => 'Guthaben zu Ihrem Kontostand hinzufügen',
        ],


        'personal_details' => [
            'subtitle' => 'Aktualisieren Sie die Profilinformationen und E-Mail-Adresse Ihres Kontos. Verwalten Sie Ihre persönlichen Daten und halten Sie Ihre Informationen auf dem neuesten Stand.',
            'section_title' => 'Persönliche Informationen',
            'section_description' => 'Grundlegende Informationen über Ihr Konto',
            'billing_title' => 'Rechnungsinformationen',
            'billing_description' => 'Adress- und Firmeninformationen für Rechnungen',
        ],


        'avatar' => [
            'section_title' => 'Profilbild',
            'section_description' => 'Laden Sie ein benutzerdefiniertes Profilbild hoch. Es wird in der Navigationsleiste, dem Dashboard, Support-Tickets und überall dort angezeigt, wo Ihr Avatar erscheint.',
            'choose' => 'Bild auswählen',
            'change' => 'Bild ändern',
            'save' => 'Bild speichern',
            'remove' => 'Entfernen',
            'hint' => 'JPG, PNG oder WEBP. Maximal 2 MB.',
            'updated' => 'Profilbild erfolgreich aktualisiert.',
            'removed' => 'Profilbild entfernt.',
        ],

        'notifications_page' => [
            'subtitle' => 'Verwalten Sie Ihre Benachrichtigungseinstellungen und konfigurieren Sie, wie Sie Updates erhalten. Wählen Sie zwischen E-Mail, In-App-Benachrichtigungen oder beidem.',
            'preferences_title' => 'Benachrichtigungseinstellungen',
            'preferences_description' => 'Wählen Sie, wie Sie Benachrichtigungen für verschiedene Ereignisse erhalten möchten',
            'saving' => 'Wird gespeichert...',
        ],


        'payment_methods_page' => [
            'setting_up' => 'Wird eingerichtet...',
            'confirm_cancel' => 'Sind Sie sicher?',
            'method_singular' => 'Methode',
            'method_plural' => 'Methoden',
            'no_transactions_title' => 'Noch keine Transaktionen',
            'no_transactions_description' => 'Ihre Zahlungstransaktionen werden hier angezeigt',
        ],


        'security_page' => [
            'subtitle' => 'Verwalten Sie Ihre Kontosicherheitseinstellungen, aktive Sitzungen und Zwei-Faktor-Authentifizierung.',
            'sessions_description' => 'Verwalten Sie Ihre aktiven Sitzungen auf verschiedenen Geräten',
            'password_description' => 'Aktualisieren Sie Ihr Passwort, um Ihr Konto sicher zu halten',
            'two_factor_description' => 'Fügen Sie eine zusätzliche Sicherheitsebene zu Ihrem Konto hinzu',
        ],
    ],


    'navigation' => [

        'footer' => [
            'company_heading' => 'Unternehmen',
            'services' => 'Dienstleistungen',
            'contact_us' => 'Kontaktieren Sie uns',
            'legal_heading' => 'Rechtliches',
            'terms_of_service' => 'Nutzungsbedingungen',
            'privacy_policy' => 'Datenschutzrichtlinie',
            'powered_by' => 'Unterstützt von',
        ],


        'navbar' => [
            'home' => 'Startseite',
            'view_cart' => 'Warenkorb anzeigen',
            'dashboard' => 'Dashboard',
            'store' => 'Shop',
            'support' => 'Support',
            'tickets' => 'Tickets',
            'admin' => 'Admin',
            'account' => 'Benutzerkonto',
            'security' => 'Sicherheit',
            'credits' => 'Guthaben',
            'personal_details' => 'Persönliche Informationen',
            'navigation_heading' => 'Navigation',
        ],


        'sidebar' => [
            'dashboard' => 'Dashboard',
            'services' => 'Dienstleistungen',
            'billing' => 'Abrechnung',
            'invoices' => 'Rechnungen',
            'credits' => 'Guthaben',
            'store' => 'Shop',
            'support' => 'Support',
            'my_tickets' => 'Meine Tickets',
            'create_ticket' => 'Ticket erstellen',
            'knowledge_base' => 'Wissensdatenbank',
            'blog' => 'Blog',
            'status' => 'Status',
            'account' => 'Benutzerkonto',
            'profile' => 'Profil',
            'security' => 'Sicherheit',
        ],
    ],


    'dashboard' => [
        'title' => 'Dashboard',
        'dashboard_description' => 'Willkommen zu Ihrem Dashboard. Hier können Sie Ihre Dienste, Rechnungen und Tickets auf einen Blick sehen.',
        'balance' => 'Guthaben',
        'active_services' => 'Aktive Dienste',
        'unpaid_invoices' => 'Offene Rechnungen',
        'open_tickets' => 'Offene Tickets',
        'services_widget' => 'Dienstleistungen',
        'invoices_widget' => 'Rechnungen',
        'tickets_widget' => 'Tickets',
        'discord_title' => 'Tritt Discord bei',
        'discord_subtitle' => 'Verbinden, Engagieren und Support erhalten',
    ],


    'cart' => [
        'empty_cart_description' => 'Ihr Warenkorb ist derzeit leer. Durchsuchen Sie unsere Produkte und fügen Sie Artikel hinzu, um zu beginnen.',
        'page_title' => 'Überprüfen & Zur Kasse',
        'error_title' => 'Beim Übermitteln Ihrer Daten ist ein Problem aufgetreten.',
        'info_title' => 'Information',
        'warning_title' => 'Warnung',
        'tos_error_title' => 'Akzeptierung der Nutzungsbedingungen erforderlich',
        'auth_required_title' => 'Authentifizierung erforderlich, um den Checkout abzuschließen.',
        'auth_required_login' => 'Bitte melden Sie sich bei Ihrem bestehenden Konto an oder erstellen Sie ein neues Konto, um fortzufahren',
        'auth_required_fields' => 'Sowohl E-Mail- als auch Passwortfelder sind erforderlich',
        'products_heading' => 'Produkte',
        'promo_code_heading' => 'Aktionscode anwenden',
        'promo_code_error_title' => 'Aktionscode-Fehler',
        'promo_code_applied_title' => 'Aktionscode angewendet!',
        'payment_method_heading' => 'Wählen Sie Ihre Zahlungsmethode',
        'payment_method_error_title' => 'Zahlungsmethoden-Fehler',
        'payment_failed_title' => 'Zahlung fehlgeschlagen',
        'account_options_heading' => 'Kontooptionen',
        'order_summary_heading' => 'Bestellübersicht',
        'total_due_today' => 'Heute fälliger Gesamtbetrag',
        'discount' => 'Rabatt',
        'checkout_error_title' => 'Checkout-Fehler',
        'checkout_failed_title' => 'Checkout fehlgeschlagen',
    ],


    'invoices' => [

        'index' => [
            'title' => 'Meine Rechnungen',
            'subtitle' => 'Sehen und verwalten Sie alle Ihre Rechnungen, verfolgen Sie den Zahlungsstatus und laden Sie Quittungen von diesem zentralen Dashboard herunter.',
            'quick_actions' => 'Schnellaktionen',
            'order_new_service' => 'Neuen Dienst bestellen',
            'contact_support' => 'Support kontaktieren',
            'invoices_heading' => 'Rechnungen',
            'all_invoices' => 'Alle Rechnungen',
            'paid' => 'Bezahlt',
            'pending' => 'Ausstehend',
            'cancelled' => 'Storniert',
            'newest' => 'Neueste',
            'oldest' => 'Älteste',
            'invoice_singular' => 'Rechnung',
            'invoice_plural' => 'Rechnungen',
            'invoice_column' => 'Rechnung',
            'items_column' => 'Artikel',
            'date_column' => 'Datum',
            'total_column' => 'Gesamt',
            'status_column' => 'Status',
            'filtering' => 'Rechnungen werden gefiltert...',
            'no_invoices_title' => 'Keine Rechnungen gefunden',
            'no_invoices_description' => 'Sie haben noch keine Rechnungen.',
            'per_page' => 'Pro Seite',
            'previous' => 'Zurück',
            'next' => 'Weiter',
        ],


        'show' => [
            'title' => 'Rechnung anzeigen',
            'subtitle' => 'Überprüfen Sie Ihre Rechnungsdetails, Zahlungsstatus und laden Sie Ihre Quittung herunter.',
            'confirm_exit' => 'Sind Sie sicher?',
            'bill_from' => 'Rechnung von',
            'invoice_number' => 'Rechnung #:',
            'invoice_date' => 'Rechnungsdatum:',
            'due_date' => 'Fälligkeitsdatum:',
            'bill_to' => 'Rechnung an:',
            'item' => 'Artikel',
            'qty' => 'Anz.',
            'price' => 'Preis',
            'amount' => 'Betrag',
            'subtotal' => 'Zwischensumme:',
            'total' => 'Gesamt:',
            'thank_you_title' => 'Vielen Dank für Ihr Geschäft',
            'thank_you_message' => 'Wir schätzen Ihr Vertrauen in uns wirklich. Wenn Sie Fragen zu dieser Rechnung haben, wenden Sie sich gerne an unser Support-Team.',
            'download_invoice' => 'Rechnung herunterladen',
            'downloading' => 'Wird heruntergeladen...',
            'amount_due' => 'Fälliger Betrag',
            'pay_with' => 'Bezahlen mit',
            'account_credit' => 'Kontoguthaben',
            'available_credit' => 'Verfügbar:',
            'use_different_method' => 'Eine andere Zahlungsmethode verwenden',
            'hide_other_methods' => 'Andere Zahlungsmethoden ausblenden',
            'pay_invoice' => 'Rechnung bezahlen',
            'processing_payment' => 'Zahlung wird verarbeitet...',
        ],


        'widget' => [
            'items_label' => 'Artikel:',
            'view_button' => 'Anzeigen',
            'no_invoices_title' => 'Keine Rechnungen gefunden',
            'no_invoices_description' => 'Sie haben noch keine Rechnungen.',
        ],
    ],


    'products' => [

        'index' => [
            'categories_heading' => 'Kategorien',
            'starting_at' => 'Ab',
            'per' => 'pro',
            'per_quarter' => 'pro Quartal',
            'per_6_months' => 'pro 6 Monate',
            'per_year' => 'pro Jahr',
            'one_time' => 'einmalig',
            'order_now' => 'Jetzt bestellen',
            'view_all' => 'Alle anzeigen',
        ],


        'show' => [
            'title' => 'Produktzusammenfassung',
            'out_of_stock' => 'Nicht auf Lager',
            'in_stock' => 'Auf Lager',
            'add_to_cart' => 'Zum Warenkorb hinzufügen',
        ],


        'checkout' => [
            'title' => 'Konfigurieren',
            'choose_billing_cycle' => 'Abrechnungszeitraum wählen',
            'order_summary' => 'Bestellübersicht',
            'setup_fee' => 'Einrichtungsgebühr',
            'total_due_today' => 'Heute fälliger Gesamtbetrag',
            'then' => 'dann',
            'add_to_cart' => 'Zum Warenkorb hinzufügen',
            'adding' => 'Wird hinzugefügt...',
            'required_field' => '*',
            'per' => 'pro',
            'per_quarter' => 'pro Quartal',
            'per_6_months' => 'pro 6 Monate',
            'per_year' => 'pro Jahr',
            'one_time' => 'einmalig',
            'save' => 'Sparen',
            'free' => 'Kostenlos',
        ],
    ],


    'services' => [

        'quick_actions' => 'Schnellaktionen',
        'order_new_service' => 'Neuen Dienst bestellen',
        'contact_support' => 'Support kontaktieren',
        

        'index' => [
            'title' => 'Meine Dienste',
            'subtitle' => 'Verwalten und überwachen Sie alle Ihre aktiven Dienste, Upgrades und Abrechnungszeiträume von diesem zentralen Dashboard aus.',
            'services_heading' => 'Dienstleistungen',
            'all_services' => 'Alle Dienste',
            'active' => 'Aktiv',
            'suspended' => 'Gesperrt',
            'pending' => 'Ausstehend',
            'cancelled' => 'Storniert',
            'newest' => 'Neueste',
            'oldest' => 'Älteste',
            'expiring_soon' => 'Läuft bald ab',
            'service_singular' => 'Dienst',
            'service_plural' => 'Dienste',
            'service_column' => 'Dienst',
            'product_column' => 'Produkt',
            'expires_column' => 'Läuft ab',
            'status_column' => 'Status',
            'filtering' => 'Dienste werden gefiltert...',
            'no_services_title' => 'Keine Dienste gefunden',
            'no_services_description' => 'Sie haben noch keine Dienste.',
            'per_page' => 'Pro Seite',
            'previous' => 'Zurück',
            'next' => 'Weiter',
        ],


        'show' => [
            'title' => 'Dienst verwalten',
            'subtitle' => 'Dienstdetails, Abrechnungsinformationen und Verwaltungsoptionen für Ihren {product}-Dienst.',
            'view_all_services' => 'Alle Dienste anzeigen',
            'unpaid_invoice_title' => 'Unbezahlte Rechnungswarnung',
            'unpaid_invoice_message' => 'Sie haben eine ausstehende Rechnung für diesen Dienst, die bezahlt werden muss, um Ihren Dienst aktiv zu halten.',
            'pay_now' => 'Jetzt bezahlen',
            'name_label' => 'Name',
            'billing_cycle_label' => 'Abrechnungszeitraum',
            'status_label' => 'Status',
            'price_label' => 'Preis',
            'expires_at_label' => 'Läuft ab am',
            'total_price_per_term' => 'Gesamtpreis pro Zeitraum',
            'expiry_date_label' => 'Ablaufdatum',
            'total_due_today' => 'Heute fälliger Gesamtbetrag',
            'service_invoices' => 'Dienstrechnungen',
            'view_all_invoices' => 'Alle Rechnungen anzeigen',
            'no_invoices_title' => 'Noch keine Rechnungen',
            'no_invoices_description' => 'Dienstrechnungen werden hier angezeigt',
            'service_actions' => 'Dienstaktionen',
            'service_management' => 'Dienstverwaltung',
            'renewal_description' => 'Wählen Sie den Verlängerungszeitraum für Ihren Dienst:',
        ],


        'upgrade' => [
            'title' => 'Dienst upgraden',
            'current_product' => 'Aktuelles Produkt',
            'new_product' => 'Neues Produkt',
            'upgrade_summary' => 'Upgrade-Zusammenfassung',
            'current_product_label' => 'Aktuelles Produkt:',
            'new_product_label' => 'Neues Produkt:',
            'upgrade_cost' => 'Upgrade-Kosten:',
            'next_step' => 'Nächster Schritt',
            'upgrade_button' => 'Upgraden',
            'choose_product_subtitle' => 'Wählen Sie das Produkt aus, auf das Sie upgraden möchten.',
            'choose_config_subtitle' => 'Konfigurieren Sie Ihre Upgrade-Optionen.',
        ],


        'widget' => [
            'products_label' => 'Produkt(e):',
            'manage_button' => 'Verwalten',
            'no_services_title' => 'Keine Dienste gefunden',
            'no_services_description' => 'Sie haben noch keine Dienste.',
        ],


        'billing_agreement' => [
            'expires' => 'Läuft ab:',
        ],
    ],


    'tickets' => [

        'quick_actions' => 'Schnellaktionen',
        'view_all_tickets' => 'Alle Tickets anzeigen',
        'knowledgebase' => 'Wissensdatenbank',
        'blog' => 'Blog',
        'status' => 'Status',
        

        'index' => [
            'title' => 'Meine Tickets',
            'subtitle' => 'Sehen und verwalten Sie Ihre Support-Tickets. Erhalten Sie Hilfe von unserem Support-Team für alle Fragen oder Probleme, die Sie haben könnten.',
            'create_new_ticket' => 'Neues Ticket erstellen',
            'tickets_heading' => 'Tickets',
            'all_tickets' => 'Alle Tickets',
            'open' => 'Offen',
            'closed' => 'Geschlossen',
            'replied' => 'Beantwortet',
            'newest' => 'Neueste',
            'oldest' => 'Älteste',
            'ticket_singular' => 'Ticket',
            'ticket_plural' => 'Tickets',
            'id_column' => 'ID',
            'subject_column' => 'Betreff',
            'department_column' => 'Abteilung',
            'last_activity_column' => 'Letzte Aktivität',
            'status_column' => 'Status',
            'filtering' => 'Tickets werden gefiltert...',
            'no_tickets_title' => 'Keine Tickets gefunden',
            'no_tickets_description' => 'Sie haben noch keine Support-Tickets.',
            'per_page' => 'Pro Seite',
            'previous' => 'Zurück',
            'next' => 'Weiter',
        ],


        'create' => [
            'title' => 'Neues Ticket erstellen',
            'subtitle' => 'Reichen Sie ein Support-Ticket ein und unser Team wird sich so schnell wie möglich bei Ihnen melden. Bitte geben Sie so viele Details wie möglich an, um uns zu helfen, Sie besser zu unterstützen.',
            'back_to_tickets' => 'Zurück zu Tickets',
            'drag_drop_text' => 'Ziehen Sie Ihre Dateien hierher oder',
            'click_to_upload' => 'Durchsuchen',
        ],


        'show' => [
            'title' => 'Ticket',
            'subtitle' => 'Sehen und verwalten Sie Ihre Support-Ticket-Konversation. Sie können auf Nachrichten antworten und den Status Ihrer Anfrage hier verfolgen.',
            'overview_title' => 'Ticket-Übersicht',
            'discord_title' => 'Tritt Discord bei',
            'discord_subtitle' => 'Verbinden, Engagieren und Support erhalten',
        ],

        'widget' => [
            'view_button' => 'Anzeigen',
            'no_tickets_title' => 'Keine Tickets gefunden',
            'no_tickets_description' => 'Sie haben noch keine Tickets.',
        ],
    ],

    'plans' => [
        'most_popular' => 'BELIEBTESTE',
        'whats_included' => 'Was enthalten ist:',
        'starting_at' => 'ab',
        'billed_every_month' => 'monatlich abgerechnet',
        'billed_every_year' => 'jährlich abgerechnet',
        'billed_every_day' => 'täglich abgerechnet',
        'billed_every_quarter' => 'vierteljährlich abgerechnet',
        'billed_every_6_months' => 'halbjährlich abgerechnet',
        'one_time_payment' => 'Einmalzahlung',
        'billed_every' => 'alle :period abgerechnet',
        'quarter' => 'Quartal',
        '6_months' => '6 Monate',
        'year' => 'Jahr',
    ],

    'banner' => [
        'copied' => 'Kopiert!',
    ],
];
