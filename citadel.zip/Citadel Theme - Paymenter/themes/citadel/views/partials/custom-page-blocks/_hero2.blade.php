@php
    use Illuminate\Support\Facades\Storage;

    $h2MainTitle  = trim((string) ($block['heading'] ?? ''));
    $h2SmallTitle = trim((string) ($block['hero2_small_title'] ?? ''));
    $h2Desc       = trim((string) ($block['subheading'] ?? ''));
    $h2BtnText    = trim((string) ($block['button_text'] ?? ''));
    $h2BtnLink    = trim((string) ($block['button_link'] ?? ''));
    $h2ImgUrl     = ! empty($block['hero2_image']) ? Storage::url($block['hero2_image']) : null;

    $h2ListRaw   = trim((string) ($block['hero2_list'] ?? ''));
    $h2ListItems = $h2ListRaw !== ''
        ? array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $h2ListRaw))))
        : [];

    $h2BgType  = $block['hero2_bg_type'] ?? 'theme';
    $h2BgColor = trim((string) ($block['hero2_bg_color'] ?? ''));

    
    $h2DefaultLink = '#';
    if (isset($category) && $category) {
        try { $h2DefaultLink = route('category.show', ['category' => $category->slug]); } catch (\Throwable $e) {}
    }
    $h2ResolvedLink = $h2BtnLink !== '' ? $h2BtnLink : $h2DefaultLink;
    $h2External     = filter_var($h2ResolvedLink, FILTER_VALIDATE_URL) && ! str_starts_with($h2ResolvedLink, url('/'));

    
    $h2SectionStyle = '';
    $h2LightText    = true;
    if ($h2BgType === 'plain' && $h2BgColor !== '') {
        $h2SectionStyle = 'background-color: ' . $h2BgColor . ';';
        $parts = preg_split('/\s+/', trim(str_replace(',', '', preg_replace('/^hsl\((.+)\)$/i', '$1', $h2BgColor))));
        $h2LightText = isset($parts[2]) ? ((float) rtrim($parts[2], '%') < 60) : true;
    } else {
        
        $h2SectionStyle = 'background-color: hsl(var(--color-primary-h) calc(var(--color-primary-s) * 0.78) calc(var(--color-primary-l) * 0.42)); background-image: radial-gradient(150% 150% at 0% 0%, hsl(var(--color-primary-h) calc(var(--color-primary-s) * 0.78) calc(var(--color-primary-l) * 0.7)) 0%, hsl(var(--color-primary-h) calc(var(--color-primary-s) * 0.78) calc(var(--color-primary-l) * 0.42)) 80%);';
        $h2LightText    = true;
    }
    $h2HasBg = true;

    
    $h2IconShade  = 'hsl(var(--color-primary-h) var(--color-primary-s) calc(var(--color-primary-l) * 1.45))';
    $h2CheckColor = 'hsl(var(--color-primary-h) var(--color-primary-s) calc(var(--color-primary-l) * 0.32))';

    
    $h2cTitle = $h2LightText ? '#ffffff'                  : 'hsl(var(--color-base))';
    $h2cSub   = $h2LightText ? 'rgba(255,255,255,0.92)'   : 'hsl(var(--color-base) / 0.82)';
    $h2cText  = $h2LightText ? 'rgba(255,255,255,0.85)'   : 'hsl(var(--color-base) / 0.72)';
    $h2cBtn   = 'background-image: linear-gradient(135deg, ' . $h2IconShade . ' 0%, hsl(var(--color-primary)) 100%); color: #ffffff;';

    
    $h2IconBg = ($h2BgType === 'plain' && $h2BgColor !== '')
        ? $h2BgColor
        : 'hsl(var(--color-primary-h) calc(var(--color-primary-s) * 0.78) calc(var(--color-primary-l) * 0.42))';
@endphp


<section class="citadel-hero2 relative isolate"
    style="margin-top: calc(-1 * ({{ $heroPad ?? '0px' }} + 2.5rem)); padding-top: {{ $heroPad ?? '0px' }};">
    <div class="absolute inset-0 left-[50%] right-[50%] -ml-[50vw] -mr-[50vw] w-screen -z-10 overflow-hidden" style="{{ $h2SectionStyle }}"></div>
    <div class="w-full mx-auto px-4 sm:px-6 lg:px-8 pt-16 sm:pt-12 pb-10" style="max-width: {{ $heroMaxW }};">
        <div class="grid md:grid-cols-2 gap-8 lg:gap-12 items-stretch">

            
            <div class="text-left flex flex-col justify-center min-w-0 px-6 sm:px-0">
                <style>@media (min-width:768px){.citadel-hero-title{max-width:80%;}.citadel-hero-title::before{content:"";float:right;width:25%;height:1em;}}</style>
                @include('partials.custom-page-blocks._hero-trustpilot', ['tpContext' => 'light'])
                @if ($h2MainTitle)
                    <h1 class="citadel-hero-title leading-tight mb-6" style="font-size: 60px; font-weight: 500; color: {{ $h2cTitle }};">
                        {{ $h2MainTitle }}
                    </h1>
                @endif

                @if ($h2Desc)
                    <p class="leading-relaxed mb-9 max-w-xl" style="font-size: 18px; font-weight: 400; color: {{ $h2cText }};">
                        {{ $h2Desc }}
                    </p>
                @endif

                @if (! empty($h2ListItems))
                    <ul class="space-y-3 mb-9">
                        @foreach ($h2ListItems as $item)
                            <li class="flex items-start gap-2.5">
                                <svg class="w-5 h-5 flex-shrink-0 mt-0.5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12Z" fill="{{ $h2IconShade }}"/>
                                    <path d="M7.5 12L10.5 15L16.5 9" stroke="{{ $h2CheckColor }}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <span style="font-size: 16px; font-weight: 400; color: {{ $h2cText }};">{{ $item }}</span>
                            </li>
                        @endforeach
                    </ul>
                @endif

                @include('partials.custom-page-blocks._hero-buttons', ['btnContext' => 'light', 'btnIconBg' => $h2IconBg, 'btnIconColor' => $h2cTitle])
            </div>

            
            <div class="md:min-h-[18rem] min-w-0 overflow-hidden">
                @if ($h2ImgUrl)
                    <img src="{{ $h2ImgUrl }}" alt="{{ $h2MainTitle }}" draggable="false"
                         class="w-full h-auto md:h-full object-cover object-left select-none pointer-events-none"
                         style="border-radius: var(--citadel-card-radius);" />
                @endif
            </div>

        </div>
    </div>
</section>
