@php
    use Illuminate\Support\Facades\Storage;
    $bmSource = $card['image_source'] ?? 'preset';
    $bmPreset = trim((string) ($card['preset'] ?? ''));
    $bmImage  = $card['image'] ?? null;
@endphp

@if ($bmSource === 'preset' && $bmPreset !== '')
    <div class="rounded-md overflow-hidden mb-3 h-48" style="border-radius: var(--citadel-card-radius);">
        <x-bento-svg :name="$bmPreset" class="w-full h-full" />
    </div>
@elseif ($bmSource === 'custom' && ! empty($bmImage))
    <div class="rounded-md overflow-hidden mb-3" style="border-radius: var(--citadel-card-radius);">
        <img src="{{ Storage::url($bmImage) }}" alt="{{ $card['title'] ?? '' }}" class="w-full h-48 object-cover pointer-events-none" />
    </div>
@endif
