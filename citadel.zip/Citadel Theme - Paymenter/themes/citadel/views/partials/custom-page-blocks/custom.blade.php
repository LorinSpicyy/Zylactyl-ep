@php

    $customHtml = (string) ($block['custom_html'] ?? '');
    $customHook = trim((string) ($block['custom_hook'] ?? ''));

    if ($customHtml !== '' && function_exists('hook')) {
        $customHtml = preg_replace_callback(
            '/\{!!\s*hook\(\s*[\'"]([^\'"]+)[\'"]\s*\)\s*!!\}|\{\{\s*hook\(\s*[\'"]([^\'"]+)[\'"]\s*\)\s*\}\}/',
            function ($matches) {
                $name = ($matches[1] ?? '') !== '' ? $matches[1] : ($matches[2] ?? '');
                if ($name === '') {
                    return '';
                }
                try {
                    return (string) hook($name);
                } catch (\Throwable $e) {
                    return '';
                }
            },
            $customHtml
        );
    }
@endphp

@if ($customHtml !== '' || $customHook !== '')
    <section class="citadel-custom-block w-full">
        @if ($customHtml !== '')
            {!! $customHtml !!}
        @endif

        @if ($customHook !== '' && function_exists('hook'))
            {!! hook($customHook) !!}
        @endif
    </section>
@endif
