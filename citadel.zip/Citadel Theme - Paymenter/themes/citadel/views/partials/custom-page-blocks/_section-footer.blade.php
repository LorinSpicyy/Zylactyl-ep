
@php
    $sfEnabled  = ! empty($block['section_footer_enabled']);
    $sfIconType = $block['section_footer_icon_type'] ?? 'remix';
    $sfIcon     = trim((string) ($block['section_footer_icon'] ?? ''));
    $sfSvg      = trim((string) ($block['section_footer_icon_svg'] ?? ''));
    $sfTitle    = trim((string) ($block['section_footer_title'] ?? ''));
    $sfText     = trim((string) ($block['section_footer_text'] ?? ''));
@endphp

@if ($sfEnabled && ($sfTitle !== '' || $sfText !== ''))
    <div class="max-w-2xl mx-auto mt-8 text-center">
        <div class="flex items-center justify-center gap-2 {{ $sfText !== '' ? 'mb-1.5' : '' }}">
            @if ($sfIconType === 'svg' && $sfSvg !== '')
                <span class="inline-flex items-center justify-center size-5 flex-shrink-0 [&>svg]:w-full [&>svg]:h-full" style="color: hsl(var(--color-primary));">{!! $sfSvg !!}</span>
            @elseif ($sfIconType !== 'svg' && $sfIcon !== '')
                <x-dynamic-component :component="$sfIcon" class="size-5 flex-shrink-0" style="color: hsl(var(--color-primary));" />
            @endif
            @if ($sfTitle !== '')
                <span class="text-base font-medium" style="color: hsl(var(--color-base));">{{ $sfTitle }}</span>
            @endif
        </div>
        @if ($sfText !== '')
            <p class="text-sm leading-relaxed" style="color: hsl(var(--color-base) / 0.65);">{{ $sfText }}</p>
        @endif
    </div>
@endif
