
@php
    $tpOn    = ! empty($block['trustpilot_enabled']);
    $tpStyle = $block['trustpilot_style'] ?? 'two_line';
    $tpText  = trim((string) ($block['trustpilot_text'] ?? ''));
    $tpCtx   = $tpContext ?? 'base';

    $tpWord = $tpCtx === 'light' ? '#ffffff' : 'hsl(var(--color-base))';
    $tpSub  = $tpCtx === 'light' ? 'rgba(255,255,255,0.85)' : 'hsl(var(--color-base) / 0.72)';

    $tpStar = 'M12 .587l3.668 7.431 8.2 1.192-5.934 5.785 1.401 8.169L12 18.896l-7.335 3.868 1.401-8.169L.132 9.21l8.2-1.192z';

    
    $tpBoxesFn = function (float $rating) use ($tpStar): string {
        $html = '';
        for ($i = 1; $i <= 5; $i++) {
            if ($rating >= $i) {
                $bg = '#00b67a';
            } elseif ($rating >= $i - 0.5) {
                $bg = 'linear-gradient(90deg,#00b67a 50%,#dcdce6 50%)';
            } else {
                $bg = '#dcdce6';
            }
            $html .= '<span style="display:inline-flex;align-items:center;justify-content:center;width:0.95rem;height:0.95rem;background:' . $bg . ';">'
                . '<svg viewBox="0 0 24 24" style="width:0.64rem;height:0.64rem;" fill="#fff"><path d="' . $tpStar . '"/></svg></span>';
        }
        return '<span style="display:inline-flex;gap:2px;vertical-align:middle;">' . $html . '</span>';
    };

    
    $tpLogo = '<span style="display:inline-flex;align-items:center;gap:0.22rem;vertical-align:middle;">'
        . '<svg viewBox="0 0 24 24" style="width:1rem;height:1rem;" fill="#00b67a"><path d="' . $tpStar . '"/></svg>'
        . '<span style="font-weight:700;font-size:0.92rem;letter-spacing:-0.02em;color:' . $tpWord . ';">Trustpilot</span>'
        . '</span>';

    
    $tpTextHtml = e($tpText);
    if ($tpStyle === 'one_line' && $tpText !== '') {
        if (preg_match('/(\d+(?:[.,]\d+)?)\s*\/\s*5/u', $tpText, $m) || preg_match('/(\d+(?:[.,]\d+)?)\s*stars?\b/ui', $tpText, $m)) {
            $rating = min(5.0, (float) str_replace(',', '.', $m[1]));
            $pos    = mb_strpos($tpText, $m[0]);
            $tpTextHtml = e(mb_substr($tpText, 0, $pos))
                . '<span style="margin:0 .25rem;">' . $tpBoxesFn($rating) . '</span>'
                . e(mb_substr($tpText, $pos));
        }
    }
@endphp

@if ($tpOn)
    <div class="mb-7" style="font-size:0.9rem;">
        @if ($tpStyle === 'one_line')
            <span style="display:inline-flex;align-items:center;flex-wrap:wrap;gap:0.3rem;color:{{ $tpWord }};font-weight:600;">
                <span>Rated</span>
                @if ($tpText !== '')<span style="display:inline-flex;align-items:center;">{!! $tpTextHtml !!}</span>@endif
                <span>on</span>
                {!! $tpLogo !!}
            </span>
        @else
            {!! $tpLogo !!}
            @if ($tpText !== '')
                <div style="margin-top:0.25rem;color:{{ $tpSub }};font-size:0.9rem;">{{ $tpText }}</div>
            @endif
        @endif
    </div>
@endif
