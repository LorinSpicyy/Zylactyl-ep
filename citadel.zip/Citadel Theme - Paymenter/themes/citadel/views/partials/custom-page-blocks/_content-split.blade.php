@php
    use Illuminate\Support\Facades\Storage;
    use Illuminate\Support\Str;


    $csStyle    = $block['content_style'] ?? 'content2';
    $csTitle    = trim((string) ($block['heading'] ?? ''));
    $csBody     = trim((string) ($block['body'] ?? ''));
    $csOrient   = $block['content_orientation'] ?? 'image_right';
    $csImg      = ! empty($block['content_image']) ? Storage::url($block['content_image']) : null;
    $csImgLeft  = $csOrient === 'image_left';
    $csIconType = $block['content_icon_type'] ?? 'remix';
    $csPoints   = ($csStyle === 'content3') ? ($block['content_points'] ?? []) : [];

    $csHasBg    = $hasBg ?? false;
    $csText     = $textColor ?? null;                                   
    $csTitleCol = $csHasBg ? $csText : 'hsl(var(--color-base))';
    $csIconCol  = $csHasBg ? $csText : 'hsl(var(--color-primary))';
    $csPtCol    = $csHasBg ? $csText : 'hsl(var(--color-base) / 0.7)';

    
    $csWidthRaw = trim((string) ($block['content_max_width'] ?? ''));
    $csMaxW = preg_match('/^\d+(\.\d+)?(px|rem|em|vw|%)$/', $csWidthRaw) ? $csWidthRaw : '72rem';

    
    $csFlush = ! empty($block['content_image_flush']);
    $csFlushSide = $csImgLeft ? 'margin-left' : 'margin-right';
    $csGridClass = $csFlush ? ($csImgLeft ? 'cs-flush-imgleft' : 'cs-flush-imgright') : '';
@endphp

@if ($csTitle || $csBody || $csImg || ! empty($csPoints))
<div class="relative">
    @if ($csHasBg)
        <div class="absolute inset-0 left-[50%] right-[50%] -ml-[50vw] -mr-[50vw] w-screen -z-10 overflow-hidden" style="background-color: {{ $panelBg }};"></div>
    @endif
<section class="relative overflow-x-clip py-12 md:py-16">
    <style>
        .citadel-cs-pt > *{margin:0;}
        .citadel-cs-pt strong{font-weight:600;color:var(--cs-strong, hsl(var(--color-base)));}
        .citadel-cs-ico svg{width:1.25rem;height:1.25rem;display:block;}
        /* Flushed image = narrower image track so the text gets the freed space. */
        @media (min-width:768px){
            .citadel-cs-grid.cs-flush-imgright{grid-template-columns:3fr 2fr;}
            .citadel-cs-grid.cs-flush-imgleft{grid-template-columns:2fr 3fr;}
        }
    </style>
    <div class="w-full mx-auto {{ $csHasBg ? 'px-4 sm:px-6 md:px-8 lg:px-10' : '' }}"
         style="max-width: {{ $csMaxW }};">
        <div class="citadel-cs-grid grid md:grid-cols-2 gap-10 lg:gap-16 items-center {{ $csGridClass }}">

            {{-- TEXT --}}
            <div class="{{ $csImgLeft ? 'md:order-2' : 'md:order-1' }} min-w-0" style="--cs-strong: {{ $csTitleCol }};">
                @if ($csTitle)
                    <h2 class="text-3xl sm:text-4xl font-bold leading-tight tracking-tight mb-5" style="color: {{ $csTitleCol }};">{{ $csTitle }}</h2>
                @endif
                @if ($csBody)
                    <div class="prose max-w-none {{ $csHasBg ? '' : 'dark:prose-invert' }}"
                         @if ($csHasBg) style="color: {{ $csText }}; --tw-prose-body: {{ $csText }}; --tw-prose-headings: {{ $csText }}; --tw-prose-bold: {{ $csText }}; --tw-prose-links: {{ $csText }}; --tw-prose-bullets: {{ $csText }}; --tw-prose-quotes: {{ $csText }}; --tw-prose-counters: {{ $csText }};" @endif>
                        {!! Str::markdown($csBody) !!}
                    </div>
                @endif
                @if (! empty($csPoints))
                    <ul role="list" class="mt-8 space-y-4">
                        @foreach ($csPoints as $pt)
                            @php
                                $ptText  = trim((string) ($pt['text'] ?? ''));
                                $ptRemix = trim((string) ($pt['icon_remix'] ?? ''));
                                $ptSvg   = trim((string) ($pt['icon_svg'] ?? ''));
                            @endphp
                            @if ($ptText !== '')
                                <li class="flex gap-3">
                                    <span class="citadel-cs-ico shrink-0 mt-1 inline-flex" style="color: {{ $csIconCol }};">
                                        @if ($csIconType === 'svg' && $ptSvg !== '')
                                            {!! $ptSvg !!}
                                        @elseif ($csIconType === 'remix' && $ptRemix !== '')
                                            <x-dynamic-component :component="$ptRemix" class="size-5" />
                                        @else
                                            <x-ri-checkbox-circle-line class="size-5" />
                                        @endif
                                    </span>
                                    <div class="citadel-cs-pt text-base leading-relaxed" style="color: {{ $csPtCol }};">{!! $ptText !!}</div>
                                </li>
                            @endif
                        @endforeach
                    </ul>
                @endif
            </div>

            
            @if ($csImg)
                <div class="{{ $csImgLeft ? 'md:order-1' : 'md:order-2' }} w-full"
                     @if ($csFlush) style="{{ $csFlushSide }}: calc(50% - 50vw);" @endif>
                    <img src="{{ $csImg }}" alt="{{ $csTitle }}" draggable="false"
                         class="w-full h-auto select-none pointer-events-none" style="border-radius: var(--citadel-card-radius); object-fit: contain; object-position: center;{{ $csFlush ? '' : ' max-height: 26rem;' }}" />
                </div>
            @endif

        </div>
    </div>
</section>
</div>
@endif
