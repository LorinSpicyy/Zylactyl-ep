@php
    use Illuminate\Support\Facades\Storage;

    
    $h3MainTitle  = trim((string) ($block['heading'] ?? ''));
    $h3SmallTitle = trim((string) ($block['hero2_small_title'] ?? ''));
    $h3Desc       = trim((string) ($block['subheading'] ?? ''));
    $h3BtnText    = trim((string) ($block['button_text'] ?? ''));
    $h3BtnLink    = trim((string) ($block['button_link'] ?? ''));
    $h3ImgUrl     = ! empty($block['hero2_image']) ? Storage::url($block['hero2_image']) : null;

    $h3ListRaw   = trim((string) ($block['hero2_list'] ?? ''));
    $h3ListItems = $h3ListRaw !== ''
        ? array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $h3ListRaw))))
        : [];

    $h3BgType  = $block['hero2_bg_type'] ?? 'primary';
    $h3BgColor = trim((string) ($block['hero2_bg_color'] ?? ''));

    
    $h3DefaultLink = '#';
    if (isset($category) && $category) {
        try { $h3DefaultLink = route('category.show', ['category' => $category->slug]); } catch (\Throwable $e) {}
    }
    $h3ResolvedLink = $h3BtnLink !== '' ? $h3BtnLink : $h3DefaultLink;
    $h3External     = filter_var($h3ResolvedLink, FILTER_VALIDATE_URL) && ! str_starts_with($h3ResolvedLink, url('/'));

    
    if ($h3BgType === 'plain' && $h3BgColor !== '') {
        $h3PanelBg = 'background-color: ' . $h3BgColor . ';';
    } else {
        $h3PanelBg = 'background-color: hsl(var(--color-primary-h) calc(var(--color-primary-s) * 0.78) calc(var(--color-primary-l) * 0.42)); background-image: radial-gradient(150% 150% at 0% 0%, hsl(var(--color-primary-h) calc(var(--color-primary-s) * 0.78) calc(var(--color-primary-l) * 0.7)) 0%, hsl(var(--color-primary-h) calc(var(--color-primary-s) * 0.78) calc(var(--color-primary-l) * 0.42)) 80%);';
    }

    
    $h3IconShade = 'hsl(var(--color-primary-h) var(--color-primary-s) calc(var(--color-primary-l) * 1.45))';

    
    $h3cTitle = 'hsl(var(--color-base))';
    $h3cSub   = 'hsl(var(--color-base) / 0.82)';
    $h3cText  = 'hsl(var(--color-base) / 0.7)';
    $h3cBtn   = 'background-image: linear-gradient(135deg, hsl(var(--color-primary)) 0%, ' . $h3IconShade . ' 100%); color: #ffffff;';

    
    $h3IconBg = ($h3BgType === 'plain' && $h3BgColor !== '')
        ? $h3BgColor
        : 'hsl(var(--color-primary-h) calc(var(--color-primary-s) * 0.78) calc(var(--color-primary-l) * 0.42))';

    
    $h3TextPadLeft = '1.5rem';
@endphp


<section class="citadel-hero3 relative isolate flex flex-col md:flex-row md:min-h-[42rem]"
    style="margin-top: calc(-1 * ({{ $heroPad ?? '0px' }} + 2.5rem)); padding-top: {{ $heroPad ?? '0px' }};@if (($heroWidth ?? '') !== '') max-width: {{ $heroWidth }}; margin-left: auto; margin-right: auto;@endif">


    <div class="hidden md:block absolute inset-y-0 -z-10 overflow-hidden" style="{{ $h3PanelBg }} left: 52%; right: {{ ($heroWidth ?? '') !== '' ? '0' : 'calc(50% - 50vw)' }};" aria-hidden="true"></div>


    <div class="relative flex flex-col justify-center pt-16 sm:pt-12 pb-12 md:w-[52%] md:shrink-0"
         style="padding-left: {{ $h3TextPadLeft }}; padding-right: 1.5rem;">
        <style>@media (min-width:768px){.citadel-hero-title{max-width:80%;}.citadel-hero-title::before{content:"";float:right;width:25%;height:1em;}}</style>
        @include('partials.custom-page-blocks._hero-trustpilot', ['tpContext' => 'base'])
        @if ($h3MainTitle)
            <h1 class="citadel-hero-title text-left leading-tight mb-6" style="font-size: 60px; font-weight: 500; color: {{ $h3cTitle }};">
                {{ $h3MainTitle }}
            </h1>
        @endif

        @if ($h3Desc)
            <p class="text-left leading-relaxed mb-9 max-w-xl" style="font-size: 18px; font-weight: 400; color: {{ $h3cText }};">
                {{ $h3Desc }}
            </p>
        @endif

        @if (! empty($h3ListItems))
            <ul class="space-y-3 mb-9">
                @foreach ($h3ListItems as $item)
                    <li class="flex items-start gap-2.5">
                        <svg class="w-5 h-5 flex-shrink-0 mt-0.5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12Z" fill="hsl(var(--color-primary))"/>
                            <path d="M7.5 12L10.5 15L16.5 9" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        <span style="font-size: 16px; font-weight: 400; color: {{ $h3cText }};">{{ $item }}</span>
                    </li>
                @endforeach
            </ul>
        @endif

        @include('partials.custom-page-blocks._hero-buttons', ['btnContext' => 'base', 'btnIconBg' => $h3IconBg, 'btnIconColor' => $h3cTitle])
    </div>


    <div class="relative md:flex-1 flex items-center justify-center md:justify-start px-6 pb-12 md:py-8 md:pl-0 md:pr-8">
        @if ($h3ImgUrl)
            <img src="{{ $h3ImgUrl }}" alt="{{ $h3MainTitle }}" draggable="false"
                 class="relative z-10 w-full h-auto md:w-auto md:h-full md:max-h-[40rem] md:max-w-full object-contain select-none pointer-events-none" />
        @endif
    </div>
</section>
