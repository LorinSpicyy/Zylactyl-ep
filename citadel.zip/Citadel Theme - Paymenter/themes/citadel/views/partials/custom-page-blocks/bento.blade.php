@php
    use Illuminate\Support\Facades\Storage;

    
    $bentoTitle = trim((string) ($block['heading'] ?? ''));
    $bentoDesc  = trim((string) ($block['description'] ?? ''));
    $bentoCards = $block['bento_cards'] ?? [];
    $bentoCards = is_array($bentoCards) ? array_values($bentoCards) : [];

    $bentoTop    = array_slice($bentoCards, 0, 2);
    $bentoBottom = array_slice($bentoCards, 2);
@endphp

@if (! empty($bentoCards))
<section class="py-16 md:py-24">
    <div class="w-full">

        @if ($bentoTitle || $bentoDesc)
            <div class="text-center mb-10">
                @if ($bentoTitle)
                    <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4" style="color: hsl(var(--color-base));">{{ $bentoTitle }}</h2>
                @endif
                @if ($bentoDesc)
                    <p class="text-sm sm:text-base max-w-2xl mx-auto leading-relaxed" style="color: hsl(var(--color-base) / 0.6);">{{ $bentoDesc }}</p>
                @endif
            </div>
        @endif

        <div class="flex flex-col gap-4">

            @if (! empty($bentoTop))
                <div class="grid grid-cols-1 md:grid-cols-5 gap-4">
                    @foreach ($bentoTop as $i => $card)
                        <div class="{{ $i === 0 ? 'md:col-span-2' : 'md:col-span-3' }} bg-background-secondary border border-neutral rounded-lg p-4 flex flex-col overflow-hidden" style="border-radius: var(--citadel-card-radius);">
                            @include('partials.custom-page-blocks._bento-media', ['card' => $card])
                            <h3 class="text-base font-semibold mb-1" style="color: hsl(var(--color-base));">{{ $card['title'] ?? '' }}</h3>
                            @if (! empty($card['description']))
                                <p class="text-sm leading-relaxed" style="color: hsl(var(--color-base) / 0.6);">{{ $card['description'] }}</p>
                            @endif
                        </div>
                    @endforeach
                </div>
            @endif

            @if (! empty($bentoBottom))
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    @foreach ($bentoBottom as $card)
                        <div class="bg-background-secondary border border-neutral rounded-lg p-4 flex flex-col overflow-hidden" style="border-radius: var(--citadel-card-radius);">
                            @include('partials.custom-page-blocks._bento-media', ['card' => $card])
                            <h3 class="text-base font-semibold mb-1" style="color: hsl(var(--color-base));">{{ $card['title'] ?? '' }}</h3>
                            @if (! empty($card['description']))
                                <p class="text-sm leading-relaxed" style="color: hsl(var(--color-base) / 0.6);">{{ $card['description'] }}</p>
                            @endif
                        </div>
                    @endforeach
                </div>
            @endif

        </div>
    </div>
</section>
@endif
