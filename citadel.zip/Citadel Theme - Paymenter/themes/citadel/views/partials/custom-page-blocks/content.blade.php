@php
    use Illuminate\Support\Str;

    
    $contentStyle = $block['content_style'] ?? 'content1';

    $heading     = trim((string) ($block['heading'] ?? ''));
    $description = trim((string) ($block['description'] ?? ''));
    $body        = trim((string) ($block['body'] ?? ''));

    
    $bgType  = $block['content_bg_type'] ?? 'normal';
    $bgColor = trim((string) ($block['content_bg_color'] ?? ''));

    $panelBg   = null;   
    $textColor = null;   
    if ($bgType === 'primary') {
        $panelBg   = 'hsl(var(--color-primary))';
        $textColor = '#ffffff';
    } elseif ($bgType === 'custom' && $bgColor !== '') {
        $panelBg = $bgColor;
        
        if (preg_match('/hsl\(\s*([\d.]+)\s*,\s*([\d.]+)%?\s*,\s*([\d.]+)%?\s*\)/i', $bgColor, $m)) {
            $h = (float) $m[1]; $s = ((float) $m[2]) / 100; $l = ((float) $m[3]) / 100;
            $c = (1 - abs(2 * $l - 1)) * $s;
            $x = $c * (1 - abs(fmod($h / 60, 2) - 1));
            $mm = $l - $c / 2;
            [$r, $g, $b] = match (true) {
                $h < 60  => [$c, $x, 0],
                $h < 120 => [$x, $c, 0],
                $h < 180 => [0, $c, $x],
                $h < 240 => [0, $x, $c],
                $h < 300 => [$x, 0, $c],
                default  => [$c, 0, $x],
            };
            $lum = 0.299 * ($r + $mm) + 0.587 * ($g + $mm) + 0.114 * ($b + $mm);
            $textColor = $lum > 0.6 ? '#0f172a' : '#ffffff';
        } else {
            $textColor = 'hsl(var(--color-base))';
        }
    }
    $hasBg     = $panelBg !== null;
    $headColor = $textColor ?: 'hsl(var(--color-base))';
    $descColor = $textColor ?: 'hsl(var(--color-base) / 0.6)';
@endphp

@if ($contentStyle === 'm2reviews')
    @include('partials.custom-page-blocks.reviews', ['block' => $block])
@elseif (in_array($contentStyle, ['content2', 'content3'], true))
    @include('partials.custom-page-blocks._content-split')
@elseif ($heading || $description || $body)

<section class="relative py-12 md:py-16">
    @if ($hasBg)
        <div class="absolute inset-0 left-[50%] right-[50%] -ml-[50vw] -mr-[50vw] w-screen -z-10 overflow-hidden" style="background-color: {{ $panelBg }};"></div>
    @endif
    <div class="max-w-3xl mx-auto {{ $hasBg ? 'px-4 sm:px-6 lg:px-8' : '' }}">
        @if ($heading)
            <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4 text-center" style="color: {{ $headColor }};">
                {{ $heading }}
            </h2>
        @endif

        @if ($description)
            <p class="text-sm sm:text-base max-w-2xl mx-auto leading-relaxed mb-6 text-center" style="color: {{ $descColor }};">
                {{ $description }}
            </p>
        @endif

        @if ($body)
            <div class="prose max-w-none {{ $hasBg ? '' : 'dark:prose-invert' }}"
                 @if ($hasBg) style="color: {{ $textColor }}; --tw-prose-body: {{ $textColor }}; --tw-prose-headings: {{ $textColor }}; --tw-prose-bold: {{ $textColor }}; --tw-prose-links: {{ $textColor }}; --tw-prose-bullets: {{ $textColor }}; --tw-prose-quotes: {{ $textColor }}; --tw-prose-counters: {{ $textColor }};" @endif>
                {!! Str::markdown($body) !!}
            </div>
        @endif
    </div>
</section>
@endif
