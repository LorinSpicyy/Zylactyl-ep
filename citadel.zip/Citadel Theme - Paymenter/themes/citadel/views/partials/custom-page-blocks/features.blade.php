@php
    
    $featureStyle = $block['feature_style'] ?? 'feature1';
    $heading      = $block['heading'] ?? '';
    $description  = $block['description'] ?? '';
    $iconBg       = array_key_exists('icon_bg', $block) ? (bool) $block['icon_bg'] : true;
    $items        = $block['items'] ?? [];
@endphp

@if ($featureStyle === 'm2features')
    @include('partials.custom-page-blocks._m2features', ['block' => $block])
@elseif ($featureStyle === 'm2bento')
    @include('partials.custom-page-blocks.bento', ['block' => $block])
@elseif ($featureStyle === 'feature2')
    @include('partials.custom-page-blocks._feature2')
@elseif ($featureStyle === 'feature3')
    @include('partials.custom-page-blocks._feature3')
@elseif (! empty($items))
<section class="py-16 md:py-24">
    <div class="w-full">
        @if ($heading || $description)
            <div class="text-center mb-12">
                @if ($heading)
                    <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4" style="color: hsl(var(--color-base));">
                        {{ $heading }}
                    </h2>
                @endif
                @if ($description)
                    <p class="text-sm sm:text-base max-w-2xl mx-auto leading-relaxed" style="color: hsl(var(--color-base) / 0.6);">
                        {{ $description }}
                    </p>
                @endif
            </div>
        @endif

        <div class="max-w-7xl mx-auto">
            <div class="flex flex-wrap justify-center gap-6">
                @foreach ($items as $item)
                    @php
                        $title       = $item['title'] ?? '';
                        $desc        = $item['description'] ?? '';
                        $iconType    = $item['icon_type'] ?? 'citadel';
                        $iconCitadel = $item['icon_citadel'] ?? '';
                        $iconRemix   = $item['icon_remix'] ?? '';
                    @endphp
                    @if ($title)
                        <div class="w-full sm:w-[calc(50%-0.75rem)] xl:w-[calc(25%-1.125rem)] p-6 rounded-xl text-center"
                             style="border-radius: var(--citadel-card-radius);">
                            <div class="mx-auto mb-4 flex items-center justify-center {{ $iconBg ? 'w-20 h-20 rounded-2xl' : '' }}"
                                @if ($iconBg) style="background-color: hsl(var(--color-primary) / 0.1); border-radius: var(--citadel-card-radius);" @endif>
                                @if ($iconType === 'citadel' && $iconCitadel)
                                    <x-citadel-icon :name="$iconCitadel" class="{{ $iconBg ? 'w-16 h-16' : 'w-16 h-16' }}" />
                                @elseif ($iconType === 'remix' && $iconRemix)
                                    <x-dynamic-component :component="$iconRemix" class="{{ $iconBg ? 'size-10' : 'size-12' }}" style="color: hsl(var(--color-primary));" />
                                @else
                                    <x-ri-checkbox-circle-line class="{{ $iconBg ? 'size-10' : 'size-12' }}" style="color: hsl(var(--color-primary));" />
                                @endif
                            </div>

                            <h3 class="text-base font-semibold mb-2" style="color: hsl(var(--color-base));">
                                {{ $title }}
                            </h3>

                            @if ($desc)
                                <p class="text-sm leading-relaxed" style="color: hsl(var(--color-base) / 0.6);">
                                    {{ $desc }}
                                </p>
                            @endif
                        </div>
                    @endif
                @endforeach
            </div>
        </div>
    </div>
</section>
@endif
