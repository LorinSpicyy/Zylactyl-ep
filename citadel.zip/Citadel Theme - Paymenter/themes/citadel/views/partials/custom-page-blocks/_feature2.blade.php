@php
    use Illuminate\Support\Facades\Storage;

    
    $f2Eyebrow  = trim((string) ($block['feature2_eyebrow'] ?? ''));
    $f2Title    = trim((string) ($block['heading'] ?? ''));
    $f2Desc     = trim((string) ($block['description'] ?? ''));
    $f2Orient   = $block['feature2_orientation'] ?? 'image_right';
    $f2IconType = $block['feature2_icon_type'] ?? 'remix';
    $f2Points   = $block['feature2_points'] ?? [];
    $f2ImgUrl   = ! empty($block['feature2_image']) ? Storage::url($block['feature2_image']) : null;
    $f2ImgLeft  = $f2Orient === 'image_left';
@endphp

@if ($f2Eyebrow || $f2Title || $f2Desc || ! empty($f2Points) || $f2ImgUrl)
<section class="py-16 md:py-24">
    <style>
        .citadel-f2-text > *{margin:0;}
        .citadel-f2-text strong{color:hsl(var(--color-base));font-weight:600;}
        .citadel-f2-ico svg{width:1.25rem;height:1.25rem;display:block;}
    </style>
    <div class="w-full mx-auto px-4 sm:px-6 lg:px-8" style="max-width: var(--citadel-content-width, 1440px);">
        <div class="grid md:grid-cols-2 gap-10 lg:gap-16 items-center">

            {{-- TEXT --}}
            <div class="{{ $f2ImgLeft ? 'md:order-2' : 'md:order-1' }} min-w-0 max-w-xl">
                @if ($f2Eyebrow)
                    <p class="text-base font-semibold mb-2" style="color: hsl(var(--color-primary));">{{ $f2Eyebrow }}</p>
                @endif
                @if ($f2Title)
                    <h2 class="text-3xl sm:text-4xl font-bold leading-tight tracking-tight mb-4" style="color: hsl(var(--color-base));">{{ $f2Title }}</h2>
                @endif
                @if ($f2Desc)
                    <p class="text-lg leading-relaxed mb-8" style="color: hsl(var(--color-base) / 0.7);">{{ $f2Desc }}</p>
                @endif

                @if (! empty($f2Points))
                    <dl class="space-y-5">
                        @foreach ($f2Points as $pt)
                            @php
                                $ptText  = trim((string) ($pt['text'] ?? ''));
                                $ptRemix = trim((string) ($pt['icon_remix'] ?? ''));
                                $ptSvg   = trim((string) ($pt['icon_svg'] ?? ''));
                            @endphp
                            @if ($ptText !== '')
                                <div class="relative pl-9">
                                    <span class="absolute left-1 top-1 inline-flex items-center justify-center" style="color: hsl(var(--color-primary));">
                                        @if ($f2IconType === 'svg' && $ptSvg !== '')
                                            <span class="citadel-f2-ico inline-flex">{!! $ptSvg !!}</span>
                                        @elseif ($f2IconType === 'remix' && $ptRemix !== '')
                                            <x-dynamic-component :component="$ptRemix" class="size-5" />
                                        @else
                                            <x-ri-checkbox-circle-line class="size-5" />
                                        @endif
                                    </span>
                                    <div class="citadel-f2-text text-base leading-relaxed" style="color: hsl(var(--color-base) / 0.7);">{!! $ptText !!}</div>
                                </div>
                            @endif
                        @endforeach
                    </dl>
                @endif
            </div>

            
            @if ($f2ImgUrl)
                <div class="{{ $f2ImgLeft ? 'md:order-1' : 'md:order-2' }} w-full overflow-hidden" style="border-radius: var(--citadel-card-radius); aspect-ratio: 10 / 9;">
                    <img src="{{ $f2ImgUrl }}" alt="{{ $f2Title }}" draggable="false"
                         class="w-full h-full object-cover select-none pointer-events-none" />
                </div>
            @endif

        </div>
    </div>
</section>
@endif
