@php
    use Illuminate\Support\Facades\Storage;

    $heading        = trim((string) ($block['heading'] ?? ''));
    $sub            = trim((string) ($block['subheading'] ?? ''));
    $btnText        = trim((string) ($block['button_text'] ?? ''));
    $btnLink        = trim((string) ($block['button_link'] ?? ''));

    $bgType         = $block['background_type'] ?? 'curved';
    $bgImage        = $block['background_image'] ?? '';
    $bgImageUrl     = $bgImage ? Storage::url($bgImage) : null;
    $overlayColor   = $block['overlay_color'] ?? 'primary';

    
    $defaultBtnLink = '#';
    if (isset($category) && $category) {
        try {
            $defaultBtnLink = route('category.show', ['category' => $category->slug]);
        } catch (\Throwable $e) {}
    }
    $resolvedBtnLink = $btnLink !== '' ? $btnLink : $defaultBtnLink;
    $btnIsExternal   = filter_var($resolvedBtnLink, FILTER_VALIDATE_URL) && ! str_starts_with($resolvedBtnLink, url('/'));
    $btnIsAnchor     = str_starts_with($resolvedBtnLink, '#');

    
    $hasBackground = $bgType !== 'none';

    
    $useLightText  = $bgType === 'curved'
        || ($bgType === 'image_overlay' && $overlayColor === 'primary')
        || ($bgType === 'image' && $bgImageUrl);


    $heroUid = 'citadel-hero-' . substr(md5(uniqid('', true)), 0, 8);

    $heroStyle = $block['hero_style'] ?? 'hero1';

    
    $isFirstBlock = $isFirstBlock ?? false;
    $heroPad = $isFirstBlock ? 'var(--citadel-hero-pad, 0px)' : '0px';


    $heroWidth = trim((string) ($block['hero_width'] ?? ''));
    $heroMaxW  = $heroWidth !== '' ? $heroWidth : 'var(--citadel-content-width, 1440px)';
@endphp

@if ($heroStyle === 'm2hero')
    @include('partials.custom-page-blocks._m2hero', ['block' => $block])
@elseif ($heroStyle === 'hero2')
    @include('partials.custom-page-blocks._hero2')
@elseif ($heroStyle === 'hero3')
    @include('partials.custom-page-blocks._hero3')
@elseif ($heroStyle === 'hero4')
    @include('partials.custom-page-blocks._hero4')
@elseif ($heroStyle === 'hero5')
    @include('partials.custom-page-blocks._hero5')
@else
<section
    class="citadel-hero-sub relative isolate"
    @if ($hasBackground)
        style="margin-top: calc(-1 * ({{ $heroPad }} + 2.5rem)); margin-bottom: 0rem; padding: calc(4.5rem + {{ $heroPad }}) 0 4rem;"
    @else
        style="padding: 2rem 0 1rem;"
    @endif
>
    @if ($bgType === 'curved')
        
        <div class="absolute inset-0 left-[50%] right-[50%] -ml-[50vw] -mr-[50vw] w-screen -z-10 overflow-hidden" aria-hidden="true">
            <svg class="w-full h-full" viewBox="0 0 1920 500" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
                <defs>
                    <linearGradient id="{{ $heroUid }}-bg" x1="0" y1="0" x2="1" y2="1">
                        <stop offset="0%"
                              stop-color="hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 1) calc(var(--color-primary-l) * 1.15))" />
                        <stop offset="100%"
                              stop-color="hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 1) calc(var(--color-primary-l) * 0.65))" />
                    </linearGradient>
                    <radialGradient id="{{ $heroUid }}-glow" cx="50%" cy="30%" r="60%">
                        <stop offset="0%" stop-color="#ffffff" stop-opacity="0.30" />
                        <stop offset="100%" stop-color="#ffffff" stop-opacity="0" />
                    </radialGradient>
                    <linearGradient id="{{ $heroUid }}-curve1" x1="0" y1="0" x2="1" y2="1">
                        <stop offset="0%" stop-color="#ffffff" stop-opacity="0.22" />
                        <stop offset="100%" stop-color="#ffffff" stop-opacity="0" />
                    </linearGradient>
                    <linearGradient id="{{ $heroUid }}-curve2" x1="1" y1="0" x2="0" y2="1">
                        <stop offset="0%" stop-color="#ffffff" stop-opacity="0.16" />
                        <stop offset="100%" stop-color="#ffffff" stop-opacity="0" />
                    </linearGradient>
                </defs>

                <rect width="1920" height="500" fill="url(#{{ $heroUid }}-bg)" />
                <rect width="1920" height="500" fill="url(#{{ $heroUid }}-glow)" />

                <path d="M1240 500C1390 420 1510 290 1660 250C1780 220 1860 170 1920 120V500Z"
                      fill="url(#{{ $heroUid }}-curve2)" />

                <path d="M1380 240C1540 200 1710 145 1920 55"
                      stroke="rgba(255,255,255,0.08)" stroke-width="2" fill="none" />
            </svg>
        </div>
    @elseif ($bgType === 'image' && $bgImageUrl)
        
        <div class="absolute inset-0 left-[50%] right-[50%] -ml-[50vw] -mr-[50vw] w-screen -z-10 bg-cover bg-center overflow-hidden" style="background-image: url('{{ $bgImageUrl }}');"></div>
    @elseif ($bgType === 'image_overlay' && $bgImageUrl)
        
        @php
            $overlayHsl = $overlayColor === 'background'
                ? 'var(--color-background)'
                : 'var(--color-primary)';
        @endphp
        <div class="absolute inset-0 left-[50%] right-[50%] -ml-[50vw] -mr-[50vw] w-screen -z-10 bg-cover bg-center overflow-hidden" style="background-image: url('{{ $bgImageUrl }}');"></div>
        <div class="absolute inset-0 left-[50%] right-[50%] -ml-[50vw] -mr-[50vw] w-screen -z-10 overflow-hidden" style="background: linear-gradient(to bottom, hsl({{ $overlayHsl }} / 0.7) 0%, hsl({{ $overlayHsl }}) 100%);"></div>
    @endif

    <div class="relative w-full px-4 sm:px-6 lg:px-8">
        <div class="{{ $heroWidth !== '' ? '' : 'max-w-3xl' }} mx-auto text-center" @if ($heroWidth !== '') style="max-width: {{ $heroWidth }};" @endif>
            @if ($heading)
                <h1
                    class="text-3xl sm:text-4xl lg:text-5xl font-bold leading-tight mb-3"
                    @if ($useLightText)
                        style="color: #ffffff;"
                    @else
                        style="color: hsl(var(--color-base));"
                    @endif
                >
                    {{ $heading }}
                </h1>
            @endif

            @if ($sub)
                <p
                    class="text-base leading-relaxed mb-5 max-w-2xl mx-auto"
                    @if ($useLightText)
                        style="color: rgba(255,255,255,0.9);"
                    @else
                        style="color: hsl(var(--color-base) / 0.75);"
                    @endif
                >
                    {{ $sub }}
                </p>
            @endif

            @if ($btnText)
                <div class="flex justify-center">
                    <a
                        href="{{ $resolvedBtnLink }}"
                        class="citadel-btn inline-flex items-center justify-center px-7 text-sm font-medium transition-all hover:opacity-90"
                        @if ($useLightText)
                            style="background-color: #ffffff; color: hsl(var(--color-primary)); border-radius: var(--citadel-button-radius);"
                        @else
                            style="background-color: hsl(var(--color-primary)); color: #ffffff; border-radius: var(--citadel-button-radius);"
                        @endif
                        @if ($btnIsExternal) target="_blank" rel="noopener noreferrer" @elseif (! $btnIsAnchor) wire:navigate @endif
                    >
                        {{ $btnText }}
                    </a>
                </div>
            @endif
        </div>
    </div>
</section>
@endif
