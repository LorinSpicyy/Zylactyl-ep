@php
    use Illuminate\Support\Facades\Storage;


    $h4Title = trim((string) ($block['heading'] ?? ''));
    $h4Desc  = trim((string) ($block['subheading'] ?? ''));

    $h4BgType    = $block['hero4_bg_type'] ?? 'primary';
    $h4BgColor   = trim((string) ($block['hero4_bg_color'] ?? ''));
    $h4G1        = trim((string) ($block['hero4_grad_1'] ?? ''));
    $h4G2        = trim((string) ($block['hero4_grad_2'] ?? ''));
    $h4G3        = trim((string) ($block['hero4_grad_3'] ?? ''));
    $h4ImgSource = $block['hero4_image_source'] ?? 'category';


    $h4ImgUrl = null;
    if ($h4BgType === 'image') {
        if ($h4ImgSource === 'custom' && ! empty($block['hero4_image'])) {
            try { $h4ImgUrl = Storage::url($block['hero4_image']); } catch (\Throwable $e) {}
        } elseif (isset($category) && $category && ! empty($category->image)) {
            try { $h4ImgUrl = Storage::url($category->image); } catch (\Throwable $e) {}
        }
    }


    $h4Light = true;
    if ($h4BgType === 'custom_color' && $h4BgColor !== '') {
        $h4SectionStyle = 'background-color: ' . $h4BgColor . ';';
        $parts   = preg_split('/\s+/', trim(str_replace(',', '', preg_replace('/^hsl\((.+)\)$/i', '$1', $h4BgColor))));
        $h4Light = isset($parts[2]) ? ((float) rtrim($parts[2], '%') < 60) : true;
    } elseif ($h4BgType === 'gradient') {
        $g1 = $h4G1 !== '' ? $h4G1 : 'hsl(var(--color-primary))';
        $g2 = $h4G2 !== '' ? $h4G2 : 'hsl(var(--color-primary))';
        $g3 = $h4G3 !== '' ? $h4G3 : 'hsl(var(--color-primary))';
        $h4SectionStyle = 'background-image: linear-gradient(120deg, ' . $g1 . ' 0%, ' . $g2 . ' 50%, ' . $g3 . ' 100%);';
        $h4Light = true;
    } elseif ($h4BgType === 'image' && $h4ImgUrl) {

        $h4SectionStyle = "background-image: linear-gradient(to top, hsl(var(--color-background)) 0%, hsl(var(--color-background) / 0.8) 100%), url('" . $h4ImgUrl . "'); background-size: cover; background-position: center; background-repeat: no-repeat;";
        $h4Light = false;
    } else {
        $h4SectionStyle = 'background-color: hsl(var(--color-primary));';
        $h4Light = true;
    }

    $h4cTitle = $h4Light ? '#ffffff'               : 'hsl(var(--color-base))';
    $h4cDesc  = $h4Light ? 'rgba(255,255,255,0.9)' : 'hsl(var(--color-base) / 0.75)';
    $h4BtnCtx = $h4Light ? 'light' : 'base';


    $h4IconBg = match ($h4BgType) {
        'custom_color' => $h4BgColor !== '' ? $h4BgColor : 'hsl(var(--color-primary))',
        'gradient'     => $h4G1 !== '' ? $h4G1 : 'hsl(var(--color-primary))',
        'image'        => 'hsl(var(--color-background))',
        default        => 'hsl(var(--color-primary))',
    };
@endphp


<section class="citadel-hero4 relative isolate"
    style="margin-top: calc(-1 * ({{ $heroPad ?? '0px' }} + 2.5rem)); padding-top: {{ $heroPad ?? '0px' }};">
    <div class="absolute inset-0 left-[50%] right-[50%] -ml-[50vw] -mr-[50vw] w-screen -z-10 overflow-hidden" style="{{ $h4SectionStyle }}"></div>
    <div class="relative w-full mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-14" style="max-width: {{ $heroMaxW }};">
        <div class="max-w-2xl text-left">
            @if ($h4Title)
                <h1 class="text-4xl sm:text-5xl font-bold leading-tight mb-4" style="color: {{ $h4cTitle }};">{{ $h4Title }}</h1>
            @endif

            @if ($h4Desc)
                <p class="text-lg leading-relaxed mb-7 max-w-xl" style="color: {{ $h4cDesc }};">{{ $h4Desc }}</p>
            @endif

            @include('partials.custom-page-blocks._hero-buttons', ['btnContext' => $h4BtnCtx, 'btnIconBg' => $h4IconBg, 'btnIconColor' => $h4cTitle])
        </div>
    </div>
</section>
