@php
    use Illuminate\Support\Facades\Storage;

    
    $f3Eyebrow = trim((string) ($block['feature3_eyebrow'] ?? ''));
    $f3Title   = trim((string) ($block['heading'] ?? ''));
    $f3Cards   = $block['feature3_cards'] ?? [];
    $f3Count   = count($f3Cards);
@endphp

@if ($f3Eyebrow || $f3Title || ! empty($f3Cards))
<section class="py-16 md:py-24">
    <style>
        
        .citadel-f3-wrap{width:100%;margin-left:auto;margin-right:auto;max-width:72rem;}
        .citadel-f3-grid{display:grid;grid-template-columns:1fr;gap:1rem;}
        @media (min-width:640px){.citadel-f3-grid{grid-template-columns:repeat(2,minmax(0,1fr));}}
        @media (min-width:1024px){
            .citadel-f3-grid{grid-template-columns:repeat(6,minmax(0,1fr));}
            .citadel-f3-grid > .citadel-f3-top{grid-column:span 3 / span 3;}
            .citadel-f3-grid > .citadel-f3-bot{grid-column:span 2 / span 2;}
        }
        .citadel-f3-card{height:100%;display:flex;flex-direction:column;overflow:hidden;border:1px solid hsl(var(--color-neutral));background-color:hsl(var(--color-background-secondary));border-radius:var(--citadel-card-radius);}
        
        @media (min-width:1024px){
            .citadel-f3-card.f3-tl{border-top-left-radius:calc(var(--citadel-card-radius) + 1rem);}
            .citadel-f3-card.f3-tr{border-top-right-radius:calc(var(--citadel-card-radius) + 1rem);}
            .citadel-f3-card.f3-bl{border-bottom-left-radius:calc(var(--citadel-card-radius) + 1rem);}
            .citadel-f3-card.f3-br{border-bottom-right-radius:calc(var(--citadel-card-radius) + 1rem);}
        }
        .citadel-f3-media{position:relative;width:100%;height:10rem;overflow:hidden;flex-shrink:0;background-color:hsl(var(--color-background-secondary));}
        @media (min-width:640px){.citadel-f3-media{height:11rem;}}
        @media (min-width:1024px){.citadel-f3-media{height:12rem;}}
        .citadel-f3-media img{width:100%;height:100%;object-fit:contain;object-position:bottom;display:block;}
        
        .citadel-f3-media img.citadel-f3-img-dark{display:none;}
        .dark .citadel-f3-media img.citadel-f3-img-dark{display:block;}
        .dark .citadel-f3-media img.citadel-f3-img-light{display:none;}
        .citadel-f3-body{padding:1.5rem 1.75rem 1.25rem;flex:1 1 auto;}
        .citadel-f3-title{font-size:1.125rem;font-weight:600;line-height:1.4;color:hsl(var(--color-base));margin:0;}
        .citadel-f3-desc{font-size:.875rem;line-height:1.6;color:hsl(var(--color-base) / .7);margin:.5rem 0 0;max-width:32rem;}
        .citadel-f3-eyebrow{font-size:1rem;font-weight:600;color:hsl(var(--color-primary));margin:0;}
        .citadel-f3-heading{font-size:clamp(1.875rem,4vw,2.25rem);font-weight:700;letter-spacing:-.02em;line-height:1.15;color:hsl(var(--color-base));margin:.5rem 0 2.5rem;}
        @media (min-width:768px){.citadel-f3-heading{margin-bottom:3.5rem;}}
    </style>
    <div class="citadel-f3-wrap">
        @if ($f3Eyebrow)
            <p class="citadel-f3-eyebrow text-center">{{ $f3Eyebrow }}</p>
        @endif
        @if ($f3Title)
            <h2 class="citadel-f3-heading text-center">{{ $f3Title }}</h2>
        @endif

        @if (! empty($f3Cards))
            <div class="citadel-f3-grid">
                @foreach ($f3Cards as $i => $card)
                    @php
                        $cImg      = ! empty($card['image']) ? Storage::url($card['image']) : null;
                        $cImgLight = (! empty($card['image_light_enabled']) && ! empty($card['image_light'])) ? Storage::url($card['image_light']) : null;
                        $cTitle    = trim((string) ($card['title'] ?? ''));
                        $cDesc  = trim((string) ($card['description'] ?? ''));
                        
                        $cCorner = '';
                        if ($f3Count <= 1) {
                            $cCorner = ' f3-tl f3-tr f3-bl f3-br';
                        } else {
                            $hasBottom = $f3Count > 2;
                            if ($i === 0) $cCorner .= ' f3-tl' . ($hasBottom ? '' : ' f3-bl');
                            if ($i === 1) $cCorner .= ' f3-tr' . ($hasBottom ? '' : ' f3-br');
                            if ($hasBottom && $i === 2) $cCorner .= ' f3-bl';
                            if ($hasBottom && $i === $f3Count - 1) $cCorner .= ' f3-br';
                        }
                    @endphp
                    <div class="{{ $i < 2 ? 'citadel-f3-top' : 'citadel-f3-bot' }}">
                        <div class="citadel-f3-card{{ $cCorner }}">
                            <div class="citadel-f3-body">
                                @if ($cTitle)<p class="citadel-f3-title">{{ $cTitle }}</p>@endif
                                @if ($cDesc)<p class="citadel-f3-desc">{{ $cDesc }}</p>@endif
                            </div>
                            <div class="citadel-f3-media">
                                @if ($cImg && $cImgLight)
                                    <img src="{{ $cImg }}" alt="{{ $cTitle }}" draggable="false" class="citadel-f3-img-dark select-none pointer-events-none" />
                                    <img src="{{ $cImgLight }}" alt="{{ $cTitle }}" draggable="false" class="citadel-f3-img-light select-none pointer-events-none" />
                                @elseif ($cImg || $cImgLight)
                                    <img src="{{ $cImg ?? $cImgLight }}" alt="{{ $cTitle }}" draggable="false" class="select-none pointer-events-none" />
                                @endif
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        @endif
    </div>
</section>
@endif
