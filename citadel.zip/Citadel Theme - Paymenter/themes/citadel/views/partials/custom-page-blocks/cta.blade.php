@php
    $heading     = $block['heading'] ?? '';
    $description = $block['description'] ?? '';
    $bgType      = $block['background_type'] ?? 'gradient';
    $bgImage     = $block['background_image'] ?? '';


    $ctaCentered = ($block['cta_orientation'] ?? 'split') === 'centered';

    
    $ctaWidthRaw = trim((string) ($block['cta_max_width'] ?? ''));
    $ctaMaxW     = preg_match('/^\d+(\.\d+)?(px|rem|em|vw|%)$/', $ctaWidthRaw) ? $ctaWidthRaw : null;
    $btn1Text    = $block['btn1_text'] ?? '';
    $btn1Link    = $block['btn1_link'] ?? '';
    $btn2Text    = $block['btn2_text'] ?? '';
    $btn2Link    = $block['btn2_link'] ?? '';
    $btn1External = filter_var($btn1Link, FILTER_VALIDATE_URL) && ! str_starts_with($btn1Link, url('/'));
    $btn2External = filter_var($btn2Link, FILTER_VALIDATE_URL) && ! str_starts_with($btn2Link, url('/'));
    $btn1Anchor = str_starts_with($btn1Link, '#');
    $btn2Anchor = str_starts_with($btn2Link, '#');
    $hasBtn1     = !empty($btn1Text) && !empty($btn1Link);
    $hasBtn2     = !empty($btn2Text) && !empty($btn2Link);
    $hasButtons  = $hasBtn1 || $hasBtn2;
    $hasContent  = !empty($heading) || !empty($description);

    $imageUrl = '';
    if ($bgImage) {
        try {
            $imageUrl = \Illuminate\Support\Facades\Storage::url($bgImage);
        } catch (\Throwable $e) {}
    }

    $useImage = in_array($bgType, ['image', 'image_overlay'], true) && $imageUrl;

    if ($bgType === 'plain') {
        $cardStyle = 'background-color: hsl(var(--color-primary));';
    } elseif ($useImage) {
        $cardStyle = "background-image: url('" . e($imageUrl) . "'); background-size: cover; background-position: center;";
    } else {
        
        $cardStyle = 'background: linear-gradient(135deg, hsl(var(--color-primary)), hsl(var(--color-primary) / 0.72));';
    }
@endphp

@if ($hasContent || $hasButtons)
<section class="py-6">
    <div class="relative overflow-hidden px-8 sm:px-12 {{ $ctaCentered ? 'py-14 sm:py-20' : 'py-8 sm:py-10' }} {{ $ctaMaxW ? 'mx-auto' : '' }}"
         style="{{ $cardStyle }} border-radius: var(--citadel-card-radius);{{ $ctaMaxW ? ' max-width: ' . $ctaMaxW . ';' : '' }}">


        @if ($useImage && $bgType === 'image_overlay')
            <div class="absolute inset-0" style="background: linear-gradient(135deg, hsl(var(--color-primary) / 0.82), hsl(var(--color-primary) / 0.58)); z-index: 0;"></div>
        @endif

        <div class="relative z-10 flex {{ $ctaCentered ? 'flex-col items-center text-center gap-6' : 'flex-col sm:flex-row sm:items-center gap-6 sm:gap-10' }}">


            <div class="{{ $ctaCentered ? 'max-w-2xl' : 'flex-1 min-w-0' }}">
                @if ($heading)
                    <h2 class="text-2xl sm:text-3xl font-bold leading-tight {{ $description ? 'mb-2' : '' }}"
                        style="color: #fff;">
                        {{ $heading }}
                    </h2>
                @endif
                @if ($description)
                    <p class="text-sm sm:text-base leading-relaxed"
                       style="color: rgba(255,255,255,0.85);">
                        {{ $description }}
                    </p>
                @endif
            </div>


            @if ($hasButtons)
                <div class="flex flex-col sm:flex-row flex-wrap gap-3 {{ $ctaCentered ? 'justify-center' : 'shrink-0' }}">
                    @if ($hasBtn1)
                        <a href="{{ $btn1Link }}" @if($btn1External) target="_blank" rel="noopener noreferrer" @elseif(! $btn1Anchor) wire:navigate @endif
                           class="citadel-btn inline-flex items-center justify-center px-7 text-sm font-medium transition-all hover:scale-105 whitespace-nowrap"
                           style="background-color: #fff; color: hsl(var(--color-primary)); border-radius: var(--citadel-button-radius);">
                            {{ $btn1Text }}
                        </a>
                    @endif
                    @if ($hasBtn2)
                        <a href="{{ $btn2Link }}" @if($btn2External) target="_blank" rel="noopener noreferrer" @elseif(! $btn2Anchor) wire:navigate @endif
                           class="citadel-btn inline-flex items-center justify-center px-7 text-sm font-medium border transition-all hover:scale-105 whitespace-nowrap"
                           style="border-color: rgba(255,255,255,0.65); color: #fff; background: transparent; border-radius: var(--citadel-button-radius);">
                            {{ $btn2Text }}
                        </a>
                    @endif
                </div>
            @endif

        </div>
    </div>
</section>
@endif
