
<div class="flex justify-center mb-10 px-4">
    <div class="flex flex-wrap items-center justify-center gap-1 p-1 border max-w-full"
         style="background: hsl(var(--color-background-secondary)); border-color: hsl(var(--color-neutral)); border-radius: var(--citadel-card-radius);">
        @foreach ($commonTermKeys as $tk)
            <button type="button"
                    x-on:click="term = @js($tk)"
                    class="px-5 py-2 text-sm font-semibold transition-all whitespace-nowrap"
                    style="border-radius: var(--citadel-button-radius);"
                    x-bind:style="term === @js($tk)
                        ? 'background: hsl(var(--color-primary)); color: #fff; border-radius: var(--citadel-button-radius);'
                        : 'color: hsl(var(--color-base) / 0.65); border-radius: var(--citadel-button-radius);'">
                {{ $termLabels[$tk] }}
            </button>
        @endforeach
    </div>
</div>
