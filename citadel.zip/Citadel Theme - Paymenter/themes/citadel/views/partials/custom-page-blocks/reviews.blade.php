@php
    
    $reviewsTitle       = trim((string) ($block['heading'] ?? ''));
    $reviewsDescription = trim((string) ($block['description'] ?? ''));
    $reviewsData        = $block['reviews_data'] ?? [];
    $reviewsData        = is_array($reviewsData) ? $reviewsData : [];
@endphp

@if (! empty($reviewsData))
<section class="py-16 md:py-24 relative left-[50%] right-[50%] -ml-[50vw] -mr-[50vw] w-screen overflow-hidden">
    <div class="w-full">

        @if ($reviewsTitle || $reviewsDescription)
            <div class="text-center mb-12 max-w-4xl mx-auto px-4">
                @if ($reviewsTitle)
                    <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4" style="color: hsl(var(--color-base));">{{ $reviewsTitle }}</h2>
                @endif
                @if ($reviewsDescription)
                    <p class="text-sm sm:text-base max-w-2xl mx-auto leading-relaxed" style="color: hsl(var(--color-base) / 0.6);">{{ $reviewsDescription }}</p>
                @endif
            </div>
        @endif

        @php
            $mid  = (int) ceil(count($reviewsData) / 2);
            $row1 = array_slice($reviewsData, 0, $mid);
            $row2 = array_slice($reviewsData, $mid);
            if (empty($row2)) { $row2 = $row1; }
        @endphp

        <div class="group mb-4" style="--review-count: {{ count($row1) }};">
            <div class="flex gap-4 animate-scroll-left group-hover:[animation-play-state:paused]">
                @for ($ri = 0; $ri < 2; $ri++)
                    @foreach ($row1 as $review)
                        <div class="review-card flex-shrink-0 w-[350px] sm:w-[400px] p-6 rounded-2xl border border-neutral bg-background-secondary transition-all duration-300" style="border-radius: var(--citadel-card-radius);">
                            <div class="flex items-center gap-3 mb-4">
                                @if (! empty($review['image']))
                                    <img src="{{ \Illuminate\Support\Facades\Storage::url($review['image']) }}" alt="{{ $review['name'] ?? '' }}" class="w-10 h-10 rounded-full object-cover flex-shrink-0" style="border: 2px solid hsl(var(--color-primary) / 0.2);" />
                                @else
                                    <div class="w-10 h-10 rounded-full flex-shrink-0 flex items-center justify-center text-sm font-semibold" style="background-color: hsl(var(--color-primary) / 0.15); color: hsl(var(--color-primary));">{{ strtoupper(substr($review['name'] ?? '?', 0, 1)) }}</div>
                                @endif
                                <span class="font-semibold text-sm" style="color: hsl(var(--color-base));">{{ $review['name'] ?? 'Anonymous' }}</span>
                            </div>
                            <p class="text-sm leading-relaxed" style="color: hsl(var(--color-base) / 0.7);">{{ $review['review'] ?? '' }}</p>
                        </div>
                    @endforeach
                @endfor
            </div>
        </div>

        <div class="group" style="--review-count: {{ count($row2) }};">
            <div class="flex gap-4 animate-scroll-right group-hover:[animation-play-state:paused]">
                @for ($ri = 0; $ri < 2; $ri++)
                    @foreach ($row2 as $review)
                        <div class="review-card flex-shrink-0 w-[350px] sm:w-[400px] p-6 rounded-2xl border border-neutral bg-background-secondary transition-all duration-300" style="border-radius: var(--citadel-card-radius);">
                            <div class="flex items-center gap-3 mb-4">
                                @if (! empty($review['image']))
                                    <img src="{{ \Illuminate\Support\Facades\Storage::url($review['image']) }}" alt="{{ $review['name'] ?? '' }}" class="w-10 h-10 rounded-full object-cover flex-shrink-0" style="border: 2px solid hsl(var(--color-primary) / 0.2);" />
                                @else
                                    <div class="w-10 h-10 rounded-full flex-shrink-0 flex items-center justify-center text-sm font-semibold" style="background-color: hsl(var(--color-primary) / 0.15); color: hsl(var(--color-primary));">{{ strtoupper(substr($review['name'] ?? '?', 0, 1)) }}</div>
                                @endif
                                <span class="font-semibold text-sm" style="color: hsl(var(--color-base));">{{ $review['name'] ?? 'Anonymous' }}</span>
                            </div>
                            <p class="text-sm leading-relaxed" style="color: hsl(var(--color-base) / 0.7);">{{ $review['review'] ?? '' }}</p>
                        </div>
                    @endforeach
                @endfor
            </div>
        </div>

    </div>
    <style>
        @keyframes scroll-left { 0% { transform: translateX(0); } 100% { transform: translateX(-50%); } }
        @keyframes scroll-right { 0% { transform: translateX(-50%); } 100% { transform: translateX(0); } }
        .animate-scroll-left { animation: scroll-left calc(var(--review-count, 4) * 8s) linear infinite; width: max-content; }
        .animate-scroll-right { animation: scroll-right calc(var(--review-count, 4) * 8s) linear infinite; width: max-content; }
        .review-card:hover { border-color: hsl(var(--color-primary) / 0.5); transform: scale(1.02); }
    </style>
</section>
@endif
