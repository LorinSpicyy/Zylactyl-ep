@php
    $heading     = $block['heading'] ?? 'Frequently Asked Questions';
    $description = $block['description'] ?? '';
    $items       = $block['items'] ?? [];
    $blockId     = 'faq-block-' . ($index ?? 0);
@endphp

@if (! empty($items))
<section class="py-16 md:py-24">
    <div class="text-center mb-12">
        <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4" style="color: hsl(var(--color-base));">
            {{ $heading }}
        </h2>
        @if ($description)
            <p class="text-sm sm:text-base max-w-2xl mx-auto leading-relaxed" style="color: hsl(var(--color-base) / 0.6);">
                {{ $description }}
            </p>
        @endif
    </div>

    <div class="max-w-3xl mx-auto flex flex-col gap-3" x-data="{ active: null }">
        @foreach ($items as $i => $item)
            @php
                $q = $item['question'] ?? '';
                $a = $item['answer'] ?? '';
            @endphp
            @if ($q)
                <div class="rounded-2xl border border-neutral bg-background-secondary overflow-hidden transition-all duration-300"
                     style="border-radius: var(--citadel-card-radius);">
                    <button type="button"
                            class="w-full flex items-center justify-between gap-4 p-5 text-left cursor-pointer"
                            @click="active = active === {{ $i }} ? null : {{ $i }}">
                        <span class="font-semibold text-sm sm:text-base" style="color: hsl(var(--color-base));">{{ $q }}</span>
                        <svg class="w-5 h-5 flex-shrink-0 transition-transform duration-300"
                             :class="{ 'rotate-180': active === {{ $i }} }"
                             style="color: hsl(var(--color-primary));"
                             fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                        </svg>
                    </button>
                    <div x-show="active === {{ $i }}" x-collapse x-cloak>
                        <div class="px-5 pb-5">
                            <p class="text-sm leading-relaxed whitespace-pre-line" style="color: hsl(var(--color-base) / 0.7);">{{ $a }}</p>
                        </div>
                    </div>
                </div>
            @endif
        @endforeach
    </div>
</section>
@endif
