@php
    use Illuminate\Support\Facades\Storage;
    use Illuminate\Support\Str;
    
    $m2 = function ($k, $d = null) use ($block) {
        $map = ['plans_title' => 'heading', 'plans_description' => 'description', 'plans_button_text' => 'button_text'];
        $bk = $map[$k] ?? ('m2_' . $k);
        return $block[$bk] ?? theme('marketing2_' . $k, $d);
    };
@endphp

@php
    $plansSource = $m2('plans_source', 'top_categories');
    $plansButtonText = $m2('plans_button_text', 'Get Started');
    $plansTitle = $m2('plans_title', 'Simple, Transparent Pricing');
    $plansDescription = $m2('plans_description', '');
    $plansPopular = (int) $m2('plans_popular', 0);
    $plansIconStyle = $m2('plans_icon_style', 'none');

    
    $categoryIconOverrides = [];
    if (theme('override_category_icons')) {
        $iconsData = json_decode(theme('category_icons_data', '[]'), true) ?: [];
        foreach ($iconsData as $entry) {
            if (!empty($entry['category_id']) && !empty($entry['icon'])) {
                $categoryIconOverrides[(int) $entry['category_id']] = $entry['icon'];
            }
        }
    }

    if ($plansSource === 'specific_category') {
        $plansCategoryId = $m2('plans_category_id');
        $plansCategory = $plansCategoryId
            ? \App\Models\Category::where('id', $plansCategoryId)
                ->with(['products' => function ($query) {
                    $query->where('hidden', false)
                        ->with(['plans.prices'])
                        ->orderBy('sort')
                        ->limit(4);
                }])
                ->first()
            : null;
        $plansProducts = $plansCategory ? $plansCategory->products : collect();


        $availableTerms = [];
        $productPricesByTerm = [];
        if ($plansProducts->count() > 0) {
            foreach ($plansProducts as $prod) {
                foreach ($prod->availablePlans() as $plan) {
                    $termKey = $plan->billing_period . '_' . $plan->billing_unit . '_' . $plan->type;
                    if (!isset($availableTerms[$termKey])) {

                        $availableTerms[$termKey] = [
                            'key' => $termKey,
                            'label' => $plan->name,
                            'billing_period' => $plan->billing_period,
                            'billing_unit' => $plan->billing_unit,
                            'type' => $plan->type,
                        ];
                    }

                    $priceObj = $plan->price();
                    if ($priceObj && $priceObj->available) {
                        $planSale = citadel_plan_sale($prod, $plan);
                        $productPricesByTerm[$prod->id][$termKey] = [
                            'price' => (string) $priceObj->formatted->price,
                            'original' => $planSale['original'] ?? null,
                            'badge' => $planSale['badge'] ?? null,
                            'billing_period' => $plan->billing_period,
                            'billing_unit' => $plan->billing_unit,
                            'type' => $plan->type,
                        ];
                    }
                }
            }
            $availableTerms = array_values($availableTerms);
        }
    } else {
        $plansCategories = \App\Models\Category::whereNull('parent_id')
            ->where(function ($query) {
                $query->whereHas('children')
                    ->orWhereHas('products', function ($query) {
                        $query->where('hidden', false);
                    });
            })
            ->with(['products' => function ($query) {
                $query->where('hidden', false)
                    ->with(['plans.prices'])
                    ->orderBy('sort')
                    ->limit(1);
            }])
            ->orderBy('sort')
            ->limit(3)
            ->get();
    }
@endphp
<section class="py-16 md:py-24">
    <div class="w-full">

        <div class="text-center mb-12">
            <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4" style="color: hsl(var(--color-base));">
                {{ $plansTitle }}
            </h2>
            @if($plansDescription)
                <p class="text-sm sm:text-base max-w-2xl mx-auto leading-relaxed" style="color: hsl(var(--color-base) / 0.6);">
                    {{ $plansDescription }}
                </p>
            @endif
        </div>

        <style>
            .plans-check-list ul {
                list-style: none !important;
                padding-left: 0 !important;
            }
            .plans-check-list ul li {
                display: flex !important;
                align-items: flex-start !important;
                gap: 10px;
            }
            .plans-check-list ul li > p {
                display: inline !important;
                margin: 0 !important;
            }
            .plans-check-list ul li::before {
                content: '';
                flex-shrink: 0;
                display: block;
                width: 18px;
                min-width: 18px;
                height: 18px;
                margin-top: 2px;
                background-color: var(--check-color);
                -webkit-mask-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='18' height='18' viewBox='0 0 18 18' fill='none'%3E%3Ccircle cx='9' cy='9' r='7.5' stroke='currentColor' stroke-width='1.5'/%3E%3Cpath d='M6.75 9L8.25 10.5L11.25 7.5' stroke='currentColor' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
                mask-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='18' height='18' viewBox='0 0 18 18' fill='none'%3E%3Ccircle cx='9' cy='9' r='7.5' stroke='currentColor' stroke-width='1.5'/%3E%3Cpath d='M6.75 9L8.25 10.5L11.25 7.5' stroke='currentColor' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
                -webkit-mask-repeat: no-repeat;
                mask-repeat: no-repeat;
                -webkit-mask-size: contain;
                mask-size: contain;
            }
            .plans-check-list strong,
            .plans-check-list b {
                color: inherit !important;
            }
        </style>

        @if($plansSource === 'top_categories' && isset($plansCategories) && $plansCategories->count() > 0)

            <div class="max-w-7xl mx-auto">
                <div class="flex flex-wrap justify-center gap-5">
                @foreach($plansCategories as $catIndex => $planCategory)
                    @php
                        $catIsPopular = $plansPopular === ($catIndex + 1);
                        $catProduct = $planCategory->products->first();
                        $catPlan = $catProduct?->availablePlans()?->first();
                        $catPrice = '';
                        $catBillingTerm = '';
                        $catSale = null;
                        if ($catProduct && $catProduct->price()->available) {
                            $catLtp = theme('show_lowest_term_price', false) ? citadel_lowest_term_price($catProduct) : null;
                            if ($catLtp) {
                                $catPlan = $catLtp['plan'];
                                $catPrice = $catLtp['formatted'];
                            } else {
                                $catPrice = $catProduct->price()->formatted->price;
                                $catSale = citadel_product_sale($catProduct);
                            }
                            if ($catPlan && $catPlan->type == 'recurring') {
                                if ($catPlan->billing_period == 1) {
                                    $catBillingTerm = trans_choice(__('services.billing_cycles.' . $catPlan->billing_unit), 1);
                                } elseif ($catPlan->billing_period == 3 && $catPlan->billing_unit == 'month') {
                                    $catBillingTerm = __('citadel::citadel.plans.quarter');
                                } elseif ($catPlan->billing_period == 6 && $catPlan->billing_unit == 'month') {
                                    $catBillingTerm = __('citadel::citadel.plans.6_months');
                                } elseif ($catPlan->billing_period == 12 && $catPlan->billing_unit == 'month') {
                                    $catBillingTerm = __('citadel::citadel.plans.year');
                                } else {
                                    $catBillingTerm = $catPlan->billing_period . ' ' .
                                        trans_choice(__('services.billing_cycles.' . $catPlan->billing_unit), $catPlan->billing_period);
                                }
                            }
                        }


                        $catIconUrl = null;
                        $catIconIsCitadel = false;
                        $catIconName = null;
                        if (isset($categoryIconOverrides[$planCategory->id])) {
                            $catIconName = $categoryIconOverrides[$planCategory->id];
                            $catIconUrl = asset('assets/icons/citadel/' . $catIconName . '.svg');
                            $catIconIsCitadel = true;
                        } elseif ($planCategory->image) {
                            $catIconUrl = Storage::url($planCategory->image);
                        }
                        $hasIcon = $plansIconStyle !== 'none' && $catIconUrl;
                    @endphp
                    <div class="{{ $catIsPopular ? '' : 'bg-background-secondary' }} border rounded-xl {{ ($plansIconStyle === 'background' || $plansIconStyle === 'corner') && $hasIcon ? '' : 'p-6' }} flex flex-col w-full md:w-[calc(50%-0.625rem)] xl:w-[calc(25%-0.9375rem)] max-w-sm {{ $catIsPopular ? (($plansIconStyle === 'background' || $plansIconStyle === 'corner') && $hasIcon ? '' : 'py-10') : ($plansPopular ? (($plansIconStyle === 'background' || $plansIconStyle === 'corner') && $hasIcon ? '' : 'md:pt-10') : '') }} relative overflow-hidden"
                        style="border-color: {{ $catIsPopular ? 'hsl(var(--color-primary) / 0.5)' : 'hsl(var(--color-neutral))' }}; {{ $catIsPopular ? 'background-color: hsl(var(--color-primary));' : '' }} border-radius: var(--citadel-card-radius);">


                        @if($plansIconStyle === 'background' && $hasIcon)
                            <div class="relative w-full h-32 mb-0">
                                <div class="absolute inset-0 flex items-center justify-center">
                                    @if($catIconIsCitadel)
                                        <x-svg-icon name="citadel/{{ $catIconName }}" class="w-full h-full p-6 object-contain" />
                                    @else
                                        <img src="{{ $catIconUrl }}" alt="{{ $planCategory->name }}" class="w-full h-full object-cover" />
                                    @endif
                                </div>
                                <div class="absolute inset-0" style="background: linear-gradient(to top, {{ $catIsPopular ? 'hsl(var(--color-primary))' : 'hsl(var(--color-background-secondary))' }} 0%, {{ $catIsPopular ? 'hsl(var(--color-primary) / 0.85)' : 'hsl(var(--color-background-secondary) / 0.7)' }} 40%, {{ $catIsPopular ? 'hsl(var(--color-primary) / 0.3)' : 'hsl(var(--color-background-secondary) / 0.2)' }} 100%);"></div>
                            </div>
                            <div class="p-6 pt-0 flex flex-col flex-1">
                        @elseif($plansIconStyle === 'corner' && $hasIcon)
                            <div class="absolute -top-4 -right-4 w-36 h-36 opacity-15 rotate-12 pointer-events-none">
                                @if($catIconIsCitadel)
                                    <x-svg-icon name="citadel/{{ $catIconName }}" class="w-full h-full" />
                                @else
                                    <img src="{{ $catIconUrl }}" alt="" class="w-full h-full object-cover" />
                                @endif
                            </div>
                            <div class="p-6 {{ $catIsPopular ? 'py-10' : ($plansPopular ? 'md:pt-10' : '') }} flex flex-col flex-1 relative z-[1]">
                        @else
                            <div class="flex flex-col flex-1">
                        @endif

                        @if($catIsPopular)
                            <span class="absolute top-4 right-4 inline-flex items-center px-3 py-1 rounded-full text-xs font-bold z-[2]"
                                style="background-color: #fff; color: hsl(var(--color-primary));">
                                {{ __('citadel::citadel.plans.most_popular') }}
                            </span>
                        @endif


                        @if($plansIconStyle === 'top' && $hasIcon)
                            <div class="flex justify-center {{ $catIsPopular ? 'mt-6' : ($plansPopular ? 'md:mt-6' : '') }} mb-4">
                                @if($catIconIsCitadel)
                                    <x-svg-icon name="citadel/{{ $catIconName }}" class="w-16 h-16" />
                                @else
                                    <img src="{{ $catIconUrl }}" alt="{{ $planCategory->name }}" class="w-16 h-16 object-contain rounded-lg" style="{{ $catIsPopular ? 'filter: brightness(0) invert(1);' : '' }} border-radius: var(--citadel-card-radius);" />
                                @endif
                            </div>
                        @endif


                        @if($plansIconStyle === 'right' && $hasIcon)
                            <div class="flex items-center justify-between {{ $catIsPopular ? 'mt-6' : ($plansPopular ? 'md:mt-6' : '') }} mb-3">
                                <h3 class="text-2xl font-bold" style="color: {{ $catIsPopular ? '#fff' : 'hsl(var(--color-base))' }};">
                                    {{ $planCategory->name }}
                                </h3>
                                @if($catIconIsCitadel)
                                    <x-svg-icon name="citadel/{{ $catIconName }}" class="w-14 h-14 flex-shrink-0" />
                                @else
                                    <img src="{{ $catIconUrl }}" alt="{{ $planCategory->name }}" class="w-14 h-14 object-contain flex-shrink-0 rounded-lg" style="{{ $catIsPopular ? 'filter: brightness(0) invert(1);' : '' }} border-radius: var(--citadel-card-radius);" />
                                @endif
                            </div>
                        @else
                            <h3 class="text-2xl font-bold {{ $plansIconStyle !== 'top' ? ($catIsPopular ? 'mt-6' : ($plansPopular ? 'md:mt-6' : '')) : '' }} mb-3" style="color: {{ $catIsPopular ? '#fff' : 'hsl(var(--color-base))' }};">
                                {{ $planCategory->name }}
                            </h3>
                        @endif


                        @if($catPrice)
                            <div class="mb-6">
                                <p class="text-xs mb-2" style="color: {{ $catIsPopular ? 'rgba(255,255,255,0.7)' : 'hsl(var(--color-base) / 0.5)' }};">{{ __('citadel::citadel.plans.starting_at') }}</p>
                                <div class="flex items-baseline gap-1.5 flex-wrap">
                                    <span class="text-2xl font-semibold" style="color: {{ $catIsPopular ? '#fff' : 'hsl(var(--color-base))' }};">{{ $catPrice }}</span>
                                    @if($catBillingTerm)
                                        <span class="text-sm font-medium" style="color: {{ $catIsPopular ? 'rgba(255,255,255,0.7)' : 'hsl(var(--color-base) / 0.5)' }};">/{{ $catBillingTerm }}</span>
                                    @endif
                                </div>
                                @if($catSale)
                                    <div class="flex items-center gap-1.5 flex-wrap mt-1">
                                        <span class="text-sm font-medium line-through" style="color: {{ $catIsPopular ? 'rgba(255,255,255,0.7)' : 'hsl(var(--color-base) / 0.45)' }};">{{ $catSale['original'] }}</span>
                                        <span class="inline-flex items-center gap-1 rounded-md text-sm font-semibold px-1.5 py-1 whitespace-nowrap" style="background-color: hsl(var(--color-primary)); color: white;"><svg class="w-3 h-3 flex-shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8 8H8.01M2 5.2L2 9.67451C2 10.1637 2 10.4083 2.05526 10.6385C2.10425 10.8425 2.18506 11.0376 2.29472 11.2166C2.4184 11.4184 2.59135 11.5914 2.93726 11.9373L10.6059 19.6059C11.7939 20.7939 12.388 21.388 13.0729 21.6105C13.6755 21.8063 14.3245 21.8063 14.927 21.6105C15.612 21.388 16.2061 20.7939 17.3941 19.6059L19.6059 17.3941C20.7939 16.2061 21.388 15.612 21.6105 14.927C21.8063 14.3245 21.8063 13.6755 21.6105 13.0729C21.388 12.388 20.7939 11.7939 19.6059 10.6059L11.9373 2.93726C11.5914 2.59135 11.4184 2.4184 11.2166 2.29472C11.0376 2.18506 10.8425 2.10425 10.6385 2.05526C10.4083 2 10.1637 2 9.67452 2L5.2 2C4.0799 2 3.51984 2 3.09202 2.21799C2.7157 2.40973 2.40973 2.71569 2.21799 3.09202C2 3.51984 2 4.07989 2 5.2ZM8.5 8C8.5 8.27614 8.27614 8.5 8 8.5C7.72386 8.5 7.5 8.27614 7.5 8C7.5 7.72386 7.72386 7.5 8 7.5C8.27614 7.5 8.5 7.72386 8.5 8Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>{{ $catSale['badge'] }}</span>
                                    </div>
                                @endif
                            </div>
                        @endif


                        <a href="{{ route('category.show', ['category' => $planCategory->slug]) }}" wire:navigate
                            class="citadel-btn w-full inline-flex items-center justify-center px-4 rounded-lg text-sm font-medium transition-colors mb-6 {{ $catIsPopular ? 'hover:opacity-90' : ($plansPopular ? '' : 'hover:opacity-90') }}"
                            style="{{ $catIsPopular
                                ? 'background-color: #fff; color: hsl(var(--color-primary));'
                                : ($plansPopular
                                    ? 'background-color: hsl(var(--color-neutral)); color: hsl(var(--color-base)); border: 1.5px solid hsl(var(--color-neutral) / 0.6);'
                                    : 'background-color: hsl(var(--color-primary)); color: white;') }} border-radius: var(--citadel-button-radius);"
                            {{ !$catIsPopular && $plansPopular ? 'onmouseover=this.style.opacity="0.8" onmouseout=this.style.opacity="1"' : '' }}>
                            {{ $plansButtonText }}
                        </a>


                        <div class="border-t-2 mb-6 {{ ($plansIconStyle === 'background' || $plansIconStyle === 'corner') && $hasIcon ? 'relative w-full' : 'relative -left-6 w-[calc(100%+3rem)]' }}" style="border-color: {{ $catIsPopular ? 'rgba(255,255,255,0.2)' : 'hsl(var(--color-neutral) / 0.75)' }};"></div>


                        @if($planCategory->description)
                            @php
                                $catDescHtml = $planCategory->description;
                                preg_match_all('/<(ul|ol)\b[^>]*>.*?<\/\1>/is', $catDescHtml, $catListMatches);
                                $catDescLists = implode('', $catListMatches[0] ?? []);
                                $catDescText = trim(preg_replace('/<(ul|ol)\b[^>]*>.*?<\/\1>/is', '', $catDescHtml));
                            @endphp
                            <div class="flex-1">
                                @if($catDescText)
                                    <article class="prose dark:prose-invert prose-sm max-w-none text-left
                                        [&_p]:mb-2 [&_p]:text-sm [&_p]:leading-relaxed
                                        [&_strong]:font-semibold [&_strong]:text-sm"
                                        style="color: {{ $catIsPopular ? 'rgba(255,255,255,0.85)' : 'hsl(var(--color-base) / 0.7)' }};">
                                        {!! $catDescText !!}
                                    </article>
                                @endif
                                @if($catDescLists)
                                    <h4 class="text-sm font-semibold {{ $catDescText ? 'mt-4' : '' }} mb-4" style="color: {{ $catIsPopular ? 'rgba(255,255,255,0.9)' : 'hsl(var(--color-base) / 0.8)' }};">{{ __('citadel::citadel.plans.whats_included') }}</h4>
                                    <article class="prose dark:prose-invert prose-sm max-w-none text-left
                                        [&_ol]:list-decimal [&_li]:mb-1.5 [&_li]:text-sm [&_li]:leading-relaxed
                                        [&_ol]:pl-5 [&_p]:mb-2 [&_li_p]:mb-0 [&_ul]:space-y-1.5
                                        [&_strong]:font-semibold [&_strong]:text-sm [&_p]:text-sm [&_p]:leading-relaxed"
                                        style="color: {{ $catIsPopular ? 'rgba(255,255,255,0.85)' : 'hsl(var(--color-base) / 0.7)' }};">
                                        <div class="plans-check-list" style="--check-color: {{ $catIsPopular ? '#fff' : 'hsl(var(--color-primary))' }};">
                                            {!! $catDescLists !!}
                                        </div>
                                    </article>
                                @endif
                            </div>
                        @endif

                        </div> 
                    </div>
                @endforeach
                </div>
            </div>

        @elseif($plansSource === 'specific_category' && isset($plansProducts) && $plansProducts->count() > 0)

            <div class="max-w-7xl mx-auto" x-data="{
                selectedTerm: '{{ $availableTerms[0]['key'] ?? '' }}',
                terms: @js($availableTerms ?? []),
                prices: @js($productPricesByTerm ?? []),
                getPrice(productId) {
                    const p = this.prices[productId];
                    if (!p) return null;
                    return p[this.selectedTerm] || null;
                },
                getBillingLabel(productId) {
                    const price = this.getPrice(productId);
                    if (!price) return '';
                    if (price.type === 'one-time') return '{{ __('citadel::citadel.plans.one_time_payment') }}';
                    const period = parseInt(price.billing_period);
                    const unit = price.billing_unit;
                    if (period === 1 && unit === 'month') return '{{ __('citadel::citadel.plans.billed_every_month') }}';
                    if (period === 1 && unit === 'year') return '{{ __('citadel::citadel.plans.billed_every_year') }}';
                    if (period === 1 && unit === 'day') return '{{ __('citadel::citadel.plans.billed_every_day') }}';
                    if (period === 3 && unit === 'month') return '{{ __('citadel::citadel.plans.billed_every_quarter') }}';
                    if (period === 6 && unit === 'month') return '{{ __('citadel::citadel.plans.billed_every_6_months') }}';
                    if (period === 12 && unit === 'month') return '{{ __('citadel::citadel.plans.billed_every_year') }}';
                    if (period === 1) return '{{ __('citadel::citadel.plans.billed_every') }}'.replace(':period', unit);
                    return '{{ __('citadel::citadel.plans.billed_every') }}'.replace(':period', period + ' ' + unit + 's');
                },
                getTermLabel(key) {
                    const term = this.terms.find(t => t.key === key);
                    return term ? term.label : '';
                }
            }">

                @if(count($availableTerms) > 1)
                    <div class="flex justify-center mb-10">
                        <div class="inline-flex items-center rounded-xl p-1.5 gap-1.5" style="background-color: hsl(var(--color-neutral) / 0.25); border-radius: var(--citadel-card-radius);">
                            <template x-for="term in terms" :key="term.key">
                                <button type="button"
                                    @click="selectedTerm = term.key"
                                    :style="selectedTerm === term.key
                                        ? 'background-color: hsl(var(--color-primary) / 0.2); color: hsl(var(--color-primary)); border-color: hsl(var(--color-primary) / 0.4); border-radius: var(--citadel-button-radius);'
                                        : 'background-color: hsl(var(--color-neutral) / 0.15); color: hsl(var(--color-base) / 0.6); border-color: transparent; border-radius: var(--citadel-button-radius);'"
                                    class="px-5 py-2 rounded-lg text-sm font-semibold transition-all duration-200 cursor-pointer border"
                                    :class="selectedTerm === term.key ? '' : 'hover:opacity-80'"
                                    x-text="term.label">
                                </button>
                            </template>
                        </div>
                    </div>
                @endif

                <div class="flex flex-wrap justify-center gap-5">
                @foreach($plansProducts as $prodIndex => $planProduct)
                    @php
                        $prodIsPopular = $plansPopular === ($prodIndex + 1);


                        $prodIconUrl = null;
                        $prodIconIsCitadel = false;
                        $prodIconName = null;
                        if ($plansCategory) {
                            if (isset($categoryIconOverrides[$plansCategory->id])) {
                                $prodIconName = $categoryIconOverrides[$plansCategory->id];
                                $prodIconUrl = asset('assets/icons/citadel/' . $prodIconName . '.svg');
                                $prodIconIsCitadel = true;
                            } elseif ($plansCategory->image) {
                                $prodIconUrl = Storage::url($plansCategory->image);
                            }
                        }
                        $hasIcon = $plansIconStyle !== 'none' && $prodIconUrl;
                    @endphp
                    <div class="{{ $prodIsPopular ? '' : 'bg-background-secondary' }} border rounded-xl {{ ($plansIconStyle === 'background' || $plansIconStyle === 'corner') && $hasIcon ? '' : 'p-6' }} flex flex-col w-full md:w-[calc(50%-0.625rem)] xl:w-[calc(25%-0.9375rem)] max-w-sm {{ $prodIsPopular ? (($plansIconStyle === 'background' || $plansIconStyle === 'corner') && $hasIcon ? '' : 'py-10') : ($plansPopular ? (($plansIconStyle === 'background' || $plansIconStyle === 'corner') && $hasIcon ? '' : 'md:pt-10') : '') }} relative overflow-hidden"
                        style="border-color: {{ $prodIsPopular ? 'hsl(var(--color-primary) / 0.5)' : 'hsl(var(--color-neutral))' }}; {{ $prodIsPopular ? 'background-color: hsl(var(--color-primary));' : '' }} border-radius: var(--citadel-card-radius);">


                        @if($plansIconStyle === 'background' && $hasIcon)
                            <div class="relative w-full h-32 mb-0">
                                <div class="absolute inset-0 flex items-center justify-center">
                                    @if($prodIconIsCitadel)
                                        <x-svg-icon name="citadel/{{ $prodIconName }}" class="w-full h-full p-6 object-contain" />
                                    @else
                                        <img src="{{ $prodIconUrl }}" alt="{{ $planProduct->name }}" class="w-full h-full object-cover" />
                                    @endif
                                </div>
                                <div class="absolute inset-0" style="background: linear-gradient(to top, {{ $prodIsPopular ? 'hsl(var(--color-primary))' : 'hsl(var(--color-background-secondary))' }} 0%, {{ $prodIsPopular ? 'hsl(var(--color-primary) / 0.85)' : 'hsl(var(--color-background-secondary) / 0.7)' }} 40%, {{ $prodIsPopular ? 'hsl(var(--color-primary) / 0.3)' : 'hsl(var(--color-background-secondary) / 0.2)' }} 100%);"></div>
                            </div>
                            <div class="p-6 pt-0 flex flex-col flex-1">
                        @elseif($plansIconStyle === 'corner' && $hasIcon)
                            <div class="absolute -top-4 -right-4 w-36 h-36 opacity-15 rotate-12 pointer-events-none">
                                @if($prodIconIsCitadel)
                                    <x-svg-icon name="citadel/{{ $prodIconName }}" class="w-full h-full" />
                                @else
                                    <img src="{{ $prodIconUrl }}" alt="" class="w-full h-full object-cover" />
                                @endif
                            </div>
                            <div class="p-6 {{ $prodIsPopular ? 'py-10' : ($plansPopular ? 'md:pt-10' : '') }} flex flex-col flex-1 relative z-[1]">
                        @else
                            <div class="flex flex-col flex-1">
                        @endif

                        @if($prodIsPopular)
                            <span class="absolute top-4 right-4 inline-flex items-center px-3 py-1 rounded-full text-xs font-bold z-[2]"
                                style="background-color: #fff; color: hsl(var(--color-primary));">
                                {{ __('citadel::citadel.plans.most_popular') }}
                            </span>
                        @endif


                        @if($plansIconStyle === 'top' && $hasIcon)
                            <div class="flex justify-center {{ $prodIsPopular ? 'mt-6' : ($plansPopular ? 'md:mt-6' : '') }} mb-4">
                                @if($prodIconIsCitadel)
                                    <x-svg-icon name="citadel/{{ $prodIconName }}" class="w-16 h-16" />
                                @else
                                    <img src="{{ $prodIconUrl }}" alt="{{ $planProduct->name }}" class="w-16 h-16 object-contain rounded-lg" style="{{ $prodIsPopular ? 'filter: brightness(0) invert(1);' : '' }} border-radius: var(--citadel-card-radius);" />
                                @endif
                            </div>
                        @endif


                        @if($plansIconStyle === 'right' && $hasIcon)
                            <div class="flex items-center justify-between {{ $prodIsPopular ? 'mt-6' : ($plansPopular ? 'md:mt-6' : '') }} mb-3">
                                <h3 class="text-2xl font-bold" style="color: {{ $prodIsPopular ? '#fff' : 'hsl(var(--color-base))' }};">
                                    {{ $planProduct->name }}
                                </h3>
                                @if($prodIconIsCitadel)
                                    <x-svg-icon name="citadel/{{ $prodIconName }}" class="w-14 h-14 flex-shrink-0" />
                                @else
                                    <img src="{{ $prodIconUrl }}" alt="{{ $planProduct->name }}" class="w-14 h-14 object-contain flex-shrink-0 rounded-lg" style="{{ $prodIsPopular ? 'filter: brightness(0) invert(1);' : '' }} border-radius: var(--citadel-card-radius);" />
                                @endif
                            </div>
                        @else
                            <h3 class="text-2xl font-bold {{ $plansIconStyle !== 'top' ? ($prodIsPopular ? 'mt-6' : ($plansPopular ? 'md:mt-6' : '')) : '' }} mb-3" style="color: {{ $prodIsPopular ? '#fff' : 'hsl(var(--color-base))' }};">
                                {{ $planProduct->name }}
                            </h3>
                        @endif


                        <div class="mb-6">
                            <template x-if="getPrice({{ $planProduct->id }})">
                                <div>
                                    <div class="mb-1 flex items-baseline gap-2 flex-wrap">
                                        <span class="text-2xl font-semibold" style="color: {{ $prodIsPopular ? '#fff' : 'hsl(var(--color-base))' }};"
                                            x-text="getPrice({{ $planProduct->id }}).price"></span>
                                    </div>
                                    <div class="flex items-center gap-2 flex-wrap mb-1" x-show="getPrice({{ $planProduct->id }}).original || getPrice({{ $planProduct->id }}).badge">
                                        <span class="text-sm font-medium line-through" style="color: {{ $prodIsPopular ? 'rgba(255,255,255,0.7)' : 'hsl(var(--color-base) / 0.45)' }};"
                                            x-show="getPrice({{ $planProduct->id }}).original"
                                            x-text="getPrice({{ $planProduct->id }}).original"></span>
                                        <span class="inline-flex items-center gap-1 rounded-md text-sm font-semibold px-1.5 py-1 whitespace-nowrap"
                                            style="background-color: hsl(var(--color-primary)); color: white;"
                                            x-show="getPrice({{ $planProduct->id }}).badge">
                                            <svg class="w-3 h-3 flex-shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8 8H8.01M2 5.2L2 9.67451C2 10.1637 2 10.4083 2.05526 10.6385C2.10425 10.8425 2.18506 11.0376 2.29472 11.2166C2.4184 11.4184 2.59135 11.5914 2.93726 11.9373L10.6059 19.6059C11.7939 20.7939 12.388 21.388 13.0729 21.6105C13.6755 21.8063 14.3245 21.8063 14.927 21.6105C15.612 21.388 16.2061 20.7939 17.3941 19.6059L19.6059 17.3941C20.7939 16.2061 21.388 15.612 21.6105 14.927C21.8063 14.3245 21.8063 13.6755 21.6105 13.0729C21.388 12.388 20.7939 11.7939 19.6059 10.6059L11.9373 2.93726C11.5914 2.59135 11.4184 2.4184 11.2166 2.29472C11.0376 2.18506 10.8425 2.10425 10.6385 2.05526C10.4083 2 10.1637 2 9.67452 2L5.2 2C4.0799 2 3.51984 2 3.09202 2.21799C2.7157 2.40973 2.40973 2.71569 2.21799 3.09202C2 3.51984 2 4.07989 2 5.2ZM8.5 8C8.5 8.27614 8.27614 8.5 8 8.5C7.72386 8.5 7.5 8.27614 7.5 8C7.5 7.72386 7.72386 7.5 8 7.5C8.27614 7.5 8.5 7.72386 8.5 8Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                            <span x-text="getPrice({{ $planProduct->id }}).badge"></span>
                                        </span>
                                    </div>
                                    <span class="text-xs font-medium" style="color: {{ $prodIsPopular ? 'rgba(255,255,255,0.7)' : 'hsl(var(--color-base) / 0.5)' }};"
                                        x-text="getBillingLabel({{ $planProduct->id }})"></span>
                                </div>
                            </template>
                            <template x-if="!getPrice({{ $planProduct->id }})">
                                <div>
                                    <span class="text-xs" style="color: {{ $prodIsPopular ? 'rgba(255,255,255,0.5)' : 'hsl(var(--color-base) / 0.5)' }};">—</span>
                                </div>
                            </template>
                        </div>


                        <a href="{{ route('products.checkout', ['category' => $plansCategory, 'product' => $planProduct->slug]) }}" wire:navigate
                            class="citadel-btn w-full inline-flex items-center justify-center px-4 rounded-lg text-sm font-medium transition-colors mb-6 {{ $prodIsPopular ? 'hover:opacity-90' : ($plansPopular ? '' : 'hover:opacity-90') }}"
                            style="{{ $prodIsPopular
                                ? 'background-color: #fff; color: hsl(var(--color-primary));'
                                : ($plansPopular
                                    ? 'background-color: hsl(var(--color-neutral)); color: hsl(var(--color-base)); border: 1.5px solid hsl(var(--color-neutral) / 0.6);'
                                    : 'background-color: hsl(var(--color-primary)); color: white;') }} border-radius: var(--citadel-button-radius);"
                            {{ !$prodIsPopular && $plansPopular ? 'onmouseover=this.style.opacity="0.8" onmouseout=this.style.opacity="1"' : '' }}>
                            {{ $plansButtonText }}
                        </a>


                        <div class="border-t-2 mb-6 {{ ($plansIconStyle === 'background' || $plansIconStyle === 'corner') && $hasIcon ? 'relative w-full' : 'relative -left-6 w-[calc(100%+3rem)]' }}" style="border-color: {{ $prodIsPopular ? 'rgba(255,255,255,0.2)' : 'hsl(var(--color-neutral) / 0.75)' }};"></div>


                        @if($planProduct->description)
                            @php
                                $prodDescHtml = $planProduct->description;
                                preg_match_all('/<(ul|ol)\b[^>]*>.*?<\/\1>/is', $prodDescHtml, $prodListMatches);
                                $prodDescLists = implode('', $prodListMatches[0] ?? []);
                                $prodDescText = trim(preg_replace('/<(ul|ol)\b[^>]*>.*?<\/\1>/is', '', $prodDescHtml));
                            @endphp
                            <div class="flex-1">
                                @if($prodDescText)
                                    <article class="prose dark:prose-invert prose-sm max-w-none text-left
                                        [&_p]:mb-2 [&_p]:text-sm [&_p]:leading-relaxed
                                        [&_strong]:font-semibold [&_strong]:text-sm"
                                        style="color: {{ $prodIsPopular ? 'rgba(255,255,255,0.85)' : 'hsl(var(--color-base) / 0.7)' }};">
                                        {!! $prodDescText !!}
                                    </article>
                                @endif
                                @if($prodDescLists)
                                    <h4 class="text-sm font-semibold {{ $prodDescText ? 'mt-4' : '' }} mb-4" style="color: {{ $prodIsPopular ? 'rgba(255,255,255,0.9)' : 'hsl(var(--color-base) / 0.8)' }};">{{ __('citadel::citadel.plans.whats_included') }}</h4>
                                    <article class="prose dark:prose-invert prose-sm max-w-none text-left
                                        [&_ol]:list-decimal [&_li]:mb-1.5 [&_li]:text-sm [&_li]:leading-relaxed
                                        [&_ol]:pl-5 [&_p]:mb-2 [&_li_p]:mb-0 [&_ul]:space-y-1.5
                                        [&_strong]:font-semibold [&_strong]:text-sm [&_p]:text-sm [&_p]:leading-relaxed"
                                        style="color: {{ $prodIsPopular ? 'rgba(255,255,255,0.85)' : 'hsl(var(--color-base) / 0.7)' }};">
                                        <div class="plans-check-list" style="--check-color: {{ $prodIsPopular ? '#fff' : 'hsl(var(--color-primary))' }};">
                                            {!! $prodDescLists !!}
                                        </div>
                                    </article>
                                @endif
                            </div>
                        @endif

                        </div> 
                    </div>
                @endforeach
                </div>
            </div>
        @endif
    </div>
</section>
