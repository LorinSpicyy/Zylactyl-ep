@php
    use Illuminate\Support\Facades\Storage;
    use Illuminate\Support\Str;
    
    $m2 = function ($k, $d = null) use ($block) {
        $map = ['features_title' => 'heading', 'features_description' => 'description'];
        $bk = $map[$k] ?? ('m2_' . $k);
        return $block[$bk] ?? theme('marketing2_' . $k, $d);
    };
@endphp

@php
    $featuresTitle = $m2('features_title', 'Every plan includes everything you need');
    $featuresDescription = $m2('features_description', 'Every plan comes fully loaded with all the essentials, powerful performance, reliable support, and zero hidden extras. Just pick your plan and get started.');
    $featuresIconBg = $m2('features_icon_bg', true);
    $featuresData = $m2('features_data', []);
    $featuresData = is_array($featuresData) ? $featuresData : (json_decode((string) $featuresData, true) ?: []);
@endphp

@if(count($featuresData) > 0)
<section class="py-16 md:py-24">
    <div class="w-full">

        <div class="text-center mb-12">
            <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4" style="color: hsl(var(--color-base));">
                {{ $featuresTitle }}
            </h2>
            @if($featuresDescription)
                <p class="text-sm sm:text-base max-w-2xl mx-auto leading-relaxed" style="color: hsl(var(--color-base) / 0.6);">
                    {{ $featuresDescription }}
                </p>
            @endif
        </div>

        <div class="max-w-7xl mx-auto">
            <div class="flex flex-wrap justify-center gap-6">
                @foreach($featuresData as $feature)
                    @php
                        $fTitle = $feature['title'] ?? '';
                        $fDesc = $feature['description'] ?? '';
                        $fIconType = $feature['icon_type'] ?? 'citadel';
                        $fIconCitadel = $feature['icon_citadel'] ?? '';
                        $fIconRemix = $feature['icon_remix'] ?? '';
                    @endphp
                    @if($fTitle)
                        <div class="w-full sm:w-[calc(50%-0.75rem)] xl:w-[calc(25%-1.125rem)] p-6 rounded-xl text-center" style="border-radius: var(--citadel-card-radius);">


                            <div class="mx-auto mb-4 flex items-center justify-center {{ $featuresIconBg ? 'w-20 h-20 rounded-2xl' : '' }}"
                                @if($featuresIconBg) style="background-color: hsl(var(--color-primary) / 0.1); border-radius: var(--citadel-card-radius);" @endif>
                                @if($fIconType === 'citadel' && $fIconCitadel)
                                    <x-citadel-icon :name="$fIconCitadel" class="{{ $featuresIconBg ? 'w-16 h-16' : 'w-16 h-16' }}" />
                                @elseif($fIconType === 'remix' && $fIconRemix)
                                    <x-dynamic-component :component="$fIconRemix" class="{{ $featuresIconBg ? 'size-10' : 'size-12' }}" style="color: hsl(var(--color-primary));" />
                                @else
                                    <x-ri-checkbox-circle-line class="{{ $featuresIconBg ? 'size-10' : 'size-12' }}" style="color: hsl(var(--color-primary));" />
                                @endif
                            </div>


                            <h3 class="text-base font-semibold mb-2" style="color: hsl(var(--color-base));">
                                {{ $fTitle }}
                            </h3>


                            @if($fDesc)
                                <p class="text-sm leading-relaxed" style="color: hsl(var(--color-base) / 0.6);">
                                    {{ $fDesc }}
                                </p>
                            @endif
                        </div>
                    @endif
                @endforeach
            </div>
        </div>

    </div>
</section>
@endif
