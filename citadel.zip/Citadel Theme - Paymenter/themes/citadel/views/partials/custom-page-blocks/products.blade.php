@php
    use Illuminate\Support\Facades\Storage;

    
    if (! empty($block['block_category_id'])) {
        try {
            $blockCat = \App\Models\Category::find((int) $block['block_category_id']);
            if ($blockCat) { $category = $blockCat; }
        } catch (\Throwable $e) {}
    }

    $heading      = $block['heading'] ?? '';
    $description  = $block['description'] ?? '';
    $buttonText   = $block['button_text'] ?? 'Get Started';
    $gridStyle    = $block['grid_style'] ?? 'grid1';
    $iconStyle    = $block['icon_style'] ?? 'none';
    $popular      = (int) ($block['popular'] ?? 0);
    $popularStyle = $block['popular_style'] ?? 'solid';
    $productIds   = $block['product_ids'] ?? [];
    $bottomButton = !empty($block['bottom_button']);
    $bottomButtonText = $block['bottom_button_text'] ?? '';
    $bottomButtonLink = $block['bottom_button_link'] ?? '';
    $bottomButtonExternal = filter_var($bottomButtonLink, FILTER_VALIDATE_URL) && ! str_starts_with($bottomButtonLink, url('/'));
    $bottomButtonAnchor = str_starts_with($bottomButtonLink, '#');

    
    $categoryIconOverrides = [];
    if (function_exists('theme') && theme('override_category_icons')) {
        $iconsData = json_decode(theme('category_icons_data', '[]'), true) ?: [];
        foreach ($iconsData as $entry) {
            if (!empty($entry['category_id']) && !empty($entry['icon'])) {
                $categoryIconOverrides[(int) $entry['category_id']] = $entry['icon'];
            }
        }
    }

    $products = collect();
    if (isset($category) && $category) {
        try {
            if (! empty($productIds)) {
                
                $fetched = \App\Models\Product::where('category_id', $category->id)
                    ->where('hidden', false)
                    ->with(['plans.prices'])
                    ->whereIn('id', $productIds)
                    ->get();
                $products = $fetched->sortBy(fn ($p) => array_search($p->id, $productIds))->values();
            } else {
                $products = \App\Models\Product::where('category_id', $category->id)
                    ->where('hidden', false)
                    ->with(['plans.prices'])
                    ->orderBy('sort')
                    ->orderBy('name')
                    ->limit(4)
                    ->get();
            }
        } catch (\Throwable $e) {
            $products = collect();
        }
    }

    
    $iconUrl = null;
    $iconIsCitadel = false;
    $iconName = null;
    if (isset($category) && $category) {
        if (isset($categoryIconOverrides[$category->id])) {
            $iconName = $categoryIconOverrides[$category->id];
            $iconUrl = asset('assets/icons/citadel/' . $iconName . '.svg');
            $iconIsCitadel = true;
        } elseif ($category->image) {
            $iconUrl = Storage::url($category->image);
        }
    }
    $hasIcon = $iconStyle !== 'none' && $iconUrl;

    
    $isDomainRegistration = isset($category)
        && $category
        && ($category->slug ?? null) === 'domain-registration'
        && class_exists(\Paymenter\Extensions\Servers\DomainNameAPI\Livewire\Products\DomainRegistration::class);

    
    $showTerms      = ! empty($block['show_terms']);
    $termPlans      = [];   
    $termLabels     = [];   
    $commonTermKeys = [];
    if ($showTerms && $products->count() > 0) {
        $termOrder = [];
        $intersect = null;
        foreach ($products as $ti => $tproduct) {
            $map = [];
            foreach ($tproduct->availablePlans() as $tplan) {
                $key = $tplan->type === 'recurring'
                    ? 'r-' . $tplan->billing_period . '-' . $tplan->billing_unit
                    : $tplan->type;
                if (! isset($map[$key])) {
                    $map[$key] = $tplan;
                    if (! isset($termLabels[$key])) {
                        if ($tplan->type === 'recurring') {
                            $adjectives = [
                                'day-1' => 'Daily', 'week-1' => 'Weekly', 'month-1' => 'Monthly',
                                'month-3' => 'Quarterly', 'month-6' => 'Semi-Annually',
                                'month-12' => 'Annually', 'year-1' => 'Annually', 'year-2' => 'Biennially',
                            ];
                            $adjKey = $tplan->billing_unit . '-' . (int) $tplan->billing_period;
                            if (isset($adjectives[$adjKey])) {
                                $termLabels[$key] = $adjectives[$adjKey];
                            } else {
                                $unit = trans_choice(__('services.billing_cycles.' . $tplan->billing_unit), (int) $tplan->billing_period);
                                $termLabels[$key] = $tplan->billing_period . ' ' . ucfirst($unit);
                            }
                            $days = ['day' => 1, 'week' => 7, 'month' => 30, 'year' => 365][$tplan->billing_unit] ?? 0;
                            $termOrder[$key] = $days * (int) $tplan->billing_period;
                        } elseif ($tplan->type === 'one-time') {
                            $termLabels[$key] = 'One-time';
                            $termOrder[$key] = PHP_INT_MAX - 1;
                        } else {
                            $termLabels[$key] = 'Free';
                            $termOrder[$key] = PHP_INT_MAX;
                        }
                    }
                }
            }
            $termPlans[$ti] = $map;
            $keys = array_keys($map);
            $intersect = $intersect === null ? $keys : array_intersect($intersect, $keys);
        }
        $commonTermKeys = array_values($intersect ?? []);
        usort($commonTermKeys, fn ($a, $b) => ($termOrder[$a] ?? 0) <=> ($termOrder[$b] ?? 0));
    }
    $useTerms       = $showTerms && count($commonTermKeys) > 1;
    $defaultTermKey = $useTerms ? $commonTermKeys[0] : null;
@endphp

@if ($isDomainRegistration)
    <section class="pt-14 pb-16 md:pt-16 md:pb-24">
        <div class="w-full">
            @if ($heading || $description)
                <div class="text-center mb-12">
                    @if ($heading)
                        <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4" style="color: hsl(var(--color-base));">
                            {{ $heading }}
                        </h2>
                    @endif
                    @if ($description)
                        <p class="text-sm sm:text-base max-w-2xl mx-auto leading-relaxed" style="color: hsl(var(--color-base) / 0.6);">
                            {{ $description }}
                        </p>
                    @endif
                </div>
            @endif

            
            <style>
                .citadel-cp-domain-search { max-width: 960px; margin-left: auto; margin-right: auto; }
                .citadel-cp-domain-search > .container { margin-top: 0 !important; padding-left: 0 !important; padding-right: 0 !important; max-width: 100% !important; }
                .citadel-cp-domain-search > .container > .mb-6 { display: none !important; }
                .citadel-cp-domain-search > .container > .flex.flex-col.md\:grid { display: block !important; grid-template-columns: none !important; }
                .citadel-cp-domain-search > .container > .flex.flex-col.md\:grid > div:first-child { display: none !important; }
                .citadel-cp-domain-search > .container > .flex.flex-col.md\:grid > div.col-span-3 { width: 100% !important; max-width: 100% !important; }
            </style>
            <div class="citadel-cp-domain-search">
                @livewire(\Paymenter\Extensions\Servers\DomainNameAPI\Livewire\Products\DomainRegistration::class)
            </div>
        </div>
    </section>
@elseif ($gridStyle === 'm2plans')
    @include('partials.custom-page-blocks._m2plans', ['block' => $block])
@elseif ($gridStyle === 'grid2' && $products->count() > 0)
@php
    $frontType      = $block['row_front_type'] ?? 'product_image';
    $priceStyle     = $block['row_price_style'] ?? 'style1';
    $specTemplate   = trim((string) ($block['row_spec_template'] ?? ''));
    $templateLabels = $specTemplate !== ''
        ? array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $specTemplate))))
        : [];
    $flags          = $block['row_front_flags'] ?? [];
    $flags          = is_array($flags) ? array_values(array_filter($flags)) : [];

    
    $popularEnabled = ! empty($block['row_popular_enabled']);
    $popularNum     = (int) ($block['row_popular_number'] ?? 0);
    $cpLightness = function ($val) {
        $s = str_replace(',', '', preg_replace('/^hsl\((.+)\)$/i', '$1', trim((string) $val)));
        $parts = preg_split('/\s+/', trim($s));
        return isset($parts[2]) ? (float) rtrim($parts[2], '%') : 50.0;
    };
    $lmPrimaryLight = $cpLightness(theme('primary', '220 90% 41%')) >= 62;
    $dmPrimaryLight = $cpLightness(theme('dark-primary', '220 90% 41%')) >= 62;
@endphp
@if ($popularEnabled)
<style>
    .cp2-pop {
        --cp2-text:   {{ $lmPrimaryLight ? 'rgba(17,17,17,0.95)' : '#ffffff' }};
        --cp2-muted:  {{ $lmPrimaryLight ? 'rgba(17,17,17,0.62)' : 'rgba(255,255,255,0.78)' }};
        --cp2-border: {{ $lmPrimaryLight ? 'rgba(17,17,17,0.14)' : 'rgba(255,255,255,0.24)' }};
    }
    .dark .cp2-pop {
        --cp2-text:   {{ $dmPrimaryLight ? 'rgba(17,17,17,0.95)' : '#ffffff' }};
        --cp2-muted:  {{ $dmPrimaryLight ? 'rgba(17,17,17,0.62)' : 'rgba(255,255,255,0.78)' }};
        --cp2-border: {{ $dmPrimaryLight ? 'rgba(17,17,17,0.14)' : 'rgba(255,255,255,0.24)' }};
    }
</style>
@endif
<section class="pt-14 pb-16 md:pt-16 md:pb-24">
    <div class="w-full">
        @if ($heading || $description)
            <div class="text-center mb-12">
                @if ($heading)
                    <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4" style="color: hsl(var(--color-base));">
                        {{ $heading }}
                    </h2>
                @endif
                @if ($description)
                    <p class="text-sm sm:text-base max-w-2xl mx-auto leading-relaxed" style="color: hsl(var(--color-base) / 0.6);">
                        {{ $description }}
                    </p>
                @endif
            </div>
        @endif

        <div class="max-w-6xl mx-auto flex flex-col gap-4"@if($useTerms) x-data="{ term: @js($defaultTermKey) }"@endif>
            @if ($useTerms)
                @include('partials.custom-page-blocks._term-switcher')
            @endif
            @foreach ($products as $pi => $product)
                @php
                    $priceObj    = $product->price();
                    $priceAvail  = $priceObj->available ?? false;
                    $priceLabel  = $priceAvail ? $priceObj->formatted->price : '';
                    $billingTerm = '';
                    $sale        = null;
                    if ($priceAvail) {
                        $ltp = theme('show_lowest_term_price', false) ? citadel_lowest_term_price($product) : null;
                        if ($ltp) {
                            $priceLabel = $ltp['formatted'];
                            $firstPlan = $ltp['plan'];
                        } else {
                            $sale = citadel_product_sale($product);
                            $firstPlan = $product->availablePlans()?->first();
                        }
                        if ($firstPlan && $firstPlan->type === 'recurring') {
                            if ($firstPlan->billing_period == 1) {
                                $billingTerm = trans_choice(__('services.billing_cycles.' . $firstPlan->billing_unit), 1);
                            } else {
                                $billingTerm = $firstPlan->billing_period . ' ' .
                                    trans_choice(__('services.billing_cycles.' . $firstPlan->billing_unit), $firstPlan->billing_period);
                            }
                        }
                    }

                    $imgUrl = $product->image ? Storage::url($product->image) : null;

                    
                    $specs = [];
                    if (!empty($templateLabels) && $product->description) {
                        $descPlain = preg_replace('/<\s*br\s*\/?>/i', "\n", $product->description);
                        $descPlain = preg_replace('/<\/(p|li|div|h[1-6]|tr)>/i', "\n", $descPlain);
                        $descPlain = strip_tags($descPlain);
                        $descPlain = html_entity_decode($descPlain, ENT_QUOTES);
                        $descPlain = str_replace("\xc2\xa0", ' ', $descPlain);
                        $descLines = preg_split('/\r\n|\r|\n/', $descPlain);
                        foreach ($templateLabels as $label) {
                            foreach ($descLines as $line) {
                                $line = trim($line);
                                if ($line === '') { continue; }
                                if (preg_match('/^' . preg_quote($label, '/') . '\s*[:：]\s*(.+)$/iu', $line, $m)) {
                                    $val = trim($m[1]);
                                    if ($val !== '') { $specs[$label] = $val; }
                                    break;
                                }
                            }
                        }
                    }

                    $rowLink = ($priceAvail && theme('direct_checkout', false))
                        ? route('products.checkout', ['category' => $category->slug, 'product' => $product->slug])
                        : route('products.show', ['category' => $category->slug, 'product' => $product->slug]);

                    $isPopular   = $popularEnabled && $popularNum === ($pi + 1);
                    $cText       = $isPopular ? 'var(--cp2-text)'   : 'hsl(var(--color-base))';
                    $cMuted      = $isPopular ? 'var(--cp2-muted)'  : 'hsl(var(--color-base) / 0.5)';
                    $cMutedSoft  = $isPopular ? 'var(--cp2-muted)'  : 'hsl(var(--color-base) / 0.7)';
                    $cMutedFaint = $isPopular ? 'var(--cp2-muted)'  : 'hsl(var(--color-base) / 0.45)';
                    $cDivider    = $isPopular ? 'var(--cp2-border)' : 'hsl(var(--color-neutral) / 0.5)';
                    $cCardClass  = $isPopular ? 'cp2-pop' : 'bg-background-secondary';
                    $cCardStyle  = $isPopular
                        ? 'background-color: hsl(var(--color-primary)); border-color: hsl(var(--color-primary));'
                        : 'border-color: hsl(var(--color-neutral));';
                    $cBtnStyle   = $isPopular
                        ? 'background-color: hsl(var(--color-background-secondary)); color: hsl(var(--color-base));'
                        : 'background-color: hsl(var(--color-primary)); color: #fff;';
                    $cSaleBadge  = $isPopular
                        ? 'background-color: hsl(var(--color-background-secondary)); color: hsl(var(--color-base));'
                        : 'background-color: hsl(var(--color-primary)); color: #fff;';
                    $cFlagGap     = $isPopular ? 'hsl(var(--color-primary))' : 'hsl(var(--color-background-secondary))';
                    $cFlagOutline = $isPopular ? 'var(--cp2-border)' : 'hsl(var(--color-neutral))';
                @endphp

                <div class="{{ $cCardClass }} border overflow-hidden flex flex-col md:flex-row"
                     style="{{ $cCardStyle }} border-radius: var(--citadel-card-radius);">

                    
                    <div class="flex-1 min-w-0 flex flex-col">
                        
                        <div class="px-5 pt-3.5 pb-3 flex items-center gap-2 flex-wrap">
                            <h3 class="text-lg lg:text-xl font-bold leading-tight" style="color: {{ $cText }};">{{ $product->name }}</h3>
                            @if ($isPopular)
                                <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[0.65rem] font-bold uppercase tracking-wide whitespace-nowrap" style="background-color: hsl(var(--color-background-secondary)); color: hsl(var(--color-base));">{{ __('citadel::citadel.plans.most_popular') }}</span>
                            @endif
                        </div>

                        
                        <div class="mx-5 border-t" style="border-color: {{ $cDivider }};"></div>

                        
                        <div class="flex flex-col md:flex-row md:items-stretch flex-1">
                            @if ($frontType === 'product_image')
                                <div class="flex-shrink-0 flex items-center justify-center px-5 py-4 md:py-5 md:w-24 lg:w-28">
                                    @if ($imgUrl)
                                        <img src="{{ $imgUrl }}" alt="{{ $product->name }}" draggable="false" class="max-w-full max-h-12 md:max-h-10 lg:max-h-12 object-contain select-none pointer-events-none" />
                                    @else
                                        <svg class="w-8 h-8 select-none" viewBox="0 0 24 24" fill="none" style="color: {{ $cMutedFaint }};"><path d="M3 16L7 12L10 15L16 9L21 14M4 5H20V19H4V5Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                    @endif
                                </div>
                            @elseif ($frontType === 'location_flags' && ! empty($flags))
                                @php
                                    $maxFlags   = 6;
                                    $shownFlags = array_slice($flags, 0, $maxFlags);
                                    $extraFlags = count($flags) - count($shownFlags);
                                @endphp
                                <div class="flex-shrink-0 flex items-center justify-center md:justify-start px-5 py-4 md:py-5">
                                    @foreach ($shownFlags as $fi => $flag)
                                        <div class="size-9 rounded-full overflow-hidden {{ $fi > 0 ? '-ml-2.5' : '' }}" style="box-shadow: 0 0 0 2px {{ $cFlagGap }}, 0 0 0 3px {{ $cFlagOutline }};">
                                            <img src="{{ Storage::url($flag) }}" alt="" draggable="false" class="w-full h-full object-cover select-none pointer-events-none" />
                                        </div>
                                    @endforeach
                                    @if ($extraFlags > 0)
                                        <div class="size-9 rounded-full -ml-2.5 flex items-center justify-center text-xs font-bold" style="box-shadow: 0 0 0 2px {{ $cFlagGap }}, 0 0 0 3px {{ $cFlagOutline }}; background-color: {{ $isPopular ? 'hsl(var(--color-background-secondary))' : 'hsl(var(--color-neutral))' }}; color: {{ $isPopular ? 'hsl(var(--color-primary))' : 'hsl(var(--color-base))' }};">+{{ $extraFlags }}</div>
                                    @endif
                                </div>
                            @endif

                            @if (!empty($specs))
                                
                                <div class="mx-5 border-t md:hidden" style="border-color: {{ $cDivider }};"></div>
                                <div class="flex-1 grid grid-cols-2 md:flex md:flex-row md:items-stretch">
                                    @foreach ($specs as $label => $value)
                                        <div class="hidden md:block w-px self-stretch my-4 flex-shrink-0" style="background-color: {{ $cDivider }};"></div>
                                        <div class="md:flex-1 min-w-0 flex flex-col justify-center px-5 md:px-4 py-3 md:py-5">
                                            <span class="text-sm lg:text-base font-bold leading-tight truncate" style="color: {{ $cText }};">{{ $value }}</span>
                                            <span class="text-xs truncate" style="color: {{ $cMuted }};">{{ $label }}</span>
                                        </div>
                                    @endforeach
                                </div>
                            @elseif ($product->description)
                                <div class="mx-5 border-t md:hidden" style="border-color: {{ $cDivider }};"></div>
                                <div class="flex-1 min-w-0 flex flex-row md:items-stretch">
                                    <div class="hidden md:block w-px self-stretch my-4 flex-shrink-0" style="background-color: {{ $cDivider }};"></div>
                                    <div class="flex-1 min-w-0 flex flex-col justify-center px-5 py-4 md:py-5">
                                        <article class="prose dark:prose-invert prose-sm max-w-none text-left
                                            [&_p]:mb-1 [&_p]:text-sm [&_p]:leading-relaxed [&_ul]:mt-1 [&_li]:text-sm
                                            [&_strong]:font-semibold [&_strong]:!text-current"
                                            style="color: {{ $cMutedSoft }};">
                                            {!! $product->description !!}
                                        </article>
                                    </div>
                                </div>
                            @endif
                        </div>
                    </div>

                    
                    @if ($priceStyle === 'style1')
                        <div class="flex-shrink-0 w-full md:w-48 lg:w-52 flex flex-row md:flex-col items-center justify-between md:justify-center gap-3 px-5 md:px-6 py-4 md:py-5 border-t md:border-t-0" style="border-color: {{ $cDivider }};">
                            <div class="flex flex-col items-start md:items-center text-left md:text-center">
                                @if ($useTerms)
                                    @foreach ($commonTermKeys as $tk)
                                        @php
                                            $tplan2  = $termPlans[$pi][$tk];
                                            $tpo2    = $tplan2->price();
                                            $tAvail2 = $tpo2->available ?? false;
                                            $tPrice2 = $tAvail2 ? $tpo2->formatted->price : '';
                                            $tBill2  = '';
                                            if ($tplan2->type === 'recurring') {
                                                $tBill2 = $tplan2->billing_period == 1
                                                    ? trans_choice(__('services.billing_cycles.' . $tplan2->billing_unit), 1)
                                                    : $tplan2->billing_period . ' ' . trans_choice(__('services.billing_cycles.' . $tplan2->billing_unit), $tplan2->billing_period);
                                            }
                                            $tSale2 = $tAvail2 ? citadel_plan_sale($product, $tplan2) : null;
                                        @endphp
                                        <div x-show="term === @js($tk)" @if(! $loop->first) x-cloak @endif>
                                            <div class="flex items-baseline gap-1 justify-center">
                                                <span class="text-xl lg:text-2xl font-bold" style="color: {{ $cText }};">{{ $tPrice2 }}</span>
                                                @if ($tBill2)
                                                    <span class="text-xs lg:text-sm" style="color: {{ $cMuted }};">/{{ $tBill2 }}</span>
                                                @endif
                                            </div>
                                            @if ($tSale2)
                                                <div class="flex items-center gap-1.5 mt-1 flex-wrap justify-center">
                                                    <span class="text-xs lg:text-sm line-through" style="color: {{ $cMutedFaint }};">{{ $tSale2['original'] }}</span>
                                                    <span class="inline-flex items-center rounded-md text-xs font-semibold px-1.5 py-0.5 whitespace-nowrap" style="{{ $cSaleBadge }}">{{ $tSale2['badge'] }}</span>
                                                </div>
                                            @endif
                                        </div>
                                    @endforeach
                                @elseif ($priceLabel)
                                    <div class="flex items-baseline gap-1 justify-center">
                                        <span class="text-xl lg:text-2xl font-bold" style="color: {{ $cText }};">{{ $priceLabel }}</span>
                                        @if ($billingTerm)
                                            <span class="text-xs lg:text-sm" style="color: {{ $cMuted }};">/{{ $billingTerm }}</span>
                                        @endif
                                    </div>
                                    @if ($sale)
                                        <div class="flex items-center gap-1.5 mt-1 flex-wrap justify-center">
                                            <span class="text-xs lg:text-sm line-through" style="color: {{ $cMutedFaint }};">{{ $sale['original'] }}</span>
                                            <span class="inline-flex items-center rounded-md text-xs font-semibold px-1.5 py-0.5 whitespace-nowrap" style="{{ $cSaleBadge }}">{{ $sale['badge'] }}</span>
                                        </div>
                                    @endif
                                @endif
                            </div>
                            <a href="{{ $rowLink }}" wire:navigate
                               class="citadel-btn inline-flex items-center justify-center w-auto md:w-full flex-shrink-0 px-6 text-sm font-medium transition-all hover:opacity-90 whitespace-nowrap"
                               style="{{ $cBtnStyle }} border-radius: var(--citadel-button-radius);">
                                {{ $buttonText }}
                            </a>
                        </div>
                    @endif
                </div>
            @endforeach
        </div>

        @if ($bottomButton && $bottomButtonText && $bottomButtonLink)
            <div class="flex justify-center mt-10">
                <a href="{{ $bottomButtonLink }}" @if($bottomButtonExternal) target="_blank" rel="noopener noreferrer" @elseif(! $bottomButtonAnchor) wire:navigate @endif
                   class="citadel-btn inline-flex items-center gap-2 px-8 text-sm font-medium border transition-all hover:opacity-90"
                   style="background-color: hsl(var(--color-neutral)); color: hsl(var(--color-base)); border-color: hsl(var(--color-neutral) / 0.6); border-radius: var(--citadel-button-radius);">
                    {{ $bottomButtonText }}
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-4 shrink-0"><path d="M16.1716 10.9999L10.8076 5.63589L12.2218 4.22168L20 11.9999L12.2218 19.778L10.8076 18.3638L16.1716 12.9999H4V10.9999H16.1716Z"/></svg>
                </a>
            </div>
        @endif

        @include('partials.custom-page-blocks._section-footer')
    </div>
</section>
@elseif ($products->count() > 0)
<section class="pt-14 pb-16 md:pt-16 md:pb-24">
    <div class="w-full">
        @if ($heading || $description)
            <div class="text-center mb-12">
                @if ($heading)
                    <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4" style="color: hsl(var(--color-base));">
                        {{ $heading }}
                    </h2>
                @endif
                @if ($description)
                    <p class="text-sm sm:text-base max-w-2xl mx-auto leading-relaxed" style="color: hsl(var(--color-base) / 0.6);">
                        {{ $description }}
                    </p>
                @endif
            </div>
        @endif

        <style>
            .cp-plans-check-list ul { list-style: none !important; padding-left: 0 !important; }
            .cp-plans-check-list ul li { display: flex !important; align-items: flex-start !important; gap: 10px; }
            .cp-plans-check-list ul li > p { display: inline !important; margin: 0 !important; }
            .cp-plans-check-list ul li::before {
                content: ''; flex-shrink: 0; display: block; width: 18px; min-width: 18px; height: 18px;
                margin-top: 2px; background-color: var(--check-color);
                -webkit-mask-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='18' height='18' viewBox='0 0 18 18' fill='none'%3E%3Ccircle cx='9' cy='9' r='7.5' stroke='currentColor' stroke-width='1.5'/%3E%3Cpath d='M6.75 9L8.25 10.5L11.25 7.5' stroke='currentColor' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
                mask-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='18' height='18' viewBox='0 0 18 18' fill='none'%3E%3Ccircle cx='9' cy='9' r='7.5' stroke='currentColor' stroke-width='1.5'/%3E%3Cpath d='M6.75 9L8.25 10.5L11.25 7.5' stroke='currentColor' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
                -webkit-mask-repeat: no-repeat; mask-repeat: no-repeat;
                -webkit-mask-size: contain; mask-size: contain;
            }
            @php
                $dgBgLight  = str_replace(',', '', preg_replace('/^hsl\((.+)\)$/', '$1', theme('dark-background-secondary', '217 33% 16%')));
                $dgBgDark   = str_replace(',', '', preg_replace('/^hsl\((.+)\)$/', '$1', theme('background-secondary',      '0 0% 97%')));
                $dgTextDark = str_replace(',', '', preg_replace('/^hsl\((.+)\)$/', '$1', theme('base',    '0 0% 0%')));
                $dgNeutral  = str_replace(',', '', preg_replace('/^hsl\((.+)\)$/', '$1', theme('neutral', '220 25% 85%')));
            @endphp
            
            .cp-dark-grad-popular { background-color: hsl({{ $dgBgLight }}) !important; }
            .dark .cp-dark-grad-popular { background-color: hsl({{ $dgBgDark }}) !important; }
            
            .cp-dark-grad-popular {
                --cp-pop-text:       rgba(255,255,255,0.95);
                --cp-pop-text-90:    rgba(255,255,255,0.9);
                --cp-pop-text-85:    rgba(255,255,255,0.85);
                --cp-pop-text-70:    rgba(255,255,255,0.7);
                --cp-pop-border:     rgba(255,255,255,0.2);
                --cp-pop-check:      #fff;
                --cp-pop-btn-bg:     #fff;
                --cp-pop-btn-color:  hsl(var(--color-primary));
                --cp-pop-badge-bg:   #fff;
                --cp-pop-badge-color: hsl(var(--color-primary));
            }
            
            .dark .cp-dark-grad-popular {
                --cp-pop-text:       hsl({{ $dgTextDark }});
                --cp-pop-text-90:    hsl({{ $dgTextDark }} / 0.9);
                --cp-pop-text-85:    hsl({{ $dgTextDark }} / 0.85);
                --cp-pop-text-70:    hsl({{ $dgTextDark }} / 0.7);
                --cp-pop-border:     hsl({{ $dgNeutral }} / 0.75);
                --cp-pop-check:      hsl(var(--color-primary));
                --cp-pop-btn-bg:     hsl(var(--color-primary));
                --cp-pop-btn-color:  #fff;
                --cp-pop-badge-bg:   hsl(var(--color-primary));
                --cp-pop-badge-color: #fff;
            }
        </style>

        @php
            
            if ($popularStyle === 'dark_gradient') {
                $pText      = 'var(--cp-pop-text)';
                $pText90    = 'var(--cp-pop-text-90)';
                $pText85    = 'var(--cp-pop-text-85)';
                $pText70    = 'var(--cp-pop-text-70)';
                $pBorder    = 'var(--cp-pop-border)';
                $pCheck     = 'var(--cp-pop-check)';
                $pBtnBg     = 'var(--cp-pop-btn-bg)';
                $pBtnColor  = 'var(--cp-pop-btn-color)';
                $pBadgeBg   = 'var(--cp-pop-badge-bg)';
                $pBadgeColor = 'var(--cp-pop-badge-color)';
            } else {
                $pText      = '#fff';
                $pText90    = 'rgba(255,255,255,0.9)';
                $pText85    = 'rgba(255,255,255,0.85)';
                $pText70    = 'rgba(255,255,255,0.7)';
                $pBorder    = 'rgba(255,255,255,0.2)';
                $pCheck     = '#fff';
                $pBtnBg     = '#fff';
                $pBtnColor  = 'hsl(var(--color-primary))';
                $pBadgeBg   = '#fff';
                $pBadgeColor = 'hsl(var(--color-primary))';
            }
        @endphp

        <div class="max-w-7xl mx-auto"@if($useTerms) x-data="{ term: @js($defaultTermKey) }"@endif>
            @if ($useTerms)
                @include('partials.custom-page-blocks._term-switcher')
            @endif
            <div class="flex flex-wrap justify-center gap-5">
                @foreach ($products as $i => $product)
                    @php
                        $isPopular = $popular === ($i + 1);
                        $cardBg = $isPopular ? match ($popularStyle) {
                            'gradient'      => 'background: linear-gradient(135deg, hsl(var(--color-primary)) 0%, hsl(var(--color-primary) / 0.6) 100%);',
                            'dark_gradient' => '',
                            default         => 'background-color: hsl(var(--color-primary));',
                        } : '';
                        $cardExtraClass = ($isPopular && $popularStyle === 'dark_gradient') ? 'cp-dark-grad-popular' : '';

                        $price = '';
                        $billingTerm = '';
                        $sale = null;
                        if ($product->price()->available ?? false) {
                            $ltp = theme('show_lowest_term_price', false) ? citadel_lowest_term_price($product) : null;
                            if ($ltp) {
                                $price = $ltp['formatted'];
                                $plan = $ltp['plan'];
                            } else {
                                $price = $product->price()->formatted->price;
                                $sale = citadel_product_sale($product);
                                $plan = $product->availablePlans()?->first();
                            }
                            if ($plan && $plan->type === 'recurring') {
                                if ($plan->billing_period == 1) {
                                    $billingTerm = trans_choice(__('services.billing_cycles.' . $plan->billing_unit), 1);
                                } else {
                                    $billingTerm = $plan->billing_period . ' ' .
                                        trans_choice(__('services.billing_cycles.' . $plan->billing_unit), $plan->billing_period);
                                }
                            }
                        }
                    @endphp
                    <div class="{{ $isPopular ? '' : 'bg-background-secondary' }} {{ $cardExtraClass }} border rounded-xl {{ ($iconStyle === 'background' || $iconStyle === 'corner') && $hasIcon ? '' : 'p-6' }} flex flex-col w-full md:w-[calc(50%-0.625rem)] xl:w-[calc(25%-0.9375rem)] max-w-sm {{ $isPopular ? (($iconStyle === 'background' || $iconStyle === 'corner') && $hasIcon ? '' : 'py-10') : ($popular ? (($iconStyle === 'background' || $iconStyle === 'corner') && $hasIcon ? '' : 'md:pt-10') : '') }} relative overflow-hidden"
                         style="border-color: {{ $isPopular ? 'hsl(var(--color-primary) / 0.5)' : 'hsl(var(--color-neutral))' }}; {{ $cardBg }} border-radius: var(--citadel-card-radius);">

                        @if ($isPopular && $popularStyle === 'dark_gradient')
                            <div class="absolute inset-0 pointer-events-none" style="background: radial-gradient(125% 125% at 50% 90%, transparent 40%, hsl(var(--color-primary) / 0.65) 100%); z-index: 0;"></div>
                        @endif

                        @if ($isPopular)
                            <span class="absolute top-4 right-4 inline-flex items-center px-3 py-1 rounded-full text-xs font-bold z-[3]"
                                  style="background-color: {{ $pBadgeBg }}; color: {{ $pBadgeColor }};">
                                {{ __('citadel::citadel.plans.most_popular') }}
                            </span>
                        @endif

                        @if ($iconStyle === 'background' && $hasIcon)
                            <div class="relative w-full h-32 mb-0">
                                <div class="absolute inset-0 flex items-center justify-center">
                                    @if ($iconIsCitadel)
                                        <x-svg-icon name="citadel/{{ $iconName }}" class="w-full h-full p-6 object-contain" />
                                    @else
                                        <img src="{{ $iconUrl }}" alt="{{ $product->name }}" class="w-full h-full object-cover" />
                                    @endif
                                </div>
                                <div class="absolute inset-0" style="background: linear-gradient(to top, {{ $isPopular ? 'hsl(var(--color-primary))' : 'hsl(var(--color-background-secondary))' }} 0%, {{ $isPopular ? 'hsl(var(--color-primary) / 0.85)' : 'hsl(var(--color-background-secondary) / 0.7)' }} 40%, {{ $isPopular ? 'hsl(var(--color-primary) / 0.3)' : 'hsl(var(--color-background-secondary) / 0.2)' }} 100%);"></div>
                            </div>
                            <div class="p-6 pt-0 flex flex-col flex-1 relative z-[1]">
                        @elseif ($iconStyle === 'corner' && $hasIcon)
                            <div class="absolute -top-4 -right-4 w-36 h-36 opacity-15 rotate-12 pointer-events-none">
                                @if ($iconIsCitadel)
                                    <x-svg-icon name="citadel/{{ $iconName }}" class="w-full h-full" />
                                @else
                                    <img src="{{ $iconUrl }}" alt="" class="w-full h-full object-cover" />
                                @endif
                            </div>
                            <div class="p-6 {{ $isPopular ? 'py-10' : ($popular ? 'md:pt-10' : '') }} flex flex-col flex-1 relative z-[1]">
                        @else
                            <div class="flex flex-col flex-1 relative z-[1]">
                        @endif

                        @if ($iconStyle === 'top' && $hasIcon)
                            <div class="flex justify-center {{ $isPopular ? 'mt-6' : ($popular ? 'md:mt-6' : '') }} mb-4">
                                @if ($iconIsCitadel)
                                    <x-svg-icon name="citadel/{{ $iconName }}" class="w-16 h-16" />
                                @else
                                    <img src="{{ $iconUrl }}" alt="{{ $product->name }}" class="w-16 h-16 object-contain rounded-lg" style="{{ $isPopular ? 'filter: brightness(0) invert(1);' : '' }} border-radius: var(--citadel-card-radius);" />
                                @endif
                            </div>
                        @endif

                        @if ($iconStyle === 'right' && $hasIcon)
                            <div class="flex items-center justify-between {{ $isPopular ? 'mt-6' : ($popular ? 'md:mt-6' : '') }} mb-3">
                                <h3 class="text-2xl font-bold" style="color: {{ $isPopular ? $pText : 'hsl(var(--color-base))' }};">
                                    {{ $product->name }}
                                </h3>
                                @if ($iconIsCitadel)
                                    <x-svg-icon name="citadel/{{ $iconName }}" class="w-14 h-14 flex-shrink-0" />
                                @else
                                    <img src="{{ $iconUrl }}" alt="{{ $product->name }}" class="w-14 h-14 object-contain flex-shrink-0 rounded-lg" style="{{ $isPopular ? 'filter: brightness(0) invert(1);' : '' }} border-radius: var(--citadel-card-radius);" />
                                @endif
                            </div>
                        @else
                            <h3 class="text-2xl font-bold {{ $iconStyle !== 'top' ? ($isPopular ? 'mt-6' : ($popular ? 'md:mt-6' : '')) : '' }} mb-3" style="color: {{ $isPopular ? $pText : 'hsl(var(--color-base))' }};">
                                {{ $product->name }}
                            </h3>
                        @endif

                        @if ($useTerms)
                            <div class="mb-6">
                                <p class="text-xs mb-2" style="color: {{ $isPopular ? $pText70 : 'hsl(var(--color-base) / 0.5)' }};">{{ __('citadel::citadel.plans.starting_at') }}</p>
                                @foreach ($commonTermKeys as $tk)
                                    @php
                                        $tplan1  = $termPlans[$i][$tk];
                                        $tpo1    = $tplan1->price();
                                        $tAvail1 = $tpo1->available ?? false;
                                        $tPrice1 = $tAvail1 ? $tpo1->formatted->price : '';
                                        $tBill1  = '';
                                        if ($tplan1->type === 'recurring') {
                                            $tBill1 = $tplan1->billing_period == 1
                                                ? trans_choice(__('services.billing_cycles.' . $tplan1->billing_unit), 1)
                                                : $tplan1->billing_period . ' ' . trans_choice(__('services.billing_cycles.' . $tplan1->billing_unit), $tplan1->billing_period);
                                        }
                                        $tSale1 = $tAvail1 ? citadel_plan_sale($product, $tplan1) : null;
                                    @endphp
                                    <div x-show="term === @js($tk)" @if(! $loop->first) x-cloak @endif>
                                        <div class="flex items-baseline gap-1.5 flex-wrap">
                                            <span class="text-2xl font-semibold" style="color: {{ $isPopular ? $pText : 'hsl(var(--color-base))' }};">{{ $tPrice1 }}</span>
                                            @if ($tBill1)
                                                <span class="text-sm font-medium" style="color: {{ $isPopular ? $pText70 : 'hsl(var(--color-base) / 0.5)' }};">/{{ $tBill1 }}</span>
                                            @endif
                                        </div>
                                        @if ($tSale1)
                                            <div class="flex items-center gap-1.5 flex-wrap mt-1">
                                                <span class="text-sm font-medium line-through" style="color: {{ $isPopular ? $pText70 : 'hsl(var(--color-base) / 0.45)' }};">{{ $tSale1['original'] }}</span>
                                                <span class="inline-flex items-center gap-1 rounded-md text-sm font-semibold px-1.5 py-1 whitespace-nowrap" style="background-color: hsl(var(--color-primary)); color: white;"><svg class="w-3 h-3 flex-shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8 8H8.01M2 5.2L2 9.67451C2 10.1637 2 10.4083 2.05526 10.6385C2.10425 10.8425 2.18506 11.0376 2.29472 11.2166C2.4184 11.4184 2.59135 11.5914 2.93726 11.9373L10.6059 19.6059C11.7939 20.7939 12.388 21.388 13.0729 21.6105C13.6755 21.8063 14.3245 21.8063 14.927 21.6105C15.612 21.388 16.2061 20.7939 17.3941 19.6059L19.6059 17.3941C20.7939 16.2061 21.388 15.612 21.6105 14.927C21.8063 14.3245 21.8063 13.6755 21.6105 13.0729C21.388 12.388 20.7939 11.7939 19.6059 10.6059L11.9373 2.93726C11.5914 2.59135 11.4184 2.4184 11.2166 2.29472C11.0376 2.18506 10.8425 2.10425 10.6385 2.05526C10.4083 2 10.1637 2 9.67452 2L5.2 2C4.0799 2 3.51984 2 3.09202 2.21799C2.7157 2.40973 2.40973 2.71569 2.21799 3.09202C2 3.51984 2 4.07989 2 5.2ZM8.5 8C8.5 8.27614 8.27614 8.5 8 8.5C7.72386 8.5 7.5 8.27614 7.5 8C7.5 7.72386 7.72386 7.5 8 7.5C8.27614 7.5 8.5 7.72386 8.5 8Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>{{ $tSale1['badge'] }}</span>
                                            </div>
                                        @endif
                                    </div>
                                @endforeach
                            </div>
                        @elseif ($price)
                            <div class="mb-6">
                                <p class="text-xs mb-2" style="color: {{ $isPopular ? $pText70 : 'hsl(var(--color-base) / 0.5)' }};">{{ __('citadel::citadel.plans.starting_at') }}</p>
                                <div class="flex items-baseline gap-1.5 flex-wrap">
                                    <span class="text-2xl font-semibold" style="color: {{ $isPopular ? $pText : 'hsl(var(--color-base))' }};">{{ $price }}</span>
                                    @if ($billingTerm)
                                        <span class="text-sm font-medium" style="color: {{ $isPopular ? $pText70 : 'hsl(var(--color-base) / 0.5)' }};">/{{ $billingTerm }}</span>
                                    @endif
                                </div>
                                @if ($sale)
                                    <div class="flex items-center gap-1.5 flex-wrap mt-1">
                                        <span class="text-sm font-medium line-through" style="color: {{ $isPopular ? $pText70 : 'hsl(var(--color-base) / 0.45)' }};">{{ $sale['original'] }}</span>
                                        <span class="inline-flex items-center gap-1 rounded-md text-sm font-semibold px-1.5 py-1 whitespace-nowrap" style="background-color: hsl(var(--color-primary)); color: white;"><svg class="w-3 h-3 flex-shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8 8H8.01M2 5.2L2 9.67451C2 10.1637 2 10.4083 2.05526 10.6385C2.10425 10.8425 2.18506 11.0376 2.29472 11.2166C2.4184 11.4184 2.59135 11.5914 2.93726 11.9373L10.6059 19.6059C11.7939 20.7939 12.388 21.388 13.0729 21.6105C13.6755 21.8063 14.3245 21.8063 14.927 21.6105C15.612 21.388 16.2061 20.7939 17.3941 19.6059L19.6059 17.3941C20.7939 16.2061 21.388 15.612 21.6105 14.927C21.8063 14.3245 21.8063 13.6755 21.6105 13.0729C21.388 12.388 20.7939 11.7939 19.6059 10.6059L11.9373 2.93726C11.5914 2.59135 11.4184 2.4184 11.2166 2.29472C11.0376 2.18506 10.8425 2.10425 10.6385 2.05526C10.4083 2 10.1637 2 9.67452 2L5.2 2C4.0799 2 3.51984 2 3.09202 2.21799C2.7157 2.40973 2.40973 2.71569 2.21799 3.09202C2 3.51984 2 4.07989 2 5.2ZM8.5 8C8.5 8.27614 8.27614 8.5 8 8.5C7.72386 8.5 7.5 8.27614 7.5 8C7.5 7.72386 7.72386 7.5 8 7.5C8.27614 7.5 8.5 7.72386 8.5 8Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>{{ $sale['badge'] }}</span>
                                    </div>
                                @endif
                            </div>
                        @endif

                        @if (($product->stock > 0 || !$product->stock) && $product->price()->available && theme('direct_checkout', false))
                        <a href="{{ route('products.checkout', ['category' => $category->slug, 'product' => $product->slug]) }}" wire:navigate
                           class="citadel-btn w-full inline-flex items-center justify-center px-4 rounded-lg text-sm font-medium transition-all mb-6 hover:opacity-90"
                           style="{{ $isPopular
                               ? 'background-color: ' . $pBtnBg . '; color: ' . $pBtnColor . ';'
                               : ($popular
                                   ? 'background-color: hsl(var(--color-neutral)); color: hsl(var(--color-base)); border: 1.5px solid hsl(var(--color-neutral) / 0.6);'
                                   : 'background-color: hsl(var(--color-primary)); color: white;') }} border-radius: var(--citadel-button-radius);">
                            {{ $buttonText }}
                        </a>
                        @else
                        <a href="{{ route('products.show', ['category' => $category->slug, 'product' => $product->slug]) }}" wire:navigate
                           class="citadel-btn w-full inline-flex items-center justify-center px-4 rounded-lg text-sm font-medium transition-all mb-6 hover:opacity-90"
                           style="{{ $isPopular
                               ? 'background-color: ' . $pBtnBg . '; color: ' . $pBtnColor . ';'
                               : ($popular
                                   ? 'background-color: hsl(var(--color-neutral)); color: hsl(var(--color-base)); border: 1.5px solid hsl(var(--color-neutral) / 0.6);'
                                   : 'background-color: hsl(var(--color-primary)); color: white;') }} border-radius: var(--citadel-button-radius);">
                            {{ $buttonText }}
                        </a>
                        @endif

                        <div class="border-t-2 mb-6 {{ ($iconStyle === 'background' || $iconStyle === 'corner') && $hasIcon ? 'relative w-full' : 'relative -left-6 w-[calc(100%+3rem)]' }}" style="border-color: {{ $isPopular ? $pBorder : 'hsl(var(--color-neutral) / 0.75)' }};"></div>

                        @if ($product->description)
                            @php
                                $descHtml = $product->description;
                                preg_match_all('/<(ul|ol)\b[^>]*>.*?<\/\1>/is', $descHtml, $listMatches);
                                $descLists = implode('', $listMatches[0] ?? []);
                                $descText = trim(preg_replace('/<(ul|ol)\b[^>]*>.*?<\/\1>/is', '', $descHtml));
                            @endphp
                            <div class="flex-1">
                                @if ($descText)
                                    <article class="prose dark:prose-invert prose-sm max-w-none text-left
                                        [&_p]:mb-2 [&_p]:text-sm [&_p]:leading-relaxed
                                        [&_strong]:font-semibold [&_strong]:text-sm [&_strong]:!text-current"
                                        style="color: {{ $isPopular ? $pText85 : 'hsl(var(--color-base) / 0.7)' }};">
                                        {!! $descText !!}
                                    </article>
                                @endif
                                @if ($descLists)
                                    <h4 class="text-sm font-semibold {{ $descText ? 'mt-4' : '' }} mb-4" style="color: {{ $isPopular ? $pText90 : 'hsl(var(--color-base) / 0.8)' }};">{{ __('citadel::citadel.plans.whats_included') }}</h4>
                                    <article class="prose dark:prose-invert prose-sm max-w-none text-left
                                        [&_ol]:list-decimal [&_li]:mb-1.5 [&_li]:text-sm [&_li]:leading-relaxed
                                        [&_ol]:pl-5 [&_p]:mb-2 [&_li_p]:mb-0 [&_ul]:space-y-1.5
                                        [&_strong]:font-semibold [&_strong]:text-sm [&_strong]:!text-current [&_p]:text-sm [&_p]:leading-relaxed"
                                        style="color: {{ $isPopular ? $pText85 : 'hsl(var(--color-base) / 0.7)' }};">
                                        <div class="cp-plans-check-list" style="--check-color: {{ $isPopular ? $pCheck : 'hsl(var(--color-primary))' }};">
                                            {!! $descLists !!}
                                        </div>
                                    </article>
                                @endif
                            </div>
                        @endif

                        </div>
                    </div>
                @endforeach
            </div>

            @if ($bottomButton && $bottomButtonText && $bottomButtonLink)
                <div class="flex justify-center mt-10">
                    <a href="{{ $bottomButtonLink }}" @if($bottomButtonExternal) target="_blank" rel="noopener noreferrer" @elseif(! $bottomButtonAnchor) wire:navigate @endif
                       class="citadel-btn inline-flex items-center gap-2 px-8 text-sm font-medium border transition-all hover:opacity-90"
                       style="background-color: hsl(var(--color-neutral)); color: hsl(var(--color-base)); border-color: hsl(var(--color-neutral) / 0.6); border-radius: var(--citadel-button-radius);">
                        {{ $bottomButtonText }}
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-4 shrink-0"><path d="M16.1716 10.9999L10.8076 5.63589L12.2218 4.22168L20 11.9999L12.2218 19.778L10.8076 18.3638L16.1716 12.9999H4V10.9999H16.1716Z"/></svg>
                    </a>
                </div>
            @endif

            @include('partials.custom-page-blocks._section-footer')
        </div>
    </div>
</section>
@endif
