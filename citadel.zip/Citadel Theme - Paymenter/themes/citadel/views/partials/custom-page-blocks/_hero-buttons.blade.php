
@php
    $hbContext   = $btnContext ?? 'base';
    $hbIconBg    = $btnIconBg ?? 'hsl(var(--color-primary))';
    
    $hbIconColor = $btnIconColor ?? '#ffffff';

    $hbDefaultLink = '#';
    if (isset($category) && $category) {
        try { $hbDefaultLink = route('category.show', ['category' => $category->slug]); } catch (\Throwable $e) {}
    }

    $hbButtons = [];
    foreach ([
        ['text' => $block['button_text']  ?? '', 'link' => $block['button_link']  ?? '', 'icon' => $block['button_icon']  ?? '', 'style' => $block['button_style']  ?? 'primary',   'pos' => $block['button_icon_position']  ?? 'before', 'iconbg' => ! empty($block['button_icon_bg'])],
        ['text' => $block['button2_text'] ?? '', 'link' => $block['button2_link'] ?? '', 'icon' => $block['button2_icon'] ?? '', 'style' => $block['button2_style'] ?? 'secondary', 'pos' => $block['button2_icon_position'] ?? 'before', 'iconbg' => ! empty($block['button2_icon_bg'])],
    ] as $hbB) {
        $hbText = trim((string) $hbB['text']);
        if ($hbText === '') {
            continue;
        }
        $hbLink     = trim((string) $hbB['link']);
        $hbResolved = $hbLink !== '' ? $hbLink : $hbDefaultLink;

        $iconRaw  = trim((string) $hbB['icon']);
        $hbPos    = $hbB['pos'] ?: 'before';
        $iconHtml = '';
        $hbPad    = '';
        $hbChip   = false;
        if ($iconRaw !== '') {
            if ($hbB['iconbg']) {
                
                $hbChip   = true;
                $hbSide   = $hbPos === 'after' ? 'right' : 'left';
                $iconHtml = '<span class="citadel-hero-btn-ico citadel-hero-btn-chip inline-flex items-center justify-center" style="position:absolute;top:0.25rem;bottom:0.25rem;' . $hbSide . ':0.25rem;aspect-ratio:1;background:' . $hbIconBg . ';color:' . $hbIconColor . ';border-radius:var(--citadel-button-radius);">' . $iconRaw . '</span>';
                $hbPad    = 'position:relative;' . ($hbPos === 'after'
                    ? 'padding-right:calc(1.5rem + 2 * var(--citadel-button-py));padding-left:0.75rem;'
                    : 'padding-left:calc(1.5rem + 2 * var(--citadel-button-py));padding-right:0.75rem;');
            } else {
                $iconHtml = '<span class="citadel-hero-btn-ico inline-flex items-center justify-center shrink-0">' . $iconRaw . '</span>';
            }
        }

        $hbButtons[] = [
            'text'     => $hbText,
            'link'     => $hbResolved,
            'iconHtml' => $iconHtml,
            'pos'      => $hbPos,
            'pad'      => $hbPad,
            'chip'     => $hbChip,
            'style'    => $hbB['style'] ?: 'primary',
            'external' => filter_var($hbResolved, FILTER_VALIDATE_URL) && ! str_starts_with($hbResolved, url('/')),
            'anchor'   => str_starts_with($hbResolved, '#'),
        ];
    }

    
    $hbStyleCss = function (string $style): string {
        if ($style === 'secondary') {
            return 'background-color: hsl(var(--color-background-secondary)); color: hsl(var(--color-base)); border: 1px solid hsl(var(--color-neutral));';
        }
        return 'background-color: hsl(var(--color-primary)); color: #ffffff;';
    };
    
    $hbLinkColor = $hbContext === 'light' ? 'rgba(255,255,255,0.78)' : 'hsl(var(--color-base) / 0.62)';
@endphp

@if (! empty($hbButtons))
    <style>
        .citadel-hero-btn-ico svg{width:1.15rem;height:1.15rem;display:block;}
        .citadel-hero-btn-chip svg{width:60%;height:60%;}
        .citadel-hero-link .chl-inner{position:relative;}
        .citadel-hero-link .chl-inner::after{content:"";position:absolute;left:0;right:0;bottom:-3px;height:1.5px;background:currentColor;opacity:.7;transform:scaleX(0);transform-origin:left;transition:transform .25s ease;}
        .citadel-hero-link:hover .chl-inner::after{transform:scaleX(1);}
        .citadel-hero-link .chl-arrow{display:inline-flex;transition:transform .25s ease;}
        .citadel-hero-link .chl-arrow svg{width:1.05rem;height:1.05rem;display:block;}
        .citadel-hero-link:hover .chl-arrow{transform:translateX(.25rem);}
    </style>
    <div class="flex flex-wrap items-center gap-x-6 gap-y-3">
        @foreach ($hbButtons as $hb)
            @if ($hb['style'] === 'none')
                <a href="{{ $hb['link'] }}"
                   class="citadel-hero-link inline-flex items-center py-2 text-sm font-normal"
                   style="color: {{ $hbLinkColor }};"
                   @if ($hb['external']) target="_blank" rel="noopener noreferrer" @elseif (! $hb['anchor']) wire:navigate @endif>
                    <span class="chl-inner inline-flex items-center gap-2">
                        <span>{{ $hb['text'] }}</span>
                        <span class="chl-arrow shrink-0" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 12H20M20 12L14 6M20 12L14 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
                    </span>
                </a>
            @else
                <a href="{{ $hb['link'] }}"
                   class="citadel-btn inline-flex items-center justify-center gap-2 px-3 py-2 text-sm font-medium transition-all hover:opacity-90"
                   style="{{ $hbStyleCss($hb['style']) }} border-radius: var(--citadel-button-radius); {{ $hb['pad'] }}"
                   @if ($hb['external']) target="_blank" rel="noopener noreferrer" @elseif (! $hb['anchor']) wire:navigate @endif>
                    @if ($hb['chip']){!! $hb['iconHtml'] !!}@endif
                    @if (! $hb['chip'] && $hb['iconHtml'] !== '' && $hb['pos'] === 'before'){!! $hb['iconHtml'] !!}@endif
                    <span>{{ $hb['text'] }}</span>
                    @if (! $hb['chip'] && $hb['iconHtml'] !== '' && $hb['pos'] === 'after'){!! $hb['iconHtml'] !!}@endif
                </a>
            @endif
        @endforeach
    </div>
@endif
