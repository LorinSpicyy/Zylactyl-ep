@php
    use Illuminate\Support\Facades\Storage;
    use Illuminate\Support\Str;
    
    $m2 = function ($k, $d = null) use ($block) {
        $map = ['title' => 'heading', 'description' => 'subheading', 'button_text' => 'button_text', 'button_link' => 'button_link'];
        $bk = $map[$k] ?? ('m2_' . $k);
        return $block[$bk] ?? theme('marketing2_' . $k, $d);
    };
@endphp

@php
    $_heroLayout = 'split_view';
    $heroCategories = \App\Models\Category::whereNull('parent_id')
        ->where(function ($query) {
            $query->whereHas('children')
                ->orWhereHas('products', function ($query) {
                    $query->where('hidden', false);
                });
        })
        ->with(['products' => function ($query) {
            $query->where('hidden', false)
                  ->with(['plans.prices'])
                  ->orderBy('sort')
                  ->limit(1);
        }])
        ->orderBy('sort')
        ->limit(3)
        ->get();

    $firstCategory = $heroCategories->first();
    $firstProduct = $firstCategory?->products->first();
    $firstPlan = $firstProduct?->availablePlans()?->first();

    $startingPrice = '';
    $billingTerm = '';
    $heroSale = null;
    if ($firstProduct && $firstProduct->price()->available) {
        $startingPrice = $firstProduct->price()->formatted->price;
        $heroSale = citadel_product_sale($firstProduct);
        if ($firstPlan && $firstPlan->type == 'recurring') {
            if ($firstPlan->billing_period == 1) {
                $billingTerm = trans_choice(__('services.billing_cycles.' . $firstPlan->billing_unit), 1);
            } elseif ($firstPlan->billing_period == 3 && $firstPlan->billing_unit == 'month') {
                $billingTerm = __('citadel::citadel.plans.quarter');
            } elseif ($firstPlan->billing_period == 6 && $firstPlan->billing_unit == 'month') {
                $billingTerm = __('citadel::citadel.plans.6_months');
            } elseif ($firstPlan->billing_period == 12 && $firstPlan->billing_unit == 'month') {
                $billingTerm = __('citadel::citadel.plans.year');
            } else {
                $billingTerm = $firstPlan->billing_period . ' ' . trans_choice(__('services.billing_cycles.' . $firstPlan->billing_unit), $firstPlan->billing_period);
            }
        }
    }

    $heroRightContent = $m2('hero_right_content') ?: 'categories';
    $heroPresetImage = $m2('hero_preset_image') ?: 'hero';

    
    $m2HeroBleed = ($isFirstBlock ?? false) && theme('header_style', 'header1') === 'header2';
@endphp

@if($heroRightContent === 'preset_image' && $heroPresetImage === 'hero')

    <div class="relative -mt-12 md:-mt-28 mb-0"
         @if($m2HeroBleed) style="margin-top: calc(-1 * (var(--citadel-hero-pad, 0px) + 2.5rem));" @endif>

        <div class="absolute inset-0 left-[50%] right-[50%] -ml-[50vw] -mr-[50vw] w-screen min-h-[600px] md:min-h-[700px] flex justify-center overflow-hidden">
            <div class="w-full h-full max-w-[1920px]">
                @include('components.hero-svg')
            </div>
        </div>


        <section class="relative pt-40 pb-20 md:py-32 flex items-center min-h-[600px] md:min-h-[700px] z-10">
            <div class="w-full">
                <div class="flex justify-start">
                    <div class="w-full lg:w-1/2 text-left">

                        @if($m2('show_trustpilot', true))
                            <div class="flex items-center gap-2 mb-6 text-sm sm:text-base" style="color: hsl(var(--color-base) / 0.9);">
                                <span>Rated <span class="font-bold">{{ $m2('trustpilot_rating') ?: theme('landing_trustpilot_rating') ?: 'Excellent' }}</span> on</span>
                                <img src="/assets/icons/trustpilot-light.png" alt="Trustpilot" class="h-5 sm:h-6 dark:hidden" />
                                <img src="/assets/icons/trustpilot-dark.png" alt="Trustpilot" class="h-5 sm:h-6 hidden dark:block" />
                            </div>
                        @endif


                        <h1 class="{{ $m2('title_size') ?: 'text-5xl sm:text-6xl lg:text-7xl' }} font-bold mb-6 leading-tight" style="color: hsl(var(--color-base));">
                            {!! Str::inlineMarkdown($m2('title') ?: 'Powerful VPS Hosting and Web Hosting') !!}
                        </h1>


                        @if($m2('description'))
                            <p class="{{ $m2('description_size') ?: 'text-base' }} mb-8 leading-relaxed" style="color: hsl(var(--color-base) / 0.8);">
                                {!! Str::inlineMarkdown($m2('description')) !!}
                            </p>
                        @endif


                        @if($m2('enable_button', true))
                            <div class="flex flex-col sm:flex-row gap-4">
                                @php
                                    $heroButtonLink = $m2('button_link') ?: ($firstCategory ? route('category.show', ['category' => $firstCategory->slug]) : route('home'));
                                    $heroButtonIsExternal = filter_var($heroButtonLink, FILTER_VALIDATE_URL) && !str_starts_with($heroButtonLink, url('/'));
                                @endphp
                                <a href="{{ $heroButtonLink }}"
                                   class="citadel-btn inline-flex items-center justify-center px-8 bg-primary text-white text-sm rounded-lg hover:opacity-90 transition-all font-medium"
                                   style="border-radius: var(--citadel-button-radius);"
                                   @if($heroButtonIsExternal) target="_blank" rel="noopener noreferrer" @elseif(! str_starts_with($heroButtonLink, '#')) wire:navigate @endif>
                                    {{ $m2('button_text') ?: 'Get Started' }}
                                </a>

                                @if($m2('show_starting_price', true) && $startingPrice)
                                    <div class="flex items-center gap-2 text-base flex-wrap" style="color: hsl(var(--color-base) / 0.8);">
                                        <span>{{ $m2('price_prefix') ?: 'Starting at Only' }}</span>
                                        @if($heroSale)<span class="line-through" style="color: hsl(var(--color-base) / 0.45);">{{ $heroSale['original'] }}</span>@endif
                                        <span class="font-semibold" style="color: hsl(var(--color-base));">{{ $startingPrice }}</span>@if($billingTerm)/{{ $billingTerm }}@endif
                                        @if($heroSale)<span class="inline-flex items-center gap-1 rounded-md text-sm font-semibold px-1.5 py-1 whitespace-nowrap" style="background-color: hsl(var(--color-primary)); color: white;"><svg class="w-3 h-3 flex-shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8 8H8.01M2 5.2L2 9.67451C2 10.1637 2 10.4083 2.05526 10.6385C2.10425 10.8425 2.18506 11.0376 2.29472 11.2166C2.4184 11.4184 2.59135 11.5914 2.93726 11.9373L10.6059 19.6059C11.7939 20.7939 12.388 21.388 13.0729 21.6105C13.6755 21.8063 14.3245 21.8063 14.927 21.6105C15.612 21.388 16.2061 20.7939 17.3941 19.6059L19.6059 17.3941C20.7939 16.2061 21.388 15.612 21.6105 14.927C21.8063 14.3245 21.8063 13.6755 21.6105 13.0729C21.388 12.388 20.7939 11.7939 19.6059 10.6059L11.9373 2.93726C11.5914 2.59135 11.4184 2.4184 11.2166 2.29472C11.0376 2.18506 10.8425 2.10425 10.6385 2.05526C10.4083 2 10.1637 2 9.67452 2L5.2 2C4.0799 2 3.51984 2 3.09202 2.21799C2.7157 2.40973 2.40973 2.71569 2.21799 3.09202C2 3.51984 2 4.07989 2 5.2ZM8.5 8C8.5 8.27614 8.27614 8.5 8 8.5C7.72386 8.5 7.5 8.27614 7.5 8C7.5 7.72386 7.72386 7.5 8 7.5C8.27614 7.5 8.5 7.72386 8.5 8Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>{{ $heroSale['badge'] }}</span>@endif
                                    </div>
                                @elseif(!$m2('show_starting_price', true) && $m2('enable_secondary_button'))
                                    @php
                                        $secondaryButtonLink = $m2('secondary_button_link') ?: route('home');
                                        $secondaryButtonIsExternal = filter_var($secondaryButtonLink, FILTER_VALIDATE_URL) && !str_starts_with($secondaryButtonLink, url('/'));
                                    @endphp
                                    <a href="{{ $secondaryButtonLink }}"
                                       class="inline-flex items-center justify-center px-8 py-3 bg-background-secondary border border-neutral rounded-lg hover:border-primary/30 transition-all font-medium"
                                       style="border-radius: var(--citadel-button-radius);"
                                       @if($secondaryButtonIsExternal) target="_blank" rel="noopener noreferrer" @elseif(! str_starts_with($secondaryButtonLink, '#')) wire:navigate @endif>
                                        {{ $m2('secondary_button_text') ?: 'View All Plans' }}
                                    </a>
                                @endif
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </section>
    </div>
@else

    <section class="py-16 md:py-20">
        <div class="w-full">
            <div class="flex flex-col lg:flex-row gap-12 lg:gap-16 items-start">


                <div class="w-full lg:w-5/12 flex flex-col justify-center">

                    @if($m2('show_trustpilot', true))
                        <div class="flex items-center gap-2 mb-5 text-sm" style="color: hsl(var(--color-base) / 0.8);">
                            <span>Rated <span class="font-bold" style="color: hsl(var(--color-base));">{{ $m2('trustpilot_rating') ?: theme('landing_trustpilot_rating') ?: 'Excellent' }}</span> on</span>
                            <img src="/assets/icons/trustpilot-light.png" alt="Trustpilot" class="h-5 dark:hidden" />
                            <img src="/assets/icons/trustpilot-dark.png" alt="Trustpilot" class="h-5 hidden dark:block" />
                        </div>
                    @endif


                    <h1 class="{{ $m2('title_size') ?: 'text-5xl sm:text-6xl lg:text-7xl' }} font-bold mb-8 leading-tight" style="color: hsl(var(--color-base));">
                        {!! Str::inlineMarkdown($m2('title') ?: 'Powerful VPS Hosting and Web Hosting') !!}
                    </h1>


                    @if($m2('description'))
                        <p class="{{ $m2('description_size') ?: 'text-base' }} mb-8 leading-relaxed" style="color: hsl(var(--color-base) / 0.7);">
                            {!! Str::inlineMarkdown($m2('description')) !!}
                        </p>
                    @endif


                    @if($m2('enable_button', true))
                        <div class="flex items-center gap-4 flex-wrap">
                            @php
                                $heroButtonLink = $m2('button_link') ?: ($firstCategory ? route('category.show', ['category' => $firstCategory->slug]) : route('home'));
                                $heroButtonIsExternal = filter_var($heroButtonLink, FILTER_VALIDATE_URL) && !str_starts_with($heroButtonLink, url('/'));
                            @endphp
                            <a href="{{ $heroButtonLink }}"
                               class="citadel-btn inline-flex items-center justify-center px-7 bg-primary text-white rounded-lg hover:opacity-90 transition-all font-medium text-sm"
                               style="border-radius: var(--citadel-button-radius);"
                               @if($heroButtonIsExternal) target="_blank" rel="noopener noreferrer" @elseif(! str_starts_with($heroButtonLink, '#')) wire:navigate @endif>
                                {{ $m2('button_text') ?: 'Get Started' }}
                                <svg class="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3" />
                                </svg>
                            </a>

                            @if($m2('show_starting_price', true) && $startingPrice)
                                <span class="text-sm" style="color: hsl(var(--color-base) / 0.6);">
                                    {{ $m2('price_prefix') ?: 'Starting at Only' }}
                                    @if($heroSale)<span class="line-through" style="color: hsl(var(--color-base) / 0.45);">{{ $heroSale['original'] }}</span> @endif<span class="font-semibold" style="color: hsl(var(--color-base));">{{ $startingPrice }}</span>@if($billingTerm)/{{ $billingTerm }}@endif@if($heroSale) <span class="inline-flex items-center gap-1 rounded-md text-sm font-semibold px-1.5 py-1 whitespace-nowrap align-middle" style="background-color: hsl(var(--color-primary)); color: white;"><svg class="w-3 h-3 flex-shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8 8H8.01M2 5.2L2 9.67451C2 10.1637 2 10.4083 2.05526 10.6385C2.10425 10.8425 2.18506 11.0376 2.29472 11.2166C2.4184 11.4184 2.59135 11.5914 2.93726 11.9373L10.6059 19.6059C11.7939 20.7939 12.388 21.388 13.0729 21.6105C13.6755 21.8063 14.3245 21.8063 14.927 21.6105C15.612 21.388 16.2061 20.7939 17.3941 19.6059L19.6059 17.3941C20.7939 16.2061 21.388 15.612 21.6105 14.927C21.8063 14.3245 21.8063 13.6755 21.6105 13.0729C21.388 12.388 20.7939 11.7939 19.6059 10.6059L11.9373 2.93726C11.5914 2.59135 11.4184 2.4184 11.2166 2.29472C11.0376 2.18506 10.8425 2.10425 10.6385 2.05526C10.4083 2 10.1637 2 9.67452 2L5.2 2C4.0799 2 3.51984 2 3.09202 2.21799C2.7157 2.40973 2.40973 2.71569 2.21799 3.09202C2 3.51984 2 4.07989 2 5.2ZM8.5 8C8.5 8.27614 8.27614 8.5 8 8.5C7.72386 8.5 7.5 8.27614 7.5 8C7.5 7.72386 7.72386 7.5 8 7.5C8.27614 7.5 8.5 7.72386 8.5 8Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>{{ $heroSale['badge'] }}</span>@endif
                                </span>
                            @elseif(!$m2('show_starting_price', true) && $m2('enable_secondary_button'))
                                @php
                                    $secondaryButtonLink = $m2('secondary_button_link') ?: route('home');
                                    $secondaryButtonIsExternal = filter_var($secondaryButtonLink, FILTER_VALIDATE_URL) && !str_starts_with($secondaryButtonLink, url('/'));
                                @endphp
                                <a href="{{ $secondaryButtonLink }}"
                                   class="inline-flex items-center justify-center px-7 py-3 bg-background-secondary border border-neutral rounded-lg hover:border-primary/30 transition-all font-medium text-sm"
                                   style="border-radius: var(--citadel-button-radius);"
                                   @if($secondaryButtonIsExternal) target="_blank" rel="noopener noreferrer" @elseif(! str_starts_with($secondaryButtonLink, '#')) wire:navigate @endif>
                                    {{ $m2('secondary_button_text') ?: 'View All Plans' }}
                                </a>
                            @endif
                        </div>
                    @endif
                </div>


                <div class="w-full lg:w-5/12 lg:ml-auto">

                    @if($heroRightContent === 'preset_image' && $heroPresetImage === 'webhosting')

                        <div class="w-full flex items-center justify-center lg:justify-end">
                            @php
                                $svgPath = public_path("assets/images/hero/webhosting.svg");
                                
                                if (file_exists($svgPath)) {
                                    $svg = file_get_contents($svgPath);
                                    

                                    $colorReplacements = [
                                        ['#618635', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.9) calc(var(--color-primary-l) * 0.7))'],
                                        ['#7FAE46', 'hsl(var(--color-primary))'],
                                        ['#7BAE3C', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.98) calc(var(--color-primary-l) * 1.02))'],
                                        ['#9AC862', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.95) calc(var(--color-primary-l) * 0.85))'],
                                        ['#83BF3B', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.96) calc(var(--color-primary-l) * 1.05))'],
                                        ['#547130', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.85) calc(var(--color-primary-l) * 0.55))'],
                                        ['#85C03D', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.96) calc(var(--color-primary-l) * 0.88))'],
                                    ];
                                    
                                    foreach ($colorReplacements as $replacement) {
                                        [$hexColor, $newColor] = $replacement;
                                        $svg = str_ireplace('fill="' . $hexColor . '"', 'fill="' . $newColor . '"', $svg);
                                        $svg = str_ireplace('stroke="' . $hexColor . '"', 'stroke="' . $newColor . '"', $svg);
                                        $svg = str_ireplace('stop-color="' . $hexColor . '"', 'stop-color="' . $newColor . '"', $svg);
                                    }
                                    

                                    $svg = preg_replace('/<svg/', '<svg class="w-full h-auto max-w-[500px] lg:max-w-full"', $svg, 1);
                                    
                                    echo $svg;
                                }
                            @endphp
                        </div>

                    @elseif($heroRightContent === 'custom_image' && $m2('hero_custom_image'))

                        <div class="w-full flex items-center justify-center lg:justify-end">
                            <img src="{{ Storage::url($m2('hero_custom_image')) }}" alt="Hero" class="w-full h-auto max-w-[500px] lg:max-w-full object-contain" />
                        </div>

                    @else

                        @if($heroCategories->count() > 0)
                            <div class="flex flex-col gap-6 lg:gap-5">
                                @foreach($heroCategories as $index => $category)
                                    @php
                                        $catProduct = $category->products->first();
                                        $catPlan = $catProduct?->availablePlans()?->first();


                                        $introText = '';
                                        if ($category->description) {
                                            $description = strip_tags($category->description, '<ul><ol><li><p><strong><em><br>');
                                            preg_match('/^(.*?)(<ul>|<ol>|\n\n)/s', $description, $matches);
                                            $introText = trim(strip_tags($matches[1] ?? $description));
                                        }
                                    @endphp
                                    <a href="{{ route('category.show', ['category' => $category->slug]) }}" wire:navigate
                                       class="group flex items-center gap-6 p-4 rounded-xl transition-all duration-200 hover:bg-primary/[0.03]"
                                       style="border-radius: var(--citadel-card-radius);">


                                        <div class="flex items-start gap-6 flex-1 min-w-0">

                                            <span class="shrink-0 text-lg font-medium leading-[1.75rem]" style="color: hsl(var(--color-primary) / 0.3);">
                                                {{ str_pad($index + 1, 2, '0', STR_PAD_LEFT) }}
                                            </span>


                                            <div class="flex-1 min-w-0 max-w-[300px]">
                                                <h3 class="text-lg font-semibold mb-1 leading-[1.75rem] group-hover:text-primary transition-colors" style="color: hsl(var(--color-base));">
                                                    {{ $category->name }}
                                                </h3>
                                                @if($introText)
                                                    <p class="text-sm leading-relaxed line-clamp-2" style="color: hsl(var(--color-base) / 0.6);">
                                                        {{ $introText }}
                                                    </p>
                                                @endif
                                            </div>
                                        </div>


                                        <div class="shrink-0 flex items-center justify-center ml-auto">
                                            @if($category->image)
                                                <img src="{{ Storage::url($category->image) }}" alt="{{ $category->name }}" class="w-16 h-16 object-contain" />
                                            @else
                                                <svg class="w-16 h-16" style="color: hsl(var(--color-primary) / 0.5);" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                                                </svg>
                                            @endif
                                        </div>
                                    </a>
                                @endforeach
                            </div>
                        @endif
                    @endif
                </div>

            </div>
        </div>
    </section>
@endif
