@php
    use Illuminate\Support\Facades\Storage;


    $h5Title = trim((string) ($block['heading'] ?? ''));
    $h5Desc  = trim((string) ($block['subheading'] ?? ''));

    $h5BgType    = $block['hero4_bg_type'] ?? 'primary';
    $h5BgColor   = trim((string) ($block['hero4_bg_color'] ?? ''));
    $h5G1        = trim((string) ($block['hero4_grad_1'] ?? ''));
    $h5G2        = trim((string) ($block['hero4_grad_2'] ?? ''));
    $h5G3        = trim((string) ($block['hero4_grad_3'] ?? ''));
    $h5ImgSource = $block['hero4_image_source'] ?? 'category';


    $h5BgImgUrl = null;
    if ($h5BgType === 'image') {
        if ($h5ImgSource === 'custom' && ! empty($block['hero4_image'])) {
            try { $h5BgImgUrl = Storage::url($block['hero4_image']); } catch (\Throwable $e) {}
        } elseif (isset($category) && $category && ! empty($category->image)) {
            try { $h5BgImgUrl = Storage::url($category->image); } catch (\Throwable $e) {}
        }
    }


    $h5ImgUrl = ! empty($block['hero5_image']) ? Storage::url($block['hero5_image']) : null;


    $h5Light = true;
    if ($h5BgType === 'custom_color' && $h5BgColor !== '') {
        $h5SectionStyle = 'background-color: ' . $h5BgColor . ';';
        $parts   = preg_split('/\s+/', trim(str_replace(',', '', preg_replace('/^hsl\((.+)\)$/i', '$1', $h5BgColor))));
        $h5Light = isset($parts[2]) ? ((float) rtrim($parts[2], '%') < 60) : true;
    } elseif ($h5BgType === 'gradient') {
        $g1 = $h5G1 !== '' ? $h5G1 : 'hsl(var(--color-primary))';
        $g2 = $h5G2 !== '' ? $h5G2 : 'hsl(var(--color-primary))';
        $g3 = $h5G3 !== '' ? $h5G3 : 'hsl(var(--color-primary))';
        $h5SectionStyle = 'background-image: linear-gradient(120deg, ' . $g1 . ' 0%, ' . $g2 . ' 50%, ' . $g3 . ' 100%);';
        $h5Light = true;
    } elseif ($h5BgType === 'image' && $h5BgImgUrl) {
        $h5SectionStyle = "background-image: linear-gradient(to top, hsl(var(--color-background)) 0%, hsl(var(--color-background) / 0.8) 100%), url('" . $h5BgImgUrl . "'); background-size: cover; background-position: center; background-repeat: no-repeat;";
        $h5Light = false;
    } else {
        $h5SectionStyle = 'background-color: hsl(var(--color-primary));';
        $h5Light = true;
    }

    $h5cTitle = $h5Light ? '#ffffff'               : 'hsl(var(--color-base))';
    $h5cDesc  = $h5Light ? 'rgba(255,255,255,0.9)' : 'hsl(var(--color-base) / 0.75)';
    $h5BtnCtx = $h5Light ? 'light' : 'base';

    $h5IconBg = match ($h5BgType) {
        'custom_color' => $h5BgColor !== '' ? $h5BgColor : 'hsl(var(--color-primary))',
        'gradient'     => $h5G1 !== '' ? $h5G1 : 'hsl(var(--color-primary))',
        'image'        => 'hsl(var(--color-background))',
        default        => 'hsl(var(--color-primary))',
    };
@endphp


<div class="citadel-hero5 relative isolate" style="margin-top: calc(-1 * ({{ $heroPad ?? '0px' }} + 2.5rem));">
    <div class="absolute inset-0 left-[50%] right-[50%] -ml-[50vw] -mr-[50vw] w-screen -z-10 overflow-hidden" style="{{ $h5SectionStyle }}"></div>
    <section class="relative" style="padding-top: {{ $heroPad ?? '0px' }};">
    <style>
        .citadel-hero5-inner{padding-top:4rem;padding-bottom:4rem;}
        .citadel-hero5-text{max-width:36rem;}
        
        .citadel-hero5-media{display:none;}
        .citadel-hero5-media img{height:auto;border-radius:0.75rem;box-shadow:0 25px 50px -12px rgba(0,0,0,0.45);border:1px solid rgba(255,255,255,0.12);display:block;}
        @media (min-width:640px){.citadel-hero5-inner{padding-top:6rem;padding-bottom:6rem;}}
        @media (min-width:1024px){
            
            .citadel-hero5-inner{padding-top:4rem;padding-bottom:7rem;}
            
            .citadel-hero5-grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,26rem);gap:2.5rem;align-items:center;}
            .citadel-hero5-text{max-width:38rem;}
            .citadel-hero5-media{display:block;width:47rem;max-width:none;transform:translateX(100px);}
            .citadel-hero5-media img{width:47rem;max-width:none;}
        }
    </style>
    <div class="citadel-hero5-inner relative w-full mx-auto px-4 sm:px-6 lg:px-8" style="max-width: {{ $heroMaxW }};">
        <div class="citadel-hero5-grid">
            <div class="citadel-hero5-text text-left">
                @if ($h5Title)
                    <h1 class="text-4xl sm:text-5xl font-bold leading-tight mb-5" style="color: {{ $h5cTitle }};">{{ $h5Title }}</h1>
                @endif

                @if ($h5Desc)
                    <p class="text-lg lg:text-xl leading-relaxed mb-8 max-w-xl" style="color: {{ $h5cDesc }};">{{ $h5Desc }}</p>
                @endif

                @include('partials.custom-page-blocks._hero-buttons', ['btnContext' => $h5BtnCtx, 'btnIconBg' => $h5IconBg, 'btnIconColor' => $h5cTitle])
            </div>

            @if ($h5ImgUrl)
                <div class="citadel-hero5-media">
                    <img src="{{ $h5ImgUrl }}" alt="{{ $h5Title }}" draggable="false" class="select-none pointer-events-none" />
                </div>
            @endif
        </div>
    </div>
    </section>
</div>
