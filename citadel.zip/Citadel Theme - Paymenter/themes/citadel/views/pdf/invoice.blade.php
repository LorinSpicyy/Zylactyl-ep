<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="generator" content="citadel-pdf">
    <title>{{ !$invoice->number && config('settings.invoice_proforma', false) ? __('invoices.proforma_invoice', ['id' => $invoice->id]) : __('invoices.invoice', ['id' => $invoice->number]) }}</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'DejaVu Sans', sans-serif;
        }
        
        body {
            font-family: 'DejaVu Sans', sans-serif;
            font-size: 14px;
            line-height: 1.6;
            color: #333;
            padding: 40px;
        }

        .invoice-container {
            max-width: 800px;
            margin: 0 auto;
            background: #fff;
        }

        .invoice-header {
            display: table;
            width: 100%;
            margin-bottom: 40px;
        }

        .header-left {
            display: table-cell;
            width: 50%;
            vertical-align: top;
        }

        .header-right {
            display: table-cell;
            width: 50%;
            text-align: right;
            vertical-align: top;
        }

        .company-name {
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .status-badge {
            display: inline-block;
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            margin-bottom: 15px;
            text-transform: capitalize;
        }

        .status-paid {
            background-color: #d1fae5;
            color: #065f46;
        }

        .status-pending {
            background-color: #fef3c7;
            color: #92400e;
        }

        .status-cancelled {
            background-color: #dbeafe;
            color: #1e40af;
        }

        .bill-from {
            font-size: 11px;
            line-height: 1.5;
            color: #666;
        }

        .bill-from-title {
            font-size: 10px;
            font-weight: bold;
            text-transform: uppercase;
            margin-bottom: 5px;
        }

        .invoice-details {
            margin-bottom: 30px;
        }

        .detail-row {
            margin-bottom: 3px;
        }

        .detail-label {
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
            display: inline-block;
            min-width: 100px;
        }

        .detail-value {
            font-size: 14px;
            font-weight: bold;
        }

        .bill-to {
            margin-bottom: 30px;
        }

        .bill-to-title {
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
            display: inline-block;
            margin-right: 8px;
        }

        .bill-to-name {
            font-size: 14px;
            font-weight: bold;
            display: inline-block;
        }

        .bill-to-address {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }


        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            overflow: hidden;
        }

        .items-table thead {
            background-color: #f9fafb;
        }

        .items-table th {
            padding: 12px;
            text-align: left;
            font-size: 11px;
            font-weight: bold;
            text-transform: uppercase;
            color: #666;
            border-bottom: 1px solid #e5e7eb;
        }

        .items-table td {
            padding: 12px;
            border-bottom: 1px solid #f3f4f6;
        }

        .items-table tbody tr:last-child td {
            border-bottom: none;
        }

        .items-table .item-description {
            font-weight: normal;
        }

        .items-table .text-right {
            text-align: right;
        }

        .totals {
            margin-left: auto;
            width: 300px;
            margin-bottom: 30px;
        }

        .total-row {
            display: table;
            width: 100%;
            margin-bottom: 8px;
        }

        .total-label {
            display: table-cell;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
            color: #666;
        }

        .total-value {
            display: table-cell;
            text-align: right;
            font-weight: bold;
        }

        .total-row.grand-total {
            margin-top: 15px;
            padding-top: 15px;
            border-top: 2px solid #e5e7eb;
        }

        .total-row.grand-total .total-label,
        .total-row.grand-total .total-value {
            font-size: 16px;
            font-weight: bold;
        }

        .transactions-section {
            margin-top: 40px;
            margin-bottom: 30px;
        }

        .section-title {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 15px;
        }

        .transactions-table {
            width: 100%;
            border-collapse: collapse;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            overflow: hidden;
        }

        .transactions-table thead {
            background-color: #f9fafb;
        }

        .transactions-table th {
            padding: 10px;
            text-align: left;
            font-size: 11px;
            font-weight: bold;
            text-transform: uppercase;
            color: #666;
            border-bottom: 1px solid #e5e7eb;
        }

        .transactions-table td {
            padding: 10px;
            font-size: 12px;
            border-bottom: 1px solid #f3f4f6;
        }

        .transactions-table tbody tr:last-child td {
            border-bottom: none;
        }

        .invoice-footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #e5e7eb;
        }

        .footer-title {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 8px;
        }

        .footer-text {
            font-size: 12px;
            color: #666;
            line-height: 1.5;
        }
    </style>
</head>
<body>
    <div class="invoice-container">
        
        <div class="invoice-header">
            <div class="header-left">
                @if(config('settings.logo'))
                <img style="height: 40px; margin-bottom: 10px;" src="{{ public_path('storage/' . config('settings.logo')) }}" alt="{{ config('app.name') }}">
                @endif
                <div class="company-name">{{ config('settings.company_name') }}</div>
            </div>
            <div class="header-right">
                
                <div class="status-badge status-{{ $invoice->status }}">
                    {{ ucfirst($invoice->status) }}
                </div>
                
                
                <div class="bill-from">
                    <div class="bill-from-title">Bill From</div>
                    {!! nl2br(e(config('settings.bill_to_text', config('settings.company_name')))) !!}
                </div>
            </div>
        </div>

        
        <div class="invoice-details">
            <div class="detail-row">
                <span class="detail-label">Invoice #:</span>
                <span class="detail-value">{{ $invoice->number }}</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Invoice date:</span>
                <span>{{ $invoice->created_at->format('M d, Y') }}</span>
            </div>
            @if($invoice->due_at)
            <div class="detail-row">
                <span class="detail-label">Due date:</span>
                <span>{{ $invoice->due_at->format('M d, Y') }}</span>
            </div>
            @endif
        </div>

        
        <div class="bill-to">
            <span class="bill-to-title">Bill to:</span>
            <span class="bill-to-name">{{ $invoice->user->name }}</span>
            <div class="bill-to-address">
                @foreach($invoice->user->properties()->with('parent_property')->whereHas('parent_property', function ($query) {
                    $query->where('show_on_invoice', true);
                })->get() as $property)
                    {{ $property->value }}<br>
                @endforeach
            </div>
        </div>

        
        <table class="items-table">
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Qty</th>
                    <th class="text-right">Price</th>
                    <th class="text-right">Amount</th>
                </tr>
            </thead>
            <tbody>
                @foreach($invoice->items as $item)
                <tr>
                    <td class="item-description">{{ $item->description }}</td>
                    <td>{{ $item->quantity }}</td>
                    <td class="text-right">{{ $item->formattedPrice }}</td>
                    <td class="text-right">{{ $item->formattedTotal }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>

        
        <div class="totals">
            @if($invoice->formattedTotal->tax > 0)
            <div class="total-row">
                <div class="total-label">Subtotal:</div>
                <div class="total-value">{{ $invoice->formattedTotal->format($invoice->formattedTotal->subtotal) }}</div>
            </div>
            <div class="total-row">
                <div class="total-label">{{ $invoice->tax->name }} ({{ $invoice->tax->rate }}%):</div>
                <div class="total-value">{{ $invoice->formattedTotal->formatted->tax }}</div>
            </div>
            @endif
            <div class="total-row grand-total">
                <div class="total-label">Total:</div>
                <div class="total-value">{{ $invoice->formattedTotal }}</div>
            </div>
        </div>

        
        @if($invoice->transactions->where('status', \App\Enums\InvoiceTransactionStatus::Succeeded)->count() > 0)
        <div class="transactions-section">
            <div class="section-title">Transactions</div>
            <table class="transactions-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Transaction ID</th>
                        <th>Gateway</th>
                        <th class="text-right">Amount</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($invoice->transactions->where('status', \App\Enums\InvoiceTransactionStatus::Succeeded) as $transaction)
                    <tr>
                        <td>{{ $transaction->created_at->format('d/m/Y') }}</td>
                        <td>{{ $transaction->transaction_id }}</td>
                        <td>{{ $transaction->gateway ? $transaction->gateway->name : '' }}</td>
                        <td class="text-right">{{ $transaction->formattedAmount }}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        @endif

        
        <div class="invoice-footer">
            <div class="footer-title">Thank You for Your Business</div>
            <div class="footer-text">
                We truly appreciate your trust in us. If you have any questions about this invoice, feel free to reach out to our support team.
            </div>
        </div>
    </div>
</body>
</html>
