{{-- @component: unified-auth --}}
<div>
    <form wire:submit="submit" id="cart-login-form">
        <div class="space-y-4">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <x-form.input 
                    name="email" 
                    type="email" 
                    :label="__('auth.input.email')"
                    :placeholder="__('general.input.email_placeholder')" 
                    wire:model="email" 
                    required 
                />
                <x-form.input 
                    name="password" 
                    type="password" 
                    :label="__('general.input.password')"
                    :placeholder="__('general.input.password_placeholder')" 
                    wire:model="password" 
                    required 
                />
            </div>
            
            <div class="flex items-center justify-between">
                <x-form.checkbox name="remember" label="Remember me" wire:model="remember" />
                <a class="text-sm text-primary hover:text-primary/80 underline" href="{{ route('password.request') }}">
                    {{ __('auth.forgot_password') }}
                </a>
            </div>

            <x-captcha :form="'cart-login-form'" />

            <x-button.primary class="w-full" type="submit" wire:loading.attr="disabled">
                <span wire:loading.remove>{{ __('auth.sign_in') }}</span>
                <span wire:loading>
                    <x-ri-loader-line class="w-4 h-4 animate-spin mr-2" />
                    Signing in...
                </span>
            </x-button.primary>
        </div>
    </form>
</div>