{{-- @component: inline-login --}}
<div>
    <form wire:submit="submit" id="cart-login-form">
        <div class="space-y-4 mt-4">
            <x-form.input 
                name="email" 
                type="email" 
                id="cart-login-email"
                :label="__('general.input.email')"
                :placeholder="__('general.input.email_placeholder')" 
                wire:model="email" 
                required 
                hideRequiredIndicator
            />
            
            <x-form.input 
                name="password" 
                type="password" 
                id="cart-login-password"
                :label="__('general.input.password')"
                :placeholder="__('general.input.password_placeholder')" 
                wire:model="password" 
                required 
                hideRequiredIndicator
            />
            
            <div class="flex items-center justify-between pt-2">
                <x-form.checkbox name="remember" id="cart-login-remember" label="Remember me" wire:model="remember" />
                <a class="check-out-text-small-bold text-primary !font-normal !leading-5 hover:text-primary/80 transition-colors" href="{{ route('password.request') }}">
                    {{ __('auth.forgot_password') }}
                </a>
            </div>

            <x-captcha :form="'cart-login-form'" />

            <div class="border-t border-neutral pt-4 mt-4">
                <x-button.primary class="w-full" type="submit" wire:loading.attr="disabled">
                    <span wire:loading.remove class="check-out-text-small-bold !font-normal !leading-5">{{ __('auth.sign_in') }}</span>
                    <span wire:loading class="check-out-text-small-bold !font-normal !leading-5">
                        <x-ri-loader-line class="w-4 h-4 animate-spin mr-2" />
                        Signing in...
                    </span>
                </x-button.primary>
            </div>
        </div>
    </form>
</div>