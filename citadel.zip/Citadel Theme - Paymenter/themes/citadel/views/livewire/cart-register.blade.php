{{-- @component: inline-register --}}
<div>
    <form wire:submit="submit" id="cart-register-form">
        <div class="space-y-4 mt-4">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <x-form.input 
                    name="first_name" 
                    type="text" 
                    id="cart-register-first-name"
                    :label="__('general.input.first_name')"
                    :placeholder="__('general.input.first_name_placeholder')" 
                    wire:model="first_name" 
                    required 
                    hideRequiredIndicator
                />
                <x-form.input 
                    name="last_name" 
                    type="text" 
                    id="cart-register-last-name"
                    :label="__('general.input.last_name')"
                    :placeholder="__('general.input.last_name_placeholder')" 
                    wire:model="last_name" 
                    required 
                    hideRequiredIndicator
                />
            </div>
            
            <x-form.input 
                name="email" 
                type="email" 
                id="cart-register-email"
                :label="__('general.input.email')"
                :placeholder="__('general.input.email_placeholder')" 
                wire:model="email" 
                required 
                hideRequiredIndicator
            />
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <x-form.input 
                    name="password" 
                    type="password" 
                    id="cart-register-password"
                    :label="__('Password')"
                    :placeholder="__('Your password')" 
                    wire:model="password" 
                    required 
                    hideRequiredIndicator
                />
                <x-form.input 
                    name="password_confirmation" 
                    type="password" 
                    id="cart-register-password-confirmation"
                    :label="__('Password')"
                    :placeholder="__('Confirm your password')" 
                    wire:model="password_confirmation" 
                    required 
                    hideRequiredIndicator
                />
            </div>

            
            <x-form.properties :custom_properties="$custom_properties" :properties="$properties" />

            @if(config('settings.tos'))
                <div class="border-t border-neutral pt-4 mt-2">
                    <x-form.checkbox wire:model="tos" name="tos" id="cart-register-tos">
                        {{ __('product.tos') }}
                        <a href="{{ config('settings.tos') }}" target="_blank" class="text-primary hover:text-primary/80 transition-colors">
                            {{ __('product.tos_link') }}
                        </a>
                    </x-form.checkbox>
                </div>
            @endif

            <x-captcha :form="'cart-register-form'" />

            <div class="border-t border-neutral pt-4 mt-4">
                <x-button.primary class="w-full" type="submit" wire:loading.attr="disabled">
                    <span wire:loading.remove class="check-out-text-small-bold !font-normal !leading-5">{{ __('auth.sign_up') }}</span>
                    <span wire:loading class="check-out-text-small-bold !font-normal !leading-5">
                        <x-ri-loader-line class="w-4 h-4 animate-spin mr-2" />
                        Creating account...
                    </span>
                </x-button.primary>
            </div>
        </div>
    </form>
</div>