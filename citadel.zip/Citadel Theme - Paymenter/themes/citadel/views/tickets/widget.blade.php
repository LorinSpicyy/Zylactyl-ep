
<div>
    <div class="bg-background-secondary border border-neutral rounded-lg">
        

        <div class="px-4 sm:px-6 py-4 border-b border-neutral">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div class="flex items-center gap-3 sm:gap-4 flex-wrap">
                    <h2 class="secondary-title">{{ __('citadel::citadel.dashboard.tickets_widget') }}</h2>
                    

                    <div class="relative" x-data="{ open: false }">
                        <button 
                            @click="open = !open" 
                            @click.away="open = false"
                            class="inline-flex items-center gap-2 px-3 py-1.5 bg-background border border-neutral rounded-md text-sm font-medium hover:bg-primary/5 transition-colors duration-200">
                            <span>
                                @if(!isset($status) || !$status)
                                    {{ __('citadel::citadel.tickets.index.all_tickets') }}
                                @else
                                    {{ ucfirst($status) }}
                                @endif
                            </span>
                            <x-ri-arrow-down-s-line class="size-4 transition-transform duration-200" x-bind:class="open ? 'rotate-180' : ''" />
                        </button>
                        
                        <div x-show="open" 
                             x-transition:enter="transition ease-out duration-200"
                             x-transition:enter-start="opacity-0 scale-95"
                             x-transition:enter-end="opacity-100 scale-100"
                             x-transition:leave="transition ease-in duration-150"
                             x-transition:leave-start="opacity-100 scale-100"
                             x-transition:leave-end="opacity-0 scale-95"
                             class="absolute top-full left-0 mt-1 w-40 bg-background-secondary border border-neutral rounded-lg z-20 overflow-hidden">
                            <div class="py-1">
                                <button wire:click="setStatus('all')" @click="open = false" 
                                        class="w-full text-left px-3 py-2 text-sm hover:bg-primary/5 transition-colors duration-200 {{ (!isset($status) || !$status) ? 'bg-primary/10 text-primary' : '' }}">
                                    {{ __('citadel::citadel.tickets.index.all_tickets') }}
                                </button>
                                <button wire:click="setStatus('open')" @click="open = false" 
                                        class="w-full text-left px-3 py-2 text-sm hover:bg-primary/5 transition-colors duration-200 {{ (isset($status) && $status === 'open') ? 'bg-primary/10 text-primary' : '' }}">
                                    {{ __('citadel::citadel.tickets.index.open') }}
                                </button>
                                <button wire:click="setStatus('replied')" @click="open = false" 
                                        class="w-full text-left px-3 py-2 text-sm hover:bg-primary/5 transition-colors duration-200 {{ (isset($status) && $status === 'replied') ? 'bg-primary/10 text-primary' : '' }}">
                                    {{ __('citadel::citadel.tickets.index.replied') }}
                                </button>
                                <button wire:click="setStatus('closed')" @click="open = false" 
                                        class="w-full text-left px-3 py-2 text-sm hover:bg-primary/5 transition-colors duration-200 {{ (isset($status) && $status === 'closed') ? 'bg-primary/10 text-primary' : '' }}">
                                    {{ __('citadel::citadel.tickets.index.closed') }}
                                </button>
                            </div>
                        </div>
                    </div>
                    

                    @if(!$compact)
                    <div class="relative" x-data="{ open: false }">
                        <button 
                            @click="open = !open" 
                            @click.away="open = false"
                            class="inline-flex items-center gap-2 px-3 py-1.5 bg-background border border-neutral rounded-md text-sm font-medium hover:bg-primary/5 transition-colors duration-200">
                            <span>{{ (isset($sortBy) && $sortBy == 'oldest') ? __('citadel::citadel.tickets.index.oldest') : __('citadel::citadel.tickets.index.newest') }}</span>
                            <x-ri-arrow-down-s-line class="size-4 transition-transform duration-200" x-bind:class="open ? 'rotate-180' : ''" />
                        </button>
                        
                        <div x-show="open" 
                             x-transition:enter="transition ease-out duration-200"
                             x-transition:enter-start="opacity-0 scale-95"
                             x-transition:enter-end="opacity-100 scale-100"
                             x-transition:leave="transition ease-in duration-150"
                             x-transition:leave-start="opacity-100 scale-100"
                             x-transition:leave-end="opacity-0 scale-95"
                             class="absolute top-full left-0 mt-1 w-32 bg-background-secondary border border-neutral rounded-lg z-20 overflow-hidden">
                            <div class="py-1">
                                <button wire:click="setSortBy('newest')" @click="open = false" 
                                        class="w-full text-left px-3 py-2 text-sm hover:bg-primary/5 transition-colors duration-200 {{ (!isset($sortBy) || $sortBy === 'newest') ? 'bg-primary/10 text-primary' : '' }}">
                                    {{ __('citadel::citadel.tickets.index.newest') }}
                                </button>
                                <button wire:click="setSortBy('oldest')" @click="open = false" 
                                        class="w-full text-left px-3 py-2 text-sm hover:bg-primary/5 transition-colors duration-200 {{ (isset($sortBy) && $sortBy === 'oldest') ? 'bg-primary/10 text-primary' : '' }}">
                                    {{ __('citadel::citadel.tickets.index.oldest') }}
                                </button>
                            </div>
                        </div>
                    </div>
                    @endif
                </div>
                
                <a href="{{ route('tickets') }}" wire:navigate class="hidden sm:inline-flex items-center gap-1.5 text-sm font-medium text-base/60 hover:text-primary transition-colors duration-200">
                    <span>{{ $compact ? __('citadel::citadel.tickets.index.view_all') : __('citadel::citadel.tickets.view_all_tickets') }}</span>
                    <x-ri-arrow-right-line class="size-4" />
                </a>
            </div>
        </div>
        

        <div class="{{ $compact ? 'hidden' : 'hidden sm:block' }} px-6 py-3 border-b border-neutral bg-background-secondary/30">
            <div class="flex items-center">
                <div style="width: 60px;">
                    <span class="text-xs text-base/60 font-semibold uppercase">{{ __('citadel::citadel.tickets.index.id_column') }}</span>
                </div>
                <div class="flex-1">
                    <span class="text-xs text-base/60 font-semibold uppercase">{{ __('citadel::citadel.tickets.index.subject_column') }}</span>
                </div>
                <div style="width: 140px;">
                    <span class="text-xs text-base/60 font-semibold uppercase">{{ __('citadel::citadel.tickets.index.department_column') }}</span>
                </div>
                <div style="width: 180px;">
                    <span class="text-xs text-base/60 font-semibold uppercase">{{ __('citadel::citadel.tickets.index.last_activity_column') }}</span>
                </div>
                <div style="width: 120px;">
                    <span class="text-xs text-base/60 font-semibold uppercase">{{ __('citadel::citadel.tickets.index.status_column') }}</span>
                </div>
                <div style="width: 40px;"></div>
            </div>
        </div>
        

        <div class="divide-y divide-neutral overflow-hidden rounded-b-lg" wire:loading.class="opacity-50 pointer-events-none" wire:target="setStatus,setSortBy">
            
            <div wire:loading wire:target="setStatus,setSortBy" class="absolute inset-0 bg-background-secondary/50 flex items-center justify-center z-10">
                <div class="bg-background border border-neutral rounded-lg p-4">
                    <div class="flex items-center gap-3">
                        <svg class="animate-spin size-5 text-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        <span class="text-sm font-medium">{{ __('citadel::citadel.tickets.index.filtering') }}</span>
                    </div>
                </div>
            </div>
            
            @forelse ($tickets as $ticket)
                <a href="{{ route('tickets.show', $ticket) }}" wire:navigate class="block px-4 sm:px-6 py-3 sm:py-4 relative group hover:bg-primary/5 transition-colors duration-200">

                    <div class="{{ $compact ? 'hidden' : 'hidden sm:flex' }} items-center">
                        <div style="width: 60px;">
                            <span class="font-mono text-sm font-medium">#{{ $ticket->id }}</span>
                        </div>
                        <div class="flex-1">
                            <span class="text-sm font-medium">{{ $ticket->subject }}</span>
                        </div>
                        <div style="width: 140px;">
                            <span class="text-sm text-base/80">
                                {{ $ticket->department ?? '-' }}
                            </span>
                        </div>
                        <div style="width: 180px;">
                            <span class="text-sm text-base/80">
                                {{ $ticket->messages()->orderBy('created_at', 'desc')->first()->created_at->diffForHumans() }}
                            </span>
                        </div>
                        <div style="width: 120px;">
                            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium
                                @if ($ticket->status == 'open') text-success bg-success/20 
                                @elseif($ticket->status == 'closed') text-inactive bg-inactive/20
                                @else text-info bg-info/20 
                                @endif">
                                @if ($ticket->status == 'open')
                                    <x-ri-checkbox-circle-fill class="size-3" />
                                @elseif($ticket->status == 'closed')
                                    <x-ri-forbid-fill class="size-3" />
                                @elseif($ticket->status == 'replied')
                                    <x-ri-chat-smile-2-fill class="size-3" />
                                @endif
                                <span class="capitalize">{{ $ticket->status }}</span>
                            </div>
                        </div>
                        <div style="width: 40px;" class="flex justify-center">
                            <x-ri-arrow-right-line class="size-5 text-base/40 group-hover:text-base/60 group-hover:translate-x-1 transition-all duration-200" />
                        </div>
                    </div>

                    <div class="{{ $compact ? 'flex' : 'flex sm:hidden' }} items-center gap-3">
                        <div class="flex-1 min-w-0">
                            <div class="flex items-center gap-2 mb-1">
                                <span class="text-sm font-medium truncate">{{ $ticket->subject }}</span>
                            </div>
                            <div class="flex items-center gap-2 text-xs text-base/60">
                                <span>#{{ $ticket->id }}</span>
                                @if($ticket->department)
                                    <span class="text-base/40">&middot;</span>
                                    <span>{{ $ticket->department }}</span>
                                @endif
                                <span class="text-base/40">&middot;</span>
                                <span>{{ $ticket->messages()->orderBy('created_at', 'desc')->first()->created_at->diffForHumans() }}</span>
                            </div>
                        </div>
                        <div class="flex items-center gap-2 shrink-0">
                            <div class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium
                                @if ($ticket->status == 'open') text-success bg-success/20 
                                @elseif($ticket->status == 'closed') text-inactive bg-inactive/20
                                @else text-info bg-info/20 
                                @endif">
                                @if ($ticket->status == 'open')
                                    <x-ri-checkbox-circle-fill class="size-3" />
                                @elseif($ticket->status == 'closed')
                                    <x-ri-forbid-fill class="size-3" />
                                @elseif($ticket->status == 'replied')
                                    <x-ri-chat-smile-2-fill class="size-3" />
                                @endif
                                <span class="capitalize">{{ $ticket->status }}</span>
                            </div>
                            <x-ri-arrow-right-s-line class="size-4 text-base/40" />
                        </div>
                    </div>
                </a>
            @empty
                <div class="px-6 py-12 text-center">
                    <div class="inline-flex items-center justify-center size-16 bg-primary/10 rounded-full mb-4">
                        <x-ri-customer-service-line class="size-8 text-primary" />
                    </div>
                    <h3 class="font-semibold text-lg mb-2">{{ __('citadel::citadel.tickets.widget.no_tickets_title') }}</h3>
                    <p class="text-base/60 text-sm">{{ __('citadel::citadel.tickets.widget.no_tickets_description') }}</p>
                </div>
            @endforelse
        </div>
    </div>
</div>
