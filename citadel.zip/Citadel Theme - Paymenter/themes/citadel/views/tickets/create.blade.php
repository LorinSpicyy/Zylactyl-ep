@php
    $_formLayout = 'split_panel';
    $hideBreadcrumb = true;
@endphp

<div>
    
    <div class="mb-8 pt-8">
        <div class="flex flex-col lg:flex-row items-start justify-between gap-4">
            <div class="flex-1 w-full">
                <h1 class="page-title">{{ __('citadel::citadel.tickets.create.title') }}</h1>
                <p class="normal-text text-base/60 mt-2">
                    {{ __('citadel::citadel.tickets.create.subtitle') }}
                </p>
            </div>
            <div class="w-full lg:w-auto">
                <x-navigation.link :href="route('tickets')" class="px-4 py-2 border border-base/30 text-base hover:bg-secondary/10 rounded-md transition-colors duration-200 text-sm font-medium flex items-center gap-2 justify-center lg:justify-start">
                    <x-ri-arrow-left-line class="size-5" />
                    <span>{{ __('citadel::citadel.tickets.create.back_to_tickets') }}</span>
                </x-navigation.link>
            </div>
        </div>
    </div>

    
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        
        <div class="lg:col-span-3">
            <div>
                <h3 class="secondary-title mb-6">{{ __('citadel::citadel.tickets.quick_actions') }}</h3>
                
                <div class="space-y-4">
                    
                    <a href="{{ route('tickets') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="shrink-0">
                            <x-ri-ticket-2-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.tickets.view_all_tickets') }}</span>
                    </a>
                    
                    
                    @if(theme('knowledgebase_link'))
                    <a href="{{ theme('knowledgebase_link') }}" 
                       target="_blank"
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="shrink-0">
                            <x-ri-book-shelf-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.tickets.knowledgebase') }}</span>
                    </a>
                    @endif
                    
                    
                    @if(theme('blog_link'))
                    <a href="{{ theme('blog_link') }}" 
                       target="_blank"
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="shrink-0">
                            <x-ri-book-marked-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.tickets.blog') }}</span>
                    </a>
                    @endif
                    
                    
                    @if(theme('status_link'))
                    <a href="{{ theme('status_link') }}" 
                       target="_blank"
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="shrink-0">
                            <x-ri-heart-pulse-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.tickets.status') }}</span>
                    </a>
                    @endif
                    
                    
                    @if(theme('custom_link_name') && theme('custom_link_url'))
                    <a href="{{ theme('custom_link_url') }}" 
                       target="_blank"
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="shrink-0">
                            <x-ri-git-branch-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ theme('custom_link_name') }}</span>
                    </a>
                    @endif
                </div>
            </div>
        </div>
        
        
        <div class="lg:col-span-9">
            <div class="bg-background-secondary border border-neutral rounded-lg p-6">
                <form wire:submit.prevent="create" class="space-y-6">
                    
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <x-form.input wire:model="subject" label="{{ __('ticket.subject') }}" name="subject" required />
                        
                        @if (count($departments) > 0)
                        <x-form.select wire:model="department" label="{{ __('ticket.department') }}" name="department" required>
                            <option value="">{{ __('ticket.select_department') }}</option>
                            @foreach ($departments as $department)
                                <option value="{{ $department }}">{{ $department }}</option>
                            @endforeach
                        </x-form.select>
                        @endif
                    </div>
                    
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <x-form.select wire:model="priority" label="{{ __('ticket.priority') }}" name="priority" required>
                            <option value="">{{ __('ticket.select_priority') }}</option>
                            <option value="low" selected>{{ __('ticket.low') }}</option>
                            <option value="medium">{{ __('ticket.medium') }}</option>
                            <option value="high">{{ __('ticket.high') }}</option>
                        </x-form.select>
                        
                        <x-form.select wire:model="service" label="{{ __('ticket.service') }}" name="service">
                            <option value="">{{ __('ticket.select_service') }}</option>
                            @foreach ($services as $product)
                                <option value="{{ $product->id }}">{{ $product->product->name }} ({{ ucfirst($product->status) }})
                                    @if ($product->expires_at)
                                        - {{ $product->expires_at->format('Y-m-d') }}
                                    @endif
                                </option>
                            @endforeach
                        </x-form.select>
                    </div>
                    
                    
                    <div class="fi-fo-field">
                        <div class="fi-fo-field-label-col mb-2">
                            <div class="fi-fo-field-label-ctn">
                                <label for="editor" class="fi-fo-field-label inline-flex items-center gap-x-1.5 text-sm font-medium leading-6">
                                    <span class="fi-fo-field-label-content">
                                        {{ __('ticket.reply') }}
                                        <sup class="fi-fo-field-label-required-mark text-error">*</sup>
                                    </span>
                                </label>
                            </div>
                        </div>
                        
                        <div class="fi-fo-field-content-col">
                            <div class="fi-input-wrp fi-fo-markdown-editor bg-background-secondary border border-neutral rounded-lg overflow-hidden">
                                <div class="fi-input-wrp-content-ctn">
                                    <textarea id="editor" class="hidden" placeholder="Initial message"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                    <div class="fi-fo-field" x-data="{
                        drop: false,
                        selectedFiles: [],
                        handleDrop(event) {
                            this.drop = false;
                            if (event.dataTransfer.files && event.dataTransfer.files.length > 0) {
                                this.selectedFiles = Array.from(event.dataTransfer.files);
                                this.$refs.fileInput.files = event.dataTransfer.files;
                                this.$refs.fileInput.dispatchEvent(new Event('change'));
                            }
                        },
                        init() {
                            this.$watch('$wire.attachments', (value) => {
                                if (value.length == 0) {
                                    this.selectedFiles = [];
                                }
                            });
                        }                            
                    }">
                        <div class="fi-fo-field-label-col mb-2">
                            <div class="fi-fo-field-label-ctn">
                                <div class="fi-fo-field-label inline-flex items-center gap-x-1.5 text-sm font-medium leading-6">
                                    <span class="fi-fo-field-label-content">
                                        {{ __('ticket.attachments') }}
                                    </span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="fi-fo-field-content-col">
                            <div class="fi-fo-file-upload fi-align-start">
                                <div class="fi-fo-file-upload-input-ctn bg-background-secondary border border-neutral rounded-lg overflow-hidden">
                                    <div class="filepond--root filepond--hopper" 
                                         @dragover.prevent="drop = true" 
                                         @dragleave.prevent="drop = false"
                                         @drop.prevent="handleDrop($event)">
                                        
                                        <input class="filepond--browser sr-only" 
                                               type="file" 
                                               id="attachments" 
                                               multiple 
                                               name="attachments[]"
                                               wire:model.live="attachments" 
                                               x-ref="fileInput"
                                               @change="selectedFiles = Array.from($event.target.files)" />
                                        
                                        <div class="filepond--drop-label flex justify-center items-center rounded-lg bg-background-secondary/50 border border-dashed border-neutral px-6 py-4 hover:border-primary/50 hover:bg-background-secondary transition-colors"
                                             :class="{'border-primary bg-primary/5': drop}">
                                            <div class="text-center w-full">
                                                <template x-if="selectedFiles.length === 0">
                                                    <div>
                                                        <x-ri-attachment-2 class="mx-auto size-8 text-base/40 mb-2" />
                                                        <label for="attachments" class="block">
                                                            <span class="text-sm">
                                                                {{ __('citadel::citadel.tickets.create.drag_drop_text') }} 
                                                                <span class="filepond--label-action text-primary font-semibold cursor-pointer hover:text-primary/80">
                                                                    {{ __('citadel::citadel.tickets.create.click_to_upload') }}
                                                                </span>
                                                            </span>
                                                        </label>
                                                    </div>
                                                </template>
                                                <div x-show="selectedFiles.length > 0">
                                                    <div class="space-y-2">
                                                        <template x-for="file in selectedFiles" :key="file.name">
                                                            <div class="flex items-center justify-between gap-3 px-4 py-2 bg-background border border-neutral rounded-lg text-sm">
                                                                <div class="flex items-center gap-2 min-w-0 flex-1">
                                                                    <x-ri-file-line class="size-4 text-base/60 shrink-0" />
                                                                    <span class="truncate" x-text="file.name"></span>
                                                                </div>
                                                                <button type="button"
                                                                        class="shrink-0 text-base/40 hover:text-error transition-colors"
                                                                        @click="selectedFiles = selectedFiles.filter(f => f !== file); if(selectedFiles.length === 0) $refs.fileInput.value = ''">
                                                                    <x-ri-close-line class="size-4" />
                                                                </button>
                                                            </div>
                                                        </template>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                    <div class="flex justify-end pt-4 border-t border-neutral">
                        <x-button.primary class="inline-flex items-center gap-2">
                            <x-ri-add-circle-fill class="size-4" />
                            <span>{{ __('ticket.create') }}</span>
                        </x-button.primary>
                    </div>
                </form>
                <x-easymde-editor />
            </div>
        </div>
    </div>
</div>
