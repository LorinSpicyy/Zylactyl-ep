@php
    $_threadView = 'chronological';
    $hideBreadcrumb = true;
@endphp

<div>

    <div class="mb-8 pt-8">
        <div class="flex items-start justify-between">
            <div class="flex-1">
                <h1 class="page-title">{{ __('citadel::citadel.tickets.show.manage_title') }}</h1>
                <p class="normal-text text-base/60 mt-2">
                    {{ __('citadel::citadel.tickets.show.subtitle') }}
                </p>
            </div>
        </div>
    </div>

    
    
    <div class="mb-8">
        <div class="flex flex-col lg:flex-row gap-6">
            
            <div class="flex-1 bg-background-secondary border border-neutral rounded-lg p-4 flex items-center justify-between gap-4 min-w-0">

                
                <div class="min-w-0 flex-1">
                    <div class="flex items-center gap-2 mb-0.5">
                        <span class="text-xs font-mono text-base/50 shrink-0">#{{ $ticket->id }}</span>
                        <h2 class="text-base font-semibold truncate" title="{{ $ticket->subject }}">{{ $ticket->subject }}</h2>
                    </div>
                    <div class="flex flex-wrap items-center gap-2 mt-1">
                        <span class="text-xs text-base/60">{{ __('ticket.created_at') }}: {{ $ticket->created_at->diffForHumans() }}</span>

                        
                        <div class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium
                            @if ($ticket->priority == 'low') text-success bg-success/20
                            @elseif($ticket->priority == 'high') text-error bg-error/20
                            @else text-warning bg-warning/20
                            @endif">
                            <span class="capitalize">{{ $ticket->priority }}</span>
                        </div>

                        
                        <div class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium
                            @if ($ticket->status == 'open') text-success bg-success/20
                            @elseif($ticket->status == 'closed') text-inactive bg-inactive/20
                            @else text-info bg-info/20
                            @endif">
                            @if ($ticket->status == 'open')
                                <x-ri-checkbox-circle-fill class="size-3" />
                            @elseif($ticket->status == 'closed')
                                <x-ri-forbid-fill class="size-3" />
                            @elseif($ticket->status == 'replied')
                                <x-ri-chat-smile-2-fill class="size-3" />
                            @endif
                            <span class="capitalize">{{ $ticket->status }}</span>
                        </div>
                    </div>
                </div>

                
                @if ($ticket->status !== 'closed' && !config('settings.ticket_client_closing_disabled', false))
                <div x-data="{ confirming: false }" class="shrink-0">
                    <div x-show="!confirming">
                        <button @click="confirming = true"
                                class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium text-error border border-error/30 bg-error/10 hover:bg-error/20 transition-colors">
                            <x-ri-close-circle-line class="size-4" />
                            {{ __('ticket.close_ticket') }}
                        </button>
                    </div>
                    <div x-show="confirming" x-cloak class="flex flex-col sm:flex-row items-end sm:items-center gap-2">
                        <p class="text-xs text-base/60 text-right sm:text-left">{{ __('ticket.close_ticket_confirmation') }}</p>
                        <div class="flex items-center gap-2">
                            <button wire:click="closeTicket"
                                    class="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm font-medium text-white bg-error hover:bg-error/80 transition-colors">
                                {{ __('ticket.close_ticket') }}
                            </button>
                            <button @click="confirming = false"
                                    class="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm font-medium border border-neutral hover:bg-background transition-colors">
                                Cancel
                            </button>
                        </div>
                    </div>
                </div>
                @endif
            </div>

            
            @if(theme('discord_invite_link'))
            <a href="{{ theme('discord_invite_link') }}" target="_blank" class="block lg:w-80 group">
                <div class="relative overflow-hidden rounded-lg p-6 bg-[#5865f2] transition-transform duration-200 hover:scale-[1.02] h-full">
                    <div class="relative z-10 flex items-center justify-between h-full">
                        <div class="flex-1">
                            <h3 class="text-lg font-semibold text-white transition-all duration-200 group-hover:brightness-125 mb-1">{{ __('citadel::citadel.tickets.show.discord_title') }}</h3>
                            <p class="text-sm text-white/80 transition-all duration-200 group-hover:brightness-125">{{ __('citadel::citadel.tickets.show.discord_subtitle') }}</p>
                        </div>
                        <x-ri-discord-fill class="size-10 text-white transition-all duration-200 group-hover:brightness-125 flex-shrink-0 ml-4" />
                    </div>
                </div>
            </a>
            @endif
        </div>
    </div>

    
    <div>

            <ul class="space-y-4">
                @foreach ($ticket->messages()->with('user')->get() as $index => $message)
                    @php $isMine = $message->user_id === $ticket->user_id; @endphp

                    <li class="flex items-start gap-2.5 {{ $isMine ? 'flex-row-reverse' : '' }}"
                        @if ($loop->last) x-data x-init="$nextTick(() => $el.scrollIntoView({ behavior: 'smooth', block: 'end' }))" @endif>

                        
                        <img src="{{ citadel_avatar_url($message->user) }}"
                             alt="{{ $message->user->name }}"
                             class="shrink-0 w-8 h-8 rounded-full border border-neutral bg-background object-cover" />

                        
                        <div class="flex flex-col gap-1 max-w-[75%] md:max-w-[60%] {{ $isMine ? 'items-end' : 'items-start' }}">

                            
                            <div class="flex items-center gap-1.5 {{ $isMine ? 'flex-row-reverse' : '' }}">
                                <span class="text-sm font-semibold">{{ $isMine ? 'You' : $message->user->name }}</span>
                                <span class="text-sm text-base/50">{{ $message->created_at->format('H:i') }}</span>
                            </div>

                            
                            <div class="leading-relaxed px-4 py-3 text-sm
                                {{ $isMine
                                    ? 'bg-primary text-white rounded-s-xl rounded-ee-xl'
                                    : 'bg-background-secondary border border-neutral rounded-e-xl rounded-es-xl' }}">
                                <div class="{{ $isMine
                                    ? 'prose prose-sm max-w-none text-white prose-headings:text-white prose-p:text-white prose-a:text-white prose-strong:text-white prose-code:text-white prose-pre:bg-white/10'
                                    : 'prose prose-sm max-w-none dark:prose-invert' }}">
                                    {!! Str::markdown($message->message, [
                                        'html_input' => 'escape',
                                        'allow_unsafe_links' => false,
                                        'renderer' => ['soft_break' => "<br>"]
                                    ]) !!}
                                </div>
                            </div>

                            
                            @foreach ($message->attachments as $attachment)
                                @if ($attachment->canPreview())
                                    
                                    <div class="group relative mt-1 max-w-xs rounded-xl overflow-hidden">
                                        <div class="absolute inset-0 bg-gray-900/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center rounded-xl">
                                            <a href="{{ route('tickets.attachments.show', $attachment) }}"
                                               target="_blank"
                                               download
                                               class="inline-flex items-center justify-center h-10 w-10 rounded-full bg-white/30 hover:bg-white/50 transition-colors">
                                                <x-ri-download-line class="w-5 h-5 text-white" />
                                            </a>
                                        </div>
                                        <img src="{{ route('tickets.attachments.show', $attachment) }}"
                                             alt="{{ $attachment->filename }}"
                                             class="rounded-xl max-h-56 object-cover w-full" />
                                    </div>
                                @else
                                    
                                    <div class="flex items-center gap-3 mt-1 rounded-xl p-3 w-full max-w-xs
                                        {{ $isMine
                                            ? 'bg-primary/80 border border-primary/30'
                                            : 'bg-background-secondary border border-neutral' }}">
                                        
                                        <div class="shrink-0 flex items-center justify-center w-10 h-10 rounded-lg
                                            {{ $isMine ? 'bg-white/15' : 'bg-background border border-neutral' }}">
                                            <x-ri-file-line class="w-5 h-5 {{ $isMine ? 'text-white' : '' }}" />
                                        </div>
                                        
                                        <div class="flex-1 min-w-0">
                                            <p class="text-sm font-medium truncate {{ $isMine ? 'text-white' : '' }}" title="{{ $attachment->filename }}">
                                                {{ $attachment->filename }}
                                            </p>
                                            <p class="text-xs {{ $isMine ? 'text-white/70' : 'text-base/50' }}">
                                                {{ strtoupper(pathinfo($attachment->filename, PATHINFO_EXTENSION)) }}
                                                @if($attachment->filesize)
                                                    · {{ round($attachment->filesize / 1024) }} KB
                                                @endif
                                            </p>
                                        </div>
                                        
                                        <a href="{{ route('tickets.attachments.show', $attachment) }}"
                                           target="_blank"
                                           download
                                           class="shrink-0 inline-flex items-center justify-center p-2 rounded-lg transition-colors
                                               {{ $isMine
                                                   ? 'text-white hover:bg-white/20'
                                                   : 'text-base/60 hover:text-base hover:bg-neutral/10' }}">
                                            <x-ri-download-line class="w-5 h-5" />
                                        </a>
                                    </div>
                                @endif
                            @endforeach

                            
                            <span class="text-xs text-base/40">{{ $message->created_at->diffForHumans() }}</span>
                        </div>
                    </li>
                @endforeach
            </ul>
            
            
            <div class="mt-8 sticky bottom-0 bg-background pt-4 pb-6 border-t border-neutral"
                 x-data="{
                     drop: false,
                     selectedFiles: [],
                     handleDrop(event) {
                         this.drop = false;
                         if (event.dataTransfer.files && event.dataTransfer.files.length > 0) {
                             this.selectedFiles = Array.from(event.dataTransfer.files);
                             this.$refs.fileInput.files = event.dataTransfer.files;
                             this.$refs.fileInput.dispatchEvent(new Event('change'));
                         }
                     },
                     removeFile(file) {
                         this.selectedFiles = this.selectedFiles.filter(f => f !== file);
                         if (this.selectedFiles.length === 0) {
                             this.$refs.fileInput.value = '';
                         }
                     },
                     init() {
                         this.$watch('$wire.attachments', (value) => {
                             if (value.length == 0) {
                                 this.selectedFiles = [];
                             }
                         });
                     }
                 }">
                <form wire:submit.prevent="save" class="space-y-3">

                    
                    <div class="fi-input-wrp fi-fo-markdown-editor bg-background-secondary border border-neutral rounded-lg overflow-hidden" wire:ignore>
                        <div class="fi-input-wrp-content-ctn">
                            <textarea id="editor" class="hidden"></textarea>
                        </div>
                    </div>

                    
                    <div x-show="selectedFiles.length > 0" x-cloak class="space-y-1.5">
                        <template x-for="file in selectedFiles" :key="file.name">
                            <div class="flex items-center justify-between gap-3 px-3 py-2 bg-background-secondary border border-neutral rounded-lg text-sm">
                                <div class="flex items-center gap-2 min-w-0 flex-1">
                                    <x-ri-file-line class="size-4 text-base/50 shrink-0" />
                                    <span class="truncate" x-text="file.name"></span>
                                    <span class="text-xs text-base/40 shrink-0" x-text="(file.size / 1024).toFixed(0) + ' KB'"></span>
                                </div>
                                <button type="button"
                                        class="shrink-0 text-base/40 hover:text-error transition-colors"
                                        @click="removeFile(file)">
                                    <x-ri-close-line class="size-4" />
                                </button>
                            </div>
                        </template>
                    </div>

                    
                    <div x-show="false"
                         @dragover.prevent="drop = true"
                         @dragleave.prevent="drop = false"
                         @drop.prevent="handleDrop($event)"></div>

                    
                    <input class="sr-only"
                           type="file"
                           id="attachments"
                           multiple
                           name="attachments[]"
                           wire:model="attachments"
                           x-ref="fileInput"
                           @change="selectedFiles = Array.from($event.target.files)" />

                    
                    <div class="flex justify-end">
                        <x-button.primary class="inline-flex items-center gap-2">
                            <x-ri-send-plane-fill class="size-4" />
                            <span>{{ __('ticket.reply') }}</span>
                        </x-button.primary>
                    </div>
                </form>
                <x-easymde-editor />
            </div>
    </div>
</div>