@php

    if (theme('home_layout', 'portal') === 'disabled') {
        $citadelHomeRedirect = trim((string) theme('home_disabled_redirect', ''));
        if ($citadelHomeRedirect !== '') {
            
            $citadelTarget = \Illuminate\Support\Str::startsWith($citadelHomeRedirect, ['http://', 'https://'])
                ? $citadelHomeRedirect
                : url($citadelHomeRedirect);
            throw new \Illuminate\Http\Exceptions\HttpResponseException(
                new \Illuminate\Http\RedirectResponse($citadelTarget)
            );
        }
    }
@endphp

<div>
    @if(theme('home_layout', 'portal') === 'landing')
        @include('home-landing')
    @elseif(theme('home_layout', 'portal') === 'marketing2')
        @include('home-marketing2')
    @elseif(theme('home_layout', 'portal') === 'custom' && view()->exists('home-custom'))
        @include('home-custom')
    @else
        @include('home-portal')
    @endif

    {!! hook('pages.home') !!}
</div>
