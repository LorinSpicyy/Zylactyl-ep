@php
    $_listingMode = 'paginated';
    $hideBreadcrumb = true;
@endphp

<div>
    
    <div class="mb-8 pt-8">
        <div class="flex items-start justify-between">
            <div class="flex-1">
                <h1 class="page-title">{{ __('citadel::citadel.services.index.title') }}</h1>
                <p class="normal-text text-base/60 mt-2">
                    {{ __('citadel::citadel.services.index.subtitle') }}
                </p>
            </div>
        </div>
    </div>

    
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        
        <div class="lg:col-span-3">
            <div>
                <h3 class="secondary-title mb-6">{{ __('citadel::citadel.services.quick_actions') }}</h3>
                
                <div class="space-y-4">
                    @php
                        
                        $firstCategory = \App\Models\Category::whereNull('parent_id')
                            ->where(function ($query) {
                                $query->whereHas('children')->orWhereHas('products', function ($query) {
                                    $query->where('hidden', false);
                                });
                            })
                            ->orderBy('sort')
                            ->first();
                    @endphp
                    
                    @if($firstCategory)
                    
                    <a href="{{ route('category.show', ['category' => $firstCategory->slug]) }}" 
                       wire:navigate 
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="flex-shrink-0">
                            <x-ri-shopping-cart-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.services.order_new_service') }}</span>
                    </a>
                    @endif
                    
                   
                    <a href="/tickets" 
                       wire:navigate 
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="flex-shrink-0">
                            <x-ri-lifebuoy-line class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.services.contact_support') }}</span>
                    </a>
                </div>
                
                
                @php
                    $enableServiceCards = theme('enable_service_cards') ?? true;
                    $serviceCardsType = theme('service_cards_type') ?? 'carousel';
                    
                    $hasCarouselCards = false;
                    $hasCustomCards = false;
                    
                    if ($enableServiceCards) {
                        if ($serviceCardsType === 'carousel') {
                            $carouselJson = theme('service_carousel_data');
                            if ($carouselJson) {
                                $decoded = is_string($carouselJson) ? json_decode($carouselJson, true) : (is_array($carouselJson) ? $carouselJson : []);
                                if (is_array($decoded)) {
                                    foreach ($decoded as $card) {
                                        if (!empty($card['title']) && !empty($card['background_image'])) {
                                            $hasCarouselCards = true;
                                            break;
                                        }
                                    }
                                }
                            }
                        } elseif ($serviceCardsType === 'cards') {
                            $cardsJson = theme('service_cards_data');
                            if ($cardsJson) {
                                $decodedCards = is_string($cardsJson) ? json_decode($cardsJson, true) : (is_array($cardsJson) ? $cardsJson : []);
                                $hasCustomCards = is_array($decodedCards) && count($decodedCards) > 0;
                            }
                        }
                    }
                @endphp
                
                @if($hasCarouselCards)
                    <div class="hidden lg:block w-full aspect-[10/12] mt-6">
                        @include('services.category-carousel')
                    </div>
                @elseif($hasCustomCards)
                    <div class="hidden lg:block mt-6 space-y-4">
                        @include('services.category-cards')
                    </div>
                @endif
            </div>
        </div>
        
        
        <div class="lg:col-span-9">

    @include('free-trial::service-trial-info')

    <div class="bg-background-secondary border border-neutral rounded-lg">
        
        <div class="px-4 sm:px-6 py-4 border-b border-neutral">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div class="flex items-center gap-3 sm:gap-4 flex-wrap">
                    <h2 class="secondary-title">{{ __('citadel::citadel.services.index.services_heading') }}</h2>
                    
                    
                    <div class="relative" x-data="{ open: false }">
                        <button 
                            @click="open = !open" 
                            @click.away="open = false"
                            class="inline-flex items-center gap-2 px-3 py-1.5 bg-background border border-neutral rounded-md text-sm font-medium hover:bg-primary/5 transition-colors duration-200">
                            <span>
                                @if(!isset($status) || !$status)
                                    {{ __('citadel::citadel.services.index.all_services') }}
                                @else
                                    {{ ucfirst($status) }}
                                @endif
                            </span>
                            <x-ri-arrow-down-s-line class="size-4 transition-transform duration-200" x-bind:class="open ? 'rotate-180' : ''" />
                        </button>
                        
                        <div x-show="open" 
                             x-transition:enter="transition ease-out duration-200"
                             x-transition:enter-start="opacity-0 scale-95"
                             x-transition:enter-end="opacity-100 scale-100"
                             x-transition:leave="transition ease-in duration-150"
                             x-transition:leave-start="opacity-100 scale-100"
                             x-transition:leave-end="opacity-0 scale-95"
                             class="absolute top-full left-0 mt-1 w-40 bg-background-secondary border border-neutral rounded-lg z-20 overflow-hidden">
                            <div class="py-1">
                                <button wire:click="setStatus(null)" @click="open = false" 
                                        class="w-full text-left px-3 py-2 text-sm hover:bg-primary/5 transition-colors duration-200 {{ (!isset($status) || !$status) ? 'bg-primary/10 text-primary' : '' }}">
                                    {{ __('citadel::citadel.services.index.all_services') }}
                                </button>
                                <button wire:click="setStatus('active')" @click="open = false" 
                                        class="w-full text-left px-3 py-2 text-sm hover:bg-primary/5 transition-colors duration-200 {{ (isset($status) && $status === 'active') ? 'bg-primary/10 text-primary' : '' }}">
                                    {{ __('citadel::citadel.services.index.active') }}
                                </button>
                                <button wire:click="setStatus('suspended')" @click="open = false" 
                                        class="w-full text-left px-3 py-2 text-sm hover:bg-primary/5 transition-colors duration-200 {{ (isset($status) && $status === 'suspended') ? 'bg-primary/10 text-primary' : '' }}">
                                    {{ __('citadel::citadel.services.index.suspended') }}
                                </button>
                                <button wire:click="setStatus('pending')" @click="open = false" 
                                        class="w-full text-left px-3 py-2 text-sm hover:bg-primary/5 transition-colors duration-200 {{ (isset($status) && $status === 'pending') ? 'bg-primary/10 text-primary' : '' }}">
                                    {{ __('citadel::citadel.services.index.pending') }}
                                </button>
                                <button wire:click="setStatus('cancelled')" @click="open = false" 
                                        class="w-full text-left px-3 py-2 text-sm hover:bg-primary/5 transition-colors duration-200 {{ (isset($status) && $status === 'cancelled') ? 'bg-primary/10 text-primary' : '' }}">
                                    {{ __('citadel::citadel.services.index.cancelled') }}
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    
                    <div class="relative" x-data="{ open: false }">
                        <button 
                            @click="open = !open" 
                            @click.away="open = false"
                            class="inline-flex items-center gap-2 px-3 py-1.5 bg-background border border-neutral rounded-md text-sm font-medium hover:bg-primary/5 transition-colors duration-200">
                            <span>{{ (isset($sortBy) && $sortBy == 'oldest') ? __('citadel::citadel.services.index.oldest') : __('citadel::citadel.services.index.newest') }}</span>
                            <x-ri-arrow-down-s-line class="size-4 transition-transform duration-200" x-bind:class="open ? 'rotate-180' : ''" />
                        </button>
                        
                        <div x-show="open" 
                             x-transition:enter="transition ease-out duration-200"
                             x-transition:enter-start="opacity-0 scale-95"
                             x-transition:enter-end="opacity-100 scale-100"
                             x-transition:leave="transition ease-in duration-150"
                             x-transition:leave-start="opacity-100 scale-100"
                             x-transition:leave-end="opacity-0 scale-95"
                             class="absolute top-full left-0 mt-1 w-32 bg-background-secondary border border-neutral rounded-lg z-20 overflow-hidden">
                            <div class="py-1">
                                <button wire:click="setSortBy('newest')" @click="open = false" 
                                        class="w-full text-left px-3 py-2 text-sm hover:bg-primary/5 transition-colors duration-200 {{ (!isset($sortBy) || $sortBy === 'newest') ? 'bg-primary/10 text-primary' : '' }}">
                                    {{ __('citadel::citadel.services.index.newest') }}
                                </button>
                                <button wire:click="setSortBy('oldest')" @click="open = false" 
                                        class="w-full text-left px-3 py-2 text-sm hover:bg-primary/5 transition-colors duration-200 {{ (isset($sortBy) && $sortBy === 'oldest') ? 'bg-primary/10 text-primary' : '' }}">
                                    {{ __('citadel::citadel.services.index.oldest') }}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <span class="hidden sm:inline text-base/60 normal-text">
                    @if(!isset($status) || !$status)
                        {{ $services->total() }} {{ $services->total() === 1 ? __('citadel::citadel.services.index.service_singular') : __('citadel::citadel.services.index.service_plural') }}
                    @else
                        {{ $services->total() }} {{ $status }} {{ $services->total() === 1 ? __('citadel::citadel.services.index.service_singular') : __('citadel::citadel.services.index.service_plural') }}
                    @endif
                </span>
            </div>
        </div>
        
        
        <div class="hidden sm:block px-6 py-3 border-b border-neutral bg-background-secondary/30">
            <div class="flex items-center">
                <div style="width: 180px;">
                    <span class="text-xs text-base/60 font-semibold uppercase">{{ __('citadel::citadel.services.index.service_column') }}</span>
                </div>
                <div class="flex-1">
                    <span class="text-xs text-base/60 font-semibold uppercase">{{ __('citadel::citadel.services.index.product_column') }}</span>
                </div>
                <div style="width: 140px;">
                    <span class="text-xs text-base/60 font-semibold uppercase">{{ __('citadel::citadel.services.index.expires_column') }}</span>
                </div>
                <div style="width: 140px;">
                    <span class="text-xs text-base/60 font-semibold uppercase">{{ __('citadel::citadel.services.index.status_column') }}</span>
                </div>
                <div style="width: 40px;"></div> 
            </div>
        </div>
        
        
        <div class="divide-y divide-neutral" wire:loading.class="opacity-50 pointer-events-none" wire:target="setStatus,setSortBy,perPage">
            
            <div wire:loading wire:target="setStatus,setSortBy,perPage" class="absolute inset-0 bg-background-secondary/50 flex items-center justify-center z-10">
                <div class="bg-background border border-neutral rounded-lg p-4">
                    <div class="flex items-center gap-3">
                        <svg class="animate-spin size-5 text-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        <span class="text-sm font-medium">{{ __('citadel::citadel.services.index.filtering') }}</span>
                    </div>
                </div>
            </div>
            
            @forelse ($services as $service)
                <a href="{{ route('services.show', $service) }}" wire:navigate class="block px-4 sm:px-6 py-4 relative group hover:bg-primary/5 transition-colors duration-200">

                    <div class="hidden sm:flex items-center">
                        
                        <div style="width: 180px;">
                            <span class="font-medium text-sm">{{ $service->product->name }}</span>
                        </div>
                        
                        <div class="flex-1">
                            <p class="text-sm text-base/80">
                                {{ $service->product->category->name }}
                                @if(in_array($service->plan->type, ['recurring']))
                                    - {{ __('services.every_period', [
                                        'period' => $service->plan->billing_period > 1 ? $service->plan->billing_period : '',
                                        'unit' => trans_choice(__('services.billing_cycles.' . $service->plan->billing_unit), $service->plan->billing_period)
                                    ]) }}
                                @endif
                            </p>
                        </div>
                        
                        <div style="width: 140px;">
                            <span class="text-sm text-base/80">
                                @if($service->expires_at)
                                    {{ $service->expires_at->format('M d, Y') }}
                                @else
                                    -
                                @endif
                            </span>
                        </div>
                        
                        <div style="width: 140px;">
                            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium
                                @if ($service->status == 'active') text-success bg-success/20 
                                @elseif($service->status == 'suspended') text-inactive bg-inactive/20
                                @else text-warning bg-warning/20 
                                @endif">
                                @if ($service->status == 'active')
                                    <x-ri-checkbox-circle-fill class="size-3" />
                                @elseif($service->status == 'suspended')
                                    <x-ri-forbid-fill class="size-3" />
                                @elseif($service->status == 'pending')
                                    <x-ri-error-warning-fill class="size-3" />
                                @endif
                                <span class="capitalize">{{ $service->status }}</span>
                            </div>
                        </div>
                        
                        <div style="width: 40px;" class="flex justify-center">
                            <x-ri-arrow-right-line class="size-5 text-base/40 group-hover:text-base/60 group-hover:translate-x-1 transition-all duration-200" />
                        </div>
                    </div>


                    <div class="flex sm:hidden items-center justify-between gap-3">
                        <div class="flex-1 min-w-0">
                            <div class="flex items-center gap-2 mb-1">
                                <span class="font-medium text-sm truncate">{{ $service->product->name }}</span>
                            </div>
                            <p class="text-xs text-base/60 truncate">{{ $service->product->category->name }}</p>
                        </div>
                        <div class="flex items-center gap-3 flex-shrink-0">
                            <div class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium
                                @if ($service->status == 'active') text-success bg-success/20 
                                @elseif($service->status == 'suspended') text-inactive bg-inactive/20
                                @else text-warning bg-warning/20 
                                @endif">
                                @if ($service->status == 'active')
                                    <x-ri-checkbox-circle-fill class="size-3" />
                                @elseif($service->status == 'suspended')
                                    <x-ri-forbid-fill class="size-3" />
                                @elseif($service->status == 'pending')
                                    <x-ri-error-warning-fill class="size-3" />
                                @endif
                                <span class="capitalize">{{ $service->status }}</span>
                            </div>
                            <x-ri-arrow-right-s-line class="size-4 text-base/40" />
                        </div>
                    </div>
                </a>
            @empty
                <div class="px-6 py-12 text-center">
                    <div class="inline-flex items-center justify-center size-16 bg-primary/10 rounded-full mb-4">
                        <x-ri-instance-line class="size-8 text-primary" />
                    </div>
                    <h3 class="font-semibold text-lg mb-2">{{ __('citadel::citadel.services.index.no_services_title') }}</h3>
                    <p class="text-base/60 text-sm">{{ __('citadel::citadel.services.index.no_services_description') }}</p>
                </div>
            @endforelse
        </div>
        
        
        <div class="px-4 sm:px-6 py-4 border-t border-neutral bg-background-secondary/30">
            <div class="flex items-center justify-between">
                
                <div class="hidden sm:flex items-center gap-3">
                    <span class="text-sm text-base/60">{{ __('citadel::citadel.services.index.per_page') }}</span>
                    <div class="relative" x-data="{ open: false }">
                        <button @click="open = !open" class="inline-flex items-center gap-2 px-3 py-1.5 bg-background border border-neutral rounded-md text-sm font-medium hover:bg-primary/5 transition-colors duration-200">
                            <span>{{ $perPage }}</span>
                            <x-ri-arrow-down-s-line class="size-4 transition-transform duration-200" x-bind:class="open ? 'rotate-180' : ''" />
                        </button>
                        <div x-show="open" 
                             @click.away="open = false"
                             x-transition:enter="transition ease-out duration-200"
                             x-transition:enter-start="opacity-0 scale-95"
                             x-transition:enter-end="opacity-100 scale-100"
                             x-transition:leave="transition ease-in duration-150"
                             x-transition:leave-start="opacity-100 scale-100"
                             x-transition:leave-end="opacity-0 scale-95"
                             class="absolute bottom-full left-0 mb-1 w-20 bg-background-secondary border border-neutral rounded-lg z-20">
                            <div class="py-1">
                                <button wire:click="$set('perPage', 10)" @click="open = false" class="w-full text-left px-3 py-2 text-sm hover:bg-primary/5 transition-colors duration-200">10</button>
                                <button wire:click="$set('perPage', 25)" @click="open = false" class="w-full text-left px-3 py-2 text-sm hover:bg-primary/5 transition-colors duration-200">25</button>
                                <button wire:click="$set('perPage', 50)" @click="open = false" class="w-full text-left px-3 py-2 text-sm hover:bg-primary/5 transition-colors duration-200">50</button>
                            </div>
                        </div>
                    </div>
                </div>
                
                
                <div class="flex items-center gap-2">
                    
                    <button 
                        wire:click="previousPage" 
                        @if(!$services->hasPages() || $services->onFirstPage()) disabled @endif
                        class="inline-flex items-center gap-2 px-3 py-1.5 bg-background border border-neutral rounded-md text-sm font-medium hover:bg-primary/5 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-background">
                        <x-ri-arrow-left-s-line class="size-4" />
                        <span>{{ __('citadel::citadel.services.index.previous') }}</span>
                    </button>
                    
                    
                    <button 
                        wire:click="nextPage" 
                        @if(!$services->hasPages() || !$services->hasMorePages()) disabled @endif
                        class="inline-flex items-center gap-2 px-3 py-1.5 bg-background border border-neutral rounded-md text-sm font-medium hover:bg-primary/5 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-background">
                        <span>{{ __('citadel::citadel.services.index.next') }}</span>
                        <x-ri-arrow-right-s-line class="size-4" />
                    </button>
                </div>
            </div>
        </div>
    </div>
        
        </div> 
    </div> 
</div>
