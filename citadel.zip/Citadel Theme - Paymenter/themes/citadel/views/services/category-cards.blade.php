@php
$_cardLayout = 'responsive';
$serviceCardsData = [];

$cardsJson = theme('service_cards_data');
if ($cardsJson) {
    $decoded = is_string($cardsJson) ? json_decode($cardsJson, true) : (is_array($cardsJson) ? $cardsJson : []);
    if (is_array($decoded)) {
        $serviceCardsData = $decoded;
    }
}
@endphp

@foreach($serviceCardsData as $card)
@php
    $cardDesign = $card['card_design'] ?? 'top_border';
    $cardTitle = $card['title'] ?? '';
    $cardDesc = $card['description'] ?? '';
    $cardBtnText = $card['button_text'] ?? '';
    $cardBtnLink = $card['button_link'] ?? '';
    $cardImage = $card['image'] ?? '';
    $cardImageUrl = $cardImage ? asset('storage/' . $cardImage) : '';
@endphp

@if($cardTitle || $cardDesc || $cardBtnText)
    @if($cardDesign === 'top_border')
    <div class="relative flex flex-col bg-background-secondary border border-neutral border-t-4 rounded-lg overflow-hidden" style="border-top-color: hsl(var(--color-primary));">
        @if($cardImageUrl)
        <div class="absolute inset-0">
            <img src="{{ $cardImageUrl }}" alt="" class="w-full h-full object-cover" />
            <div class="absolute inset-0 bg-background-secondary/90 dark:bg-background-secondary/95"></div>
        </div>
        @endif
        <div class="relative z-10 p-5">
            @if($cardTitle)
            <h3 class="font-semibold" style="color: hsl(var(--color-base));">{{ $cardTitle }}</h3>
            @endif
            @if($cardDesc)
            <p class="mt-2 text-sm" style="color: hsl(var(--color-base) / 0.6);">{{ $cardDesc }}</p>
            @endif
            @if($cardBtnText && $cardBtnLink)
            <a href="{{ $cardBtnLink }}" wire:navigate class="mt-3 inline-flex items-center gap-x-1 text-sm font-semibold transition-colors duration-200 hover:underline" style="color: hsl(var(--color-primary));">
                {{ $cardBtnText }}
                <svg class="shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>
            </a>
            @endif
        </div>
    </div>
    @elseif($cardDesign === 'image_bg')
    <div class="relative bg-background-secondary border border-neutral rounded-lg overflow-hidden" style="min-height: 200px;">
        @if($cardImageUrl)
        <img src="{{ $cardImageUrl }}" alt="" class="w-full h-full absolute inset-0 object-cover" />
        <div class="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/70"></div>
        @endif
        <div class="relative z-10 p-5 flex flex-col justify-between h-full" style="min-height: 200px;">
            <div>
                @if($cardTitle)
                <h3 class="font-semibold text-white">{{ $cardTitle }}</h3>
                @endif
                @if($cardDesc)
                <p class="mt-1 text-sm text-white/80">{{ $cardDesc }}</p>
                @endif
            </div>
            @if($cardBtnText && $cardBtnLink)
            <a href="{{ $cardBtnLink }}" wire:navigate class="mt-4 inline-flex items-center gap-x-1 text-sm font-semibold text-white hover:underline transition-colors duration-200">
                {{ $cardBtnText }}
                <svg class="shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>
            </a>
            @endif
        </div>
    </div>
    @elseif($cardDesign === 'icon_card')
    <div class="flex flex-col bg-background-secondary border border-neutral rounded-lg overflow-hidden">
        <div class="p-5">
            <div class="flex items-center gap-3 mb-2">
                @if($cardImageUrl)
                <img src="{{ $cardImageUrl }}" alt="" class="size-10 rounded-lg object-cover flex-shrink-0" />
                @endif
                @if($cardTitle)
                <h3 class="font-semibold" style="color: hsl(var(--color-base));">{{ $cardTitle }}</h3>
                @endif
            </div>
            @if($cardDesc)
            <p class="mt-1 text-sm" style="color: hsl(var(--color-base) / 0.6);">{{ $cardDesc }}</p>
            @endif
            @if($cardBtnText && $cardBtnLink)
            <a href="{{ $cardBtnLink }}" wire:navigate class="mt-3 inline-flex items-center gap-x-1 text-sm font-semibold transition-colors duration-200 hover:underline" style="color: hsl(var(--color-primary));">
                {{ $cardBtnText }}
                <svg class="shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>
            </a>
            @endif
        </div>
    </div>
    @endif
@endif
@endforeach
