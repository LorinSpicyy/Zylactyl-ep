@php
$_transitionMode = 'slide';
$carouselData = [];

$carouselJson = theme('service_carousel_data');
if ($carouselJson) {
    $decoded = is_string($carouselJson) ? json_decode($carouselJson, true) : (is_array($carouselJson) ? $carouselJson : []);
    if (is_array($decoded)) {
        foreach ($decoded as $i => $card) {
            $title = $card['title'] ?? '';
            $backgroundImage = $card['background_image'] ?? '';
            if ($title && $backgroundImage) {
                $carouselData[] = [
                    'title' => $title,
                    'description' => $card['description'] ?? '',
                    'button_text' => $card['button_text'] ?? '',
                    'button_link' => $card['button_link'] ?? '',
                    'background_image' => asset('storage/' . $backgroundImage),
                    'overlay_type' => $card['overlay_type'] ?? 'primary',
                    'text_alignment' => $card['text_alignment'] ?? 'bottom_left',
                    'card_number' => $i + 1,
                ];
            }
        }
    }
}
@endphp

<div 
    x-data="{
        currentSlide: 0,
        slides: {{ count($carouselData) }},
        autoplay: true,
        autoplayInterval: null,
        startAutoplay() {
            if (this.autoplay && this.slides > 1) {
                this.autoplayInterval = setInterval(() => {
                    this.nextSlide();
                }, 5000);
            }
        },
        stopAutoplay() {
            if (this.autoplayInterval) {
                clearInterval(this.autoplayInterval);
            }
        },
        nextSlide() {
            this.currentSlide = (this.currentSlide + 1) % this.slides;
        },
        prevSlide() {
            this.currentSlide = (this.currentSlide - 1 + this.slides) % this.slides;
        },
        goToSlide(index) {
            this.currentSlide = index;
        }
    }"
    x-init="startAutoplay()"
    @mouseenter="stopAutoplay()"
    @mouseleave="startAutoplay()"
    class="relative w-full h-full rounded-lg overflow-hidden"
>
    @if(count($carouselData) > 0)
        @foreach($carouselData as $index => $slide)
        @php
            $overlayType = $slide['overlay_type'];
            $alignment = $slide['text_alignment'];


            if ($overlayType === 'dark') {
                $overlayGradient = match($alignment) {
                    'bottom_left' => 'bg-gradient-to-t from-black/80 via-black/40 to-black/20',
                    'top_left' => 'bg-gradient-to-b from-black/80 via-black/40 to-black/20',
                    'center' => 'bg-black/50',
                    'top_right' => 'bg-gradient-to-bl from-black/80 via-black/40 to-black/20',
                    default => 'bg-gradient-to-t from-black/80 via-black/40 to-black/20',
                };
            } else {
                $overlayGradient = match($alignment) {
                    'bottom_left' => 'bg-gradient-to-t from-primary/80 via-primary/40 to-primary/20',
                    'top_left' => 'bg-gradient-to-b from-primary/80 via-primary/40 to-primary/20',
                    'center' => 'bg-primary/50',
                    'top_right' => 'bg-gradient-to-bl from-primary/80 via-primary/40 to-primary/20',
                    default => 'bg-gradient-to-t from-primary/80 via-primary/40 to-primary/20',
                };
            }


            $contentPosition = match($alignment) {
                'bottom_left' => 'flex items-end justify-start p-8 pb-8',
                'top_left' => 'flex items-start justify-start p-8 pt-12',
                'center' => 'flex items-center justify-center p-8',
                'top_right' => 'flex items-start justify-end p-8 pt-12',
                default => 'flex items-end justify-start p-8 pb-8',
            };

            $textAlign = match($alignment) {
                'center' => 'text-center',
                'top_right' => 'text-right',
                default => 'text-left',
            };
        @endphp
        <div 
            x-show="currentSlide === {{ $index }}"
            x-transition:enter="transition ease-out duration-500"
            x-transition:enter-start="opacity-0 transform translate-x-full"
            x-transition:enter-end="opacity-100 transform translate-x-0"
            x-transition:leave="transition ease-in duration-500"
            x-transition:leave-start="opacity-100 transform translate-x-0"
            x-transition:leave-end="opacity-0 transform -translate-x-full"
            class="absolute inset-0 w-full h-full"
        >
            @if($slide['button_text'])
                <div class="relative w-full h-full rounded-lg overflow-hidden">
                    <div 
                        class="absolute inset-0 bg-cover bg-center bg-no-repeat"
                        style="background-image: url('{{ $slide['background_image'] }}');"
                    ></div>
                    <div class="absolute inset-0 {{ $overlayGradient }}"></div>
                    
                    <div class="relative z-10 {{ $contentPosition }} h-full">
                        <div class="{{ $textAlign }} max-w-2xl text-white">
                            <h2 class="text-3xl font-bold mb-3 leading-tight">{{ $slide['title'] }}</h2>
                            @if($slide['description'])
                                <p class="text-white/90 text-lg mb-6 leading-relaxed">{{ $slide['description'] }}</p>
                            @endif
                            @if($slide['button_link'])
                                <a 
                                    href="{{ $slide['button_link'] }}" 
                                    class="inline-flex items-center px-8 py-4 bg-white text-primary font-semibold rounded-lg hover:bg-white/90 transition-all duration-200"
                                >
                                    {{ $slide['button_text'] }}
                                    <i class="ri-arrow-right-fill ml-2"></i>
                                </a>
                            @endif
                        </div>
                    </div>
                </div>
            @else
                @if($slide['button_link'])
                    <a href="{{ $slide['button_link'] }}" class="block relative w-full h-full rounded-lg overflow-hidden hover:transform hover:scale-[1.02] transition-transform duration-200">
                        <div 
                            class="absolute inset-0 bg-cover bg-center bg-no-repeat"
                            style="background-image: url('{{ $slide['background_image'] }}');"
                        ></div>
                        <div class="absolute inset-0 {{ $overlayGradient }}"></div>
                        
                        <div class="relative z-10 {{ $contentPosition }} h-full">
                            <div class="{{ $textAlign }} max-w-2xl text-white">
                                <h2 class="text-3xl font-bold mb-3 leading-tight">{{ $slide['title'] }}</h2>
                                @if($slide['description'])
                                    <p class="text-white/90 text-lg leading-relaxed">{{ $slide['description'] }}</p>
                                @endif
                            </div>
                        </div>
                    </a>
                @else
                    <div class="relative w-full h-full rounded-lg overflow-hidden">
                        <div 
                            class="absolute inset-0 bg-cover bg-center bg-no-repeat"
                            style="background-image: url('{{ $slide['background_image'] }}');"
                        ></div>
                        <div class="absolute inset-0 {{ $overlayGradient }}"></div>
                        
                        <div class="relative z-10 {{ $contentPosition }} h-full">
                            <div class="{{ $textAlign }} max-w-2xl text-white">
                                <h2 class="text-3xl font-bold mb-3 leading-tight">{{ $slide['title'] }}</h2>
                                @if($slide['description'])
                                    <p class="text-white/90 text-lg leading-relaxed">{{ $slide['description'] }}</p>
                                @endif
                            </div>
                        </div>
                    </div>
                @endif
            @endif
        </div>
        @endforeach
        
        @if(count($carouselData) > 1)
            <div class="absolute top-4 left-1/2 transform -translate-x-1/2 z-20 flex space-x-1 w-full max-w-xs px-4">
                @for($i = 0; $i < count($carouselData); $i++)
                <button 
                    @click="goToSlide({{ $i }}); stopAutoplay()"
                    :class="currentSlide === {{ $i }} ? 'bg-white' : 'bg-white/30'"
                    class="flex-1 h-1 rounded-full transition-colors duration-200 hover:bg-white/75"
                    aria-label="Go to slide {{ $i + 1 }}"
                ></button>
                @endfor
            </div>
        @endif
    @endif
</div>