@php
    $_detailView = 'expanded';
    $hideBreadcrumb = true;
@endphp

<div>
    
    <div class="mb-8 pt-8">
        <div class="flex items-start justify-between">
            <div class="flex-1">
                <h1 class="page-title">{{ __('citadel::citadel.services.show.title') }}</h1>
                <p class="normal-text text-base/60 mt-2">
                    {{ __('citadel::citadel.services.show.subtitle', ['product' => $service->product->name]) }}
                </p>
            </div>
        </div>
    </div>

    
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        
        <div class="lg:col-span-3">
            <div>
                <h3 class="secondary-title mb-6">{{ __('citadel::citadel.services.quick_actions') }}</h3>
                
                <div class="space-y-4">
                    @php
                        
                        $firstCategory = \App\Models\Category::whereNull('parent_id')
                            ->where(function ($query) {
                                $query->whereHas('children')->orWhereHas('products', function ($query) {
                                    $query->where('hidden', false);
                                });
                            })
                            ->orderBy('sort')
                            ->first();
                    @endphp
                    
                    @if($firstCategory)
                    
                    <a href="{{ route('category.show', ['category' => $firstCategory->slug]) }}" 
                       wire:navigate 
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="flex-shrink-0">
                            <x-ri-shopping-cart-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.services.order_new_service') }}</span>
                    </a>
                    @endif
                    
                    
                    <a href="{{ route('services') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="flex-shrink-0">
                            <x-ri-server-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.services.show.view_all_services') }}</span>
                    </a>
                    
                    
                    <a href="/tickets" 
                       wire:navigate 
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="flex-shrink-0">
                            <x-ri-lifebuoy-line class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.services.contact_support') }}</span>
                    </a>
                </div>
                
                
                @php
                    $enableServiceCards = theme('enable_service_cards') ?? true;
                    $serviceCardsType = theme('service_cards_type') ?? 'carousel';
                    
                    $hasCarouselCards = false;
                    $hasCustomCards = false;
                    
                    if ($enableServiceCards) {
                        if ($serviceCardsType === 'carousel') {
                            $carouselJson = theme('service_carousel_data');
                            if ($carouselJson) {
                                $decoded = is_string($carouselJson) ? json_decode($carouselJson, true) : (is_array($carouselJson) ? $carouselJson : []);
                                if (is_array($decoded)) {
                                    foreach ($decoded as $card) {
                                        if (!empty($card['title']) && !empty($card['background_image'])) {
                                            $hasCarouselCards = true;
                                            break;
                                        }
                                    }
                                }
                            }
                        } elseif ($serviceCardsType === 'cards') {
                            $cardsJson = theme('service_cards_data');
                            if ($cardsJson) {
                                $decodedCards = is_string($cardsJson) ? json_decode($cardsJson, true) : (is_array($cardsJson) ? $cardsJson : []);
                                $hasCustomCards = is_array($decodedCards) && count($decodedCards) > 0;
                            }
                        }
                    }
                @endphp
                
                @if($hasCarouselCards)
                    <div class="hidden lg:block w-full aspect-[10/12] mt-6">
                        @include('services.category-carousel')
                    </div>
                @elseif($hasCustomCards)
                    <div class="hidden lg:block mt-6 space-y-4">
                        @include('services.category-cards')
                    </div>
                @endif
            </div>
        </div>
        
        
        <div class="lg:col-span-9">
            
            @if($invoice = $service->invoices()->where('status', 'pending')->first())
            <div class="mb-6">
                <div class="bg-warning border border-warning rounded-lg">
                    <div class="p-4">
                        <div class="flex items-center justify-between">
                            <div class="flex items-center gap-3">
                                <div class="flex-shrink-0">
                                    <div class="inline-flex items-center justify-center w-8 h-8 rounded-full bg-white/20">
                                        <x-ri-error-warning-fill class="size-4 text-white" />
                                    </div>
                                </div>
                                <div class="flex-1">
                                    <h3 class="nav-text font-medium text-white mb-1">{{ __('citadel::citadel.services.show.unpaid_invoice_title') }}</h3>
                                    <p class="small-text text-white/90">
                                        {{ __('citadel::citadel.services.show.unpaid_invoice_message') }}
                                    </p>
                                </div>
                            </div>
                            <div class="flex-shrink-0 ml-6">
                                <a href="{{ route('invoices.show', $invoice) }}" 
                                   wire:navigate 
                                   class="inline-flex items-center gap-2 px-4 py-2 bg-white text-warning rounded-md hover:bg-white/90 transition-colors duration-200 small-text font-medium">
                                    {{ __('citadel::citadel.services.show.pay_now') }}
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @endif
            
            @php
                $isDomainService = $service->properties()->where('key', 'domain_name')->exists();
            @endphp

            @if(!$isDomainService)
            <div class="mb-6">
                <div class="bg-background-secondary border border-neutral rounded-lg">
                    <div class="p-6">
                        
                        <div class="mb-6">
                            <div class="flex justify-between items-center">
                                <div class="flex-1 min-w-0">
                                    <h2 class="secondary-title">{{ $service->product->name }}</h2>
                                    {{-- v1.5.0: custom service label --}}
                                    @if(!$editLabel)
                                        <div class="flex items-center gap-2 mt-1">
                                            @if($service->label)
                                                <span class="normal-text text-base/70 text-sm italic">{{ $service->label }}</span>
                                            @endif
                                            <button type="button" wire:click="$set('editLabel', true)"
                                                class="inline-flex items-center gap-1 text-xs text-base/50 hover:text-primary transition-colors"
                                                title="{{ __('services.label_modal_title') }}">
                                                <x-ri-pencil-line class="size-3.5" />
                                                <span>{{ $service->label ? __('services.update_label') : __('services.label') }}</span>
                                            </button>
                                        </div>
                                    @else
                                        <form wire:submit.prevent="updateLabel" class="flex items-center gap-2 mt-2 max-w-md">
                                            <input type="text" wire:model="label" maxlength="255"
                                                placeholder="{{ __('services.label_placeholder') }}"
                                                class="flex-1 rounded-md border border-neutral bg-background px-3 py-1.5 text-sm normal-text focus:border-primary focus:outline-none" />
                                            <x-button.primary type="submit" class="!py-1.5 !px-3 text-sm">{{ __('services.update_label') }}</x-button.primary>
                                            <button type="button" wire:click="$set('editLabel', false)" class="text-sm text-base/60 hover:text-base px-2">{{ __('common.cancel') }}</button>
                                        </form>
                                        @error('label') <p class="text-xs text-red-500 mt-1">{{ $message }}</p> @enderror
                                    @endif
                                </div>
                                @if($service->upgradable)
                                <a href="{{ route('services.upgrade', $service->id) }}" class="ml-4">
                                    <x-button.primary class="inline-flex items-center">
                                        <span>Upgrade Plan</span>
                                    </x-button.primary>
                                </a>
                                @elseif($service->upgrade()->where('status', 'pending')->exists())
                                <div class="ml-4">
                                    <x-button.primary class="inline-flex items-center opacity-50 cursor-not-allowed"
                                        @click="Alpine.store('notifications').addNotification([{message: '{{ __('services.upgrade_pending') }}', type: 'error'}])">
                                        <span>Upgrade Plan</span>
                                    </x-button.primary>
                                </div>
                                @endif
                            </div>
                        </div>
                        
                       
                        <div class="mb-6">
                            <div class="grid md:grid-cols-2 gap-x-8 gap-y-3">
                                <div class="flex justify-between items-center py-2 border-b border-neutral">
                                    <span class="normal-text font-medium">{{ __('citadel::citadel.services.show.name_label') }}</span>
                                    <span class="normal-text text-base/60">{{ $service->product->name }}</span>
                                </div>
                                <div class="flex justify-between items-center py-2 border-b border-neutral">
                                    <span class="normal-text font-medium">{{ __('citadel::citadel.services.show.price_label') }}</span>
                                    <span class="normal-text text-base/60">{{ $service->formattedPrice }}</span>
                                </div>
                                @if($service->plan->type == 'recurring')
                                <div class="flex justify-between items-center py-2 border-b border-neutral">
                                    <span class="normal-text font-medium">{{ __('citadel::citadel.services.show.billing_cycle_label') }}</span>
                                    <span class="normal-text text-base/60">{{ __('services.every_period', [
                                        'period' => $service->plan->billing_period > 1 ? $service->plan->billing_period : '',
                                        'unit' => trans_choice(__('services.billing_cycles.' . $service->plan->billing_unit),
                                        $service->plan->billing_period)
                                        ])
                                        }}</span>
                                </div>
                                <div class="flex justify-between items-center py-2 border-b border-neutral">
                                    <span class="normal-text font-medium">{{ __('citadel::citadel.services.show.expires_at_label') }}</span>
                                    <span class="normal-text text-base/60">{{ $service->expires_at ? $service->expires_at->format('M d, Y')
                                        : 'N/A' }}</span>
                                </div>
                                @endif
                                <div class="flex justify-between items-center py-2 border-b border-neutral">
                                    <span class="normal-text font-medium">{{ __('citadel::citadel.services.show.status_label') }}</span>
                                    @if($service->cancellation && $service->status == 'active')
                                    <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium text-warning bg-warning/20">
                                        <x-ri-error-warning-fill class="size-3" />
                                        <span>{{ __('services.statuses.cancellation_pending') }}</span>
                                    </div>
                                    @else
                                    <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium
                                        @if ($service->status == 'active') text-success bg-success/20 
                                        @elseif($service->status == 'suspended') text-inactive bg-inactive/20
                                        @elseif($service->status == 'cancelled') text-danger bg-danger/20
                                        @else text-warning bg-warning/20 
                                        @endif">
                                        @if ($service->status == 'active')
                                            <x-ri-checkbox-circle-fill class="size-3" />
                                        @elseif($service->status == 'suspended')
                                            <x-ri-forbid-fill class="size-3" />
                                        @elseif($service->status == 'cancelled')
                                            <x-ri-close-circle-fill class="size-3" />
                                        @elseif($service->status == 'pending')
                                            <x-ri-error-warning-fill class="size-3" />
                                        @endif
                                        <span class="capitalize">{{ __('services.statuses.' . $service->status) }}</span>
                                    </div>
                                    @endif
                                </div>

                                
                                @foreach ($fields as $field)
                                <div class="flex justify-between items-center py-2 border-b border-neutral">
                                    <span class="normal-text font-medium">{{ $field['label'] }}</span>
                                    <span class="normal-text text-base/60">{{ $field['text'] }}</span>
                                </div>
                                @endforeach
                            </div>
                        </div>
                        
                        
                        <div class="border-t border-neutral pt-4">
                            <div class="flex justify-between items-center">
                                <span class="nav-text font-medium">{{ __('citadel::citadel.services.show.total_price_per_term') }}</span>
                                <span class="nav-text font-bold">{{ $service->formattedPrice }}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @endif

           
            @if($service->cancellable || count($buttons) > 0)
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                
                <div>
                    <div class="bg-background-secondary border border-neutral rounded-lg">
                        <div class="p-6 pb-0">
                            <h3 class="secondary-title mb-4">{{ __('citadel::citadel.services.show.service_invoices') }}</h3>
                        </div>
                        
                        @php
                            $serviceInvoices = $service->invoices()->orderBy('id', 'desc')->limit(5)->get();
                        @endphp
                        
                        @if($serviceInvoices->count() > 0)
                            <div>
                                @foreach($serviceInvoices as $invoice)
                                <div class="px-6 py-4 flex items-center justify-between relative group hover:bg-primary/5 transition-colors duration-200">
                                    <div class="flex-1">
                                        <div class="flex items-center gap-3 mb-2">
                                            <span class="font-medium">Invoice #{{ $invoice->number }}</span>
                                            <span class="text-base/50 font-semibold">
                                                <x-ri-circle-fill class="size-1 text-base/20" />
                                            </span>
                                            <span class="text-base text-sm">{{ $invoice->formattedTotal }}</span>
                                        </div>
                                        <p class="text-base text-sm text-base/60">
                                            {{ __('invoices.invoice_date')}}: {{ $invoice->created_at->format('d M Y') }}
                                        </p>
                                    </div>
                                    <div class="flex items-center gap-3 ml-4">
                                        <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium
                                            @if ($invoice->status == 'paid') text-success bg-success/20
                                            @elseif($invoice->status == 'cancelled') text-info bg-info/20
                                            @else text-warning bg-warning/20
                                            @endif">
                                            @if ($invoice->status == 'paid')
                                                <x-ri-checkbox-circle-fill class="size-3" />
                                            @elseif($invoice->status == 'cancelled')
                                                <x-ri-forbid-fill class="size-3" />
                                            @elseif($invoice->status == 'pending')
                                                <x-ri-error-warning-fill class="size-3" />
                                            @endif
                                            <span class="capitalize">{{ $invoice->status }}</span>
                                        </div>
                                        <a href="{{ route('invoices.show', $invoice) }}" wire:navigate class="px-4 py-2 border border-base/30 text-base hover:bg-secondary/10 rounded-md transition-colors duration-200 text-sm font-medium min-w-[100px] text-center">
                                            View
                                        </a>
                                    </div>
                                </div>
                                @endforeach
                            </div>
                            
                            @if($service->invoices()->count() > 5)
                            <div class="px-6 py-4 border-t border-neutral">
                                <a href="{{ route('invoices') }}" 
                                   class="text-primary hover:text-primary/80 transition-colors duration-200 text-sm font-medium">
                                    View all invoices ({{ $service->invoices()->count() }})
                                </a>
                            </div>
                            @endif
                        @else
                            <div class="px-6 py-8 text-center">
                                <div class="text-base/60 mb-2">
                                    <x-ri-receipt-line class="size-8 mx-auto mb-3 opacity-40" />
                                </div>
                                <p class="text-base text-sm text-base/60">No invoices found for this service</p>
                            </div>
                        @endif
                    </div>
                </div>

                
                <div>
                    <div class="bg-background-secondary border border-neutral rounded-lg">
                        <div class="p-6">
                            <h3 class="secondary-title mb-4">{{ __('citadel::citadel.services.show.service_actions') }}</h3>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                                @if($service->cancellable)
                                <x-button.danger class="w-full justify-center" wire:click="$set('showCancel', true)">
                                    <x-ri-close-circle-fill class="size-4 mr-2" />
                                    <span wire:loading.remove wire:target="$set('showCancel', true)">{{ __('services.cancel') }}</span>
                                    <x-loading target="$set('showCancel', true)" />
                                </x-button.danger>
                                @endif

                                @foreach ($buttons as $button)
                                @if (isset($button['function']))
                                <x-button.primary class="w-full justify-center" wire:click="goto('{{ $button['function'] }}')">
                                    {{ $button['label'] }}
                                </x-button.primary>
                                @else
                                <a href="{{ $button['url'] }}" class="block"
                                    @if(!empty($button['target'])) target="{{ $button['target'] }}" @endif
                                    @if(($button['target'] ?? null) === '_blank') rel="noopener noreferrer" @endif>
                                    <x-button.primary class="w-full justify-center">
                                        {{ $button['label'] }}
                                    </x-button.primary>
                                </a>
                                @endif
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @endif

            
            @if (count($views) > 0)
            <div class="bg-background-secondary border border-neutral rounded-lg">
                <div class="flex items-center justify-between p-6 pb-4">
                    <h2 class="secondary-title">{{ __('citadel::citadel.services.show.service_management') }}</h2>
                </div>
                <div class="border-t border-neutral"></div>
                <div class="p-6">
                    @if (count($views) > 1)
                    <div class="flex w-fit mb-6 flex-row flex-wrap border-b border-neutral">
                        @foreach ($views as $view)
                        <button wire:click="changeView('{{ $view['name'] }}')"
                            class="px-4 py-2 -mb-px focus:outline-none transition-colors duration-200 {{ $view['name'] == $currentView ? 'border-b-2 border-primary font-semibold text-primary' : 'normal-text border-b border-transparent hover:text-primary/80' }}">
                            {{ $view['label'] }}
                        </button>
                        @endforeach
                    </div>
                    @endif

                    
                    <x-loading target="changeView" />
                    <div wire:loading.remove wire:target="changeView">
                        {!! $extensionView !!}
                    </div>
                </div>
            </div>
            @endif
        </div>
    </div>

    
    @if($showCancel)
    <x-modal open="true"
        title="{{ __('services.cancellation', ['service' => $service->product->name]) }}"
        width="max-w-3xl">
        <livewire:services.cancel :service="$service" />
        <x-slot name="closeTrigger">
            <div class="flex gap-4">
                <button wire:click="$set('showCancel', false)" @click="open = false"
                    class="text-primary-100">
                    <x-ri-close-fill class="size-6" />
                </button>
            </div>
        </x-slot>
    </x-modal>
    @endif
</div>