@php
    $_upgradeFlow = true;
    $hideBreadcrumb = true;
@endphp

<div>
   
    <div class="mb-8 pt-8">
        <div class="flex items-start justify-between">
            <div class="flex-1">
                <h1 class="page-title">{{ __('services.upgrade_service', ['service' => $service->product->name]) }}</h1>
                <p class="normal-text text-base/60 mt-2">
                    @if($step == 1)
                        {{ __('services.upgrade_choose_product') }}
                    @else
                        {{ __('services.upgrade_choose_config') }}
                    @endif
                </p>
            </div>
        </div>
    </div>

    
    <div class="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        <div class="lg:col-span-3">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            @if($step == 1)
            
            @if(theme('pricing_card_icon_style', 'icon_top') == 'background')
                
                <div class="flex flex-col border border-neutral rounded-lg text-left relative overflow-hidden isolate">
                    
                    @if($service->product->image)
                        <div class="absolute inset-0 rounded-lg overflow-hidden z-0">
                            <img src="{{ Storage::url($service->product->image) }}" alt="{{ $service->product->name }}" 
                                 class="w-full h-full object-cover">
                        </div>
                    @endif
                    
                    
                    <div class="absolute inset-0 bg-gradient-to-b from-background-secondary/75 via-background-secondary/90 to-background-secondary z-[1]"></div>
                    
                    
                    <div class="relative z-[2] p-6 flex flex-col h-full">
                        
                        <div class="mb-4">
                            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium bg-primary/20 text-primary w-fit mb-3">
                                <x-ri-star-fill class="size-3" />
                                <span>{{ __('services.current_plan') }}</span>
                            </div>
                            <h2 class="text-xl font-bold">{{ $service->product->name }}</h2>
                        </div>
                        
                        
                        <div class="text-base mb-4 text-left">
                            <div class="text-sm font-medium mb-1 text-muted">Current Price</div>
                            <div class="flex items-baseline gap-2">
                                <span class="text-2xl font-bold">
                                    @if($service->plan->type == 'recurring')
                                    {{ $service->product->price(null, $service->plan->billing_period, $service->plan->billing_unit, $service->currency_code) }}
                                    @else 
                                    {{ $service->product->price(null, null, null, $service->currency_code) }}
                                    @endif
                                </span>
                                @if($service->plan->type == 'recurring')
                                <span class="text-sm font-medium text-muted">
                                    / {{ $service->plan->billing_period > 1 ? $service->plan->billing_period . ' ' : '' }}{{ trans_choice(__('services.billing_cycles.' . $service->plan->billing_unit), $service->plan->billing_period) }}
                                </span>
                                @endif
                            </div>
                        </div>
                        
                        
                        <div class="w-full h-px bg-neutral/60 mb-4"></div>
                        
                        
                        @if($service->product->description)
                            <div class="mb-3 flex-grow">
                                <article class="prose dark:prose-invert prose-sm max-w-none text-left py-1
                                    [&_ul]:list-disc [&_ol]:list-decimal [&_li]:mb-0 [&_li]:text-sm [&_li]:leading-tight
                                    [&_ul]:pl-4 [&_ol]:pl-4 [&_li]:pl-1 [&_p]:mb-0 [&_li_p]:mb-0 [&_ul]:space-y-0
                                    [&_strong]:font-semibold [&_strong]:text-base">
                                    {!! $service->product->description !!}
                                </article>
                            </div>
                        @endif
                        
                        
                        <input type="radio" name="upgrade" value="{{ $service->product->id }}" wire:model.live="upgrade"
                            class="hidden peer" id="product-{{ $service->product->id }}">
                        <label for="product-{{ $service->product->id }}" class="mt-auto cursor-pointer">
                            <div class="w-full px-4 py-3 border rounded-lg transition-all duration-200 text-center normal-text font-medium
                                {{ $upgrade == $service->product->id ? 'border-primary bg-primary text-white' : 'border-neutral bg-background-secondary text-base hover:border-primary/40' }}">
                                {{ $upgrade == $service->product->id ? 'Selected' : 'Select Plan' }}
                            </div>
                        </label>
                    </div>
                </div>
            @else
                
                <div class="flex flex-col bg-background-secondary hover:bg-background-secondary/80 border border-neutral p-6 rounded-lg
                    {{ in_array(theme('pricing_card_icon_style', 'icon_top'), ['icon_top']) ? 'text-center' : 'text-left' }} relative">
                    
                    
                    <div class="mb-4">
                        <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium bg-primary/20 text-primary w-fit {{ theme('pricing_card_icon_style', 'icon_top') == 'icon_top' ? 'mx-auto' : '' }}">
                            <x-ri-star-fill class="size-3" />
                            <span>{{ __('services.current_plan') }}</span>
                        </div>
                    </div>
                    
                    @if(theme('pricing_card_icon_style', 'icon_top') == 'icon_top')
                       
                        @if ($service->product->image)
                            <div class="flex justify-center mb-3">
                                <img src="{{ Storage::url($service->product->image) }}" alt="{{ $service->product->name }}" 
                                     class="w-12 h-12 object-cover object-center rounded-lg">
                            </div>
                        @endif
                        
                        <h2 class="text-xl font-bold mb-3">{{ $service->product->name }}</h2>
                    @elseif(theme('pricing_card_icon_style', 'icon_top') == 'icon_top_left')
                        
                        <div class="flex items-center gap-3 mb-4">
                            @if ($service->product->image)
                                <img src="{{ Storage::url($service->product->image) }}" alt="{{ $service->product->name }}" 
                                     class="w-12 h-12 object-cover object-center rounded-lg flex-shrink-0">
                            @endif
                            <h2 class="text-xl font-bold">{{ $service->product->name }}</h2>
                        </div>
                    @elseif(theme('pricing_card_icon_style', 'icon_top') == 'icon_right')
                        
                        <div class="flex items-end justify-between gap-4 mb-4 relative">
                            <div class="flex-1 z-10 relative">
                                <h2 class="text-xl font-bold mb-2">{{ $service->product->name }}</h2>
                                
                                
                                <div class="text-left">
                                    <div class="text-sm font-medium mb-1 text-muted">Current Price</div>
                                    <div class="flex items-baseline gap-2">
                                        <span class="text-2xl font-bold">
                                            @if($service->plan->type == 'recurring')
                                            {{ $service->product->price(null, $service->plan->billing_period, $service->plan->billing_unit, $service->currency_code) }}
                                            @else 
                                            {{ $service->product->price(null, null, null, $service->currency_code) }}
                                            @endif
                                        </span>
                                        @if($service->plan->type == 'recurring')
                                        <span class="text-sm font-medium text-muted">
                                            / {{ $service->plan->billing_period > 1 ? $service->plan->billing_period . ' ' : '' }}{{ trans_choice(__('services.billing_cycles.' . $service->plan->billing_unit), $service->plan->billing_period) }}
                                        </span>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            
                            @if ($service->product->image)
                                <div class="absolute right-0 bottom-0 z-0">
                                    <img src="{{ Storage::url($service->product->image) }}" alt="{{ $service->product->name }}" 
                                         class="w-20 h-20 object-cover object-center rounded-lg opacity-90">
                                </div>
                            @endif
                        </div>
                        
                        <div class="w-full h-px bg-neutral/60 mb-4"></div>
                    @else
                        <h2 class="text-xl font-bold mb-4">{{ $service->product->name }}</h2>
                    @endif
                    
                    
                    @if(theme('pricing_card_icon_style', 'icon_top') == 'icon_top_left')
                        <div class="text-base mb-4 text-left">
                            <div class="text-sm font-medium mb-1 text-muted">Current Price</div>
                            <div class="flex items-baseline gap-2">
                                <span class="text-2xl font-bold">
                                    @if($service->plan->type == 'recurring')
                                    {{ $service->product->price(null, $service->plan->billing_period, $service->plan->billing_unit, $service->currency_code) }}
                                    @else 
                                    {{ $service->product->price(null, null, null, $service->currency_code) }}
                                    @endif
                                </span>
                                @if($service->plan->type == 'recurring')
                                <span class="text-sm font-medium text-muted">
                                    / {{ $service->plan->billing_period > 1 ? $service->plan->billing_period . ' ' : '' }}{{ trans_choice(__('services.billing_cycles.' . $service->plan->billing_unit), $service->plan->billing_period) }}
                                </span>
                                @endif
                            </div>
                        </div>
                        <div class="w-full h-px bg-neutral/60 mb-4"></div>
                    @elseif(theme('pricing_card_icon_style', 'icon_top') == 'icon_top')
                        <div class="mb-3">
                            <span class="text-sm font-medium text-muted">Current Price</span><br>
                            <span class="text-2xl font-bold">
                                @if($service->plan->type == 'recurring')
                                {{ $service->product->price(null, $service->plan->billing_period, $service->plan->billing_unit, $service->currency_code) }}
                                @else 
                                {{ $service->product->price(null, null, null, $service->currency_code) }}
                                @endif
                            </span>
                            @if($service->plan->type == 'recurring')
                                <div class="text-sm font-medium text-muted mt-1">
                                    / {{ $service->plan->billing_period > 1 ? $service->plan->billing_period . ' ' : '' }}{{ trans_choice(__('services.billing_cycles.' . $service->plan->billing_unit), $service->plan->billing_period) }}
                                </div>
                            @endif
                        </div>
                        <div class="w-full h-px bg-neutral/60 mb-3"></div>
                    @endif

                    
                    @if($service->product->description)
                        <div class="{{ in_array(theme('pricing_card_icon_style', 'icon_top'), ['icon_top_left', 'icon_right']) ? 'mb-4' : 'mb-3' }} flex-grow">
                            @if(in_array(theme('pricing_card_icon_style', 'icon_top'), ['icon_top_left', 'icon_right']))
                                <article class="prose dark:prose-invert prose-sm max-w-none text-left py-2
                                    [&_ul]:list-disc [&_ol]:list-decimal [&_li]:mb-0 [&_li]:text-sm [&_li]:leading-tight
                                    [&_ul]:pl-4 [&_ol]:pl-4 [&_li]:pl-1 [&_p]:mb-0 [&_li_p]:mb-0 [&_ul]:space-y-0
                                    [&_strong]:font-semibold [&_strong]:text-base">
                                    {!! $service->product->description !!}
                                </article>
                            @else
                                <article class="prose dark:prose-invert prose-sm max-w-none text-left py-1
                                    [&_ul]:list-disc [&_ol]:list-decimal [&_li]:mb-0 [&_li]:text-sm [&_li]:leading-tight
                                    [&_ul]:pl-4 [&_ol]:pl-4 [&_li]:pl-1 [&_p]:mb-0 [&_li_p]:mb-0 [&_ul]:space-y-0
                                    [&_strong]:font-semibold [&_strong]:text-base">
                                    {!! $service->product->description !!}
                                </article>
                            @endif
                        </div>
                    @endif
                    
                    
                    <input type="radio" name="upgrade" value="{{ $service->product->id }}" wire:model.live="upgrade"
                        class="hidden peer" id="product-{{ $service->product->id }}">
                    <label for="product-{{ $service->product->id }}" class="mt-auto cursor-pointer">
                        <div class="w-full px-4 py-3 border rounded-lg transition-all duration-200 text-center normal-text font-medium
                            {{ $upgrade == $service->product->id ? 'border-primary bg-primary text-white' : 'border-neutral bg-background-secondary text-base hover:border-primary/40' }}">
                            {{ $upgrade == $service->product->id ? 'Selected' : 'Select Plan' }}
                        </div>
                    </label>
                </div>
            @endif
            @foreach ($service->productUpgrades() as $product)
            @if(theme('pricing_card_icon_style', 'icon_top') == 'background')
                
                <div class="flex flex-col border border-neutral rounded-lg text-left relative overflow-hidden isolate">
                    
                    @if($product->image)
                        <div class="absolute inset-0 rounded-lg overflow-hidden z-0">
                            <img src="{{ Storage::url($product->image) }}" alt="{{ $product->name }}" 
                                 class="w-full h-full object-cover">
                        </div>
                    @endif
                    
                    
                    <div class="absolute inset-0 bg-gradient-to-b from-background-secondary/75 via-background-secondary/90 to-background-secondary z-[1]"></div>
                    
                    
                    <div class="relative z-[2] p-6 flex flex-col h-full">
                        
                        <div class="mb-4">
                            @if($upgrade == $product->id)
                            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium bg-secondary/20 text-secondary w-fit mb-3">
                                <x-ri-arrow-right-up-line class="size-3" />
                                <span>{{ __('services.new_plan') }}</span>
                            </div>
                            @else
                            <div class="mb-3 h-7"></div>
                            @endif
                            <h2 class="text-xl font-bold">{{ $product->name }}</h2>
                        </div>
                        
                        
                        <div class="text-base mb-4 text-left">
                            <div class="text-sm font-medium mb-1 text-muted">Upgrade Price</div>
                            <div class="flex items-baseline gap-2">
                                <span class="text-2xl font-bold">
                                    @if($service->plan->type == 'recurring')
                                    {{ $product->price(null, $service->plan->billing_period, $service->plan->billing_unit, $service->currency_code) }}
                                    @else 
                                    {{ $product->price(null, null, null, $service->currency_code) }}
                                    @endif
                                </span>
                                @if($service->plan->type == 'recurring')
                                <span class="text-sm font-medium text-muted">
                                    / {{ $service->plan->billing_period > 1 ? $service->plan->billing_period . ' ' : '' }}{{ trans_choice(__('services.billing_cycles.' . $service->plan->billing_unit), $service->plan->billing_period) }}
                                </span>
                                @endif
                            </div>
                        </div>
                        
                       
                        <div class="w-full h-px bg-neutral/60 mb-4"></div>
                        
                        
                        @if($product->description)
                            <div class="mb-3 flex-grow">
                                <article class="prose dark:prose-invert prose-sm max-w-none text-left py-1
                                    [&_ul]:list-disc [&_ol]:list-decimal [&_li]:mb-0 [&_li]:text-sm [&_li]:leading-tight
                                    [&_ul]:pl-4 [&_ol]:pl-4 [&_li]:pl-1 [&_p]:mb-0 [&_li_p]:mb-0 [&_ul]:space-y-0
                                    [&_strong]:font-semibold [&_strong]:text-base">
                                    {!! $product->description !!}
                                </article>
                            </div>
                        @endif
                        
                        
                        <input type="radio" name="upgrade" value="{{ $product->id }}" wire:model.live="upgrade"
                            class="hidden peer" id="product-{{ $product->id }}">
                        <label for="product-{{ $product->id }}" class="mt-auto cursor-pointer">
                            <div class="w-full px-4 py-3 border rounded-lg transition-all duration-200 text-center normal-text font-medium
                                {{ $upgrade == $product->id ? 'border-primary bg-primary text-white' : 'border-neutral bg-background-secondary text-base hover:border-primary/40' }}">
                                {{ $upgrade == $product->id ? 'Selected' : 'Select Plan' }}
                            </div>
                        </label>
                    </div>
                </div>
            @else
                
                <div class="flex flex-col bg-background-secondary hover:bg-background-secondary/80 border border-neutral p-6 rounded-lg
                    {{ in_array(theme('pricing_card_icon_style', 'icon_top'), ['icon_top']) ? 'text-center' : 'text-left' }} relative">
                    
                    
                    <div class="mb-4">
                        @if($upgrade == $product->id)
                        <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium bg-secondary/20 text-secondary w-fit {{ theme('pricing_card_icon_style', 'icon_top') == 'icon_top' ? 'mx-auto' : '' }}">
                            <x-ri-arrow-right-up-line class="size-3" />
                            <span>{{ __('services.new_plan') }}</span>
                        </div>
                        @else
                        <div class="h-7"></div>
                        @endif
                    </div>
                    
                    @if(theme('pricing_card_icon_style', 'icon_top') == 'icon_top')
                        
                        @if ($product->image)
                            <div class="flex justify-center mb-3">
                                <img src="{{ Storage::url($product->image) }}" alt="{{ $product->name }}" 
                                     class="w-12 h-12 object-cover object-center rounded-lg">
                            </div>
                        @endif
                        
                        <h2 class="text-xl font-bold mb-3">{{ $product->name }}</h2>
                    @elseif(theme('pricing_card_icon_style', 'icon_top') == 'icon_top_left')
                        
                        <div class="flex items-center gap-3 mb-4">
                            @if ($product->image)
                                <img src="{{ Storage::url($product->image) }}" alt="{{ $product->name }}" 
                                     class="w-12 h-12 object-cover object-center rounded-lg flex-shrink-0">
                            @endif
                            <h2 class="text-xl font-bold">{{ $product->name }}</h2>
                        </div>
                    @elseif(theme('pricing_card_icon_style', 'icon_top') == 'icon_right')
                        
                        <div class="flex items-end justify-between gap-4 mb-4 relative">
                            <div class="flex-1 z-10 relative">
                                <h2 class="text-xl font-bold mb-2">{{ $product->name }}</h2>
                                
                               
                                <div class="text-left">
                                    <div class="text-sm font-medium mb-1 text-muted">Upgrade Price</div>
                                    <div class="flex items-baseline gap-2">
                                        <span class="text-2xl font-bold">
                                            @if($service->plan->type == 'recurring')
                                            {{ $product->price(null, $service->plan->billing_period, $service->plan->billing_unit, $service->currency_code) }}
                                            @else 
                                            {{ $product->price(null, null, null, $service->currency_code) }}
                                            @endif
                                        </span>
                                        @if($service->plan->type == 'recurring')
                                        <span class="text-sm font-medium text-muted">
                                            / {{ $service->plan->billing_period > 1 ? $service->plan->billing_period . ' ' : '' }}{{ trans_choice(__('services.billing_cycles.' . $service->plan->billing_unit), $service->plan->billing_period) }}
                                        </span>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            
                            @if ($product->image)
                                <div class="absolute right-0 bottom-0 z-0">
                                    <img src="{{ Storage::url($product->image) }}" alt="{{ $product->name }}" 
                                         class="w-20 h-20 object-cover object-center rounded-lg opacity-90">
                                </div>
                            @endif
                        </div>
                        
                        <div class="w-full h-px bg-neutral/60 mb-4"></div>
                    @else
                        <h2 class="text-xl font-bold mb-4">{{ $product->name }}</h2>
                    @endif
                    
                    
                    @if(theme('pricing_card_icon_style', 'icon_top') == 'icon_top_left')
                        <div class="text-base mb-4 text-left">
                            <div class="text-sm font-medium mb-1 text-muted">Upgrade Price</div>
                            <div class="flex items-baseline gap-2">
                                <span class="text-2xl font-bold">
                                    @if($service->plan->type == 'recurring')
                                    {{ $product->price(null, $service->plan->billing_period, $service->plan->billing_unit, $service->currency_code) }}
                                    @else 
                                    {{ $product->price(null, null, null, $service->currency_code) }}
                                    @endif
                                </span>
                                @if($service->plan->type == 'recurring')
                                <span class="text-sm font-medium text-muted">
                                    / {{ $service->plan->billing_period > 1 ? $service->plan->billing_period . ' ' : '' }}{{ trans_choice(__('services.billing_cycles.' . $service->plan->billing_unit), $service->plan->billing_period) }}
                                </span>
                                @endif
                            </div>
                        </div>
                        <div class="w-full h-px bg-neutral/60 mb-4"></div>
                    @elseif(theme('pricing_card_icon_style', 'icon_top') == 'icon_top')
                        <div class="mb-3">
                            <span class="text-sm font-medium text-muted">Upgrade Price</span><br>
                            <span class="text-2xl font-bold">
                                @if($service->plan->type == 'recurring')
                                {{ $product->price(null, $service->plan->billing_period, $service->plan->billing_unit, $service->currency_code) }}
                                @else 
                                {{ $product->price(null, null, null, $service->currency_code) }}
                                @endif
                            </span>
                            @if($service->plan->type == 'recurring')
                                <div class="text-sm font-medium text-muted mt-1">
                                    / {{ $service->plan->billing_period > 1 ? $service->plan->billing_period . ' ' : '' }}{{ trans_choice(__('services.billing_cycles.' . $service->plan->billing_unit), $service->plan->billing_period) }}
                                </div>
                            @endif
                        </div>
                        <div class="w-full h-px bg-neutral/60 mb-3"></div>
                    @endif

                    
                    @if($product->description)
                        <div class="{{ in_array(theme('pricing_card_icon_style', 'icon_top'), ['icon_top_left', 'icon_right']) ? 'mb-4' : 'mb-3' }} flex-grow">
                            @if(in_array(theme('pricing_card_icon_style', 'icon_top'), ['icon_top_left', 'icon_right']))
                                <article class="prose dark:prose-invert prose-sm max-w-none text-left py-2
                                    [&_ul]:list-disc [&_ol]:list-decimal [&_li]:mb-0 [&_li]:text-sm [&_li]:leading-tight
                                    [&_ul]:pl-4 [&_ol]:pl-4 [&_li]:pl-1 [&_p]:mb-0 [&_li_p]:mb-0 [&_ul]:space-y-0
                                    [&_strong]:font-semibold [&_strong]:text-base">
                                    {!! $product->description !!}
                                </article>
                            @else
                                <article class="prose dark:prose-invert prose-sm max-w-none text-left py-1
                                    [&_ul]:list-disc [&_ol]:list-decimal [&_li]:mb-0 [&_li]:text-sm [&_li]:leading-tight
                                    [&_ul]:pl-4 [&_ol]:pl-4 [&_li]:pl-1 [&_p]:mb-0 [&_li_p]:mb-0 [&_ul]:space-y-0
                                    [&_strong]:font-semibold [&_strong]:text-base">
                                    {!! $product->description !!}
                                </article>
                            @endif
                        </div>
                    @endif
                    
                    
                    <input type="radio" name="upgrade" value="{{ $product->id }}" wire:model.live="upgrade"
                        class="hidden peer" id="product-{{ $product->id }}">
                    <label for="product-{{ $product->id }}" class="mt-auto cursor-pointer">
                        <div class="w-full px-4 py-3 border rounded-lg transition-all duration-200 text-center normal-text font-medium
                            {{ $upgrade == $product->id ? 'border-primary bg-primary text-white' : 'border-neutral bg-background-secondary text-base hover:border-primary/40' }}">
                            {{ $upgrade == $product->id ? 'Selected' : 'Select Plan' }}
                        </div>
                    </label>
                </div>
            @endif
            @endforeach
            @else
            <div class="md:col-span-2 flex flex-col gap-6">
                @foreach ($upgradeProduct->upgradableConfigOptions as $configOption)
                @php
                    $showPriceTag = $configOption->children->filter(fn ($value) => !$value->price(billing_period: $service->plan->billing_period, billing_unit: $service->plan->billing_unit)->is_free)->count() > 0;
                    
                    
                    $envVarDescription = '';
                    if ($configOption->env_variable) {
                        $varsJson = theme('env_var_descriptions_data', '[]');
                        $varsData = is_string($varsJson) ? json_decode($varsJson, true) : (is_array($varsJson) ? $varsJson : []);
                        foreach ($varsData as $varItem) {
                            if (!empty($varItem['name']) && strtolower(trim($varItem['name'])) === strtolower(trim($configOption->env_variable))) {
                                $envVarDescription = $varItem['description'] ?? '';
                                break;
                            }
                        }
                    }
                @endphp
                
                @if ($configOption->type == 'select')
                    <div>
                        <h3 class="check-out-title-semi mb-2 !font-normal">{{ $configOption->name }}{{ $configOption->required ? ' *' : '' }}</h3>
                        @if($envVarDescription)
                            <p class="small-text text-base mb-4 leading-relaxed !font-light">{{ $envVarDescription }}</p>
                        @endif
                        <select wire:model.live="configOptions.{{ $configOption->id }}" 
                                class="w-full px-4 py-3 border rounded-lg
                                       focus:outline-none transition-all duration-200 
                                       border-neutral bg-background-secondary focus:border-primary/40 hover:border-neutral">
                            @foreach ($configOption->children as $configOptionValue)
                                <option value="{{ $configOptionValue->id }}">
                                    {{ $configOptionValue->name }}
                                    {{ ($showPriceTag && $configOptionValue->price(billing_period: $service->plan->billing_period, billing_unit: $service->plan->billing_unit)->available) ? ' - ' . $configOptionValue->price(billing_period: $service->plan->billing_period, billing_unit: $service->plan->billing_unit) : '' }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                @elseif($configOption->type == 'radio')
                    <div>
                        <h3 class="check-out-title-semi mb-2 !font-normal">{{ $configOption->name }}{{ $configOption->required ? ' *' : '' }}</h3>
                        @if($envVarDescription)
                            <p class="small-text text-base mb-4 leading-relaxed !font-light">{{ $envVarDescription }}</p>
                        @endif
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            @foreach ($configOption->children as $configOptionValue)
                                @php
                                    
                                    $iconPath = null;
                                    $optionName = $configOptionValue->name;
                                    
                                    
                                    $possibleNames = [
                                        strtolower($optionName),
                                        strtoupper($optionName),
                                        $optionName,
                                        str_replace(' ', '', strtolower($optionName)),
                                        str_replace(' ', '-', strtolower($optionName)),
                                        str_replace(' ', '_', strtolower($optionName)),
                                        str_replace([',', ' '], '', strtolower($optionName)),
                                        str_replace([',', ' '], '-', strtolower($optionName)),
                                        str_replace([',', ' '], '_', strtolower($optionName)),
                                        preg_replace('/[^a-zA-Z0-9]/', '', strtolower($optionName)),
                                        preg_replace('/[^a-zA-Z0-9]/', '', strtoupper($optionName)),
                                        strtolower(explode(',', $optionName)[0]),
                                        strtolower(trim(explode(',', $optionName)[0])),
                                        strtolower(trim(explode(',', $optionName)[count(explode(',', $optionName)) - 1])),
                                        strtolower(str_replace([', usa', ', us', ' usa', ' us'], '', $optionName)),
                                        strtolower(str_replace([', uk', ' uk'], '', $optionName)),
                                    ];
                                    
                                    $possibleNames = array_filter(array_unique($possibleNames));
                                    
                                    foreach ($possibleNames as $name) {
                                        if (empty($name)) continue;
                                        
                                        $svgPath = public_path("assets/variables/{$name}.svg");
                                        if (file_exists($svgPath)) {
                                            $iconPath = "/assets/variables/{$name}.svg";
                                            break;
                                        }
                                    }
                                @endphp
                                
                                <div wire:click="$set('configOptions.{{ $configOption->id }}', {{ $configOptionValue->id }})"
                                     class="cursor-pointer p-4 border rounded-lg transition-all duration-200
                                            {{ (isset($configOptions[$configOption->id]) && $configOptions[$configOption->id] == $configOptionValue->id) ? 'border-primary/40 bg-primary/5' : 'border-neutral bg-background-secondary hover:border-neutral' }}">
                                    
                                    <div class="flex justify-between items-center">
                                        <div class="flex flex-col">
                                            
                                            <h4 class="radio-title mb-1 !font-bold">{{ $configOptionValue->name }}</h4>
                                            
                                            
                                            @if($showPriceTag && $configOptionValue->price(billing_period: $service->plan->billing_period, billing_unit: $service->plan->billing_unit)->available)
                                                <div class="check-out-text-small-bold text-primary !font-medium">
                                                    {{ $configOptionValue->price(billing_period: $service->plan->billing_period, billing_unit: $service->plan->billing_unit) }}
                                                </div>
                                            @else
                                                <div class="check-out-text-small-bold text-muted !font-medium">
                                                    Free
                                                </div>
                                            @endif
                                        </div>
                                        
                                        
                                        @if($iconPath)
                                            <div class="flex-shrink-0 w-12 h-12 opacity-70 relative">
                                                <img src="{{ $iconPath }}" alt="{{ $configOptionValue->name }}" class="w-full h-full object-contain">
                                            </div>
                                        @endif
                                    </div>
                                    
                                    
                                    <input type="radio" id="{{ $configOptionValue->id }}" name="{{ $configOption->id }}"
                                        wire:model.live="configOptions.{{ $configOption->id }}"
                                        value="{{ $configOptionValue->id }}" class="sr-only" />
                                </div>
                            @endforeach
                        </div>
                    </div>
                @elseif($configOption->type == 'text' || $configOption->type == 'number')
                    <div>
                        <h3 class="check-out-title-semi mb-2 !font-normal">{{ $configOption->name }}{{ $configOption->required ? ' *' : '' }}</h3>
                        @if($envVarDescription)
                            <p class="small-text text-base mb-4 leading-relaxed !font-light">{{ $envVarDescription }}</p>
                        @endif
                        <input type="{{ $configOption->type }}" 
                               wire:model.live="configOptions.{{ $configOption->id }}"
                               class="w-full px-4 py-3 border rounded-lg
                                      focus:outline-none transition-all duration-200 
                                      border-neutral bg-background-secondary focus:border-primary/40 hover:border-neutral"
                               placeholder="{{ $configOption->placeholder ?? '' }}" />
                    </div>
                @elseif($configOption->type == 'checkbox')
                    <div>
                        <h3 class="check-out-title-semi mb-2 !font-normal">{{ $configOption->name }}{{ $configOption->required ? ' *' : '' }}</h3>
                        @if($envVarDescription)
                            <p class="small-text text-base mb-4 leading-relaxed !font-light">{{ $envVarDescription }}</p>
                        @endif
                        <div class="flex items-center gap-3 p-3 border rounded-lg
                                    border-neutral bg-background-secondary">
                            <input type="checkbox" id="config_{{ $configOption->id }}"
                                   wire:model.live="configOptions.{{ $configOption->id }}"
                                   class="w-4 h-4 text-primary border border-neutral rounded focus:ring-primary/20 focus:ring-2 
                                          bg-background-secondary checked:bg-primary checked:border-primary 
                                          checked:text-white transition-all duration-200 accent-primary" />
                            <label for="config_{{ $configOption->id }}" class="normal-text cursor-pointer">
                                {{ $configOption->name }}
                            </label>
                        </div>
                    </div>
                @elseif($configOption->type == 'slider')
                    <div>
                        <h3 class="check-out-title-semi mb-2 !font-normal">{{ $configOption->name }}{{ $configOption->required ? ' *' : '' }}</h3>
                        @if($envVarDescription)
                            <p class="small-text text-base mb-4 leading-relaxed !font-light">{{ $envVarDescription }}</p>
                        @endif
                        <div class="p-6 border border-neutral bg-background-secondary rounded-lg transition-all duration-200 hover:border-neutral">
                            <div x-data="{
                                options: @js($configOption->children->map(fn($child) => ['option' => $child->name, 'value' => $child->id, 'price' => ($showPriceTag && $child->price(billing_period: $service->plan->billing_period, billing_unit: $service->plan->billing_unit)->available) ? (string)$child->price(billing_period: $service->plan->billing_period, billing_unit: $service->plan->billing_unit) : ''])),
                                showPriceTag: @js($showPriceTag),
                                selectedOption: 0,
                                backendOption: $wire.entangle('configOptions.{{ $configOption->id }}').live,
                                progressOption: '0%',
                                segmentsWidthOption: '0%',

                                init() {
                                    const initialValue = this.$wire.get('configOptions.{{ $configOption->id }}');
                                    const foundIndex = this.options.findIndex(option => option.value == initialValue);
                                    if (foundIndex !== -1) {
                                        this.selectedOption = foundIndex;
                                    }
                                    this.updateSliderVisuals();
                                    $watch('selectedOption', Alpine.debounce(() => this.backendOption = this.options[this.selectedOption].value, 300))
                                },

                                updateSliderVisuals() {
                                    this.progressOption = `${(this.selectedOption / (this.options.length - 1)) * 100}%`;
                                    this.segmentsWidthOption = `${100 / (this.options.length - 1)}%`;
                                },

                                setOptionValue(index) {
                                    this.selectedOption = parseInt(index);
                                    this.updateSliderVisuals();
                                }
                            }" class="flex flex-col gap-2 relative pt-6">
                                
                                <div class="relative flex items-center" :style="`--progress:${progressOption};--segments-width:${segmentsWidthOption}`" wire:ignore>
                                    
                                    <div class="
                                        absolute left-2.5 right-2.5 h-3 bg-neutral/20 rounded-full overflow-hidden transition-all duration-500 ease-in-out
                                        before:absolute before:inset-0 before:bg-primary before:rounded-full
                                        before:[mask-image:_linear-gradient(to_right,theme(colors.white),theme(colors.white)_var(--progress),transparent_var(--progress))]
                                        [&[x-cloak]]:hidden" aria-hidden="true"></div>
                                    
                                    
                                    <div class="absolute left-2.5 right-2.5 flex justify-between items-center pointer-events-none h-3" aria-hidden="true">
                                        @foreach($configOption->children as $child)
                                            @if(!$loop->first && !$loop->last)
                                                <div class="w-0.5 h-2 bg-neutral/60 rounded-full transition-all duration-200"
                                                     :class="selectedOption >= {{ $loop->index }} ? 'bg-primary' : 'bg-neutral/60'"></div>
                                            @else
                                                <div></div>
                                            @endif
                                        @endforeach
                                    </div>
                                    
                                    
                                    <div class="absolute pointer-events-none transition-all duration-300 ease-out z-10" 
                                         :style="`left: calc(${progressOption} + 10px - ${progressOption === '0%' ? '0px' : progressOption === '100%' ? '50px' : '25px'})`">
                                        <div class="bg-primary text-white px-3 py-2 rounded-lg text-sm font-semibold whitespace-nowrap 
                                                    transform -translate-y-10 relative" x-show="showPriceTag && options[selectedOption]?.price">
                                            <span x-text="options[selectedOption]?.price"></span>
                                        </div>
                                    </div>
                                    
                                    <input class="
                                        relative appearance-none cursor-pointer w-full bg-transparent focus:outline-none transition-all duration-500 ease-in-out
                                        [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:h-7 [&::-webkit-slider-thumb]:w-4
                                        [&::-webkit-slider-thumb]:rounded-md [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:border [&::-webkit-slider-thumb]:border-neutral
                                        [&::-webkit-slider-thumb]:cursor-pointer [&::-webkit-slider-thumb]:transition-all [&::-webkit-slider-thumb]:duration-200
                                        [&::-webkit-slider-thumb]:focus:ring-2 [&::-webkit-slider-thumb]:focus:ring-primary/20
                                        [&::-moz-range-thumb]:h-7 [&::-moz-range-thumb]:w-4 [&::-moz-range-thumb]:rounded-md [&::-moz-range-thumb]:bg-white
                                        [&::-moz-range-thumb]:border [&::-moz-range-thumb]:border-neutral [&::-moz-range-thumb]:cursor-pointer
                                        [&::-moz-range-thumb]:transition-all [&::-moz-range-thumb]:duration-200
                                    " type="range" min="0" :max="options.length - 1" x-model="selectedOption" @input="setOptionValue(selectedOption)" 
                                       aria-label="Option Slider" name="configOptions.{{ $configOption->id }}" id="configOptions.{{ $configOption->id }}" />
                                </div>
                                
                                
                                <div class="flex justify-between items-start pt-2">
                                    @foreach($configOption->children as $child)
                                        <div class="flex flex-col items-center text-center cursor-pointer transition-all duration-200 hover:scale-105" 
                                             @click="setOptionValue({{ $loop->index }})">
                                            <span class="button-text mb-1">
                                                {{ $child->name }}
                                            </span>
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                @else
                    <x-form.configoption :config="$configOption" :name="'configOptions.' . $configOption->id" :showPriceTag="$showPriceTag" :plan="$service->plan">
                    </x-form.configoption>
                @endif
                @endforeach
            </div>
            @endif
            </div>
        </div>
        
        
        <div class="lg:col-span-1">
            <div class="bg-background-secondary border border-neutral rounded-lg p-6 sticky top-6">
                <h2 class="secondary-title mb-6">{{ __('citadel::citadel.services.upgrade.upgrade_summary') }}</h2>
                
                <div class="space-y-4 mb-6">
                    
                    <div class="flex flex-col gap-1">
                        <span class="normal-text text-base/60">{{ __('services.current_plan') }}</span>
                        <span class="normal-text font-medium">{{ $service->product->name }}</span>
                    </div>
                    
                    
                    @if($upgrade != $service->product->id)
                    <div class="flex flex-col gap-1">
                        <span class="normal-text text-base/60">{{ __('services.new_plan') }}</span>
                        <span class="normal-text font-medium">{{ $upgradeProduct ? $upgradeProduct->name : __('general.select_plan') }}</span>
                    </div>
                    @endif
                </div>

                
                <div class="border-t border-neutral pt-4 mb-6">
                    <div class="flex items-center justify-between">
                        <span class="normal-text font-medium">{{ __('services.total_today') }}</span>
                        <span class="check-out-text-small-bold !font-semibold text-primary">{{ $this->totalToday() }}</span>
                    </div>
                </div>

                
                <x-button.primary class="w-full" :wire:click="($upgradeProduct->upgradableConfigOptions()->count() > 0 && $step == 1)? 'nextStep' : 'doUpgrade'">
                    @if($upgradeProduct && $upgradeProduct->upgradableConfigOptions()->count() > 0 && $step == 1)
                        <x-ri-arrow-right-line class="size-5" />
                        <span>{{ __('services.next_step') }}</span>
                    @else
                        <x-ri-arrow-up-line class="size-5" />
                        <span>{{ __('services.upgrade') }}</span>
                    @endif
                </x-button.primary>
            </div>
        </div>
    </div>
</div>