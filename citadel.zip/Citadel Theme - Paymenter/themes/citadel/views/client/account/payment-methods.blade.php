@php
    
    $hideBreadcrumb = true;
@endphp

<div>
    
    @if($setupModalVisible)
    <x-modal :title="__('account.payment_methods')" open="true">
        <x-slot name="closeTrigger">
            <div class="flex gap-4">
                <button wire:click="$set('setupModalVisible', false)" class="text-primary hover:text-primary/80">
                    <x-ri-close-fill class="size-6" />
                </button>
            </div>
        </x-slot>
        @if(count($this->gateways) > 1)
        <x-form.select name="gateway" :label="__('account.input.payment_gateway')" wire:model.live="gateway" required>
            @foreach($this->gateways as $gateway)
            <option value="{{ $gateway->id }}">{{ $gateway->name }}</option>
            @endforeach
        </x-form.select>
        @elseif(count($this->gateways) === 0)
        <p class="text-sm text-red-500">{{ __('account.no_payment_gateways_available') }}</p>
        @endif
        <button wire:click="createBillingAgreement" 
                wire:loading.attr="disabled"
                class="citadel-btn w-full mt-4 px-4 bg-primary text-white text-sm font-medium rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50">
            <span wire:loading.remove wire:target="createBillingAgreement">
                {{ __('account.setup_payment_method') }}
            </span>
            <span wire:loading wire:target="createBillingAgreement">
                {{ __('citadel::citadel.account.payment_methods_page.setting_up') }}
            </span>
        </button>
        @if ($this->setup)
        <x-modal :title="__('account.setup_payment_method')" open>
            <div class="mt-8">
                {{ $this->setup }}
            </div>
            <x-slot name="closeTrigger">
                <div class="flex gap-4">
                    <button wire:confirm="{{ __('citadel::citadel.account.payment_methods_page.confirm_cancel') }}" 
                            wire:click="cancelSetup" 
                            wire:loading.attr="disabled"
                            wire:target="cancelSetup" 
                            class="text-primary hover:text-primary/80">
                        <x-ri-close-fill class="size-6" />
                    </button>
                </div>
            </x-slot>
        </x-modal>
        @endif
    </x-modal>
    @endif

    
    <div class="mb-8 pt-8">
        <div class="flex items-start justify-between">
            <div class="flex-1">
                <h1 class="page-title">{{ __('account.payment_methods') }}</h1>
                <p class="normal-text text-base/60 mt-2">
                    {{ __('account.saved_payment_methods_description') }}
                </p>
            </div>
        </div>
    </div>

    
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        
        <div class="lg:col-span-3">
            <div>
                <h3 class="secondary-title mb-6">{{ __('citadel::citadel.account.navigation.account_settings') }}</h3>
                
                <div class="space-y-4">
                    
                    <a href="{{ route('account') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="flex-shrink-0">
                            <x-ri-profile-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.navigation.navbar.personal_details') }}</span>
                    </a>
                    
                    
                    <a href="{{ route('account.security') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="flex-shrink-0">
                            <x-ri-fingerprint-2-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.navigation.navbar.security') }}</span>
                    </a>
                    
                    
                    @if(config('settings.credits_enabled'))
                    <a href="{{ route('account.credits') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 text-primary transition-all duration-200 group hover:translate-x-1"
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'">
                        <div class="flex-shrink-0">
                            <x-ri-wallet-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.navigation.navbar.credits') }}</span>
                    </a>
                    @endif
                    
                    
                    <a href="{{ route('account.payment-methods') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1"
                       style="color: hsl(var(--color-secondary));">
                        <div class="flex-shrink-0">
                            <x-ri-bank-card-fill class="size-5" />
                        </div>
                        <span class="normal-text font-semibold">{{ __('citadel::citadel.account.navigation.payment_methods') }}</span>
                    </a>
                    
                   
                    @if(Route::has('account.notifications'))
                    <a href="{{ route('account.notifications') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 text-primary transition-all duration-200 group hover:translate-x-1"
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'">
                        <div class="flex-shrink-0">
                            <x-ri-notification-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.account.navigation.notifications') }}</span>
                    </a>
                    @endif
                </div>
            </div>
        </div>

        
        <div class="lg:col-span-9">
            <div class="space-y-8">
                
                
                <div>
                    <div class="flex items-center justify-between mb-6">
                        <div>
                            <h2 class="secondary-title">{{ __('account.saved_payment_methods') }}</h2>
                        </div>
                        @if(count($this->gateways) > 0)
                        <button wire:click="$set('setupModalVisible', true)"
                                wire:loading.attr="disabled" 
                                wire:target="setupModalVisible"
                                class="citadel-btn btn-primary px-4 bg-primary text-white text-sm font-medium rounded-lg hover:bg-primary/90 transition-colors flex items-center gap-2">
                            <x-ri-add-line class="size-4" />
                            <span>{{ __('account.add_payment_method') }}</span>
                        </button>
                        @endif
                    </div>

                    @php
                    $groupedAgreements = $billingAgreements->groupBy('gateway.name');
                    @endphp

                    @if($groupedAgreements->count() > 0)
                        @foreach($groupedAgreements as $gatewayName => $agreements)
                        <div class="mb-8">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center gap-3">
                                    <div class="bg-background-secondary border border-neutral rounded-lg overflow-hidden size-10 flex items-center justify-center">
                                        @if($agreements->first()?->gateway?->meta?->icon)
                                        <img src="{{ $agreements->first()->gateway->meta->icon }}" alt="{{ $gatewayName }}" class="size-10" />
                                        @else
                                        <x-ri-secure-payment-line class="size-5 text-primary" />
                                        @endif
                                    </div>
                                    <h3 class="normal-text font-semibold text-lg">{{ $gatewayName }}</h3>
                                </div>
                                <span class="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm font-semibold">
                                    {{ $agreements->count() }} {{ $agreements->count() === 1 ? __('citadel::citadel.account.payment_methods_page.method_singular') : __('citadel::citadel.account.payment_methods_page.method_plural') }}
                                </span>
                            </div>

                            <div class="space-y-3">
                                @foreach($agreements as $agreement)
                                <div class="bg-background-secondary border border-neutral p-4 rounded-lg hover:border-neutral transition-all">
                                    <div class="flex items-center justify-between">
                                        <div class="flex items-center gap-4">
                                            <div class="rounded-lg overflow-hidden flex items-center justify-center">
                                                @switch(strtolower($agreement->type))
                                                @case('visa')<x-icons.visa class="size-10" />@break
                                                @case('mastercard')<x-icons.mastercard class="size-10" />@break
                                                @case('amex')<x-icons.amex class="size-10" />@break
                                                @case('american express')<x-icons.american-express class="size-10" />@break
                                                @case('discover')<x-icons.discover class="size-10" />@break
                                                @case('paypal')<x-icons.paypal class="size-10" />@break
                                                @case('sepa_debit')<x-icons.sepa class="size-10" />@break
                                                @case('ideal')<x-icons.ideal class="size-10" />@break
                                                @case('bancontact')<x-icons.bancontact class="size-10" />@break
                                                @case('sofort')<x-icons.sofort class="size-10" />@break
                                                @case('us_bank_account')
                                                @case('bacs_debit')
                                                @case('au_becs_debit')<x-icons.bank-debit class="size-10" />@break
                                                @default<x-ri-bank-card-line class="size-7 text-primary" />
                                                @endswitch
                                            </div>
                                            <div>
                                                <div class="font-semibold normal-text">
                                                    {{ $agreement->name }}
                                                </div>
                                                @if($agreement->expiry)
                                                <div class="text-sm text-base/60 mt-0.5">
                                                    Expires: {{ \Carbon\Carbon::parse($agreement->expiry)->format('m/Y') }}
                                                </div>
                                                @endif
                                                @if($agreement->services()->count() > 0)
                                                <div class="text-xs text-base/50 mt-1">
                                                    {{ __('account.services_linked', ['count' => $agreement->services()->count()]) }}
                                                </div>
                                                @endif
                                            </div>
                                        </div>

                                        <button x-on:click="$store.confirmation.confirm({
                                                    title: '{{ __('account.remove_payment_method') }}',
                                                    message: '{{ __('account.remove_payment_method_confirm', ['name' => $agreement->name]) }}',
                                                    confirmText: '{{ __('account.confirm') }}',
                                                    cancelText: '{{ __('account.cancel') }}',
                                                    callback: () => $wire.removePaymentMethod('{{ $agreement->ulid }}')
                                                })"
                                                class="px-3 py-2 bg-red-500/10 text-red-600 rounded-lg hover:bg-red-500/20 transition-colors flex items-center gap-2">
                                            <x-ri-delete-bin-line class="size-4" />
                                            <span class="text-sm font-medium">{{ __('account.remove') }}</span>
                                        </button>
                                    </div>
                                </div>
                                @endforeach
                            </div>
                        </div>
                        @endforeach
                    @else
                        <div class="bg-background-secondary border border-neutral p-8 rounded-lg text-center">
                            <div class="bg-primary/10 size-16 rounded-full flex items-center justify-center mx-auto mb-4">
                                <x-ri-bank-card-line class="size-8 text-primary" />
                            </div>
                            <h3 class="normal-text font-semibold mb-2">{{ __('account.no_saved_payment_methods') }}</h3>
                            <p class="normal-text text-base/60 text-sm">Add a payment method to make future purchases easier</p>
                        </div>
                    @endif
                </div>

                
                <div>
                    <div class="mb-6">
                        <h2 class="secondary-title">{{ __('account.recent_transactions') }}</h2>
                        <p class="normal-text text-base/60 text-sm">View your recent payment transactions</p>
                    </div>
                    
                    @if($transactions->count() > 0)
                    <div class="space-y-3">
                        @foreach ($transactions as $transaction)
                        <a href="{{ route('invoices.show', $transaction->invoice) }}" wire:navigate>
                            <div class="bg-background-secondary border border-neutral p-4 rounded-lg hover:border-neutral transition-all">
                                <div class="flex items-center justify-between">
                                    <div class="flex items-center gap-4 flex-1">
                                        <div class="bg-secondary/10 p-2 rounded-lg flex-shrink-0">
                                            <x-ri-bill-line class="size-5 text-secondary" />
                                        </div>
                                        <div class="flex-1 min-w-0">
                                            <div class="font-medium normal-text truncate">
                                                {{ $transaction->transaction_id ? 'Transaction: ' . $transaction->transaction_id : 'Transaction ID N/A' }}
                                            </div>
                                            <div class="text-sm text-base/60 mt-0.5">
                                                {{ $transaction->formattedAmount }} using {{ $transaction->gateway ? $transaction->gateway->name : 'N/A' }}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="flex items-center gap-3 flex-shrink-0 ml-4">
                                        @if($transaction->status === \App\Enums\InvoiceTransactionStatus::Succeeded)
                                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs bg-green-100 text-green-800 font-medium">
                                            <x-ri-check-line class="size-3 mr-1" />
                                            {{ __('invoices.transaction_statuses.succeeded') }}
                                        </span>
                                        @elseif($transaction->status === \App\Enums\InvoiceTransactionStatus::Processing)
                                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs bg-yellow-100 text-yellow-800 font-medium">
                                            <x-ri-loader-5-fill class="size-3 mr-1 fill-yellow-600 animate-spin" />
                                            {{ __('invoices.transaction_statuses.processing') }}
                                        </span>
                                        @elseif($transaction->status === \App\Enums\InvoiceTransactionStatus::Failed)
                                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs bg-red-100 text-red-800 font-medium">
                                            <x-ri-close-line class="size-3 mr-1" />
                                            {{ __('invoices.transaction_statuses.failed') }}
                                        </span>
                                        @endif
                                        <span class="text-sm text-base/60">
                                            {{ $transaction->created_at->format('d M Y H:i') }}
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </a>
                        @endforeach
                    </div>
                    {{ $transactions->links() }}
                    @else
                    <div class="bg-background-secondary border border-neutral p-8 rounded-lg text-center">
                        <div class="bg-primary/10 size-16 rounded-full flex items-center justify-center mx-auto mb-4">
                            <x-ri-bill-line class="size-8 text-primary" />
                        </div>
                        <h3 class="normal-text font-semibold mb-2">{{ __('citadel::citadel.account.payment_methods_page.no_transactions_title') }}</h3>
                        <p class="normal-text text-base/60 text-sm">{{ __('citadel::citadel.account.payment_methods_page.no_transactions_description') }}</p>
                    </div>
                    @endif
                </div>

            </div>
        </div>
        
    </div>
</div>
