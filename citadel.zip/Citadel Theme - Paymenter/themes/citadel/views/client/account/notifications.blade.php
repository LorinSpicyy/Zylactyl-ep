@php
    
    $hideBreadcrumb = true;
@endphp

<div>
    
    <div class="mb-8 pt-8">
        <div class="flex items-start justify-between">
            <div class="flex-1">
                <h1 class="page-title">{{ __('citadel::citadel.account.navigation.notifications') }}</h1>
                <p class="normal-text text-base/60 mt-2">
                    {{ __('citadel::citadel.account.notifications_page.subtitle') }}
                </p>
            </div>
        </div>
    </div>

    
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        
        <div class="lg:col-span-3">
            <div>
                <h3 class="secondary-title mb-6">{{ __('citadel::citadel.account.navigation.account_settings') }}</h3>
                
                <div class="space-y-4">
                    
                    <a href="{{ route('account') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="flex-shrink-0">
                            <x-ri-profile-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.navigation.navbar.personal_details') }}</span>
                    </a>
                    
                    
                    <a href="{{ route('account.security') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="flex-shrink-0">
                            <x-ri-fingerprint-2-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.navigation.navbar.security') }}</span>
                    </a>
                    
                   
                    @if(config('settings.credits_enabled'))
                    <a href="{{ route('account.credits') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="flex-shrink-0">
                            <x-ri-wallet-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.navigation.navbar.credits') }}</span>
                    </a>
                    @endif
                    
                    
                    @if(Route::has('account.payment-methods'))
                    <a href="{{ route('account.payment-methods') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="flex-shrink-0">
                            <x-ri-bank-card-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.account.navigation.payment_methods') }}</span>
                    </a>
                    @endif
                    
                    
                    @if(Route::has('account.notifications'))
                    <a href="{{ route('account.notifications') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="flex-shrink-0">
                            <x-ri-notification-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.account.navigation.notifications') }}</span>
                    </a>
                    @endif
                </div>
            </div>
        </div>
        
        
        <div class="lg:col-span-9">
            
            <div class="space-y-8">
                
                
                @if($this->supportsPush())
                <div>
                    <div class="mb-4">
                        <h3 class="secondary-title mb-1">{{ __('account.push_notifications') }}</h3>
                        <p class="normal-text text-base/60 text-sm">{{ __('account.push_notifications_description') }}</p>
                    </div>
                    
                    <div class="bg-background-secondary border border-neutral rounded-lg overflow-hidden" x-data="pushNotifications">
                        <div class="px-6 py-6">
                            <x-button.primary type="button" class="!w-fit" @click="subscribe"
                                x-bind:disabled="subscriptionStatus !== 'not_subscribed'">
                                <x-ri-notification-line class="size-5 mr-2" />
                                {{ __('account.enable_push_notifications') }}
                            </x-button.primary>
                            <div x-show="subscriptionStatus !== 'unknown'" class="mt-4">
                                <template x-if="subscriptionStatus === 'not_supported'">
                                    <p class="text-sm text-red-600">{{ __('account.push_status.not_supported') }}</p>
                                </template>
                                <template x-if="subscriptionStatus === 'denied'">
                                    <p class="text-sm text-red-600">{{ __('account.push_status.denied') }}</p>
                                </template>
                                <template x-if="subscriptionStatus === 'subscribed'">
                                    <p class="text-sm text-green-600">{{ __('account.push_status.subscribed') }}</p>
                                </template>
                            </div>
                        </div>
                    </div>
                </div>
                @endif

                
                <div>
                    <div class="mb-4">
                        <h3 class="secondary-title mb-1">{{ __('citadel::citadel.account.notifications_page.preferences_title') }}</h3>
                        <p class="normal-text text-base/60 text-sm">{{ __('citadel::citadel.account.notifications_page.preferences_description') }}</p>
                    </div>
                    
                    <div class="bg-background-secondary border border-neutral rounded-lg overflow-hidden">
                        <div class="px-6 py-6">
                            <div class="space-y-4">
                                @foreach ($this->notifications as $notification)
                                <div class="flex items-center justify-between p-4 bg-background border border-neutral rounded-lg">
                                    <div class="flex-1">
                                        <h3 class="normal-text font-semibold mb-1">{{ $notification->name }}</h3>
                                    </div>
                                    <div class="flex items-center gap-6">
                                        @if ($notification->mail_controllable)
                                        <label class="flex items-center gap-2 cursor-pointer">
                                            <input type="checkbox" 
                                                   wire:model.defer="preferences.{{ $notification->key }}.mail_enabled"
                                                   {{ $notification->mail_enabled ? 'checked' : '' }}
                                                   class="w-4 h-4 text-primary bg-background border-neutral rounded focus:ring-primary focus:ring-2">
                                            <span class="normal-text text-sm">Email</span>
                                        </label>
                                        @else
                                        <div class="flex items-center gap-2 opacity-50">
                                            <input type="checkbox" 
                                                   {{ $notification->mail_enabled ? 'checked' : '' }}
                                                   disabled
                                                   class="w-4 h-4 text-primary bg-background border-neutral rounded">
                                            <span class="normal-text text-sm">Email</span>
                                        </div>
                                        @endif
                                        
                                        @if ($notification->in_app_controllable)
                                        <label class="flex items-center gap-2 cursor-pointer">
                                            <input type="checkbox" 
                                                   wire:model.defer="preferences.{{ $notification->key }}.in_app_enabled"
                                                   {{ $notification->in_app_enabled ? 'checked' : '' }}
                                                   class="w-4 h-4 text-primary bg-background border-neutral rounded focus:ring-primary focus:ring-2">
                                            <span class="normal-text text-sm">In-App</span>
                                        </label>
                                        @else
                                        <div class="flex items-center gap-2 opacity-50">
                                            <input type="checkbox" 
                                                   {{ $notification->in_app_enabled ? 'checked' : '' }}
                                                   disabled
                                                   class="w-4 h-4 text-primary bg-background border-neutral rounded">
                                            <span class="normal-text text-sm">In-App</span>
                                        </div>
                                        @endif
                                    </div>
                                </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                    
                    
                    <div class="mt-6">
                        <button wire:click="savePreferences" 
                                wire:loading.attr="disabled"
                                class="citadel-btn btn-primary w-full sm:w-auto px-8 bg-primary text-white text-sm font-medium rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
                            <span wire:loading.remove wire:target="savePreferences">{{ __('general.save') }}</span>
                            <span wire:loading wire:target="savePreferences">{{ __('citadel::citadel.account.notifications_page.saving') }}</span>
                        </button>
                    </div>
                </div>

            </div>
            
        </div>
        
    </div>
</div>

@script
<script>
    Alpine.data('pushNotifications', () => ({
            subscriptionStatus: 'unknown',
            
            init() {
                this.checkSubscription();
            },
            
            async checkSubscription() {
                if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
                    this.subscriptionStatus = 'not_supported';
                    return;
                }
                
                try {
                    const registration = await navigator.serviceWorker.ready;
                    const subscription = await registration.pushManager.getSubscription();
                    
                    if (subscription) {
                        this.subscriptionStatus = 'subscribed';
                    } else {
                        const permission = Notification.permission;
                        if (permission === 'denied') {
                            this.subscriptionStatus = 'denied';
                        } else {
                            this.subscriptionStatus = 'not_subscribed';
                        }
                    }
                } catch (error) {
                    console.error('Error checking subscription:', error);
                    this.subscriptionStatus = 'not_supported';
                }
            },
            
            async subscribe() {
                if (Notification.permission === 'denied') {
                    alert('Push notifications are blocked. Please enable them in your browser settings.');
                    return;
                }
                
                try {
                    const permission = await Notification.requestPermission();
                    
                    if (permission !== 'granted') {
                        this.subscriptionStatus = 'denied';
                        return;
                    }
                    
                    const registration = await navigator.serviceWorker.ready;
                    const response = await fetch('/api/vapid-public-key');
                    const vapidPublicKey = await response.text();
                    
                    const subscription = await registration.pushManager.subscribe({
                        userVisibleOnly: true,
                        applicationServerKey: vapidPublicKey
                    });
                    
                    await @this.call('subscribeToPush', subscription.toJSON());
                    
                    this.subscriptionStatus = 'subscribed';
                    
                    Alpine.store('notifications').addNotification([{
                        message: 'Push notifications enabled successfully!',
                        type: 'success'
                    }]);
                } catch (error) {
                    console.error('Error subscribing to push notifications:', error);
                    alert('Failed to enable push notifications. Please try again.');
                }
            }
        }));
</script>
@endscript
