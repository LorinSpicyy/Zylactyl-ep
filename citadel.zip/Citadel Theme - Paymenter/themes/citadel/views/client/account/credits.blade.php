@php
    
    $hideBreadcrumb = true;
@endphp

<div>
    
    <div class="mb-8 pt-8">
        <div class="flex items-start justify-between">
            <div class="flex-1">
                <h1 class="page-title">{{ __('account.credits') }}</h1>
                <p class="normal-text text-base/60 mt-2">
                    {{ __('citadel::citadel.account.credits.subtitle') }}
                </p>
            </div>
        </div>
    </div>

    
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
       
        <div class="lg:col-span-3">
            <div>
                <h3 class="secondary-title mb-6">{{ __('citadel::citadel.account.navigation.account_settings') }}</h3>
                
                <div class="space-y-4">
                    
                    <a href="{{ route('account') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="flex-shrink-0">
                            <x-ri-profile-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.navigation.navbar.personal_details') }}</span>
                    </a>
                    
                    
                    <a href="{{ route('account.security') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="flex-shrink-0">
                            <x-ri-fingerprint-2-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.navigation.navbar.security') }}</span>
                    </a>
                    
                    
                    <a href="{{ route('account.credits') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 text-primary transition-all duration-200 group hover:translate-x-1"
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'">
                        <div class="flex-shrink-0">
                            <x-ri-wallet-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.navigation.navbar.credits') }}</span>
                    </a>
                    
                    
                    @if(Route::has('account.payment-methods'))
                    <a href="{{ route('account.payment-methods') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 text-primary transition-all duration-200 group hover:translate-x-1"
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'">
                        <div class="flex-shrink-0">
                            <x-ri-bank-card-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.account.navigation.payment_methods') }}</span>
                    </a>
                    @endif
                    
                    
                    @if(Route::has('account.notifications'))
                    <a href="{{ route('account.notifications') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 text-primary transition-all duration-200 group hover:translate-x-1"
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'">
                        <div class="flex-shrink-0">
                            <x-ri-notification-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.account.navigation.notifications') }}</span>
                    </a>
                    @endif
                </div>
            </div>
        </div>
        
        
        <div class="lg:col-span-9">
            
            <div class="space-y-8">


                <div>
                    <div class="mb-4">
                        <h3 class="secondary-title mb-1">{{ __('citadel::citadel.account.credits.balance_title') }}</h3>
                        <p class="normal-text text-base/60 text-sm">{{ __('citadel::citadel.account.credits.balance_subtitle') }}</p>
                    </div>

                    @php $citadelCredits = auth()->user()?->credits ?? collect(); @endphp
                    @if($citadelCredits->count() > 0)
                        <div class="flex flex-wrap gap-4">
                            @foreach($citadelCredits as $credit)
                                <div class="bg-background-secondary border border-neutral rounded-lg px-5 py-4 flex flex-col gap-1 min-w-[9rem]">
                                    <span class="normal-text text-base/50 text-xs font-semibold uppercase tracking-wide">{{ $credit->currency->code ?? '' }}</span>
                                    <span class="secondary-title text-2xl font-bold !leading-tight">{{ $credit->formattedAmount }}</span>
                                </div>
                            @endforeach
                        </div>
                    @else
                        <div class="bg-background-secondary border border-neutral rounded-lg px-6 py-6">
                            <p class="normal-text text-base/60 text-sm">{{ __('citadel::citadel.account.credits.no_balance') }}</p>
                        </div>
                    @endif
                </div>


                <div>
                    <div class="mb-4">
                        <h3 class="secondary-title mb-1">{{ __('account.add_credit') }}</h3>
                        <p class="normal-text text-base/60 text-sm">{{ __('citadel::citadel.account.credits.add_funds_title') }}</p>
                    </div>
                    
                    <div class="bg-background-secondary border border-neutral rounded-lg overflow-hidden">
                        <div class="px-6 py-6">
                            <form wire:submit.prevent="addCredit">
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <x-form.select name="currency" :label="__('account.input.currency')" wire:model.live="currency" required>
                                        @foreach(\App\Models\Currency::all() as $currency)
                                        <option value="{{ $currency->code }}">{{ $currency->code }}</option>
                                        @endforeach
                                    </x-form.select>
                                    
                                    <x-form.input x-mask:dynamic="$money($input, '.', '', 2)" name="amount" type="number"
                                        :label="__('account.input.amount')" :placeholder="__('account.input.amount_placeholder')"
                                        wire:model.live.debounce.250ms="amount" required />

                                    <div class="md:col-span-2">
                                        <x-form.select name="gateway" :label="__('product.payment_method')" wire:model.live="gateway" required>
                                            @foreach($gateways as $gatewayy)
                                            <option value="{{ $gatewayy->id }}" wire:key="{{ $gatewayy->id }}" @if($gatewayy->id == $gateway) selected @endif>{{ $gatewayy->name }}</option>
                                            @endforeach
                                        </x-form.select>
                                    </div>
                                </div>

                                <div class="mt-6">
                                    <x-button.primary type="submit" class="w-full md:w-auto px-8">
                                        {{ __('account.add_credit') }}
                                    </x-button.primary>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
            </div>
            
        </div>
        
    </div>
</div>