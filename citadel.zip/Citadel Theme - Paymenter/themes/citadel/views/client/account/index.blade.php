@php
    
    $hideBreadcrumb = true;
@endphp

<div>
    
    <div class="mb-8 pt-8">
        <div class="flex items-start justify-between">
            <div class="flex-1">
                <h1 class="page-title">{{ __('account.personal_details') }}</h1>
                <p class="normal-text text-base/60 mt-2">
                    {{ __('citadel::citadel.account.personal_details.subtitle') }}
                </p>
            </div>
        </div>
    </div>

    
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        
        <div class="lg:col-span-3">
            <div>
                <h3 class="secondary-title mb-6">{{ __('citadel::citadel.account.navigation.account_settings') }}</h3>
                
                <div class="space-y-4">
                    
                    <a href="{{ route('account') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="flex-shrink-0">
                            <x-ri-profile-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.navigation.navbar.personal_details') }}</span>
                    </a>
                    
                    
                    <a href="{{ route('account.security') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="flex-shrink-0">
                            <x-ri-fingerprint-2-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.navigation.navbar.security') }}</span>
                    </a>
                    
                    
                    @if(config('settings.credits_enabled'))
                    <a href="{{ route('account.credits') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="flex-shrink-0">
                            <x-ri-wallet-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.navigation.navbar.credits') }}</span>
                    </a>
                    @endif
                    
                    
                    @if(Route::has('account.payment-methods'))
                    <a href="{{ route('account.payment-methods') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="flex-shrink-0">
                            <x-ri-bank-card-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.account.navigation.payment_methods') }}</span>
                    </a>
                    @endif
                    
                    
                    @if(Route::has('account.notifications'))
                    <a href="{{ route('account.notifications') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 text-primary transition-all duration-200 group hover:translate-x-1"
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'">
                        <div class="flex-shrink-0">
                            <x-ri-notification-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.account.navigation.notifications') }}</span>
                    </a>
                    @endif
                </div>
            </div>
        </div>
        
       
        <div class="lg:col-span-9">
            
            <form wire:submit.prevent="submit" class="space-y-8">
                
                
                <div>
                    <div class="mb-4">
                        <h3 class="secondary-title mb-1">{{ __('citadel::citadel.account.personal_details.section_title') }}</h3>
                        <p class="normal-text text-base/60 text-sm">{{ __('citadel::citadel.account.personal_details.section_description') }}</p>
                    </div>
                    
                    <div class="bg-background-secondary border border-neutral rounded-lg overflow-hidden">
                        <div class="px-6 py-6">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                
                                <x-form.input name="first_name" type="text" :label="__('general.input.first_name')"
                                    :placeholder="__('general.input.first_name_placeholder')" wire:model="first_name" required dirty />
                                
                                
                                <x-form.input name="last_name" type="text" :label="__('general.input.last_name')"
                                    :placeholder="__('general.input.last_name_placeholder')" wire:model="last_name" required dirty />
                                
                                
                                <div class="md:col-span-2">
                                    <x-form.input name="email" type="email" :label="__('general.input.email')"
                                        :placeholder="__('general.input.email_placeholder')" required wire:model="email" dirty />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                
                <livewire:account.avatar-upload />

               
                @if($custom_properties->count() > 0)
                <div>
                    <div class="mb-4">
                        <h3 class="secondary-title mb-1">{{ __('citadel::citadel.account.personal_details.billing_title') }}</h3>
                        <p class="normal-text text-base/60 text-sm">{{ __('citadel::citadel.account.personal_details.billing_description') }}</p>
                    </div>
                    
                    <div class="bg-background-secondary border border-neutral rounded-lg overflow-hidden">
                        <div class="px-6 py-6">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        
                        @foreach ($custom_properties as $property)
                            @switch($property->type)
                                @case('date')
                                @case('string')
                                @case('number')
                                    <x-form.input :type="$property->type" name="properties.{{ $property->key }}" :label="$property->name" :required="$property->required"
                                        wire:model="properties.{{ $property->key }}" :value="$properties[$property->key] ?? ''" :disabled="$property->non_editable && isset($properties[$property->key])" dirty />
                                @break

                                @case('checkbox')
                                    <x-form.checkbox name="properties.{{ $property->key }}" :label="$property->name" :required="$property->required"
                                        wire:model="properties.{{ $property->key }}" :checked="$properties[$property->key] ?? false" :disabled="$property->non_editable && isset($properties[$property->key])" dirty />
                                @break

                                @case('radio')
                                    <div class="flex flex-col gap-1">
                                        <label class="text-sm font-medium text-primary">{{ $property->name }}</label>
                                        @foreach ($property->allowed_values as $value)
                                            <div class="flex items-center">
                                                <input type="radio" value="{{ $value }}" name="properties.{{ $property->key }}" type="radio"
                                                    @checked($properties[$property->key] === $value ?? false) label="{{ $value }}" @required($property->required)
                                                    wire:model="properties.{{ $property->key }}" :disabled="$property->non_editable && isset($properties[$property->key])"
                                                    class="form-radio size-4 text-primary rounded-full focus:ring-secondary hover:bg-secondary ring-offset-primary-800 focus:ring-2 bg-background-secondary border-neutral" />
                                                <label class="ml-2 text-sm text-primary-100" for="properties.{{ $property->key }}">{{ $value }}</label>
                                            </div>
                                        @endforeach
                                    </div>
                                @break

                                @case('select')
                                    <x-form.select name="properties.{{ $property->key }}" :label="$property->name"
                                        wire:model="properties.{{ $property->key }}" :required="$property->required" :options="$property->allowed_values" :selected="$properties[$property->key] ?? ''" :disabled="$property->non_editable && isset($properties[$property->key])" dirty />
                                @break

                                @case('text')
                                    <div class="md:col-span-2">
                                        <x-form.textarea :type="$property->type" name="properties.{{ $property->key }}" :label="$property->name" :required="$property->required"
                                            wire:model="properties.{{ $property->key }}" :disabled="$property->non_editable && isset($properties[$property->key])" dirty>{{ $properties[$property->key] ?? '' }}</x-form.textarea>
                                    </div>
                                @break

                                @default
                            @endswitch
                        @endforeach
                            </div>
                        </div>
                    </div>
                </div>
                @endif

                
                <div class="flex justify-start">
                    <x-button.primary type="submit" class="w-full md:w-auto px-8">
                        {{ __('general.update') }}
                    </x-button.primary>
                </div>
                
            </form>
            
        </div>
        
    </div>
</div>