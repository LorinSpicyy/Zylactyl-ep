@php
    
    $hideBreadcrumb = true;
@endphp

<div>
    
    <div class="mb-8 pt-8">
        <div class="flex items-start justify-between">
            <div class="flex-1">
                <h1 class="page-title">{{ __('account.security') }}</h1>
                <p class="normal-text text-base/60 mt-2">
                    {{ __('citadel::citadel.account.security_page.subtitle') }}
                </p>
            </div>
        </div>
    </div>

    
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        
        <div class="lg:col-span-3">
            <div>
                <h3 class="secondary-title mb-6">{{ __('citadel::citadel.account.navigation.account_settings') }}</h3>
                
                <div class="space-y-4">
                    
                    <a href="{{ route('account') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="flex-shrink-0">
                            <x-ri-profile-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.navigation.navbar.personal_details') }}</span>
                    </a>
                    
                    
                    <a href="{{ route('account.security') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="flex-shrink-0">
                            <x-ri-fingerprint-2-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.navigation.navbar.security') }}</span>
                    </a>
                    
                    
                    @if(config('settings.credits_enabled'))
                    <a href="{{ route('account.credits') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="flex-shrink-0">
                            <x-ri-wallet-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.navigation.navbar.credits') }}</span>
                    </a>
                    @endif
                    
                    
                    @if(Route::has('account.payment-methods'))
                    <a href="{{ route('account.payment-methods') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="flex-shrink-0">
                            <x-ri-bank-card-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.account.navigation.payment_methods') }}</span>
                    </a>
                    @endif
                    
                    
                    @if(Route::has('account.notifications'))
                    <a href="{{ route('account.notifications') }}" 
                       wire:navigate 
                       class="flex items-center gap-3 transition-all duration-200 group hover:translate-x-1 {{ theme('quick_actions_use_normal_colors') ? 'normal-text hover:text-base' : 'text-primary' }}"
                       @if(!theme('quick_actions_use_normal_colors'))
                       style="color: hsl(var(--color-primary));"
                       onmouseover="this.style.color = 'hsl(var(--color-secondary))'"
                       onmouseout="this.style.color = 'hsl(var(--color-primary))'"
                       @endif>
                        <div class="flex-shrink-0">
                            <x-ri-notification-fill class="size-5" />
                        </div>
                        <span class="normal-text">{{ __('citadel::citadel.account.navigation.notifications') }}</span>
                    </a>
                    @endif
                </div>
            </div>
        </div>
        
        
        <div class="lg:col-span-9">
            
            <div class="space-y-8">
                
                
                <div>
                    <div class="mb-4">
                        <h3 class="secondary-title mb-1">{{ __('account.sessions') }}</h3>
                        <p class="normal-text text-base/60 text-sm">{{ __('citadel::citadel.account.security_page.sessions_description') }}</p>
                    </div>
                    
                    <div class="bg-background-secondary border border-neutral rounded-lg overflow-hidden">
                        <div class="divide-y divide-neutral">
                            @foreach (Auth::user()->sessions->filter(function ($session) {
                                if (method_exists($session, 'impersonating')) {
                                    return ! $session->impersonating();
                                }
                                if (isset($session->impersonator_id)) {
                                    return empty($session->impersonator_id);
                                }
                                return true;
                            }) as $session)
                            <div class="px-6 py-4 flex flex-row items-center justify-between">
                                <div>
                                    <p class="text-sm font-medium">{{ $session->ip_address }}</p>
                                    <p class="text-sm text-base/60 mt-1">{{ $session->formatted_device }}</p>
                                    <p class="text-xs text-base/50 mt-1">{{ $session->last_activity->diffForHumans() }}</p>
                                </div>
                                <x-button.primary wire:click="logoutSession('{{ $session->id }}')" class="text-sm !w-fit">
                                    {{ __('account.logout_sessions') }}
                                </x-button.primary>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>

                
                <div>
                    <div class="mb-4">
                        <h3 class="secondary-title mb-1">{{ __('account.change_password') }}</h3>
                        <p class="normal-text text-base/60 text-sm">{{ __('citadel::citadel.account.security_page.password_description') }}</p>
                    </div>
                    
                    <div class="bg-background-secondary border border-neutral rounded-lg overflow-hidden">
                        <div class="px-6 py-6">
                            <form wire:submit="changePassword">
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div class="md:col-span-2">
                                        <x-form.input name="current_password" type="password"
                                            :label="__('account.input.current_password')"
                                            :placeholder="__('account.input.current_password_placeholder')" wire:model="current_password"
                                            required />
                                    </div>
                                    <x-form.input name="password" type="password" :label="__('account.input.new_password')"
                                        :placeholder="__('account.input.new_password_placeholder')" wire:model="password" required />
                                    <x-form.input name="password_confirmation" type="password" :label="__('account.input.confirm_password')"
                                        :placeholder="__('account.input.confirm_password_placeholder')" wire:model="password_confirmation"
                                        required />
                                </div>

                                <div class="mt-6">
                                    <x-button.primary type="submit" class="w-full md:w-auto px-8">
                                        {{ __('account.change_password') }}
                                    </x-button.primary>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                
                <div>
                    <div class="mb-4">
                        <h3 class="secondary-title mb-1">{{ __('account.two_factor_authentication') }}</h3>
                        <p class="normal-text text-base/60 text-sm">{{ __('citadel::citadel.account.security_page.two_factor_description') }}</p>
                    </div>
                    
                    <div class="bg-background-secondary border border-neutral rounded-lg overflow-hidden">
                        <div class="px-6 py-6">
                            @if ($twoFactorEnabled)
                                <p class="text-sm text-base/80 mb-4">{{ __('account.two_factor_authentication_enabled') }}</p>
                                <x-button.danger wire:click="disableTwoFactor" class="w-full md:w-auto px-8">
                                    {{ __('Disable two factor authentication') }}
                                </x-button.danger>
                            @else
                                <p class="text-sm text-base/80 mb-4">{{ __('account.two_factor_authentication_description') }}</p>
                                <x-button.primary wire:click="enableTwoFactor" class="w-full md:w-auto px-8">
                                    {{ __('account.two_factor_authentication_enable') }}
                                </x-button.primary>
                            @endif
                            
                            @if ($showEnableTwoFactor)
                            <x-modal :title="__('account.two_factor_authentication_enable')" open="true">
                                <p class="text-primary-100">{{ __('account.two_factor_authentication_enable_description') }}</p>
                                <div class="flex flex-col items-center mt-4">
                                    <img src="{{ $twoFactorData['image'] }}" alt="QR code" class="w-64 h-64" />
                                    <p class="text-primary-400 mt-2 text-sm text-center">
                                        {{ __('account.two_factor_authentication_secret') }}<br />{{ $twoFactorData['secret'] }}</p>
                                </div>
                                <form wire:submit.prevent="enableTwoFactor">
                                    <x-form.input divClass="mt-8" name="two_factor_code" type="text"
                                        :label="__('account.input.two_factor_code')"
                                        :placeholder="__('account.input.two_factor_code_placeholder')" wire:model="twoFactorCode"
                                        required />
                                    <x-button.primary class="w-full mt-4" type="submit">
                                        {{ __('account.two_factor_authentication_enable') }}
                                    </x-button.primary>
                                </form>
                                <x-slot name="closeTrigger">
                                    <button @click="document.location.reload()" class="text-primary-100">
                                        <x-ri-close-fill class="size-6" />
                                    </button>
                                </x-slot>
                            </x-modal>
                            @endif
                        </div>
                    </div>
                </div>
                
            </div>
            
        </div>
        
    </div>
</div>