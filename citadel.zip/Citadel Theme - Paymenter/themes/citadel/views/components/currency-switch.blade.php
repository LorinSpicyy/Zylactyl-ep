<div class="space-y-0.5 max-h-64 overflow-y-auto 
     scrollbar-thin scrollbar-track-transparent scrollbar-thumb-neutral/20 
     hover:scrollbar-thumb-neutral/40 scrollbar-thumb-rounded-full
     [&::-webkit-scrollbar]:w-1 [&::-webkit-scrollbar-thumb]:bg-neutral/20 
     [&::-webkit-scrollbar-thumb:hover]:bg-neutral/40 [&::-webkit-scrollbar-track]:bg-transparent
     [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar]:rounded-full">
    @foreach($this->currencies as $currency)
    <a href="#" 
       wire:click="$set('currentCurrency', '{{ $currency['value'] }}')"
       class="flex items-center justify-between py-2.5 px-3 rounded-lg text-sm text-base hover:bg-neutral/50 transition-colors {{ session('currency', config('settings.default_currency')) === $currency['value'] ? 'bg-primary/10 text-primary font-medium' : '' }}">
        <span class="flex-1">{{ $currency['label'] }}</span>
        @if(session('currency', config('settings.default_currency')) === $currency['value'])
        <x-ri-check-fill class="size-4 text-primary" />
        @endif
    </a>
    @endforeach
</div>