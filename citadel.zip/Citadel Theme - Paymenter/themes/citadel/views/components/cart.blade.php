<div class="flex items-center">
    <x-navigation.link :href="route('cart')" class="flex items-center gap-1.5 px-2 py-1.5 rounded-lg hover:text-primary transition-colors cursor-pointer">
        <x-ri-shopping-basket-2-fill class="size-4" />
        <div class="relative">
            <span class="text-sm font-medium">View Cart</span>
            @if($cartCount > 0)
            <div class="absolute w-2 h-2 bg-primary/80 rounded-full -top-0.5 -right-0.5"></div>
            @endif
        </div>
    </x-navigation.link>
</div>