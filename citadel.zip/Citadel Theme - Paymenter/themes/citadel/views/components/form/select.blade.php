@props([
'name',
'label' => null,
'options' => [],
'selected' => null,
'multiple' => false,
'required' => false,
'divClass' => null,
'class' => null,
'hideRequiredIndicator' => false,
'dirty' => false,
])

<div class="w-full {{ $divClass ?? '' }}">
    @if ($label)
        <label for="{{ $id ?? $name }}" class="block text-sm mb-2 font-medium text-primary-100">
            {{ $label }}
            @if ($required && !$hideRequiredIndicator)
                <span class="text-red-500 ml-1">*</span>
            @endif
        </label>
    @endif
    
    <select id="{{ $id ?? $name }}" name="{{ $name }}" {{ $multiple ? 'multiple' : '' }}
        class="block px-4 py-3 w-full text-base border border-neutral bg-background rounded-md outline-none focus:outline-none focus:border-primary/40 transition-all duration-300 ease-in-out form-select disabled:opacity-50 disabled:cursor-not-allowed {{ $class ?? '' }}"
        {{ $attributes->except(['options', 'id', 'name', 'multiple', 'class', 'divClass', 'required', 'hideRequiredIndicator', 'dirty']) }}
        @required($required)>
        
        @if (count($options) == 0 && $slot)
            {{ $slot }}
        @else
            @foreach ($options as $key => $option)
                <option value="{{ gettype($options) == 'array' ? $option : $key }}" {{ ($multiple && $selected ? in_array($key, $selected) : $selected==$option) ? 'selected' : '' }}>
                    {{ $option }}
                </option>
            @endforeach
        @endif
    </select>
    
    @if ($multiple)
        <p class="mt-1 text-xs text-primary-100">
            Pro tip: Hold down the Ctrl (Windows) / Command (Mac) button to select multiple options.
        </p>
    @endif

    @error($name)
        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
    @enderror
</div>