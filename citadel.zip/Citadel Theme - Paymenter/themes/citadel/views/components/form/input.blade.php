@props(['name', 'label' => null, 'required' => false, 'divClass' => null, 'class' => null,'placeholder' => null, 'id' => null, 'type' => null, 'hideRequiredIndicator' => false, 'dirty' => false])
<div class="w-full {{ $divClass ?? '' }}">
    @if ($label)
        <label for="{{ $id ?? $name }}" class="block text-sm mb-2 font-medium text-base">
            {{ $label }}
            @if ($required && !$hideRequiredIndicator)
                <span class="text-red-500 ml-1">*</span>
            @endif
        </label>
    @endif
    <div class="relative">
        <input type="{{ $type ?? 'text' }}" id="{{ $id ?? $name }}" name="{{ $name }}"
            class="w-full px-4 py-3 text-base border rounded-lg focus:outline-none transition-all duration-200 placeholder:text-xs placeholder:text-base/30
                   @error($name) 
                       border-red-500 bg-red-50 focus:border-red-600 focus:ring-2 focus:ring-red-200
                   @else 
                       border-neutral bg-background focus:border-primary/40 hover:border-neutral
                   @enderror
                   disabled:opacity-50 disabled:pointer-events-none {{ $class ?? '' }}"
            placeholder="{{ $placeholder ?? '' }}"
            @if ($dirty && isset($attributes['wire:model'])) wire:dirty.class="!border-yellow-600" @endif
            {{ $attributes->except(['placeholder', 'label', 'id', 'name', 'type', 'class', 'divClass', 'required', 'hideRequiredIndicator', 'dirty']) }} 
            @required($required) />
        @error($name)
            <div class="absolute inset-y-0 end-0 flex items-center pointer-events-none pe-3">
                <svg class="size-5 text-red-500" width="16" height="16" fill="currentColor" viewBox="0 0 16 16" aria-hidden="true">
                    <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8 4a.905.905 0 0 0-.9.995l.35 3.507a.552.552 0 0 0 1.1 0l.35-3.507A.905.905 0 0 0 8 4zm.002 6a1 1 0 1 0 0 2 1 1 0 0 0 0-2z"/>
                </svg>
            </div>
        @enderror
    </div>
    @error($name)
        <p class="mt-2 text-sm text-red-600 flex items-center gap-2" id="{{ $name }}-error">
            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
            </svg>
            {{ $message }}
        </p>
    @enderror
</div>
