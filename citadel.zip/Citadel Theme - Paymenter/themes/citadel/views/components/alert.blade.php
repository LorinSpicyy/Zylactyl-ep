@props([
    'type' => 'error',
    'title' => null,
    'message' => null,
    'errors' => null,
    'dismissible' => false
])

@php
$validTypes = ['success', 'error', 'warning', 'info'];
$type = in_array($type, $validTypes) ? $type : 'error';

$typeClasses = [
    'success' => 'bg-green-50 border border-green-200 text-green-800 dark:bg-green-800/10 dark:border-green-900 dark:text-green-500',
    'error' => 'bg-red-50 border border-red-200 text-red-800 dark:bg-red-800/10 dark:border-red-900 dark:text-red-500',
    'warning' => 'bg-yellow-50 border border-yellow-200 text-yellow-800 dark:bg-yellow-800/10 dark:border-yellow-900 dark:text-yellow-500',
    'info' => 'bg-blue-50 border border-blue-200 text-blue-800 dark:bg-blue-800/10 dark:border-blue-900 dark:text-blue-500'
];

$textClasses = [
    'success' => 'text-green-700 dark:text-green-400',
    'error' => 'text-red-700 dark:text-red-400',
    'warning' => 'text-yellow-700 dark:text-yellow-400',
    'info' => 'text-blue-700 dark:text-blue-400'
];

$defaultTitles = [
    'success' => 'Success!',
    'error' => 'A problem has been occurred while submitting your data.',
    'warning' => 'Warning',
    'info' => 'Information'
];

$title = $title ?? $defaultTitles[$type];
@endphp

<div {{ $attributes->merge(['class' => $typeClasses[$type] . ' text-sm rounded-lg p-4']) }} 
     role="alert" tabindex="-1" 
     @if($dismissible) x-data="{ show: true }" x-show="show" @endif>
    <div class="flex">
        <div class="shrink-0">
            @if($type === 'success')
                
                <svg class="shrink-0 size-4 mt-0.5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                    <polyline points="22,4 12,14.01 9,11.01"></polyline>
                </svg>
            @elseif($type === 'error')
                
                <svg class="shrink-0 size-4 mt-0.5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <path d="m15 9-6 6"></path>
                    <path d="m9 9 6 6"></path>
                </svg>
            @elseif($type === 'warning')
                
                <svg class="shrink-0 size-4 mt-0.5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"></path>
                    <path d="M12 9v4"></path>
                    <path d="m12 17 .01 0"></path>
                </svg>
            @elseif($type === 'info')
                
                <svg class="shrink-0 size-4 mt-0.5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <path d="m9 12 2 2 4-4"></path>
                </svg>
            @endif
        </div>
        <div class="ms-4 flex-1">
            @if($title)
                <h3 class="text-sm font-semibold">
                    {{ $title }}
                </h3>
            @endif
            
            @if($message || $errors || $slot->isNotEmpty())
                <div class="mt-2 text-sm {{ $textClasses[$type] }}">
                    @if($message)
                        <p>{{ $message }}</p>
                    @endif
                    
                    @if($errors && $errors->any())
                        <ul class="list-disc space-y-1 ps-5">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    @endif
                    
                    @if($slot->isNotEmpty())
                        {{ $slot }}
                    @endif
                </div>
            @endif
        </div>
        
        @if($dismissible)
            <div class="ms-auto">
                <button type="button" @click="show = false" class="inline-flex shrink-0 justify-center items-center size-5 rounded-lg text-sm opacity-50 hover:opacity-100">
                    <span class="sr-only">Close</span>
                    <svg class="shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="m18 6-12 12"></path>
                        <path d="m6 6 12 12"></path>
                    </svg>
                </button>
            </div>
        @endif
    </div>
</div>