<div x-data>
    <template x-for="(notification, index) in $store.notifications.notifications" :key="notification.id">
        <div x-show="notification.show && notification.type !== 'success'" x-transition:enter="transition ease-out duration-300"
            x-transition:enter-start="opacity-0 scale-90" x-transition:enter-end="opacity-100 scale-100"
            x-transition:leave="transition ease-in duration-300" x-transition:leave-start="opacity-100 scale-100"
            x-transition:leave-end="opacity-0 scale-90" @click="$store.notifications.removeNotification(notification.id)"
            class="fixed z-50 text-sm rounded-lg p-4 border border-neutral cursor-pointer mb-4"
            :style="'top: ' + (20 + index * 80) + 'px;left: 50%; transform: translateX(-50%); max-width: 400px;'"
            :class="{
                'bg-red-50 border border-red-200 text-red-800 dark:bg-red-800/10 dark:border-red-900 dark:text-red-400': notification.type === 'error',
                'bg-yellow-50 border border-yellow-200 text-yellow-800 dark:bg-yellow-800/10 dark:border-yellow-900 dark:text-yellow-400': notification.type === 'warning',
                'bg-blue-50 border border-blue-200 text-blue-800 dark:bg-blue-800/10 dark:border-blue-900 dark:text-blue-400': notification.type === 'info'
            }"
            role="alert" tabindex="-1">
            <div class="flex">
                <div class="shrink-0">
                    
                    <svg x-show="notification.type === 'error'" class="shrink-0 size-4 mt-0.5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"></circle>
                        <path d="m15 9-6 6"></path>
                        <path d="m9 9 6 6"></path>
                    </svg>
                    
                    <svg x-show="notification.type === 'warning'" class="shrink-0 size-4 mt-0.5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"></path>
                        <path d="M12 9v4"></path>
                        <path d="m12 17 .01 0"></path>
                    </svg>
                    
                    <svg x-show="notification.type === 'info'" class="shrink-0 size-4 mt-0.5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"></circle>
                        <path d="m9 12 2 2 4-4"></path>
                    </svg>
                </div>
                <div class="ms-4">
                    <h3 class="text-sm font-semibold">
                        <span x-show="notification.type === 'error'">Error occurred</span>
                        <span x-show="notification.type === 'warning'">Warning</span>
                        <span x-show="notification.type === 'info'">Information</span>
                    </h3>
                    <div class="mt-1 text-sm"
                        :class="{
                            'text-red-700 dark:text-red-300': notification.type === 'error',
                            'text-yellow-700 dark:text-yellow-300': notification.type === 'warning',
                            'text-blue-700 dark:text-blue-300': notification.type === 'info'
                        }">
                        <p x-text="notification.message"></p>
                    </div>
                </div>
            </div>
        </div>
    </template>
</div>
