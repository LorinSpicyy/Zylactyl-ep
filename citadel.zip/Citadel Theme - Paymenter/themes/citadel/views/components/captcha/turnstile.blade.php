@assets
<script src="https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit"></script>
@endassets

@php
    $uniqueId = 'cf-turnstile-' . uniqid();
@endphp

<div id="{{ $uniqueId }}"></div>

<script>
    (function() {
        const containerId = '{{ $uniqueId }}';
        const container = document.getElementById(containerId);
        
        function renderTurnstile() {
            if (!container || container.dataset.rendered === 'true') {
                return;
            }
            
            const isDarkMode = localStorage.getItem('_x_darkMode') === 'true';
            const theme = isDarkMode ? 'dark' : 'light';

            turnstile.render('#' + containerId, {
                sitekey: '{{ config('settings.captcha_site_key') }}',
                size: 'flexible',
                theme: theme,
                callback: token => @this.set('captcha', token, false),
            });
            
            container.dataset.rendered = 'true';
        }

        document.addEventListener('livewire:initialized', () => {
            Livewire.hook('request', ({ succeed }) => {
                succeed(() => {
                    if (container && container.dataset.rendered === 'true') {
                        turnstile.reset('#' + containerId);
                    }
                });
            })
        });
        
        if (typeof turnstile !== 'undefined') {
            renderTurnstile();
        } else {
            const checkTurnstile = setInterval(() => {
                if (typeof turnstile !== 'undefined') {
                    clearInterval(checkTurnstile);
                    renderTurnstile();
                }
            }, 100);
        }
    })();
</script>
