@php
    $uniqueId = 'g-recaptcha-' . uniqid();
@endphp

<script src="https://www.google.com/recaptcha/api.js?render=explicit" async defer></script>
<div id="{{ $uniqueId }}" data-sitekey="{{ config('settings.captcha_site_key') }}"></div>

<script>
    (function() {
        const containerId = '{{ $uniqueId }}';
        const container = document.getElementById(containerId);
        let widgetId = null;
        
        function renderRecaptcha() {
            if (!container || container.dataset.rendered === 'true' || typeof grecaptcha === 'undefined') {
                return;
            }
            
            widgetId = grecaptcha.render(containerId, {
                sitekey: '{{ config('settings.captcha_site_key') }}',
                callback: function(token) {
                    @this.set('captcha', token, false)
                },
            });
            
            container.dataset.rendered = 'true';
        }
        
        document.addEventListener('livewire:initialized', () => {

            Livewire.hook('request', ({ succeed }) => {
                succeed(() => {
                    if (widgetId !== null && typeof grecaptcha !== 'undefined') {
                        grecaptcha.reset(widgetId);
                    }
                });
            })
        });
        

        if (typeof grecaptcha !== 'undefined' && grecaptcha.render) {
            renderRecaptcha();
        } else {
            const checkRecaptcha = setInterval(() => {
                if (typeof grecaptcha !== 'undefined' && grecaptcha.render) {
                    clearInterval(checkRecaptcha);
                    renderRecaptcha();
                }
            }, 100);
        }
    })();
</script>
