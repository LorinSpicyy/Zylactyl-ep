@php
    $uniqueId = 'h-captcha-' . uniqid();
@endphp

<script src="https://js.hcaptcha.com/1/api.js?render=explicit" async defer></script>
<div id="{{ $uniqueId }}" data-sitekey="{{ config('settings.captcha_site_key') }}"></div>

<script>
    (function() {
        const containerId = '{{ $uniqueId }}';
        const container = document.getElementById(containerId);
        let widgetId = null;
        
        function renderHCaptcha() {
            if (!container || container.dataset.rendered === 'true' || typeof hcaptcha === 'undefined') {
                return;
            }
            
            widgetId = hcaptcha.render(containerId, {
                sitekey: '{{ config('settings.captcha_site_key') }}',
                callback: function(token) {
                    @this.set('captcha', token, false)
                },
            });
            
            container.dataset.rendered = 'true';
        }
        
        document.addEventListener('livewire:initialized', () => {

            Livewire.hook('request', ({ succeed }) => {
                succeed(() => {
                    if (widgetId !== null && typeof hcaptcha !== 'undefined') {
                        hcaptcha.reset(widgetId);
                    }
                });
            })
        });
        

        if (typeof hcaptcha !== 'undefined') {
            renderHCaptcha();
        } else {
            const checkHCaptcha = setInterval(() => {
                if (typeof hcaptcha !== 'undefined') {
                    clearInterval(checkHCaptcha);
                    renderHCaptcha();
                }
            }, 100);
        }
    })();
</script>
