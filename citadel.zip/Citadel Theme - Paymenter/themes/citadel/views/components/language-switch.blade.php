@php
    $availableLocales = collect(config('settings.allowed_languages', []))->map(fn($code) => [
        'code' => $code,
        'name' => config('app.available_locales')[$code] ?? $code,
    ]);
@endphp

<div class="space-y-0.5 max-h-64 overflow-y-auto 
     scrollbar-thin scrollbar-track-transparent scrollbar-thumb-neutral/20 
     hover:scrollbar-thumb-neutral/40 scrollbar-thumb-rounded-full
     [&::-webkit-scrollbar]:w-1 [&::-webkit-scrollbar-thumb]:bg-neutral/20 
     [&::-webkit-scrollbar-thumb:hover]:bg-neutral/40 [&::-webkit-scrollbar-track]:bg-transparent
     [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar]:rounded-full">
    @foreach($availableLocales as $locale)
    <a href="#" 
       wire:click="$set('currentLocale', '{{ $locale['code'] }}')"
       class="flex items-center gap-3 py-2.5 px-3 rounded-lg text-sm text-base hover:bg-neutral/50 transition-colors {{ app()->getLocale() === $locale['code'] ? 'bg-primary/10 text-primary font-medium' : '' }}">
        <img src="/assets/languages/{{ strtolower($locale['code']) }}.svg" class="w-5 h-5 rounded-full border border-neutral object-cover" alt="{{ $locale['code'] }}">
        <span class="flex-1">{{ $locale['name'] }}</span>
        @if(app()->getLocale() === $locale['code'])
        <x-ri-check-fill class="size-4 text-primary" />
        @endif
    </a>
    @endforeach
</div>