@assets
<link rel="stylesheet" href="https://unpkg.com/easymde/dist/easymde.min.css">
<script src="https://unpkg.com/easymde/dist/easymde.min.js"></script>
@endassets
@script
    <script>
        const editor = new EasyMDE({
            element: document.getElementById('editor'),
            spellChecker: false,
            previewImagesInEditor: true,
            autoDownloadFontAwesome: false,
            status: [{
                className: 'upload-image',
                defaultValue: '',
            }],
            toolbar: [{
                    name: 'bold',
                    action: EasyMDE.toggleBold,
                }, {
                    name: 'italic',
                    action: EasyMDE.toggleItalic,
                }, {
                    name: 'strikethrough',
                    action: EasyMDE.toggleStrikethrough,
                }, {
                    name: 'link',
                    action: EasyMDE.drawLink,
                }, '|',
                {
                    name: 'heading',
                    action: EasyMDE.toggleHeadingSmaller,
                }, '|',
                {
                    name: 'quote',
                    action: EasyMDE.toggleBlockquote,
                }, {
                    name: 'code',
                    action: EasyMDE.toggleCodeBlock,

                }, {
                    name: 'unordered-list',
                    action: EasyMDE.toggleUnorderedList,
                }, {
                    name: 'ordered-list',
                    action: EasyMDE.toggleOrderedList,
                }, '|',
                {
                    name: 'undo',
                    action: EasyMDE.undo,
                }, {
                    name: 'redo',
                    action: EasyMDE.redo,
                },

            ],
        });

        editor.codemirror.on('change', function() {
            @this.set('message', editor.value(), false);
        });

        
        $wire.on('saved', () => {
            editor.clearAutosavedValue();
            editor.value('');
        });

        
        const _fileInput = document.getElementById('attachments');
        if (_fileInput) {
            const _toolbar = editor.gui.toolbar;
            if (_toolbar) {
                const _sep = document.createElement('i');
                _sep.className = 'separator';
                _sep.innerHTML = '|';
                _toolbar.appendChild(_sep);

                const _btn = document.createElement('a');
                _btn.title = 'Attach files';
                _btn.setAttribute('tabindex', '-1');
                _btn.style.cssText = 'display:inline-flex;align-items:center;justify-content:center;';
                _btn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="15" height="15" fill="currentColor"><path d="M21.435 2.582a5.625 5.625 0 0 0-7.953 0L4.817 11.247a7.5 7.5 0 0 0 10.607 10.607l7.072-7.071-1.415-1.415-7.07 7.071a5.5 5.5 0 0 1-7.779-7.778l8.664-8.665a3.625 3.625 0 0 1 5.126 5.125l-8.664 8.664a1.75 1.75 0 0 1-2.475-2.474l7.42-7.42-1.413-1.415-7.42 7.42a3.75 3.75 0 0 0 5.302 5.303l8.664-8.664a5.625 5.625 0 0 0 0-7.953z"/></svg>`;
                _btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    _fileInput.click();
                });
                _toolbar.appendChild(_btn);
            }
        }
    </script>
@endscript
