@php
    
    $svgPath = public_path("assets/images/hero.svg");
    
    if (!file_exists($svgPath)) {
        return;
    }
    
    $svg = file_get_contents($svgPath);
    
    
    $colorReplacements = [

        ['#618635', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.9) calc(var(--color-primary-l) * 0.7))'],
        

        ['#7FAE46', 'hsl(var(--color-primary))'],
        

        ['#7BAE3C', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.98) calc(var(--color-primary-l) * 1.02))'],
        

        ['#9AC862', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.95) calc(var(--color-primary-l) * 0.85))'],
        

        ['#83BF3B', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.96) calc(var(--color-primary-l) * 1.05))'],
        

        ['#547130', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.85) calc(var(--color-primary-l) * 0.55))'],
        

        ['#85C03D', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.96) calc(var(--color-primary-l) * 0.88))'],
    ];
    

    foreach ($colorReplacements as $replacement) {
        [$hexColor, $newColor] = $replacement;
        

        $svg = str_ireplace('fill="' . $hexColor . '"', 'fill="' . $newColor . '"', $svg);
        

        $svg = str_ireplace('stroke="' . $hexColor . '"', 'stroke="' . $newColor . '"', $svg);
        

        $svg = str_ireplace('stop-color="' . $hexColor . '"', 'stop-color="' . $newColor . '"', $svg);
    }
    

    $svg = preg_replace('/<svg/', '<svg preserveAspectRatio="xMidYMin slice" class="w-full h-full object-cover"', $svg, 1);
@endphp

{!! $svg !!}
