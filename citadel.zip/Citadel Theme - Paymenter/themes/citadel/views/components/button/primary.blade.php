<button 
    style="border-radius: var(--citadel-button-radius);"
    {{ $attributes->merge(['class' => 'citadel-btn flex items-center gap-2 justify-center bg-primary text-white text-sm font-medium hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:ring-offset-2 py-2 px-3 rounded-lg w-full transition-all duration-200 cursor-pointer disabled:cursor-not-allowed disabled:opacity-50 disabled:bg-primary/50']) }}>
    @if (isset($type) && $type === 'submit')
        <div role="status" wire:loading>
            <x-ri-loader-5-fill aria-hidden="true" class="size-5 me-2 fill-white animate-spin" />
            <span class="sr-only">Loading...</span>
        </div>
        <div wire:loading.remove>
            {{ $slot }}
        </div>
    @else
        {{ $slot }}
    @endif
</button>
