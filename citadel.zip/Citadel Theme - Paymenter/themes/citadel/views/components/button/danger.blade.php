<x-button.primary style="border-radius: var(--citadel-button-radius);" {{ $attributes->merge(['class' => 'bg-red-700 bg-none text-white py-2 px-4 rounded hover:bg-red-600'])}}>
    {{ $slot }}
</x-button.primary>