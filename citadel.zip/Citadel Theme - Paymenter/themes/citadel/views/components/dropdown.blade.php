<div class="relative" x-data="{ open: false, adjustWidth: 0, adjustPosition: 'right' }" x-init="$watch('open', value => {
    if (value) {
        adjustWidth = 0; // Reset adjustWidth when opening
        adjustPosition = 'right'; // Reset position when opening
        $nextTick(() => {
            let dropdown = $refs.dropdown;
            let rect = dropdown.getBoundingClientRect();
            let windowWidth = window.innerWidth;
            let windowHeight = window.innerHeight;
            
            // Wait a bit more for any width overrides to take effect
            setTimeout(() => {
                rect = dropdown.getBoundingClientRect();
                
                // Check horizontal overflow
                if (rect.right > windowWidth - 10) {
                    // If dropdown overflows right, calculate how much to shift left
                    adjustWidth = Math.min(rect.width - 40, rect.right - windowWidth + 20);
                    adjustPosition = 'left';
                }
                
                // For mobile screens, ensure dropdown fits within viewport
                if (windowWidth < 640) { // sm breakpoint
                    let maxWidth = windowWidth - 20; // 10px margin on each side
                    if (rect.width > maxWidth) {
                        dropdown.style.maxWidth = maxWidth + 'px';
                        dropdown.style.width = 'auto';
                    }
                    // Center on mobile if there's space
                    if (rect.left < 10) {
                        adjustWidth = Math.abs(rect.left - 10);
                        adjustPosition = 'right';
                    }
                    // If still overflowing right after width adjustment
                    rect = dropdown.getBoundingClientRect();
                    if (rect.right > windowWidth - 10) {
                        adjustWidth = rect.right - windowWidth + 20;
                        adjustPosition = 'left';
                    }
                }
            }, 10);
        });
    }
})">

    <button
        class="flex flex-row items-center text-sm font-medium text-base hover:text-primary transition-colors focus:outline-none focus:text-primary"
        x-on:click="open = !open"
        :aria-expanded="open">
        {{ $trigger }}
    </button>

    <div x-ref="dropdown"
        class="absolute mt-2 min-w-48 bg-background-secondary rounded-lg z-50 divide-y divide-neutral overflow-hidden border border-neutral"
        x-bind:style="{
            left: adjustPosition === 'left' ? `-${adjustWidth}px` : (adjustPosition === 'right' ? `${adjustWidth}px` : '0px'),
        }"
        x-bind:class="{
            'right-0': adjustPosition === 'left' && window.innerWidth >= 640,
            'left-0': adjustPosition === 'right' && window.innerWidth < 640
        }"
        x-show="open"
        x-transition:enter="transition ease-out duration-150" x-transition:enter-start="opacity-0 scale-95"
        x-transition:enter-end="opacity-100 scale-100" x-transition:leave="transition ease-in duration-100"
        x-transition:leave-start="opacity-100 scale-100" x-transition:leave-end="opacity-0 scale-95"
        x-on:click.outside="open = false" x-cloak>
        {{ $content }}
    </div>
</div>