@if(theme('announcement_banner_enabled') && theme('announcement_banner_text'))
@php
    $_bannerPosition = 'fixed_top';
    $bannerText = theme('announcement_banner_text');
    $bannerIcon = theme('announcement_banner_icon', 'megaphone-fill');
    $bgType = theme('announcement_banner_bg_type', 'solid');
    $dismissible = theme('announcement_banner_dismissible', true);
    $alignment = theme('announcement_banner_alignment', 'center');

    if ($bgType === 'gradient') {
        $gradStart = theme('announcement_banner_gradient_start', 'hsl(229, 100%, 64%)');
        $gradMid = theme('announcement_banner_gradient_mid', '');
        $gradEnd = theme('announcement_banner_gradient_end', 'hsl(320, 100%, 64%)');
        $gradAngle = theme('announcement_banner_gradient_angle', '90deg');
        
        $stops = array_filter([$gradStart, $gradMid, $gradEnd], fn($c) => !empty(trim($c)));
        $bannerBgStyle = 'background: linear-gradient(' . $gradAngle . ', ' . implode(', ', $stops) . ');';
    } elseif ($bgType === 'primary_solid') {
        $bannerBgStyle = 'background-color: hsl(var(--color-primary));';
    } elseif ($bgType === 'primary_gradient') {
        $bannerBgStyle = 'background: linear-gradient(90deg, hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 1) calc(var(--color-primary-l) * 1.15)), hsl(var(--color-primary)), hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 1) calc(var(--color-primary-l) * 0.8)));';
    } else {
        $bannerBg = theme('announcement_banner_bg_color', 'hsl(229, 100%, 64%)');
        $bannerBgStyle = 'background-color: ' . $bannerBg . ';';
    }
    
    $html = e($bannerText);
    
    $html = preg_replace('/\*\*(.+?)\*\*/', '<strong>$1</strong>', $html);
    $html = preg_replace('/__(.+?)__/', '<strong>$1</strong>', $html);
    
    $html = preg_replace('/\*(.+?)\*/', '<em>$1</em>', $html);
    $html = preg_replace('/(?<!\w)_(.+?)_(?!\w)/', '<em>$1</em>', $html);
    
    $html = preg_replace('/`(.+?)`/', '<code class="px-1.5 py-0.5 rounded text-xs font-mono bg-white/20">$1</code>', $html);
    
    $html = preg_replace('/\[(.+?)\]\((.+?)\)/', '<a href="$2" target="_blank" class="underline underline-offset-2 font-semibold hover:opacity-80 transition-opacity">$1</a>', $html);
    
    $copyLabel = __('citadel::citadel.banner.copied');
    $html = preg_replace_callback(
        '/&lt;copy&gt;(.+?)&lt;\/copy&gt;/',
        function ($matches) use ($copyLabel) {
            $text = $matches[1];
            $plainText = strip_tags($text);
            $encoded = htmlspecialchars($plainText, ENT_QUOTES, 'UTF-8');
            return '<span class="inline-flex items-center gap-1 cursor-pointer font-semibold underline underline-offset-2 decoration-white/40 hover:decoration-white transition-colors" x-data="{ copied: false }" data-copy="' . $encoded . '" @click.stop="navigator.clipboard.writeText($el.dataset.copy); copied = true; setTimeout(() => copied = false, 2000)"><span>' . $text . '</span><svg x-show="!copied" class="size-3 opacity-70 hover:opacity-100 transition-opacity" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg><svg x-show="copied" x-cloak class="size-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg></span>';
        },
        $html
    );
    
    $bannerHash = md5($bannerText);
@endphp

<div id="announcement-banner"
     x-data="{ 
         dismissed: localStorage.getItem('banner_{{ $bannerHash }}') === 'true',
         bannerHeight: 0,
         updateHeight() {
             this.bannerHeight = this.dismissed ? 0 : this.$el.offsetHeight;
             document.documentElement.style.setProperty('--banner-height', this.bannerHeight + 'px');
         }
     }"
     x-init="$nextTick(() => updateHeight()); 
            new ResizeObserver(() => updateHeight()).observe($el);
            $watch('dismissed', () => $nextTick(() => updateHeight()))"
     x-show="!dismissed"
     x-transition:enter="transition ease-out duration-300"
     x-transition:enter-start="opacity-0 -translate-y-full"
     x-transition:enter-end="opacity-100 translate-y-0"
     x-transition:leave="transition ease-in duration-200"
     x-transition:leave-start="opacity-100 translate-y-0"
     x-transition:leave-end="opacity-0 -translate-y-full"
     class="w-full fixed top-0 left-0 right-0 z-50"
     style="{{ $bannerBgStyle }}">
    <div class="container max-w-[1440px] mx-auto px-4 lg:px-8">
        <div class="flex items-center py-2.5 text-white text-sm">
            <div class="flex items-center gap-3 {{ $alignment === 'center' ? 'flex-1 justify-center' : 'flex-1' }}">
                @if($bannerIcon)
                    <x-dynamic-component :component="'ri-' . $bannerIcon" class="size-4 shrink-0 opacity-90" />
                @endif
                <p class="leading-relaxed">
                    {!! $html !!}
                </p>
            </div>
            
            @if($dismissible)
                <button @click="dismissed = true; localStorage.setItem('banner_{{ $bannerHash }}', 'true')"
                        class="shrink-0 ml-4 p-0.5 rounded-full hover:bg-white/20 transition-colors cursor-pointer"
                        aria-label="Dismiss">
                    <svg class="size-4 opacity-70 hover:opacity-100 transition-opacity" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                    </svg>
                </button>
            @endif
        </div>
    </div>
</div>
@else
<div x-init="document.documentElement.style.setProperty('--banner-height', '0px')" class="hidden"></div>
@endif
