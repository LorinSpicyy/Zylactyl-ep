@props(['name', 'class' => 'w-9 h-9'])

@php
    
    $svgPath = public_path("assets/icons/{$name}.svg");
    
    if (!file_exists($svgPath)) {
        return;
    }
    
    $svg = file_get_contents($svgPath);
    
    $colorReplacements = [

        ['#496627', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.85) calc(var(--color-primary-l) * 0.55))'],
        

        ['#91B665', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.95) calc(var(--color-primary-l) * 0.85))'],
        

        ['#7FAE46', 'hsl(var(--color-primary))'],
        

        ['#618635', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.9) calc(var(--color-primary-l) * 0.7))'],
        

        ['#0D8B24', 'hsl(var(--color-primary))'],
        

        ['#00510F', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.85) calc(var(--color-primary-l) * 0.6))'],
    ];
    

    foreach ($colorReplacements as $replacement) {
        [$hexColor, $newColor] = $replacement;
        

        $svg = str_ireplace('fill="' . $hexColor . '"', 'fill="' . $newColor . '"', $svg);
        

        $svg = str_ireplace('stroke="' . $hexColor . '"', 'stroke="' . $newColor . '"', $svg);
    }
    

    $svg = preg_replace('/fill="#[0-9A-Fa-f]{6}"\s+fill-opacity="0\.1"/', 'fill="hsl(var(--color-primary))" fill-opacity="0.1"', $svg);
    

    $svg = preg_replace('/<svg/', '<svg preserveAspectRatio="xMidYMid meet" class="' . $class . '"', $svg);
@endphp

{!! $svg !!}
