<div>
    <x-dropdown :showArrow="false">
        <x-slot:trigger>
            <div class="flex items-center gap-1.5 px-2 py-1.5 rounded-lg hover:text-primary transition-colors cursor-pointer relative" 
                 x-data="{ hasNew: false }" 
                 x-on:new-notification.window="hasNew = true"
                 @click="hasNew = false">
                <x-ri-notification-3-fill class="size-4" ::class="{'animate-wiggle': hasNew}" />
                @if($this->notifications->where('read_at', null)->count() > 0)
                <div class="absolute w-2 h-2 bg-primary/80 rounded-full top-1 right-1"></div>
                @endif
            </div>
        </x-slot:trigger>
        <x-slot:content>
            <div class="p-1 space-y-0.5 w-[450px] min-w-[300px] max-w-[90vw] sm:w-[450px]" 
                 x-init="$nextTick(() => { 
                     let dropdown = $el.closest('.absolute');
                     if (dropdown) {
                         dropdown.classList.add('!min-w-0', 'w-max');
                         // Re-trigger positioning calculation after width override
                         if (window.innerWidth < 640) {
                             dropdown.style.maxWidth = '90vw';
                             dropdown.style.width = 'auto';
                         }
                     }
                 })">
                <div class="w-full max-h-96 overflow-y-auto 
                     scrollbar-thin scrollbar-track-transparent scrollbar-thumb-neutral/20 
                     hover:scrollbar-thumb-neutral/40 scrollbar-thumb-rounded-full
                     [&::-webkit-scrollbar]:w-1 [&::-webkit-scrollbar-thumb]:bg-neutral/20 
                     [&::-webkit-scrollbar-thumb:hover]:bg-neutral/40 [&::-webkit-scrollbar-track]:bg-transparent
                     [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar]:rounded-full">
                    @if ($this->notifications->isEmpty())
                    <div class="p-4 text-center text-sm text-base/80">
                        {{ __('No new notifications') }}
                    </div>
                    @else
                    @foreach ($this->notifications as $notification)
                    <div wire:click="goToNotification({{ $notification->id }})"
                        class="block px-4 py-3 hover:bg-background-secondary/30 cursor-pointer transition-colors">
                        <div class="flex items-start gap-3">
                            <x-ri-notification-3-fill class="size-4 mt-1 flex-shrink-0 {{ $notification->read_at ? 'text-base/80' : 'text-primary' }}" />
                            <div class="flex flex-col">
                                <span class="font-medium text-sm">{{ $notification->title }}</span>
                                <span class="text-sm text-base/80">{{ $notification->body }}</span>
                                <div class="flex flex-row justify-between mt-1 text-xs text-base/60">
                                    <p>
                                        {{ $notification->created_at->diffForHumans() }}
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    @if (!$loop->last)
                    <div class="border-b border-neutral mx-4"></div>
                    @endif
                    @endforeach
                    @endif
                </div>
                
                
                @if (!$this->notifications->isEmpty())
                <div class="border-t border-neutral p-3 flex items-center justify-between bg-background/30">
                    <a href="{{ route('account.notifications') }}" 
                       wire:navigate 
                       class="text-sm text-primary hover:text-secondary transition-colors font-medium">
                        Manage Notifications
                    </a>
                    <button wire:click="markAllAsRead" 
                            class="flex items-center gap-1.5 text-sm text-base/70 hover:text-primary transition-colors font-medium">
                        <x-ri-check-double-fill class="size-4" />
                        Mark All As Read
                    </button>
                </div>
                @endif
            </div>
        </x-slot:content>
    </x-dropdown>
</div>
