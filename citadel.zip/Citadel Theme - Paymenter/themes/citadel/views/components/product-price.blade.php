@props([
    'product',
    'plan' => null,
    'priceClass' => 'text-2xl font-bold',
    'origClass' => 'text-sm',
    'term' => null,
    'priceOverride' => null,
])

@php
    if ($priceOverride !== null && $priceOverride !== '') {
        $__sale = null;
        $__priceText = $priceOverride;
    } else {
        $__sale = $plan ? citadel_plan_sale($product, $plan) : citadel_product_sale($product);
        $__priceObj = $plan ? $plan->price() : $product->price();
        $__priceText = $__priceObj?->formatted->price ?? '';
    }
@endphp

<span {{ $attributes->merge(['class' => 'inline-flex flex-col gap-0.5']) }}>
    <span class="inline-flex items-baseline gap-1">
        <span class="{{ $priceClass }}">{{ $__priceText }}</span>
        @if($term)
            <span class="text-sm font-medium text-muted">{{ $term }}</span>
        @endif
    </span>
    @if($__sale)
        <span class="inline-flex items-center gap-1.5 flex-wrap {{ $origClass }}">
            <span class="text-muted line-through font-medium">{{ $__sale['original'] }}</span>
            <span class="inline-flex items-center gap-1 rounded-md bg-primary text-white text-sm font-semibold px-1.5 py-1 whitespace-nowrap"><svg class="w-3 h-3 flex-shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8 8H8.01M2 5.2L2 9.67451C2 10.1637 2 10.4083 2.05526 10.6385C2.10425 10.8425 2.18506 11.0376 2.29472 11.2166C2.4184 11.4184 2.59135 11.5914 2.93726 11.9373L10.6059 19.6059C11.7939 20.7939 12.388 21.388 13.0729 21.6105C13.6755 21.8063 14.3245 21.8063 14.927 21.6105C15.612 21.388 16.2061 20.7939 17.3941 19.6059L19.6059 17.3941C20.7939 16.2061 21.388 15.612 21.6105 14.927C21.8063 14.3245 21.8063 13.6755 21.6105 13.0729C21.388 12.388 20.7939 11.7939 19.6059 10.6059L11.9373 2.93726C11.5914 2.59135 11.4184 2.4184 11.2166 2.29472C11.0376 2.18506 10.8425 2.10425 10.6385 2.05526C10.4083 2 10.1637 2 9.67452 2L5.2 2C4.0799 2 3.51984 2 3.09202 2.21799C2.7157 2.40973 2.40973 2.71569 2.21799 3.09202C2 3.51984 2 4.07989 2 5.2ZM8.5 8C8.5 8.27614 8.27614 8.5 8 8.5C7.72386 8.5 7.5 8.27614 7.5 8C7.5 7.72386 7.72386 7.5 8 7.5C8.27614 7.5 8.5 7.72386 8.5 8Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>{{ $__sale['badge'] }}</span>
        </span>
    @endif
</span>
