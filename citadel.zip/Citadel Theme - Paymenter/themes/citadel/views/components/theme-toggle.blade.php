<div 
    x-data="{ 
        init() {
            // Set initial theme based on current darkMode state
            this.themeMode = this.darkMode ? 'dark' : 'light';
        },
        themeMode: 'light',
        setTheme(mode) {
            this.themeMode = mode;
            this.darkMode = (mode === 'dark');
        }
    }"
    role="radiogroup"
    aria-label="theme-preference"
    class="flex items-center p-[2px] border border-neutral rounded-full w-max bg-background-secondary">
    

    <button
        @click="setTheme('light')"
        :class="{
            'bg-primary/20 text-primary': themeMode === 'light',
            'text-base hover:text-primary': themeMode !== 'light'
        }"
        class="inline-flex items-center justify-center transition-all duration-200 w-6 h-6 p-1 rounded-full hover:bg-neutral/50"
        aria-label="Light mode"
        type="button">
        <svg class="w-3 h-3" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="4"/>
            <path d="m12 2 0 2"/>
            <path d="m12 20 0 2"/>
            <path d="m4.93 4.93 1.41 1.41"/>
            <path d="m17.66 17.66 1.41 1.41"/>
            <path d="m2 12 2 0"/>
            <path d="m20 12 2 0"/>
            <path d="m6.34 17.66-1.41 1.41"/>
            <path d="m19.07 4.93-1.41 1.41"/>
        </svg>
    </button>


    <button
        @click="setTheme('dark')"
        :class="{
            'bg-primary/20 text-primary': themeMode === 'dark',
            'text-base hover:text-primary': themeMode !== 'dark'
        }"
        class="inline-flex items-center justify-center transition-all duration-200 w-6 h-6 p-1 rounded-full hover:bg-neutral/50"
        aria-label="Dark mode"
        type="button">
        <svg class="w-3 h-3" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>
        </svg>
    </button>
</div>
