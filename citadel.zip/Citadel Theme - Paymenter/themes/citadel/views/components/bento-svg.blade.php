@props(['name', 'class' => 'w-full h-full'])

@php
    
    $svgPath = public_path("assets/images/bento/{$name}.svg");
    
    if (!file_exists($svgPath)) {
        return;
    }
    
    $svg = file_get_contents($svgPath);
    
    $colorReplacements = [

        ['#496627', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.85) calc(var(--color-primary-l) * 0.55))'],
        

        ['#547130', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.85) calc(var(--color-primary-l) * 0.55))'],
        

        ['#618635', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.9) calc(var(--color-primary-l) * 0.7))'],
        

        ['#7FAE46', 'hsl(var(--color-primary))'],
        

        ['#7AA843', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.99) calc(var(--color-primary-l) * 0.97))'],
        

        ['#7BAE3C', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.98) calc(var(--color-primary-l) * 1.02))'],
        

        ['#85C03D', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.96) calc(var(--color-primary-l) * 0.88))'],
        

        ['#83BF3B', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.96) calc(var(--color-primary-l) * 1.05))'],
        

        ['#91B665', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.95) calc(var(--color-primary-l) * 0.85))'],
        

        ['#9AC862', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.95) calc(var(--color-primary-l) * 0.85))'],
        

        ['#AAC38D', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.6) calc(var(--color-primary-l) * 1.15))'],
        

        ['#CDE2B4', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.45) calc(var(--color-primary-l) * 1.35))'],
        

        ['#E1ECD4', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.35) calc(var(--color-primary-l) * 1.45))'],
    ];
    
    foreach ($colorReplacements as $replacement) {
        [$hexColor, $newColor] = $replacement;
        
        $svg = str_ireplace('fill="' . $hexColor . '"', 'fill="' . $newColor . '"', $svg);
        
        $svg = str_ireplace('stroke="' . $hexColor . '"', 'stroke="' . $newColor . '"', $svg);
        
        $svg = str_ireplace('stop-color="' . $hexColor . '"', 'stop-color="' . $newColor . '"', $svg);
    }
    

    $rgbaReplacements = [
        ['rgba(122, 168, 67, 1)', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.99) calc(var(--color-primary-l) * 0.97))'],
        ['rgba(97, 134, 53, 1)', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.9) calc(var(--color-primary-l) * 0.7))'],
        ['rgba(127, 174, 70, 1)', 'hsl(var(--color-primary))'],
    ];
    
    foreach ($rgbaReplacements as $replacement) {
        [$rgbaColor, $newColor] = $replacement;
        $svg = str_replace($rgbaColor, $newColor, $svg);
    }
    
    $svg = preg_replace('/<svg/', '<svg preserveAspectRatio="xMidYMid slice" class="' . $class . ' pointer-events-none"', $svg, 1);
@endphp

{!! $svg !!}
