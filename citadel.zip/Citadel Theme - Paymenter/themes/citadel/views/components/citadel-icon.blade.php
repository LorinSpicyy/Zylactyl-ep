@props(['name', 'class' => 'w-full h-full'])

@php
    
    $svgPath = public_path("assets/icons/citadel/{$name}.svg");
    
    if (!file_exists($svgPath)) {
        return;
    }
    
    $svg = file_get_contents($svgPath);
    

    $colorReplacements = [

        ['#3D5223', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.8) calc(var(--color-primary-l) * 0.45))'],
        

        ['#405723', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.8) calc(var(--color-primary-l) * 0.45))'],
        

        ['#618635', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.9) calc(var(--color-primary-l) * 0.7))'],

        ['#7FAE46', 'hsl(var(--color-primary))'],
    ];
    
    foreach ($colorReplacements as $replacement) {
        [$hexColor, $newColor] = $replacement;
        
        $svg = str_ireplace('fill="' . $hexColor . '"', 'fill="' . $newColor . '"', $svg);
        $svg = str_ireplace('stroke="' . $hexColor . '"', 'stroke="' . $newColor . '"', $svg);
        $svg = str_ireplace('stop-color="' . $hexColor . '"', 'stop-color="' . $newColor . '"', $svg);
    }
    
    $svg = preg_replace('/<svg/', '<svg class="' . $class . '"', $svg, 1);
@endphp

{!! $svg !!}
