<aside aria-label="sidebar-panel" class="w-72 md:flex hidden flex-col justify-between border-e border-neutral bg-background-secondary fixed left-0 rtl:right-0 rtl:left-auto z-30"
       style="top: var(--banner-height, 0px); height: calc(100vh - var(--banner-height, 0px));">
    
    <div class="flex flex-col h-full">
        <div class="flex items-center h-16 px-5 lg:px-5">
            <a href="{{ route('home') }}" class="flex flex-row items-center" wire:navigate>
                <x-logo class="{{ theme('logo_only_display') ? 'h-10' : 'h-8' }} mr-3 rtl:ml-3 rtl:mr-0" />
                @if(!theme('logo_only_display') && config('settings.company_name'))
                <span class="secondary-title text-sm !font-semibold !leading-none flex items-center">{{ config('settings.company_name') }}</span>
                @endif
            </a>
        </div>
        
        
        <div class="flex-1 overflow-y-auto">
            <x-navigation.sidebar-links />
        </div>
    </div>
</aside>
