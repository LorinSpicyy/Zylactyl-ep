﻿<div role="menubar" class="px-4 pt-0 pb-6 flex flex-col gap-2">

@php
    $sidebarConfigRaw = theme('sidebar_items_data');
    $sidebarConfig = [];
    if (is_string($sidebarConfigRaw) && $sidebarConfigRaw) {
        $sidebarConfig = json_decode($sidebarConfigRaw, true) ?: [];
    }
    if (empty($sidebarConfig)) {
        $sidebarConfig = [
            ['type' => 'dashboard', 'label' => '', 'icon' => 'dashbord'],
            ['type' => 'services',  'label' => '', 'icon' => 'server'],
            ['type' => 'billing',   'label' => '', 'icon' => 'billing'],
            ['type' => 'store',     'label' => '', 'icon' => 'store'],
            ['type' => 'support',   'label' => '', 'icon' => 'support'],
            ['type' => 'account',   'label' => '', 'icon' => 'account'],
        ];
    }

    $domainsNav = collect(\App\Classes\Navigation::getDashboardLinks())->first(function($nav) {
        return isset($nav['url']) && str_contains($nav['url'], '/domains');
    });

    $shopNav = collect(\App\Classes\Navigation::getLinks())->first(function($nav) {
        return $nav['name'] === 'Shop' || $nav['name'] === __('navigation.shop');
    });
    $hasStoreItems = $shopNav && !empty($shopNav['children']);


    $citadelIsDashPage = request()->routeIs('dashboard')
        || request()->routeIs('services.*')
        || request()->routeIs('invoices.*')
        || request()->routeIs('tickets.*')
        || request()->routeIs('account*')
        || request()->routeIs('domains*')
        || request()->routeIs('affiliates*')
        || request()->routeIs('notifications*');
@endphp

@foreach ($sidebarConfig as $_sItem)
@php
    $sType  = $_sItem['type'] ?? 'custom';
    $sLabel = $_sItem['label'] ?? '';
    $sIcon  = $_sItem['icon'] ?: match($sType) {
        'dashboard' => 'dashbord',
        'services'  => 'server',
        'billing'   => 'billing',
        'store'     => 'store',
        'support'   => 'support',
        'account'   => 'account',
        default     => 'server',
    };
@endphp

@if ($sType === 'dashboard')
    
    <div class="flex items-center rounded-lg {{ request()->routeIs('dashboard') ? 'bg-primary/5' : 'hover:bg-primary/5' }}">
        <a href="{{ route('dashboard') }}" wire:navigate
            class="flex items-center gap-3 w-full p-3 nav-item">
            <x-svg-icon :name="$sIcon" class="w-9 h-9" />
            <span class="nav-text text-base !font-normal !leading-5">{{ $sLabel ?: __('citadel::citadel.navigation.sidebar.dashboard') }}</span>
        </a>
    </div>

    
    @if($domainsNav && $citadelIsDashPage)
    <div class="flex items-center rounded-lg {{ ($domainsNav['active'] ?? false) ? 'bg-primary/5' : 'hover:bg-primary/5' }}">
        <a href="{{ $domainsNav['url'] }}" {{ ($domainsNav['spa'] ?? true) ? 'wire:navigate' : '' }}
            class="flex items-center gap-3 w-full p-3 nav-item">
            <x-svg-icon name="Network" class="w-9 h-9" />
            <span class="nav-text text-base !font-normal !leading-5">{{ $domainsNav['name'] }}</span>
        </a>
    </div>
    @endif

@elseif ($sType === 'services')
    
    <div class="flex items-center rounded-lg {{ request()->routeIs('services.*') ? 'bg-primary/5' : 'hover:bg-primary/5' }}">
        <a href="{{ route('services') }}" wire:navigate
            class="flex items-center gap-3 w-full p-3 nav-item">
            <x-svg-icon :name="$sIcon" class="w-9 h-9" />
            <span class="nav-text text-base !font-normal !leading-5">{{ $sLabel ?: __('citadel::citadel.navigation.sidebar.services') }}</span>
        </a>
    </div>

@elseif ($sType === 'billing')
    
    <div x-data="{ activeAccordion: {{ request()->routeIs('invoices.*') || request()->routeIs('account.credits') ? 'true' : 'false' }} }"
        class="relative w-full overflow-hidden text-sm font-normal">
        <button @click="activeAccordion = !activeAccordion"
            class="flex items-center justify-between w-full p-3 nav-item whitespace-nowrap rounded-lg hover:bg-primary/5">
            <div class="flex flex-row items-center gap-3">
                <x-svg-icon :name="$sIcon" class="w-9 h-9" />
                <span class="nav-text text-base !font-normal !leading-5">{{ $sLabel ?: __('citadel::citadel.navigation.sidebar.billing') }}</span>
            </div>
            <x-ri-arrow-down-s-line x-bind:class="{ 'rotate-180': activeAccordion }"
                class="size-4 text-base ease-out duration-300" />
        </button>
        <div x-show="activeAccordion" x-collapse x-cloak>
            <div class="pl-11 pr-4 py-2 space-y-1">
                <a href="{{ route('invoices') }}" wire:navigate
                    class="flex items-center gap-2 px-3 py-2 normal-text text-base !font-normal !leading-5 rounded-lg hover:bg-primary/5 hover:text-primary transition-all duration-200 hover:translate-x-1 {{ request()->routeIs('invoices.*') ? 'text-primary' : 'opacity-70' }}">
                    <x-ri-file-fill class="size-4" />
                    <span>{{ __('citadel::citadel.navigation.sidebar.invoices') }}</span>
                </a>
                @if(config('settings.credits_enabled'))
                <a href="{{ route('account.credits') }}" wire:navigate
                    class="flex items-center gap-2 px-3 py-2 normal-text text-base !font-normal !leading-5 rounded-lg hover:bg-primary/5 hover:text-primary transition-all duration-200 hover:translate-x-1 {{ request()->routeIs('account.credits') ? 'text-primary' : 'opacity-70' }}">
                    <x-ri-coins-fill class="size-4" />
                    <span>{{ __('citadel::citadel.navigation.sidebar.credits') }}</span>
                </a>
                @endif
            </div>
        </div>
    </div>

@elseif ($sType === 'store')
    
    @if($hasStoreItems)
    <div x-data="{ activeAccordion: {{ collect($shopNav['children'])->contains('active', true) ? 'true' : 'false' }} }"
        class="relative w-full overflow-hidden text-sm font-normal">
        <button @click="activeAccordion = !activeAccordion"
            class="flex items-center justify-between w-full p-3 nav-item whitespace-nowrap rounded-lg hover:bg-primary/5">
            <div class="flex flex-row items-center gap-3">
                <x-svg-icon :name="$sIcon" class="w-9 h-9" />
                <span class="nav-text text-base !font-normal !leading-5">{{ $sLabel ?: __('citadel::citadel.navigation.sidebar.store') }}</span>
            </div>
            <x-ri-arrow-down-s-line x-bind:class="{ 'rotate-180': activeAccordion }"
                class="size-4 text-base ease-out duration-300" />
        </button>
        <div x-show="activeAccordion" x-collapse x-cloak>
            <div class="pl-11 pr-4 py-2 space-y-1">
                @foreach($shopNav['children'] as $child)
                    <a href="{{ $child['url'] }}" wire:navigate
                        class="flex items-center gap-2 px-3 py-2 normal-text text-base !font-normal !leading-5 rounded-lg hover:bg-primary/5 hover:text-primary transition-all duration-200 hover:translate-x-1 {{ $child['active'] ? 'text-primary' : 'opacity-70' }}">
                        <x-ri-store-fill class="size-4" />
                        <span>{{ $child['name'] }}</span>
                    </a>
                @endforeach
            </div>
        </div>
    </div>
    @endif

@elseif ($sType === 'support')
    
    <div x-data="{ activeAccordion: {{ request()->routeIs('tickets.*') ? 'true' : 'false' }} }"
        class="relative w-full overflow-hidden text-sm font-normal">
        <button @click="activeAccordion = !activeAccordion"
            class="flex items-center justify-between w-full p-3 nav-item whitespace-nowrap rounded-lg hover:bg-primary/5">
            <div class="flex flex-row items-center gap-3">
                <x-svg-icon :name="$sIcon" class="w-9 h-9" />
                <span class="nav-text text-base !font-normal !leading-5">{{ $sLabel ?: __('citadel::citadel.navigation.sidebar.support') }}</span>
            </div>
            <x-ri-arrow-down-s-line x-bind:class="{ 'rotate-180': activeAccordion }"
                class="size-4 text-base ease-out duration-300" />
        </button>
        <div x-show="activeAccordion" x-collapse x-cloak>
            <div class="pl-11 pr-4 py-2 space-y-1">
                <a href="{{ route('tickets') }}" wire:navigate
                    class="flex items-center gap-2 px-3 py-2 normal-text text-base !font-normal !leading-5 rounded-lg hover:bg-primary/5 hover:text-primary transition-all duration-200 hover:translate-x-1 {{ request()->routeIs('tickets') ? 'text-primary' : 'opacity-70' }}">
                    <x-ri-coupon-fill class="size-4" />
                    <span>{{ __('citadel::citadel.navigation.sidebar.my_tickets') }}</span>
                </a>
                <a href="{{ route('tickets.create') }}" wire:navigate
                    class="flex items-center gap-2 px-3 py-2 normal-text text-base !font-normal !leading-5 rounded-lg hover:bg-primary/5 hover:text-primary transition-all duration-200 hover:translate-x-1 {{ request()->routeIs('tickets.create') ? 'text-primary' : 'opacity-70' }}">
                    <x-ri-coupon-fill class="size-4" />
                    <span>{{ __('citadel::citadel.navigation.sidebar.create_ticket') }}</span>
                </a>
                @foreach (($_sItem['dropdown_items'] ?? []) as $_extra)
                @if(!empty($_extra['url']))
                @php $_extraIcon = !empty($_extra['icon']) ? $_extra['icon'] : 'ri-link'; @endphp
                <a href="{{ $_extra['url'] }}"
                    @if(!empty($_extra['new_tab'])) target="_blank" rel="noopener" @else wire:navigate @endif
                    class="flex items-center gap-2 px-3 py-2 normal-text text-base !font-normal !leading-5 rounded-lg hover:bg-primary/5 hover:text-primary transition-all duration-200 hover:translate-x-1 opacity-70">
                    <x-dynamic-component :component="$_extraIcon" class="size-4" />
                    <span>{{ $_extra['label'] ?? 'Link' }}</span>
                </a>
                @endif
                @endforeach
            </div>
        </div>
    </div>

@elseif ($sType === 'account')
    
    @php
        $accountNav = collect(\App\Classes\Navigation::getDashboardLinks())->first(function($nav) {
            return isset($nav['children']) && !empty($nav['children']);
        });
        $hardcodedAccountUrls = [
            route('account'),
            route('account.security'),
            route('account.credits'),
            route('account.payment-methods'),
            route('account.notifications'),
        ];
    @endphp
    <div x-data="{ activeAccordion: {{ request()->routeIs('account.*') && !request()->routeIs('account.credits') ? 'true' : 'false' }} }"
        class="relative w-full overflow-hidden text-sm font-normal">
        <button @click="activeAccordion = !activeAccordion"
            class="flex items-center justify-between w-full p-3 nav-item whitespace-nowrap rounded-lg hover:bg-primary/5">
            <div class="flex flex-row items-center gap-3">
                <x-svg-icon :name="$sIcon" class="w-9 h-9" />
                <span class="nav-text text-base !font-normal !leading-5">{{ $sLabel ?: __('citadel::citadel.navigation.sidebar.account') }}</span>
            </div>
            <x-ri-arrow-down-s-line x-bind:class="{ 'rotate-180': activeAccordion }"
                class="size-4 text-base ease-out duration-300" />
        </button>
        <div x-show="activeAccordion" x-collapse x-cloak>
            <div class="pl-11 pr-4 py-2 space-y-1">
                <a href="{{ route('account') }}" wire:navigate
                    class="flex items-center gap-2 px-3 py-2 normal-text text-base !font-normal !leading-5 rounded-lg hover:bg-primary/5 hover:text-primary transition-all duration-200 hover:translate-x-1 {{ request()->routeIs('account') && !request()->routeIs('account.*') ? 'text-primary' : 'opacity-70' }}">
                    <x-ri-user-fill class="size-4" />
                    <span>{{ __('citadel::citadel.navigation.sidebar.profile') }}</span>
                </a>
                <a href="{{ route('account.security') }}" wire:navigate
                    class="flex items-center gap-2 px-3 py-2 normal-text text-base !font-normal !leading-5 rounded-lg hover:bg-primary/5 hover:text-primary transition-all duration-200 hover:translate-x-1 {{ request()->routeIs('account.security') ? 'text-primary' : 'opacity-70' }}">
                    <x-ri-fingerprint-2-fill class="size-4" />
                    <span>{{ __('citadel::citadel.navigation.sidebar.security') }}</span>
                </a>
                @if(config('settings.credits_enabled'))
                <a href="{{ route('account.credits') }}" wire:navigate
                    class="flex items-center gap-2 px-3 py-2 normal-text text-base !font-normal !leading-5 rounded-lg hover:bg-primary/5 hover:text-primary transition-all duration-200 hover:translate-x-1 {{ request()->routeIs('account.credits') ? 'text-primary' : 'opacity-70' }}">
                    <x-ri-wallet-fill class="size-4" />
                    <span>{{ __('citadel::citadel.navigation.sidebar.credits') }}</span>
                </a>
                @endif

                @if($accountNav && isset($accountNav['children']))
                    @foreach($accountNav['children'] as $child)
                        @if(($child['condition'] ?? true) && isset($child['url']) && !in_array($child['url'], $hardcodedAccountUrls))
                            <a href="{{ $child['url'] }}" {{ ($child['spa'] ?? true) ? 'wire:navigate' : '' }}
                                class="flex items-center gap-2 px-3 py-2 normal-text text-base !font-normal !leading-5 rounded-lg hover:bg-primary/5 hover:text-primary transition-all duration-200 hover:translate-x-1 {{ ($child['active'] ?? false) ? 'text-primary' : 'opacity-70' }}">
                                @isset($child['icon'])
                                    <x-dynamic-component :component="$child['icon']" class="size-4" />
                                @else
                                    <x-ri-circle-fill class="size-4" />
                                @endisset
                                <span>{{ $child['name'] }}</span>
                            </a>
                        @endif
                    @endforeach
                @endif

                @if(auth()->user()->role_id !== null)
                <a href="{{ route('filament.admin.pages.dashboard') }}"
                    class="flex items-center gap-2 px-3 py-2 normal-text text-base !font-normal !leading-5 rounded-lg hover:bg-primary/5 hover:text-primary transition-all duration-200 hover:translate-x-1 opacity-70">
                    <x-ri-lock-2-fill class="size-4" />
                    <span>{{ __('navigation.admin') }}</span>
                </a>
                @endif

                <div class="border-t border-neutral mt-1 pt-1">
                    <div class="normal-text text-base !font-normal !leading-5 flex items-center gap-2 py-2 px-3 rounded-lg hover:bg-red-500/10 hover:text-red-600 transition-colors cursor-pointer opacity-70">
                        <x-ri-logout-box-r-line class="size-4" />
                        <livewire:auth.logout />
                    </div>
                </div>
            </div>
        </div>
    </div>

@elseif ($sType === 'custom_dropdown' && !empty($_sItem['dropdown_items']))
    @php
        $_sShowDash  = $_sItem['show_on_dashboard'] ?? true;
        $_sShowFront = $_sItem['show_on_front'] ?? true;
        $_sAllowed   = $citadelIsDashPage ? $_sShowDash : $_sShowFront;
    @endphp
    @if ($_sAllowed)
    <div x-data="{ activeAccordion: false }"
        class="relative w-full overflow-hidden text-sm font-normal">
        <button @click="activeAccordion = !activeAccordion"
            class="flex items-center justify-between w-full p-3 nav-item whitespace-nowrap rounded-lg hover:bg-primary/5">
            <div class="flex flex-row items-center gap-3">
                <x-svg-icon :name="$sIcon" class="w-9 h-9" />
                <span class="nav-text text-base !font-normal !leading-5">{{ $sLabel ?: 'Menu' }}</span>
            </div>
            <x-ri-arrow-down-s-line x-bind:class="{ 'rotate-180': activeAccordion }"
                class="size-4 text-base ease-out duration-300" />
        </button>
        <div x-show="activeAccordion" x-collapse x-cloak>
            <div class="pl-11 pr-4 py-2 space-y-1">
                @foreach ($_sItem['dropdown_items'] as $_ddItem)
                @if(!empty($_ddItem['url']))
                @php $_ddIcon = !empty($_ddItem['icon']) ? $_ddItem['icon'] : 'ri-link'; @endphp
                <a href="{{ $_ddItem['url'] }}"
                    @if(!empty($_ddItem['new_tab'])) target="_blank" rel="noopener" @else wire:navigate @endif
                    class="flex items-center gap-2 px-3 py-2 normal-text text-base !font-normal !leading-5 rounded-lg hover:bg-primary/5 hover:text-primary transition-all duration-200 hover:translate-x-1 opacity-70">
                    <x-dynamic-component :component="$_ddIcon" class="size-4" />
                    <span>{{ $_ddItem['label'] ?? 'Link' }}</span>
                </a>
                @endif
                @endforeach
            </div>
        </div>
    </div>
    @endif

@elseif ($sType === 'custom' && !empty($_sItem['url']))
    @php
        $_sShowDash  = $_sItem['show_on_dashboard'] ?? true;
        $_sShowFront = $_sItem['show_on_front'] ?? true;
        $_sAllowed   = $citadelIsDashPage ? $_sShowDash : $_sShowFront;
    @endphp
    @if ($_sAllowed)
    <div class="flex items-center rounded-lg hover:bg-primary/5">
        <a href="{{ $_sItem['url'] }}" target="_blank"
            class="flex items-center gap-3 w-full p-3 nav-item">
            <x-svg-icon :name="$sIcon" class="w-9 h-9" />
            <span class="nav-text text-base !font-normal !leading-5">{{ $sLabel ?: 'Link' }}</span>
        </a>
    </div>
    @endif
@endif

@endforeach

    
    @foreach (\App\Classes\Navigation::getDashboardLinks() as $nav)
        @php
            $hardcodedRoutes = ['dashboard', 'services', 'invoices', 'tickets'];
            $isHardcoded = false;

            if (isset($nav['url'])) {
                foreach ($hardcodedRoutes as $route) {
                    if (str_contains($nav['url'], route($route))) {
                        $isHardcoded = true;
                        break;
                    }
                }
                if (!$isHardcoded && str_contains($nav['url'], '/domains')) {
                    $isHardcoded = true;
                }
            }

            $isAccountSection = isset($nav['children']) && !empty($nav['children']) && isset($nav['icon']) && str_contains($nav['icon'], 'settings');
        @endphp

        @if (!$isHardcoded && !$isAccountSection && ($nav['condition'] ?? true))
            @if (!empty($nav['children']))
                <div x-data="{ activeAccordion: {{ $nav['active'] ? 'true' : 'false' }} }"
                    class="relative w-full overflow-hidden text-sm font-normal">
                    <button @click="activeAccordion = !activeAccordion"
                        class="flex items-center justify-between w-full p-3 nav-item whitespace-nowrap rounded-lg hover:bg-primary/5">
                        <div class="flex flex-row gap-3">
                            <x-svg-icon name="server" class="w-9 h-9" />
                            <span class="nav-text text-base !font-normal !leading-5">{{ $nav['name'] }}</span>
                        </div>
                        <x-ri-arrow-down-s-line x-bind:class="{ 'rotate-180': activeAccordion }"
                            class="size-4 text-base ease-out duration-300" />
                    </button>
                    <div x-show="activeAccordion" x-collapse x-cloak>
                        <div class="pl-11 pr-4 py-2 space-y-1">
                            @foreach ($nav['children'] as $child)
                                @if ($child['condition'] ?? true)
                                    <a href="{{ $child['url'] }}" {{ ($child['spa'] ?? true) ? 'wire:navigate' : '' }}
                                        class="flex items-center gap-2 px-3 py-2 normal-text text-base !font-normal !leading-5 rounded-lg hover:bg-primary/5 hover:text-primary transition-all duration-200 hover:translate-x-1 {{ $child['active'] ? 'text-primary' : 'opacity-70' }}">
                                        @isset($child['icon'])
                                            <x-dynamic-component :component="$child['icon']" class="size-4" />
                                        @else
                                            <x-ri-circle-fill class="size-4" />
                                        @endisset
                                        <span>{{ $child['name'] }}</span>
                                    </a>
                                @endif
                            @endforeach
                        </div>
                    </div>
                </div>
            @else
                <div class="flex items-center rounded-lg {{ $nav['active'] ? 'bg-primary/5' : 'hover:bg-primary/5' }}">
                    <a href="{{ $nav['url'] }}" {{ ($nav['spa'] ?? true) ? 'wire:navigate' : '' }}
                        class="flex items-center gap-3 w-full p-3 nav-item">
                        <x-svg-icon name="server" class="w-9 h-9" />
                        <span class="nav-text text-base !font-normal !leading-5">{{ $nav['name'] }}</span>
                    </a>
                </div>
            @endif

            @isset($nav['separator'])
            <div class="h-px w-full bg-neutral/30 my-2"></div>
            @endisset
        @endif
    @endforeach
</div>