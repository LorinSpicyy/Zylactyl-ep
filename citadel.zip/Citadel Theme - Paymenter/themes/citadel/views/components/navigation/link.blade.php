@props(['href', 'spa' => true])
<a href="{{ $href }}" {{ $attributes->merge(['class' => ($href === request()->url() ? 'text-primary' : '')]) }} @if($spa) wire:navigate @endif>
    {{ $slot }}
</a>