@props(['showSidebar' => false])

@php

    $citadelUtilityBar = theme('header_utility_bar', false);
    $citadelSticky = theme('header_sticky', true);
    $navConfig = theme('nav_items_data');
    if (is_string($navConfig)) $navConfig = json_decode($navConfig, true) ?: [];
    if (empty($navConfig)) {
        $navConfig = [
            ['type' => 'store'],
            ['type' => 'dashboard'],
            ['type' => 'support'],
        ];
    }

    $citadelNavIsDashPage = auth()->check() && (
        request()->routeIs('dashboard')
        || request()->routeIs('services.*')
        || request()->routeIs('invoices.*')
        || request()->routeIs('tickets.*')
        || request()->routeIs('account*')
        || request()->routeIs('domains*')
        || request()->routeIs('affiliates*')
        || request()->routeIs('notifications*')
    );

    $citadelHiddenStoreUrls = [];
    try {
        $citadelCustomPagesRaw = \App\Models\Setting::where('key', 'theme_citadel_custom_pages_data')->value('value');
        foreach (($citadelCustomPagesRaw ? json_decode($citadelCustomPagesRaw, true) : []) ?? [] as $_cp) {
            if (($_cp['page_type'] ?? 'custom') !== 'product') continue;
            if (! ($_cp['hide_from_store'] ?? false)) continue;
            if (! empty($_cp['category_id'])) {
                $_cat = \App\Models\Category::find($_cp['category_id']);
                if ($_cat) $citadelHiddenStoreUrls[] = rtrim(url('/products/' . $_cat->slug), '/');
            }
            if (($_cp['url_strategy'] ?? 'replace') === 'separate' && ! empty($_cp['slug'])) {
                $citadelHiddenStoreUrls[] = rtrim(url('/' . $_cp['slug']), '/');
            }
        }
    } catch (\Throwable $_e) {}
@endphp


<nav aria-label="primary-navigation"
     class="{{ $showSidebar ? 'md:hidden' : '' }} {{ $citadelSticky ? 'fixed' : 'absolute' }} z-20 left-0 right-0 transition-[margin] duration-300"
     style="top: calc(var(--banner-height, 0px) + var(--citadel-utility-height, 0px) + 0.85rem);">
    <div x-data="{
        slideOverOpen: false
    }"
        x-init="$watch('slideOverOpen', value => { document.documentElement.style.overflow = value ? 'hidden' : '' })"
        class="relative z-50 w-full">

        <div class="container mx-auto px-4 lg:px-8" style="max-width: var(--citadel-content-width, 1440px);">
            <div class="citadel-header-pill border border-neutral bg-background-secondary px-3 sm:px-4 lg:px-6"
                 style="border-radius: var(--citadel-card-radius, 1rem); box-shadow: 0 6px 16px -12px rgba(0, 0, 0, 0.20), 0 2px 5px -4px rgba(0, 0, 0, 0.10);">
                <div class="grid h-16 lg:h-[4.25rem] w-full grid-cols-[auto_1fr] lg:grid-cols-[auto_1fr_auto] items-center gap-3 lg:gap-6">

                    {{-- LOGO --}}
                    <div class="flex flex-row items-center min-w-0 max-w-[55vw] lg:max-w-none">
                        <a href="{{ route('home') }}" class="flex flex-row items-center h-10 gap-2" wire:navigate>
                            <x-logo class="{{ theme('logo_only_display') ? 'h-8' : 'h-6' }} flex-shrink-0" />
                            @if(!theme('logo_only_display') && config('settings.company_name'))
                            <span class="secondary-title text-xs sm:text-sm !font-semibold !leading-tight flex items-center truncate py-0.5">{{ config('settings.company_name') }}</span>
                            @endif
                        </a>
                    </div>

                    
                    <div class="hidden lg:flex flex-row items-center justify-center justify-self-center">
                        @foreach ($navConfig as $_navItem)
                        @php $navType = $_navItem['type'] ?? 'custom'; @endphp

                        @if ($navType === 'store')
                        @foreach (\App\Classes\Navigation::getLinks() as $nav)
                        @if (isset($nav['children']) && count($nav['children']) > 0)
                        <div class="relative">
                            <x-dropdown>
                                <x-slot:trigger>
                                    <div class="flex flex-col cursor-pointer">
                                        <span class="nav-text text-base !font-normal !leading-5 flex flex-row items-center px-4 py-2 whitespace-nowrap hover:text-primary/80">
                                            @if($nav['name'] === 'Shop' || $nav['name'] === __('navigation.shop'))
                                                {{ __('citadel::citadel.navigation.navbar.store') }} <x-ri-arrow-drop-down-fill class="size-4" />
                                            @else
                                                {{ $nav['name'] }} <x-ri-arrow-drop-down-fill class="size-4" />
                                            @endif
                                        </span>
                                    </div>
                                </x-slot:trigger>
                                <x-slot:content>
                                    <div class="p-1 space-y-0.5">
                                        @foreach ($nav['children'] as $child)
                                        @if(isset($child['url']) && ! in_array(rtrim($child['url'], '/'), $citadelHiddenStoreUrls))
                                        <a href="{{ $child['url'] }}"
                                           @if(isset($child['spa']) ? $child['spa'] : true) wire:navigate @endif
                                           class="normal-text text-base !font-normal !leading-5 flex items-center gap-3 py-2.5 px-3 rounded-lg hover:bg-neutral/50 transition-colors">
                                            @if(!theme('hide_navbar_icons'))
                                            <x-ri-shopping-cart-fill class="size-4" />
                                            @endif
                                            <span>{{ $child['name'] }}</span>
                                        </a>
                                        @endif
                                        @endforeach
                                    </div>
                                </x-slot:content>
                            </x-dropdown>
                        </div>
                        @elseif(isset($nav['url']))
                        <x-navigation.link
                            :href="$nav['url']"
                            :spa="isset($nav['spa']) ? $nav['spa'] : true"
                            class="nav-text text-base !font-normal !leading-5 flex flex-row items-center px-4 py-2 whitespace-nowrap hover:text-primary/80 cursor-pointer">
                            @if($nav['name'] === 'Shop' || $nav['name'] === __('navigation.shop'))
                                {{ __('citadel::citadel.navigation.navbar.store') }} <x-ri-arrow-drop-down-fill class="size-4" />
                            @elseif($nav['name'] === 'Home' || $nav['name'] === __('navigation.home'))
                                {{ __('citadel::citadel.navigation.navbar.home') }}
                            @else
                                {{ $nav['name'] }}
                            @endif
                        </x-navigation.link>
                        @endif
                        @endforeach

                        @elseif ($navType === 'dashboard' && auth()->check())
                        <div class="relative">
                            <a href="{{ route('dashboard') }}"
                               wire:navigate
                               class="nav-text text-base !font-normal !leading-5 flex flex-row items-center px-4 py-2 whitespace-nowrap hover:text-primary/80 cursor-pointer">
                                {{ __('citadel::citadel.navigation.navbar.dashboard') }}
                            </a>
                        </div>

                        @elseif ($navType === 'support' && auth()->check())
                        <div class="relative">
                            <x-dropdown>
                                <x-slot:trigger>
                                    <div class="flex flex-col cursor-pointer">
                                        <span class="nav-text text-base !font-normal !leading-5 flex flex-row items-center px-4 py-2 whitespace-nowrap hover:text-primary/80">
                                            {{ __('citadel::citadel.navigation.navbar.support') }} <x-ri-arrow-drop-down-fill class="size-4" />
                                        </span>
                                    </div>
                                </x-slot:trigger>
                                <x-slot:content>
                                    <div class="p-1 space-y-0.5">
                                        <a href="{{ route('tickets') }}"
                                           wire:navigate
                                           class="normal-text text-base !font-normal !leading-5 flex items-center gap-3 py-2.5 px-3 rounded-lg hover:bg-neutral/50 transition-colors">
                                            @if(!theme('hide_navbar_icons'))
                                            <x-ri-coupon-fill class="size-4" />
                                            @endif
                                            <span>Tickets</span>
                                        </a>
                                        @foreach (($_navItem['dropdown_items'] ?? []) as $_extra)
                                        @if(!empty($_extra['url']))
                                        @php $_extraIcon = !empty($_extra['icon']) ? $_extra['icon'] : 'ri-link'; @endphp
                                        <a href="{{ $_extra['url'] }}"
                                           @if(!empty($_extra['new_tab'])) target="_blank" rel="noopener" @else wire:navigate @endif
                                           class="normal-text text-base !font-normal !leading-5 flex items-center gap-3 py-2.5 px-3 rounded-lg hover:bg-neutral/50 transition-colors">
                                            @if(!theme('hide_navbar_icons'))
                                            <x-dynamic-component :component="$_extraIcon" class="size-4" />
                                            @endif
                                            <span>{{ $_extra['label'] ?? 'Link' }}</span>
                                        </a>
                                        @endif
                                        @endforeach
                                    </div>
                                </x-slot:content>
                            </x-dropdown>
                        </div>

                        @elseif ($navType === 'custom_dropdown' && !empty($_navItem['dropdown_items']) && ($citadelNavIsDashPage ? ($_navItem['show_on_dashboard'] ?? true) : ($_navItem['show_on_front'] ?? true)))
                        <div class="relative">
                            <x-dropdown>
                                <x-slot:trigger>
                                    <div class="flex flex-col cursor-pointer">
                                        <span class="nav-text text-base !font-normal !leading-5 flex flex-row items-center px-4 py-2 whitespace-nowrap hover:text-primary/80">
                                            {{ $_navItem['custom_label'] ?? 'Menu' }} <x-ri-arrow-drop-down-fill class="size-4" />
                                        </span>
                                    </div>
                                </x-slot:trigger>
                                <x-slot:content>
                                    <div class="p-1 space-y-0.5">
                                        @foreach ($_navItem['dropdown_items'] as $_ddItem)
                                        @if(!empty($_ddItem['url']))
                                        @php $_ddIcon = !empty($_ddItem['icon']) ? $_ddItem['icon'] : 'ri-link'; @endphp
                                        <a href="{{ $_ddItem['url'] }}"
                                           @if(!empty($_ddItem['new_tab'])) target="_blank" rel="noopener" @else wire:navigate @endif
                                           class="normal-text text-base !font-normal !leading-5 flex items-center gap-3 py-2.5 px-3 rounded-lg hover:bg-neutral/50 transition-colors">
                                            @if(!theme('hide_navbar_icons'))
                                            <x-dynamic-component :component="$_ddIcon" class="size-4" />
                                            @endif
                                            <span>{{ $_ddItem['label'] ?? 'Link' }}</span>
                                        </a>
                                        @endif
                                        @endforeach
                                    </div>
                                </x-slot:content>
                            </x-dropdown>
                        </div>

                        @elseif ($navType === 'custom' && !empty($_navItem['custom_label']) && !empty($_navItem['custom_url']) && ($citadelNavIsDashPage ? ($_navItem['show_on_dashboard'] ?? true) : ($_navItem['show_on_front'] ?? true)))
                        <div class="relative">
                            <a href="{{ $_navItem['custom_url'] }}"
                               class="nav-text text-base !font-normal !leading-5 flex flex-row items-center px-4 py-2 whitespace-nowrap hover:text-primary/80 cursor-pointer">
                                {{ $_navItem['custom_label'] }}
                            </a>
                        </div>

                        @endif

                        @endforeach

                        @if($citadelNavIsDashPage)
                        @php
                            $domainsNavLink = collect(\App\Classes\Navigation::getDashboardLinks())->first(function($nav) {
                                return isset($nav['url']) && str_contains($nav['url'], '/domains');
                            });
                        @endphp
                        @if($domainsNavLink)
                        <div class="relative">
                            <a href="{{ $domainsNavLink['url'] }}"
                               {{ ($domainsNavLink['spa'] ?? true) ? 'wire:navigate' : '' }}
                               class="nav-text text-base !font-normal !leading-5 flex flex-row items-center px-4 py-2 whitespace-nowrap hover:text-primary/80 cursor-pointer">
                                {{ $domainsNavLink['name'] }}
                            </a>
                        </div>
                        @endif
                        @endif
                    </div>

                    
                    <div class="flex flex-row items-center gap-1 justify-self-end">

                        <a href="{{ route('cart') }}" class="flex items-center gap-1.5 px-2 py-1.5 rounded-lg hover:text-primary transition-colors cursor-pointer relative" wire:navigate>
                            <x-ri-shopping-basket-2-fill class="size-4" />
                            <div class="relative hidden sm:block">
                                <span class="normal-text text-base !font-normal !leading-5">{{ __('citadel::citadel.navigation.navbar.view_cart') }}</span>
                                @if(session('cart') && count(session('cart')) > 0)
                                <div class="absolute w-2 h-2 bg-primary/80 rounded-full -top-0.5 -right-0.5"></div>
                                @endif
                            </div>
                            @if(session('cart') && count(session('cart')) > 0)
                            <div class="sm:hidden absolute w-2 h-2 bg-primary/80 rounded-full top-1 right-1"></div>
                            @endif
                        </a>

                        @if(auth()->check())
                        <div class="flex items-center {{ $citadelUtilityBar ? 'md:hidden' : '' }}">
                            <livewire:components.notifications />
                        </div>
                        @endif

                        @unless($citadelUtilityBar)
                        <div class="items-center hidden md:flex">
                            <x-dropdown>
                                <x-slot:trigger>
                                    <div class="flex items-center gap-1.5 px-2 py-1.5 rounded-lg hover:text-primary transition-colors cursor-pointer">
                                        <img src="/assets/languages/{{ strtolower(app()->getLocale()) }}.svg" class="w-4 h-4 rounded-full border border-neutral object-cover" alt="{{ app()->getLocale() }}">
                                        <span class="normal-text text-base !font-normal !leading-5">{{ strtoupper(app()->getLocale()) }}</span>
                                    </div>
                                </x-slot:trigger>
                                <x-slot:content>
                                    <div class="p-1 space-y-0.5">
                                        <livewire:components.language-switch />
                                    </div>
                                </x-slot:content>
                            </x-dropdown>
                        </div>

                        <div class="hidden md:block h-4 w-px bg-neutral/50 mx-1"></div>

                        <div class="items-center hidden md:flex">
                            <x-dropdown>
                                <x-slot:trigger>
                                    <div class="flex items-center gap-1.5 px-2 py-1.5 rounded-lg hover:text-primary transition-colors cursor-pointer">
                                        <span class="normal-text text-base !font-normal !leading-5">{{ session('currency', config('settings.default_currency')) }}</span>
                                    </div>
                                </x-slot:trigger>
                                <x-slot:content>
                                    <div class="p-1 space-y-0.5">
                                        <livewire:components.currency-switch />
                                    </div>
                                </x-slot:content>
                            </x-dropdown>
                        </div>
                        @endunless

                        @if(!theme('disable_color_switching'))
                            @if($citadelUtilityBar)
                                <div class="md:hidden"><x-theme-toggle /></div>
                            @else
                                <x-theme-toggle />
                            @endif
                        @endif

                        
                        <div class="hidden lg:flex flex-row items-center ml-1">
                            @if(auth()->check())
                            <x-dropdown>
                                <x-slot:trigger>
                                    <div class="flex items-center gap-1.5 px-2 py-1.5 rounded-lg hover:text-primary transition-colors cursor-pointer">
                                        <img class="w-8 h-8 rounded-full border border-neutral object-cover" src="{{ citadel_avatar_url(auth()->user()) }}" alt="Avatar">
                                        <div class="hidden xl:flex flex-col items-start">
                                            <span class="normal-text text-base !font-semibold !leading-tight">{{ auth()->user()->name }}</span>
                                            <span class="normal-text text-base/70 !font-normal !leading-tight">{{ auth()->user()->email }}</span>
                                        </div>
                                    </div>
                                </x-slot:trigger>
                                <x-slot:content>
                                    <div class="p-1 space-y-0.5">
                                        <x-navigation.link href="{{ route('account') }}"
                                            class="normal-text text-base !font-normal !leading-5 flex items-center gap-3 py-2.5 px-3 rounded-lg hover:bg-neutral/50 transition-colors"
                                            wire:navigate>
                                            @if(!theme('hide_navbar_icons'))
                                            <x-ri-profile-fill class="size-4" />
                                            @endif
                                            <span>{{ __('citadel::citadel.navigation.navbar.account') }}</span>
                                        </x-navigation.link>
                                        <x-navigation.link href="{{ route('account.security') }}"
                                            class="normal-text text-base !font-normal !leading-5 flex items-center gap-3 py-2.5 px-3 rounded-lg hover:bg-neutral/50 transition-colors"
                                            wire:navigate>
                                            @if(!theme('hide_navbar_icons'))
                                            <x-ri-fingerprint-2-fill class="size-4" />
                                            @endif
                                            <span>{{ __('citadel::citadel.navigation.navbar.security') }}</span>
                                        </x-navigation.link>
                                        @if(config('settings.credits_enabled'))
                                        <x-navigation.link href="{{ route('account.credits') }}"
                                            class="normal-text text-base !font-normal !leading-5 flex items-center gap-3 py-2.5 px-3 rounded-lg hover:bg-neutral/50 transition-colors"
                                            wire:navigate>
                                            @if(!theme('hide_navbar_icons'))
                                            <x-ri-wallet-fill class="size-4" />
                                            @endif
                                            <span>{{ __('citadel::citadel.navigation.navbar.credits') }}</span>
                                        </x-navigation.link>
                                        @endif
                                        @if(auth()->user()->role_id !== null)
                                        <x-navigation.link href="{{ route('filament.admin.pages.dashboard') }}"
                                            class="normal-text text-base !font-normal !leading-5 flex items-center gap-3 py-2.5 px-3 rounded-lg hover:bg-neutral/50 transition-colors"
                                            :spa="false">
                                            @if(!theme('hide_navbar_icons'))
                                            <x-ri-admin-fill class="size-4" />
                                            @endif
                                            <span>{{ __('citadel::citadel.navigation.navbar.admin') }}</span>
                                        </x-navigation.link>
                                        @endif
                                        <div class="border-t border-neutral mt-1 pt-1">
                                            <div class="normal-text text-base !font-normal !leading-5 flex items-center gap-3 py-2.5 px-3 rounded-lg hover:bg-red-500/10 hover:text-red-600 transition-colors cursor-pointer">
                                                @if(!theme('hide_navbar_icons'))
                                                <x-ri-logout-box-fill class="size-4" />
                                                @endif
                                                <livewire:auth.logout />
                                            </div>
                                        </div>
                                    </div>
                                </x-slot:content>
                            </x-dropdown>
                            @else
                            <div class="flex flex-row gap-3">
                                <a href="{{ route('login') }}" wire:navigate>
                                    <x-button.secondary class="button-text text-base !font-medium !leading-5 px-6 py-2">
                                        {{ __('navigation.login') }}
                                    </x-button.secondary>
                                </a>
                                @if(!config('settings.registration_disabled', false))
                                <a href="{{ route('register') }}" wire:navigate>
                                    <x-button.primary class="button-text text-base !font-medium !leading-5 px-6 py-2">
                                        {{ __('navigation.register') }}
                                    </x-button.primary>
                                </a>
                                @endif
                            </div>
                            @endif
                        </div>

                        
                        <button
                            @click="slideOverOpen = !slideOverOpen"
                            class="relative w-10 h-10 flex lg:hidden items-center justify-center rounded-lg hover:bg-neutral transition ml-1"
                            aria-label="Toggle Menu">

                            <span
                                x-show="!slideOverOpen"
                                x-transition:enter="transition duration-300"
                                x-transition:enter-start="opacity-0 -rotate-90 scale-75"
                                x-transition:enter-end="opacity-100 rotate-0 scale-100"
                                x-transition:leave="transition duration-150"
                                x-transition:leave-start="opacity-100 rotate-0 scale-100"
                                x-transition:leave-end="opacity-0 rotate-90 scale-75"
                                class="absolute inset-0 flex items-center justify-center"
                                aria-hidden="true">
                                <x-ri-menu-fill class="size-5" />
                            </span>

                            <span
                                x-show="slideOverOpen"
                                x-transition:enter="transition duration-300"
                                x-transition:enter-start="opacity-0 rotate-90 scale-75"
                                x-transition:enter-end="opacity-100 rotate-0 scale-100"
                                x-transition:leave="transition duration-150"
                                x-transition:leave-start="opacity-100 rotate-0 scale-100"
                                x-transition:leave-end="opacity-0 -rotate-90 scale-75"
                                class="absolute inset-0 flex items-center justify-center"
                                aria-hidden="true">
                                <x-ri-close-fill class="size-5" />
                            </span>
                        </button>
                    </div>
                </div>
            </div>
        </div>

    
        @include('components.navigation._mobile-menu')
    </div>
</nav>
