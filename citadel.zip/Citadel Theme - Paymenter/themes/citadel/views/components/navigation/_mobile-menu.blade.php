        <template x-teleport="body">
            <div
                x-show="slideOverOpen"
                @keydown.window.escape="slideOverOpen=false"
                x-cloak
                class="fixed left-0 right-0 w-full z-[99]"
                style="top: calc(var(--banner-height, 0px) + 4rem); height: calc(100dvh - 4rem - var(--banner-height, 0px));"
                aria-modal="true"
                tabindex="-1">
                <div
                    x-show="slideOverOpen"
                    @click.away="slideOverOpen = false"
                    x-transition.opacity.duration.300ms
                    class="absolute inset-0 bg-background-secondary border-t border-neutral overflow-y-auto flex flex-col">

                    <div class="flex flex-col h-full">
                        @if(auth()->check())
                        
                        <div class="p-4 border-b border-neutral">
                            <div class="flex items-center gap-3">
                                <img src="{{ citadel_avatar_url(auth()->user()) }}" class="w-12 h-12 rounded-full border border-neutral object-cover" alt="avatar" />
                                <div class="flex flex-col items-start">
                                    <span class="nav-text-sm font-semibold leading-tight">{{ auth()->user()->name }}</span>
                                    <span class="nav-text-sm text-base/70 leading-tight">{{ auth()->user()->email }}</span>
                                </div>
                            </div>
                        </div>
                        @endif

                        <div class="flex-1 overflow-y-auto p-4">
                           
                            <div class="mb-6">
                                <h3 class="dropdown-text font-semibold uppercase text-base/50 mb-3 px-2">{{ __('citadel::citadel.navigation.navbar.navigation_heading') }}</h3>
                                <div class="space-y-1">
                                    @foreach (\App\Classes\Navigation::getLinks() as $nav)
                                    @if (!empty($nav['children']))
                                    <div x-data="{ activeAccordion: {{ $nav['active'] ? 'true' : 'false' }} }"
                                        class="rounded-lg">
                                        <button @click="activeAccordion = !activeAccordion"
                                            class="nav-item flex items-center justify-between w-full p-3 rounded-lg hover:bg-primary/5 transition-colors">
                                            <span>
                                                @if($nav['name'] === 'Shop' || $nav['name'] === __('navigation.shop'))
                                                    {{ __('citadel::citadel.navigation.navbar.store') }}
                                                @else
                                                    {{ $nav['name'] }}
                                                @endif
                                            </span>
                                            <x-ri-arrow-down-s-line x-bind:class="{ 'rotate-180' : activeAccordion }"
                                                class="size-4 transition-transform duration-300" />
                                        </button>
                                        <div x-show="activeAccordion" x-collapse>
                                            <div class="ml-8 mt-1 space-y-1">
                                                @foreach ($nav['children'] as $child)
                                                @if(isset($child['url']) && ! in_array(rtrim($child['url'], '/'), $citadelHiddenStoreUrls ?? []))
                                                <a href="{{ $child['url'] }}"
                                                   @if($child['spa'] ?? true) wire:navigate @endif
                                                   class="dropdown-text flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-neutral/50 transition-colors {{ $child['active'] ? 'text-primary font-semibold' : '' }}">
                                                    @if(!theme('hide_navbar_icons'))
                                                    <x-ri-shopping-cart-fill class="size-4" />
                                                    @endif
                                                    <span>{{ $child['name'] }}</span>
                                                </a>
                                                @endif
                                                @endforeach
                                            </div>
                                        </div>
                                    </div>
                                    @elseif(isset($nav['url']))
                                    <a href="{{ $nav['url'] }}"
                                       @if(isset($nav['spa']) ? $nav['spa'] : true) wire:navigate @endif
                                       class="nav-item flex items-center gap-3 p-3 rounded-lg hover:bg-primary/5 transition-colors {{ $nav['active'] ? 'text-primary bg-primary/5' : '' }}">
                                        <span>
                                            @if($nav['name'] === 'Home' || $nav['name'] === __('navigation.home'))
                                                {{ __('citadel::citadel.navigation.navbar.home') }}
                                            @elseif($nav['name'] === 'Shop' || $nav['name'] === __('navigation.shop'))
                                                {{ __('citadel::citadel.navigation.navbar.store') }}
                                            @else
                                                {{ $nav['name'] }}
                                            @endif
                                        </span>
                                    </a>
                                    @endif
                                    @endforeach

                                    @if(auth()->check())
                                   
                                    <a href="{{ route('dashboard') }}" wire:navigate
                                       class="nav-item flex items-center gap-3 p-3 rounded-lg hover:bg-primary/5 transition-colors">
                                        <span>{{ __('citadel::citadel.navigation.navbar.dashboard') }}</span>
                                    </a>

                                    
                                    @if($citadelNavIsDashPage)
                                    @php
                                        $domainsNavMobile = collect(\App\Classes\Navigation::getDashboardLinks())->first(function($nav) {
                                            return isset($nav['url']) && str_contains($nav['url'], '/domains');
                                        });
                                    @endphp
                                    @if($domainsNavMobile)
                                    <a href="{{ $domainsNavMobile['url'] }}" {{ ($domainsNavMobile['spa'] ?? true) ? 'wire:navigate' : '' }}
                                       class="nav-item flex items-center gap-3 p-3 rounded-lg hover:bg-primary/5 transition-colors {{ ($domainsNavMobile['active'] ?? false) ? 'text-primary bg-primary/5' : '' }}">
                                        <span>{{ $domainsNavMobile['name'] }}</span>
                                    </a>
                                    @endif
                                    @endif

                                    
                                    <div x-data="{ supportOpen: false }" class="rounded-lg">
                                        <button @click="supportOpen = !supportOpen"
                                            class="nav-item flex items-center justify-between w-full p-3 rounded-lg hover:bg-primary/5 transition-colors">
                                            <span>{{ __('citadel::citadel.navigation.navbar.support') }}</span>
                                            <x-ri-arrow-down-s-line x-bind:class="{ 'rotate-180' : supportOpen }"
                                                class="size-4 transition-transform duration-300" />
                                        </button>
                                        <div x-show="supportOpen" x-collapse>
                                            <div class="ml-8 mt-1 space-y-1">
                                                <a href="{{ route('tickets') }}" wire:navigate
                                                   class="dropdown-text flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-neutral/50 transition-colors">
                                                    @if(!theme('hide_navbar_icons'))
                                                    <x-ri-coupon-fill class="size-4" />
                                                    @endif
                                                    <span>{{ __('citadel::citadel.navigation.navbar.tickets') }}</span>
                                                </a>
                                                @foreach ($navConfig as $_supItem)
                                                    @if(($_supItem['type'] ?? null) === 'support')
                                                        @foreach (($_supItem['dropdown_items'] ?? []) as $_supExtra)
                                                            @if(!empty($_supExtra['url']))
                                                            @php $_supIcon = !empty($_supExtra['icon']) ? $_supExtra['icon'] : 'ri-link'; @endphp
                                                            <a href="{{ $_supExtra['url'] }}"
                                                               @if(!empty($_supExtra['new_tab'])) target="_blank" rel="noopener" @else wire:navigate @endif
                                                               class="dropdown-text flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-neutral/50 transition-colors">
                                                                @if(!theme('hide_navbar_icons'))
                                                                <x-dynamic-component :component="$_supIcon" class="size-4" />
                                                                @endif
                                                                <span>{{ $_supExtra['label'] ?? 'Link' }}</span>
                                                            </a>
                                                            @endif
                                                        @endforeach
                                                    @endif
                                                @endforeach
                                            </div>
                                        </div>
                                    </div>

                                    @foreach ($navConfig as $_mobItem)
                                        @php
                                            $_mobType = $_mobItem['type'] ?? null;
                                            $_mobShowDash  = $_mobItem['show_on_dashboard'] ?? true;
                                            $_mobShowFront = $_mobItem['show_on_front'] ?? true;
                                            $_mobAllowed   = $citadelNavIsDashPage ? $_mobShowDash : $_mobShowFront;
                                        @endphp
                                        @if($_mobType === 'custom_dropdown' && !empty($_mobItem['dropdown_items']) && $_mobAllowed)
                                        <div x-data="{ ddOpen: false }" class="rounded-lg">
                                            <button @click="ddOpen = !ddOpen"
                                                class="nav-item flex items-center justify-between w-full p-3 rounded-lg hover:bg-primary/5 transition-colors">
                                                <span>{{ $_mobItem['custom_label'] ?? 'Menu' }}</span>
                                                <x-ri-arrow-down-s-line x-bind:class="{ 'rotate-180' : ddOpen }"
                                                    class="size-4 transition-transform duration-300" />
                                            </button>
                                            <div x-show="ddOpen" x-collapse>
                                                <div class="ml-8 mt-1 space-y-1">
                                                    @foreach ($_mobItem['dropdown_items'] as $_ddItem)
                                                        @if(!empty($_ddItem['url']))
                                                        @php $_mobDdIcon = !empty($_ddItem['icon']) ? $_ddItem['icon'] : 'ri-link'; @endphp
                                                        <a href="{{ $_ddItem['url'] }}"
                                                           @if(!empty($_ddItem['new_tab'])) target="_blank" rel="noopener" @else wire:navigate @endif
                                                           class="dropdown-text flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-neutral/50 transition-colors">
                                                            @if(!theme('hide_navbar_icons'))
                                                            <x-dynamic-component :component="$_mobDdIcon" class="size-4" />
                                                            @endif
                                                            <span>{{ $_ddItem['label'] ?? 'Link' }}</span>
                                                        </a>
                                                        @endif
                                                    @endforeach
                                                </div>
                                            </div>
                                        </div>
                                        @elseif($_mobType === 'custom' && !empty($_mobItem['custom_label']) && !empty($_mobItem['custom_url']) && $_mobAllowed)
                                        <a href="{{ $_mobItem['custom_url'] }}"
                                           class="nav-item flex items-center gap-3 p-3 rounded-lg hover:bg-primary/5 transition-colors">
                                            <span>{{ $_mobItem['custom_label'] }}</span>
                                        </a>
                                        @endif
                                    @endforeach
                                    @endif
                                </div>
                            </div>

                            @if(auth()->check())
                            
                            <div class="border-t border-neutral pt-4">
                                <div x-data="{ accountOpen: false }" class="rounded-lg">
                                    <button @click="accountOpen = !accountOpen"
                                        class="nav-item flex items-center justify-between w-full p-3 rounded-lg hover:bg-primary/5 transition-colors">
                                        <span>Account</span>
                                        <x-ri-arrow-down-s-line x-bind:class="{ 'rotate-180' : accountOpen }"
                                            class="size-4 transition-transform duration-300" />
                                    </button>
                                    <div x-show="accountOpen" x-collapse>
                                        <div class="ml-8 mt-1 space-y-1">
                                            <a href="{{ route('account') }}" wire:navigate
                                               class="dropdown-text flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-neutral/50 transition-colors">
                                                @if(!theme('hide_navbar_icons'))
                                                <x-ri-profile-fill class="size-4" />
                                                @endif
                                                <span>Account Settings</span>
                                            </a>
                                            
                                            <a href="{{ route('account.security') }}" wire:navigate
                                               class="dropdown-text flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-neutral/50 transition-colors">
                                                @if(!theme('hide_navbar_icons'))
                                                <x-ri-shield-keyhole-fill class="size-4" />
                                                @endif
                                                <span>Security</span>
                                            </a>
                                            
                                            @if(config('settings.credits_enabled'))
                                            <a href="{{ route('account.credits') }}" wire:navigate
                                               class="dropdown-text flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-neutral/50 transition-colors">
                                                @if(!theme('hide_navbar_icons'))
                                                <x-ri-wallet-3-fill class="size-4" />
                                                @endif
                                                <span>Credits</span>
                                            </a>
                                            @endif
                                            
                                            @php
                                                $accountNav = collect(\App\Classes\Navigation::getDashboardLinks())->first(function($nav) {
                                                    return isset($nav['children']) && !empty($nav['children']);
                                                });
                                                
                                                $hardcodedAccountUrls = [
                                                    route('account'),
                                                    route('account.security'),
                                                    route('account.credits'),
                                                    route('account.payment-methods'),
                                                    route('account.notifications'),
                                                ];
                                            @endphp
                                            
                                            @if($accountNav && isset($accountNav['children']))
                                                @foreach($accountNav['children'] as $child)
                                                    @if(($child['condition'] ?? true) && isset($child['url']) && !in_array($child['url'], $hardcodedAccountUrls))
                                                        <a href="{{ $child['url'] }}" {{ ($child['spa'] ?? true) ? 'wire:navigate' : '' }}
                                                           class="dropdown-text flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-neutral/50 transition-colors">
                                                            @if(!theme('hide_navbar_icons'))
                                                                @isset($child['icon'])
                                                                    <x-dynamic-component :component="$child['icon']" class="size-4" />
                                                                @else
                                                                    <x-ri-circle-fill class="size-4" />
                                                                @endisset
                                                            @endif
                                                            <span>{{ $child['name'] }}</span>
                                                        </a>
                                                    @endif
                                                @endforeach
                                            @endif
                                            
                                            @if(auth()->user()->role_id !== null)
                                            <a href="{{ route('filament.admin.pages.dashboard') }}"
                                               class="dropdown-text flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-neutral/50 transition-colors">
                                                @if(!theme('hide_navbar_icons'))
                                                <x-ri-admin-fill class="size-4" />
                                                @endif
                                                <span>{{ __('navigation.admin') }}</span>
                                            </a>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endif
                        </div>

                        @if(auth()->check())
                        
                        <div class="p-4 border-t border-neutral">
                            <div class="normal-text text-base !font-normal !leading-5 flex items-center justify-center gap-3 py-2.5 px-3 rounded-lg hover:bg-red-500/10 hover:text-red-600 transition-colors cursor-pointer">
                                @if(!theme('hide_navbar_icons'))
                                <x-ri-logout-box-fill class="size-4" />
                                @endif
                                <livewire:auth.logout :key="'mobile-logout'" />
                            </div>
                        </div>
                        @endif

                        @if(!auth()->check())
                        
                        <div class="p-4 border-t border-neutral">
                            <div class="flex flex-col gap-3">
                                <a href="{{ route('login') }}" wire:navigate>
                                    <x-button.secondary class="nav-item w-full">
                                        {{ __('navigation.login') }}
                                    </x-button.secondary>
                                </a>
                                @if(!config('settings.registration_disabled', false))
                                <a href="{{ route('register') }}" wire:navigate>
                                    <x-button.primary class="nav-item w-full">
                                        {{ __('navigation.register') }}
                                    </x-button.primary>
                                </a>
                                @endif
                            </div>
                        </div>
                        @endif
                    </div>
                </div>
            </div>
        </template>
