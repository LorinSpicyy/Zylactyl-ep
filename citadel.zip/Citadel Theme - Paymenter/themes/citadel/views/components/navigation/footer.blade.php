
<footer data-boundary="page-end" class="mt-auto w-full">
    
    <div class="w-full border-t border-neutral bg-background-secondary" style="background-color: hsl(var(--color-background-secondary));">
        <div class="px-4 sm:px-6 lg:px-8 py-10 mx-auto" style="max-width: var(--citadel-content-width, 1440px);">
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
                
                <div class="lg:col-span-7">
                    
                    <a href="{{ route('home') }}" class="flex flex-row items-center mb-4" wire:navigate>
                        <x-logo class="{{ theme('logo_only_display') ? 'h-9' : 'h-7' }} mr-2 rtl:ml-2" />
                        @if(!theme('logo_only_display') && config('settings.company_name'))
                        <span class="secondary-title text-sm !font-semibold !leading-none flex items-center" style="color: hsl(var(--color-base));">{{ config('settings.company_name') }}</span>
                        @endif
                    </a>
                    
                    
                    @if(theme('site_description'))
                    <div class="mt-4 text-sm leading-relaxed max-w-md prose prose-sm prose-invert prose-p:my-1 prose-a:text-primary prose-a:no-underline hover:prose-a:underline prose-strong:font-semibold" style="color: hsl(var(--color-base) / 0.7); --tw-prose-body: hsl(var(--color-base) / 0.7); --tw-prose-headings: hsl(var(--color-base) / 0.9); --tw-prose-links: hsl(var(--color-primary)); --tw-prose-bold: hsl(var(--color-base) / 0.9);">
                        {!! Str::markdown(theme('site_description'), ['html_input' => 'strip', 'allow_unsafe_links' => false]) !!}
                    </div>
                    @endif
                    
                    
                    <div class="mt-6 flex items-center gap-4">
                        @if(theme('social_youtube'))
                        <a href="{{ theme('social_youtube') }}" target="_blank" class="transition-colors" style="color: hsl(var(--color-base) / 0.5);" onmouseover="this.style.color = 'hsl(var(--color-primary))'" onmouseout="this.style.color = 'hsl(var(--color-base) / 0.5)'">
                            <svg class="w-5 h-5" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                            </svg>
                        </a>
                        @endif
                        @if(theme('social_x'))
                        <a href="{{ theme('social_x') }}" target="_blank" class="transition-colors" style="color: hsl(var(--color-base) / 0.5);" onmouseover="this.style.color = 'hsl(var(--color-primary))'" onmouseout="this.style.color = 'hsl(var(--color-base) / 0.5)'">
                            <svg class="w-5 h-5" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                            </svg>
                        </a>
                        @endif
                        @if(theme('social_instagram'))
                        <a href="{{ theme('social_instagram') }}" target="_blank" class="transition-colors" style="color: hsl(var(--color-base) / 0.5);" onmouseover="this.style.color = 'hsl(var(--color-primary))'" onmouseout="this.style.color = 'hsl(var(--color-base) / 0.5)'">
                            <svg class="w-5 h-5" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                            </svg>
                        </a>
                        @endif
                        @if(theme('social_tiktok'))
                        <a href="{{ theme('social_tiktok') }}" target="_blank" class="transition-colors" style="color: hsl(var(--color-base) / 0.5);" onmouseover="this.style.color = 'hsl(var(--color-primary))'" onmouseout="this.style.color = 'hsl(var(--color-base) / 0.5)'">
                            <svg class="w-5 h-5" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
                            </svg>
                        </a>
                        @endif
                        @if(theme('social_linkedin'))
                        <a href="{{ theme('social_linkedin') }}" target="_blank" class="transition-colors" style="color: hsl(var(--color-base) / 0.5);" onmouseover="this.style.color = 'hsl(var(--color-primary))'" onmouseout="this.style.color = 'hsl(var(--color-base) / 0.5)'">
                            <svg class="w-5 h-5" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                            </svg>
                        </a>
                        @endif
                        @if(theme('social_github'))
                        <a href="{{ theme('social_github') }}" target="_blank" class="transition-colors" style="color: hsl(var(--color-base) / 0.5);" onmouseover="this.style.color = 'hsl(var(--color-primary))'" onmouseout="this.style.color = 'hsl(var(--color-base) / 0.5)'">
                            <svg class="w-5 h-5" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
                            </svg>
                        </a>
                        @endif
                    </div>
                    
                    
                    @if(!theme('remove_branding'))
                    <p class="normal-text text-xs hidden lg:block mt-4" style="color: hsl(var(--color-base) / 0.5);">
                        @if(theme('copyright_message'))
                            {{ str_replace(['{year}', '{company}'], [date('Y'), config('settings.company_name', config('app.name'))], theme('copyright_message')) }}
                        @else
                            {{ __('© :year :app_name. All rights reserved.', ['year' => date('Y'), 'app_name' => config('settings.company_name', config('app.name'))]) }}
                        @endif
                    </p>
                    @endif
                </div>
                
                
                <div class="lg:col-span-5 flex gap-8 lg:gap-12 justify-start lg:justify-end">
                    
                    @php
                        $footerCategories = \App\Models\Category::whereNull('parent_id')
                            ->where(function ($query) {
                                $query->whereHas('children')->orWhereHas('products', function ($query) {
                                    $query->where('hidden', false);
                                });
                            })
                            ->orderBy('sort')
                            ->take(5)
                            ->get();
                    @endphp
                    
                    @if($footerCategories->count() > 0)
                    <div>
                        <h4 class="text-sm font-semibold uppercase mb-4" style="color: hsl(var(--color-base));">{{ __('Services') }}</h4>
                        <div class="space-y-3">
                            @foreach($footerCategories as $category)
                            <div>
                                <a class="text-sm transition-colors" href="{{ route('category.show', ['category' => $category->slug]) }}" style="color: hsl(var(--color-base) / 0.7);" onmouseover="this.style.color = 'hsl(var(--color-primary))'" onmouseout="this.style.color = 'hsl(var(--color-base) / 0.7)'">{{ $category->name }}</a>
                            </div>
                            @endforeach
                        </div>
                    </div>
                    @endif

                    @php
                        $companyItems = theme('footer_company_items_data');
                        if (is_string($companyItems)) $companyItems = json_decode($companyItems, true) ?: [];
                        if (empty($companyItems)) {
                            $companyItems = [];
                            if (theme('footer_services_link')) $companyItems[] = ['label' => __('citadel::citadel.navigation.footer.services'), 'url' => theme('footer_services_link')];
                            if (theme('footer_contact_link')) $companyItems[] = ['label' => __('citadel::citadel.navigation.footer.contact_us'), 'url' => theme('footer_contact_link')];
                        }

                        $legalItems = theme('footer_legal_items_data');
                        if (is_string($legalItems)) $legalItems = json_decode($legalItems, true) ?: [];
                        if (empty($legalItems)) {
                            $legalItems = [];
                            if (theme('footer_tos_link')) $legalItems[] = ['label' => __('citadel::citadel.navigation.footer.terms_of_service'), 'url' => theme('footer_tos_link')];
                            if (theme('footer_privacy_link')) $legalItems[] = ['label' => __('citadel::citadel.navigation.footer.privacy_policy'), 'url' => theme('footer_privacy_link')];
                        }
                    @endphp

                    @if(count($companyItems) > 0)
                    <div>
                        <h4 class="text-sm font-semibold uppercase mb-4" style="color: hsl(var(--color-base));">{{ __('citadel::citadel.navigation.footer.company_heading') }}</h4>
                        <div class="space-y-3">
                            @foreach($companyItems as $item)
                            @if(!empty($item['label']) && !empty($item['url']))
                            <div>
                                <a class="text-sm transition-colors" href="{{ $item['url'] }}" style="color: hsl(var(--color-base) / 0.7);" onmouseover="this.style.color = 'hsl(var(--color-primary))'" onmouseout="this.style.color = 'hsl(var(--color-base) / 0.7)'">{{ $item['label'] }}</a>
                            </div>
                            @endif
                            @endforeach
                        </div>
                    </div>
                    @endif

                    @if(count($legalItems) > 0)
                    <div>
                        <h4 class="text-sm font-semibold uppercase mb-4" style="color: hsl(var(--color-base));">{{ __('citadel::citadel.navigation.footer.legal_heading') }}</h4>
                        <div class="space-y-3">
                            @foreach($legalItems as $item)
                            @if(!empty($item['label']) && !empty($item['url']))
                            <div>
                                <a class="text-sm transition-colors" href="{{ $item['url'] }}" style="color: hsl(var(--color-base) / 0.7);" onmouseover="this.style.color = 'hsl(var(--color-primary))'" onmouseout="this.style.color = 'hsl(var(--color-base) / 0.7)'">{{ $item['label'] }}</a>
                            </div>
                            @endif
                            @endforeach
                        </div>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
    
    
    <div class="w-full py-4 sm:py-4 relative" style="background-color: hsl(var(--color-background-secondary)); min-height: 46px;">
        <div class="absolute inset-0 bg-black/[0.02] dark:bg-black/[0.05]"></div>
        <div class="h-full px-4 sm:px-6 lg:px-8 mx-auto relative z-10" style="max-width: var(--citadel-content-width, 1440px);">
            <div class="h-full flex flex-col sm:flex-row items-center justify-between gap-2 sm:gap-0">
                
                <div class="flex flex-wrap items-center gap-2 max-w-full sm:max-w-[70%] {{ theme('remove_branding') ? 'lg:order-2' : '' }}">
                    @php
                        $gatewayImages = [];
                        

                        $uploadedIcons = theme('payment_method_icons');
                        if ($uploadedIcons) {
                            if (is_string($uploadedIcons)) {
                                $uploadedIcons = json_decode($uploadedIcons, true);
                            }
                            if (is_array($uploadedIcons) && count($uploadedIcons) > 0) {
                                foreach ($uploadedIcons as $icon) {
                                    if ($icon) {
                                        $gatewayImages[] = '/storage/' . $icon;
                                    }
                                }
                            }
                        }
                        

                        if (empty($gatewayImages)) {
                            $assetsPath = public_path('assets/footer');
                            
                            if (is_dir($assetsPath)) {
                                $files = glob($assetsPath . '/gateway*.{png,svg,jpg,jpeg}', GLOB_BRACE);
                                
                                usort($files, function($a, $b) {
                                    preg_match('/gateway(\d+)/', basename($a), $matchA);
                                    preg_match('/gateway(\d+)/', basename($b), $matchB);
                                    $numA = isset($matchA[1]) ? (int)$matchA[1] : 0;
                                    $numB = isset($matchB[1]) ? (int)$matchB[1] : 0;
                                    return $numA - $numB;
                                });
                                
                                foreach ($files as $file) {
                                    $gatewayImages[] = '/assets/footer/' . basename($file);
                                }
                            }
                        }
                    @endphp
                    
                    @php $paymentDisableBg = (bool) theme('footer_payment_disable_bg', true); @endphp
                    @if(count($gatewayImages) > 0)
                        @foreach($gatewayImages as $image)

                        <div class="flex items-center justify-center rounded w-10 h-6 sm:w-14 sm:h-8 md:w-[60px] md:h-8" @unless($paymentDisableBg) style="background-color: hsl(var(--color-base) / 0.05); border: 1px solid hsl(var(--color-base) / 0.1);" @endunless>
                            <img src="{{ $image }}" alt="Payment Method" loading="lazy" class="max-w-[85%] max-h-[70%] object-contain" />
                        </div>
                        @endforeach
                    @endif
                </div>
                
                
                @if(!theme('remove_branding'))
                <div class="flex items-center">
                    <a href="https://paymenter.org" target="_blank" class="group flex items-center gap-2 transition-colors" style="color: hsl(var(--color-base) / 0.5);" onmouseover="this.style.color = 'hsl(var(--color-base))'" onmouseout="this.style.color = 'hsl(var(--color-base) / 0.5)'">
                        <svg class="w-4 h-4 group-hover:text-[#4667FF] transition-colors" width="150" height="205" viewBox="0 0 150 205" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_1_17)">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M0 107V205H42.8571V139.638H100C133.333 139.638 150 123 150 89.7246V69.5L75 107V69.5L148.227 32.8863C143.133 10.9621 127.057 0 100 0H0V107ZM0 107V69.5L75 32V69.5L0 107Z"></path>
                            </g>
                            <defs>
                                <clipPath id="clip0_1_17">
                                    <rect width="150" height="205"></rect>
                                </clipPath>
                            </defs>
                        </svg>
                        <span class="text-xs">{{ __('citadel::citadel.navigation.footer.powered_by') }} Paymenter</span>
                    </a>
                </div>
                @else
                <div class="hidden lg:flex items-center lg:order-1">
                    <p class="normal-text text-xs" style="color: hsl(var(--color-base) / 0.5);">
                        @if(theme('copyright_message'))
                            {{ str_replace(['{year}', '{company}'], [date('Y'), config('settings.company_name', config('app.name'))], theme('copyright_message')) }}
                        @else
                            {{ __('© :year :app_name. All rights reserved.', ['year' => date('Y'), 'app_name' => config('settings.company_name', config('app.name'))]) }}
                        @endif
                    </p>
                </div>
                @endif
            </div>
            
            
            <div class="lg:hidden flex flex-col sm:flex-row items-center justify-between gap-2 mt-3">
                <p class="normal-text text-xs text-center sm:text-left" style="color: hsl(var(--color-base) / 0.5);">
                    @if(theme('copyright_message'))
                        {{ str_replace(['{year}', '{company}'], [date('Y'), config('settings.company_name', config('app.name'))], theme('copyright_message')) }}
                    @else
                        {{ __('© :year :app_name. All rights reserved.', ['year' => date('Y'), 'app_name' => config('settings.company_name', config('app.name'))]) }}
                    @endif
                </p>
            </div>
        </div>
    </div>
</footer>

