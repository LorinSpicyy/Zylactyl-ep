@props(['showSidebar' => false])

@php

    $citadelUtilityBar = theme('header_utility_bar', false);
    $citadelSticky = theme('header_sticky', true);

    $citadelUtilityItems = theme('header_utility_items_data', []);
    $citadelUtilityItems = is_array($citadelUtilityItems) ? $citadelUtilityItems : (json_decode((string) $citadelUtilityItems, true) ?: []);
    $citadelHasUtilItems = false;
    foreach ($citadelUtilityItems as $_chk) {
        if (trim((string) ($_chk['text'] ?? '')) !== '') { $citadelHasUtilItems = true; break; }
    }

    
    $citadelBgLight = trim((string) theme('header_utility_bar_bg', ''));
    $citadelBgDark  = trim((string) theme('header_utility_bar_bg_dark', ''));
    $citadelEffLight = $citadelBgLight !== '' ? $citadelBgLight : ($citadelBgDark !== '' ? $citadelBgDark : null);
    $citadelEffDark  = $citadelBgDark !== '' ? $citadelBgDark : ($citadelBgLight !== '' ? $citadelBgLight : null);

    
    $citadelContrast = function ($bg) {
        $bg = strtolower(trim((string) $bg));
        if ($bg === '') return null;
        $rgb = null;
        if (preg_match('/^#([0-9a-f]{6})$/', $bg, $m)) {
            $rgb = [hexdec(substr($m[1], 0, 2)), hexdec(substr($m[1], 2, 2)), hexdec(substr($m[1], 4, 2))];
        } elseif (preg_match('/^#([0-9a-f]{3})$/', $bg, $m)) {
            $rgb = [hexdec(str_repeat($m[1][0], 2)), hexdec(str_repeat($m[1][1], 2)), hexdec(str_repeat($m[1][2], 2))];
        } elseif (preg_match('/rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)/i', $bg, $m)) {
            $rgb = [(float) $m[1], (float) $m[2], (float) $m[3]];
        } elseif (preg_match('/hsla?\(\s*([\d.]+)[,\s]+([\d.]+)%?[,\s]+([\d.]+)%?/i', $bg, $m)) {
            $h = ((float) $m[1]) / 360; $s = ((float) $m[2]) / 100; $l = ((float) $m[3]) / 100;
            if ($s == 0) {
                $r = $g = $b = $l;
            } else {
                $q = $l < 0.5 ? $l * (1 + $s) : $l + $s - $l * $s;
                $p = 2 * $l - $q;
                $hue = function ($p, $q, $t) {
                    if ($t < 0) $t += 1;
                    if ($t > 1) $t -= 1;
                    if ($t < 1 / 6) return $p + ($q - $p) * 6 * $t;
                    if ($t < 1 / 2) return $q;
                    if ($t < 2 / 3) return $p + ($q - $p) * (2 / 3 - $t) * 6;
                    return $p;
                };
                $r = $hue($p, $q, $h + 1 / 3); $g = $hue($p, $q, $h); $b = $hue($p, $q, $h - 1 / 3);
            }
            $rgb = [$r * 255, $g * 255, $b * 255];
        }
        if (! $rgb) return null;
        $lum = (0.2126 * $rgb[0] + 0.7152 * $rgb[1] + 0.0722 * $rgb[2]) / 255;
        return $lum > 0.6
            ? ['#0a0a0a', 'rgba(10, 10, 10, 0.22)', 'rgba(10, 10, 10, 0.08)']
            : ['#ffffff', 'rgba(255, 255, 255, 0.28)', 'rgba(255, 255, 255, 0.12)'];
    };

    $citadelFgLight = $citadelContrast($citadelEffLight);
    $citadelFgDark  = $citadelContrast($citadelEffDark);

    
    $citadelFgModes = [];
    if ($citadelFgLight) $citadelFgModes[] = ['', $citadelFgLight];
    if ($citadelFgDark)  $citadelFgModes[] = ['.dark ', $citadelFgDark];

    $citadelHasUtilBg = $citadelEffLight !== null;
    $citadelUtilColored = $citadelFgLight || $citadelFgDark;
@endphp

@if($citadelUtilityBar)
<div aria-label="utility-bar"
     class="citadel-ub {{ $showSidebar ? 'md:ml-72 rtl:ml-0 rtl:md:mr-72' : '' }} {{ $citadelUtilColored ? 'citadel-util-colored' : '' }} hidden md:block {{ $citadelSticky ? 'fixed' : 'absolute' }} left-0 right-0 z-[30] border-b border-neutral"
     style="top: var(--banner-height, 0px); height: var(--citadel-utility-height, 2.5rem);">
    <style>.citadel-util-ico svg{width:1rem;height:1rem;display:block;} .citadel-ub .normal-text{font-weight:500 !important;}</style>
    {{-- No admin-set colour: use a tiny shade of the main background, mixed from
         the theme colour vars so it auto-adapts to light/dark and any preset. --}}
    @if(! $citadelHasUtilBg)<style>.citadel-ub{background-color: color-mix(in srgb, hsl(var(--color-background)) 95%, hsl(var(--color-base)) 5%);}</style>@endif
    @if($citadelEffLight)<style>.citadel-ub{background-color: {{ $citadelEffLight }};}</style>@endif
    @if($citadelEffDark && $citadelEffDark !== $citadelEffLight)<style>.dark .citadel-ub{background-color: {{ $citadelEffDark }};}</style>@endif
    @if($citadelUtilColored)
    <style>
        
        @foreach($citadelFgModes as [$citadelPfx, $citadelFg])
        {{ $citadelPfx }}.citadel-util-colored .citadel-util-fg,
        {{ $citadelPfx }}.citadel-util-colored .citadel-util-fg * { color: {{ $citadelFg[0] }} !important; }
        {{ $citadelPfx }}.citadel-util-colored .citadel-util-fg [class*="border"] { border-color: {{ $citadelFg[1] }} !important; }
        {{ $citadelPfx }}.citadel-util-colored .citadel-util-sep { background-color: {{ $citadelFg[0] }} !important; opacity: 0.3; }
        {{ $citadelPfx }}.citadel-util-colored [role="radiogroup"] { background-color: transparent !important; border-color: {{ $citadelFg[1] }} !important; }
        {{ $citadelPfx }}.citadel-util-colored [role="radiogroup"] button { color: {{ $citadelFg[0] }} !important; }
        {{ $citadelPfx }}.citadel-util-colored [role="radiogroup"] button:hover { background-color: {{ $citadelFg[2] }} !important; }
        {{ $citadelPfx }}.citadel-util-colored .citadel-util-notif .relative > button,
        {{ $citadelPfx }}.citadel-util-colored .citadel-util-notif .relative > button * { color: {{ $citadelFg[0] }} !important; }
        @endforeach
    </style>
    @endif
    <div class="container mx-auto px-4 lg:px-8 h-full" style="max-width: var(--citadel-content-width, 1440px);">
        <div class="flex flex-row items-center h-full gap-1 justify-end">

            
            @foreach($citadelUtilityItems as $_utilItem)
                @php
                    $_uText     = trim((string) ($_utilItem['text'] ?? ''));
                    $_uUrl      = trim((string) ($_utilItem['url'] ?? ''));
                    $_uIconType = $_utilItem['icon_type'] ?? 'remix';
                    $_uIcon     = trim((string) ($_utilItem['icon'] ?? ''));
                    $_uSvg      = trim((string) ($_utilItem['icon_svg'] ?? ''));
                    $_uTab      = ! empty($_utilItem['new_tab']);
                @endphp
                @if($_uText !== '')
                    @if($_uUrl !== '')
                    <a href="{{ $_uUrl }}"
                       @if($_uTab) target="_blank" rel="noopener" @endif
                       class="citadel-util-fg flex items-center gap-1.5 px-2 py-1 rounded-lg hover:text-primary transition-colors cursor-pointer">
                        @if($_uIconType === 'svg' && $_uSvg !== '')
                            <span class="citadel-util-ico inline-flex shrink-0">{!! $_uSvg !!}</span>
                        @elseif($_uIconType === 'remix' && $_uIcon !== '')
                            <x-dynamic-component :component="$_uIcon" class="size-4 shrink-0" />
                        @endif
                        <span class="normal-text text-xs !font-normal !leading-none">{{ $_uText }}</span>
                    </a>
                    @else
                    <span class="citadel-util-fg flex items-center gap-1.5 px-2 py-1">
                        @if($_uIconType === 'svg' && $_uSvg !== '')
                            <span class="citadel-util-ico inline-flex shrink-0">{!! $_uSvg !!}</span>
                        @elseif($_uIconType === 'remix' && $_uIcon !== '')
                            <x-dynamic-component :component="$_uIcon" class="size-4 shrink-0" />
                        @endif
                        <span class="normal-text text-xs !font-normal !leading-none">{{ $_uText }}</span>
                    </span>
                    @endif
                @endif
            @endforeach

            @if($citadelHasUtilItems)
            <div class="citadel-util-sep h-3.5 w-px bg-neutral/50 mx-1"></div>
            @endif

            
            @auth
            <div class="citadel-util-notif items-center flex">
                <livewire:components.notifications />
            </div>
            @endauth

            
            <div class="items-center flex">
                <x-dropdown>
                    <x-slot:trigger>
                        <div class="citadel-util-fg flex items-center gap-1.5 px-2 py-1 rounded-lg hover:text-primary transition-colors cursor-pointer">
                            <img src="/assets/languages/{{ strtolower(app()->getLocale()) }}.svg" class="w-4 h-4 rounded-full border border-neutral object-cover" alt="{{ app()->getLocale() }}">
                            <span class="normal-text text-xs !font-normal !leading-none">{{ strtoupper(app()->getLocale()) }}</span>
                        </div>
                    </x-slot:trigger>
                    <x-slot:content>
                        <div class="p-1 space-y-0.5">
                            <livewire:components.language-switch />
                        </div>
                    </x-slot:content>
                </x-dropdown>
            </div>

            <div class="citadel-util-sep h-3.5 w-px bg-neutral/50 mx-1"></div>

            {{-- Currency --}}
            <div class="items-center flex">
                <x-dropdown>
                    <x-slot:trigger>
                        <div class="citadel-util-fg flex items-center gap-1.5 px-2 py-1 rounded-lg hover:text-primary transition-colors cursor-pointer">
                            <span class="normal-text text-xs !font-normal !leading-none">{{ session('currency', config('settings.default_currency')) }}</span>
                        </div>
                    </x-slot:trigger>
                    <x-slot:content>
                        <div class="p-1 space-y-0.5">
                            <livewire:components.currency-switch />
                        </div>
                    </x-slot:content>
                </x-dropdown>
            </div>

            
            @if(!theme('disable_color_switching'))
            <div class="citadel-util-sep h-3.5 w-px bg-neutral/50 mx-1"></div>
            <x-theme-toggle />
            @endif
        </div>
    </div>
</div>
@endif
