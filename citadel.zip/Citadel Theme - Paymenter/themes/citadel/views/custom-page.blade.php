<x-app-layout>
    <x-slot name="title">
        {{ $page['title'] ?? 'Page' }}
    </x-slot>

    @isset($page['description'])
        @push('head')
            <meta name="description" content="{{ \Illuminate\Support\Str::limit(strip_tags($page['description']), 160) }}">
        @endpush
    @endisset

    <div class="container py-10">
        <div class="max-w-3xl mx-auto">
            
            <header class="mb-8">
                <h1 class="page-title">{{ $page['title'] ?? '' }}</h1>
                @if (! empty($page['description']))
                    <p class="normal-text text-base/60 mt-2">{{ $page['description'] }}</p>
                @endif
            </header>

            
            <article class="prose prose-sm md:prose-base max-w-none dark:prose-invert">
                {!! \Illuminate\Support\Str::markdown((string) ($page['content'] ?? ''), [
                    'html_input' => 'escape',
                    'allow_unsafe_links' => false,
                    'renderer' => ['soft_break' => '<br>'],
                ]) !!}
            </article>
        </div>
    </div>
</x-app-layout>
