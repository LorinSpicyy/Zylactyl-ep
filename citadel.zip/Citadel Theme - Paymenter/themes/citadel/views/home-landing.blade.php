
@php $citadelLandingFloat = theme('header_style', 'header1') === 'header2'; @endphp
<div class="relative -mt-12 md:-mt-28 mb-0"
     @if($citadelLandingFloat) style="margin-top: calc(-1 * var(--citadel-hero-pad, 0px));" @endif>

    <div class="absolute inset-0 left-[50%] right-[50%] -ml-[50vw] -mr-[50vw] w-screen min-h-[600px] md:min-h-[700px] flex justify-center overflow-hidden">
        <div class="w-full h-full max-w-[1920px]">
            @include('components.hero-svg')
        </div>
    </div>
    
    
    <section id="hero-landing" class="relative pt-40 pb-20 md:py-32 flex items-center min-h-[600px] md:min-h-[700px] z-10">
        <div class="w-full">
            <div class="flex justify-start">
                
                <div class="w-full lg:w-1/2 text-left">
                    
                    <div class="flex items-center gap-2 mb-6 text-sm sm:text-base" style="color: hsl(var(--color-base) / 0.9);">
                        <span>Rated <span class="font-bold">{{ theme('landing_trustpilot_rating') ?: 'Excellent' }}</span> on</span>
                        <img src="/assets/icons/trustpilot-light.png" alt="Trustpilot" class="h-5 sm:h-6 dark:hidden" />
                        <img src="/assets/icons/trustpilot-dark.png" alt="Trustpilot" class="h-5 sm:h-6 hidden dark:block" />
                    </div>
                    
                    <h1 class="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">
                        {{ theme('landing_hero_title') ?: 'Where Hosting Meets Performance' }}
                    </h1>
                    
                    <p class="text-base mb-8" style="color: hsl(var(--color-base) / 0.8);">
                        {{ theme('landing_hero_description') ?: 'Where speed meets stability and innovation meets reliability. Citadel gives you the tools, uptime, and performance to power your ideas without limits.' }}
                    </p>
                    
                    <div class="flex flex-col sm:flex-row gap-4">
                        @php
                            $button1Link = theme('landing_hero_button1_link') ?: route('home');
                            $button1IsExternal = filter_var($button1Link, FILTER_VALIDATE_URL) && !str_starts_with($button1Link, url('/'));
                        @endphp
                        <a href="{{ $button1Link }}" 
                           class="citadel-btn inline-flex items-center justify-center px-8 bg-primary text-white text-sm rounded-lg hover:opacity-90 transition-all font-medium"
                           style="border-radius: var(--citadel-button-radius);"
                           @if(!$button1IsExternal) wire:navigate @else target="_blank" rel="noopener noreferrer" @endif>
                            {{ theme('landing_hero_button1_text') ?: 'Get Started' }}
                        </a>
                        
                        @php
                            $button2Link = theme('landing_hero_button2_link') ?: route('home');
                            $button2IsExternal = filter_var($button2Link, FILTER_VALIDATE_URL) && !str_starts_with($button2Link, url('/'));
                        @endphp
                        <a href="{{ $button2Link }}" 
                           class="inline-flex items-center justify-center px-8 py-3 bg-background-secondary border border-neutral rounded-lg hover:border-primary/30 transition-all font-medium"
                           style="border-radius: var(--citadel-button-radius);"
                           @if(!$button2IsExternal) wire:navigate @else target="_blank" rel="noopener noreferrer" @endif>
                            {{ theme('landing_hero_button2_text') ?: 'View All Plans' }}
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
{!! hook('pages.home1') !!}
<div>

    
    @php
        
        $featuredCategories = \App\Models\Category::whereNull('parent_id')
            ->where(function ($query) {
                $query->whereHas('children')
                    ->orWhereHas('products', function ($query) {
                        $query->where('hidden', false);
                    });
            })
            ->with(['products' => function ($query) {
                $query->where('hidden', false)
                      ->with(['plans.prices'])
                      ->orderBy('sort')
                      ->limit(1);
            }])
            ->orderBy('sort')
            ->limit(3)
            ->get();
            
        
        if($featuredCategories->count() === 3) {
            $reordered = collect([
                $featuredCategories->get(1), 
                $featuredCategories->get(0), 
                $featuredCategories->get(2), 
            ]);
            $featuredCategories = $reordered;
        }
    @endphp

    @if($featuredCategories->count() > 0)
    <section class="py-16 md:py-20">
        <div class="mx-auto container px-4">
            
            <div class="text-center mb-12">
                <h2 class="page-title mb-4">{{ theme('landing_services_title') ?: 'Check Our Services' }}</h2>
                <p class="text-base max-w-2xl mx-auto" style="color: hsl(var(--color-base) / 0.7);">
                    {{ theme('landing_services_description') ?: 'Discover the perfect plan tailored to your needs' }}
                </p>
            </div>
            
            
            <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
                @foreach ($featuredCategories as $index => $category)
                    @php
                        
                        $isMiddleCard = $index === 1;
                        $cardClasses = $isMiddleCard 
                            ? 'bg-background-secondary border border-neutral'
                            : 'bg-background-secondary border border-neutral';
                    @endphp
                    
                    
                    <div class="flex flex-col {{ $cardClasses }} p-6 rounded-lg text-center relative overflow-hidden" style="border-radius: var(--citadel-card-radius);">
                        
                        @if($isMiddleCard)
                            <div class="absolute top-6 -right-12 bg-primary text-white text-xs font-bold py-1.5 w-40 transform rotate-45 text-center">
                                Most Popular
                            </div>
                        @endif
                        
                        
                        <h3 class="text-xl font-bold mb-3">{{ $category->name }}</h3>
                        
                        
                        @if($category->description)
                            @php
                                
                                $description = strip_tags($category->description, '<ul><ol><li><p><strong><em><br>');
                                
                                preg_match('/^(.*?)(<ul>|<ol>|\n\n)/s', $description, $matches);
                                $introText = $matches[1] ?? '';
                                $remainingText = substr($description, strlen($introText));
                                
                                
                                $introText = trim(strip_tags($introText));
                            @endphp
                            
                            @if($introText)
                                <p class="text-sm text-muted mb-4 leading-relaxed">
                                    {{ $introText }}
                                </p>
                            @endif
                        @endif
                        
                        
                        @php
                            $firstProduct = $category->products->first();
                        @endphp
                        @if($firstProduct && $firstProduct->price()->available)
                            <div class="text-base my-6">
                                <div class="text-sm font-medium text-muted mb-2">Starting at</div>
                                @php
                                    $landLtp = theme('show_lowest_term_price', false) ? citadel_lowest_term_price($firstProduct) : null;
                                    $landSale = $landLtp ? null : citadel_product_sale($firstProduct);
                                @endphp
                                <div class="flex items-baseline justify-center gap-2 flex-wrap mb-1">
                                    <div class="text-3xl sm:text-4xl font-bold">{{ $landLtp ? $landLtp['formatted'] : $firstProduct->price()->formatted->price }}</div>
                                </div>
                                @if($landSale)
                                    <div class="flex items-center justify-center gap-2 flex-wrap mb-1">
                                        <span class="text-base sm:text-lg font-medium text-muted line-through">{{ $landSale['original'] }}</span>
                                        <span class="inline-flex items-center gap-1 rounded-md bg-primary text-white text-sm font-semibold px-2 py-1 whitespace-nowrap"><svg class="w-3 h-3 flex-shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8 8H8.01M2 5.2L2 9.67451C2 10.1637 2 10.4083 2.05526 10.6385C2.10425 10.8425 2.18506 11.0376 2.29472 11.2166C2.4184 11.4184 2.59135 11.5914 2.93726 11.9373L10.6059 19.6059C11.7939 20.7939 12.388 21.388 13.0729 21.6105C13.6755 21.8063 14.3245 21.8063 14.927 21.6105C15.612 21.388 16.2061 20.7939 17.3941 19.6059L19.6059 17.3941C20.7939 16.2061 21.388 15.612 21.6105 14.927C21.8063 14.3245 21.8063 13.6755 21.6105 13.0729C21.388 12.388 20.7939 11.7939 19.6059 10.6059L11.9373 2.93726C11.5914 2.59135 11.4184 2.4184 11.2166 2.29472C11.0376 2.18506 10.8425 2.10425 10.6385 2.05526C10.4083 2 10.1637 2 9.67452 2L5.2 2C4.0799 2 3.51984 2 3.09202 2.21799C2.7157 2.40973 2.40973 2.71569 2.21799 3.09202C2 3.51984 2 4.07989 2 5.2ZM8.5 8C8.5 8.27614 8.27614 8.5 8 8.5C7.72386 8.5 7.5 8.27614 7.5 8C7.5 7.72386 7.72386 7.5 8 7.5C8.27614 7.5 8.5 7.72386 8.5 8Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>{{ $landSale['badge'] }}</span>
                                    </div>
                                @endif
                                @php
                                    $cheapestPlan = $landLtp ? $landLtp['plan'] : $firstProduct->availablePlans()->first();
                                @endphp
                                @if($cheapestPlan && $cheapestPlan->type == 'recurring')
                                    <div class="text-sm font-medium text-muted">
                                        @if($cheapestPlan->billing_period == 1)
                                            {{ trans_choice(__('services.billing_cycles.' . $cheapestPlan->billing_unit), 1) }}
                                        @elseif($cheapestPlan->billing_period == 3 && $cheapestPlan->billing_unit == 'month')
                                            quarter
                                        @elseif($cheapestPlan->billing_period == 6 && $cheapestPlan->billing_unit == 'month')
                                            6 months
                                        @elseif($cheapestPlan->billing_period == 12 && $cheapestPlan->billing_unit == 'month')
                                            year
                                        @else
                                            {{ $cheapestPlan->billing_period }} {{ trans_choice(__('services.billing_cycles.' . $cheapestPlan->billing_unit), $cheapestPlan->billing_period) }}
                                        @endif
                                    </div>
                                @endif
                            </div>
                        @endif
                        
                        
                        @if($category->description && isset($remainingText) && trim(strip_tags($remainingText)))
                            <div class="mb-12 flex-grow">
                                <article class="prose dark:prose-invert prose-sm max-w-none text-center
                                    [&_ul]:list-none [&_ol]:list-none [&_li]:mb-0.5 [&_li]:text-xs [&_li]:leading-snug
                                    [&_ul]:pl-0 [&_ol]:pl-0 [&_li]:pl-0 [&_p]:mb-1 [&_p]:text-xs [&_li_p]:mb-0 [&_ul]:space-y-0
                                    [&_strong]:font-semibold [&_strong]:text-xs">
                                    {!! $remainingText !!}
                                </article>
                            </div>
                        @endif
                        
                        
                        <div class="mt-auto flex justify-center">
                            <a href="{{ route('category.show', ['category' => $category->slug]) }}"
                                wire:navigate>
                                @if($isMiddleCard)
                                    <x-button.primary class="px-6" style="width: auto !important;">
                                        Checkout Plans
                                    </x-button.primary>
                                @else
                                    <x-button.secondary class="px-6" style="width: auto !important;">
                                        Checkout Plans
                                    </x-button.secondary>
                                @endif
                            </a>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>
    @endif

  
    <section class="py-16 md:py-20">
        <div class="max-w-5xl px-4 sm:px-6 lg:px-8 mx-auto">
           
            <div class="text-center mb-12">
                <h2 class="text-3xl sm:text-4xl font-bold mb-4">{{ theme('landing_features_title') ?: 'Our Features' }}</h2>
                <p class="text-base" style="color: hsl(var(--color-base) / 0.7);">
                    {{ theme('landing_features_description') ?: 'Powerful hosting features designed for your success' }}
                </p>
            </div>

            
            <div class="grid md:grid-cols-2 gap-6 lg:gap-12">
                
                <div class="space-y-6 lg:space-y-10">
                    
                    <div class="flex gap-x-5 sm:gap-x-8">
                        <x-dynamic-component :component="'ri-' . (theme('landing_feature1_icon') ?: 'server-fill')" class="shrink-0 mt-2 size-8 text-primary" />
                        <div class="grow">
                            <h3 class="text-base sm:text-lg font-semibold mb-2">
                                {{ theme('landing_feature1_title') ?: '99.9% Uptime Guarantee' }}
                            </h3>
                            <p class="text-sm sm:text-base" style="color: hsl(var(--color-base) / 0.7);">
                                {{ theme('landing_feature1_description') ?: 'Your servers stay online with our reliable infrastructure and redundant systems ensuring maximum availability.' }}
                            </p>
                        </div>
                    </div>

                    
                    <div class="flex gap-x-5 sm:gap-x-8">
                        <x-dynamic-component :component="'ri-' . (theme('landing_feature2_icon') ?: 'rocket-fill')" class="shrink-0 mt-2 size-8 text-primary" />
                        <div class="grow">
                            <h3 class="text-base sm:text-lg font-semibold mb-2">
                                {{ theme('landing_feature2_title') ?: 'Instant Deployment' }}
                            </h3>
                            <p class="text-sm sm:text-base" style="color: hsl(var(--color-base) / 0.7);">
                                {{ theme('landing_feature2_description') ?: 'Get your server up and running in seconds with our automated setup process and one-click installations.' }}
                            </p>
                        </div>
                    </div>

                    
                    <div class="flex gap-x-5 sm:gap-x-8">
                        <x-dynamic-component :component="'ri-' . (theme('landing_feature3_icon') ?: 'flashlight-fill')" class="shrink-0 mt-2 size-8 text-primary" />
                        <div class="grow">
                            <h3 class="text-base sm:text-lg font-semibold mb-2">
                                {{ theme('landing_feature3_title') ?: 'Lightning Fast Performance' }}
                            </h3>
                            <p class="text-sm sm:text-base" style="color: hsl(var(--color-base) / 0.7);">
                                {{ theme('landing_feature3_description') ?: 'Experience blazing-fast speeds with NVMe SSD storage and optimized server configurations.' }}
                            </p>
                        </div>
                    </div>
                </div>

                
                <div class="space-y-6 lg:space-y-10">
                    
                    <div class="flex gap-x-5 sm:gap-x-8">
                        <x-dynamic-component :component="'ri-' . (theme('landing_feature4_icon') ?: 'cpu-fill')" class="shrink-0 mt-2 size-8 text-primary" />
                        <div class="grow">
                            <h3 class="text-base sm:text-lg font-semibold mb-2">
                                {{ theme('landing_feature4_title') ?: 'Premium Hardware' }}
                            </h3>
                            <p class="text-sm sm:text-base" style="color: hsl(var(--color-base) / 0.7);">
                                {{ theme('landing_feature4_description') ?: 'Powered by enterprise-grade hardware with latest generation processors and unlimited bandwidth.' }}
                            </p>
                        </div>
                    </div>

                    
                    <div class="flex gap-x-5 sm:gap-x-8">
                        <x-dynamic-component :component="'ri-' . (theme('landing_feature5_icon') ?: 'customer-service-2-fill')" class="shrink-0 mt-2 size-8 text-primary" />
                        <div class="grow">
                            <h3 class="text-base sm:text-lg font-semibold mb-2">
                                {{ theme('landing_feature5_title') ?: '24/7 Expert Support' }}
                            </h3>
                            <p class="text-sm sm:text-base" style="color: hsl(var(--color-base) / 0.7);">
                                {{ theme('landing_feature5_description') ?: 'Our dedicated support team is available round the clock to assist you with any questions or issues.' }}
                            </p>
                        </div>
                    </div>

                    
                    <div class="flex gap-x-5 sm:gap-x-8">
                        <x-dynamic-component :component="'ri-' . (theme('landing_feature6_icon') ?: 'dashboard-fill')" class="shrink-0 mt-2 size-8 text-primary" />
                        <div class="grow">
                            <h3 class="text-base sm:text-lg font-semibold mb-2">
                                {{ theme('landing_feature6_title') ?: 'Easy to Use Control Panel' }}
                            </h3>
                            <p class="text-sm sm:text-base" style="color: hsl(var(--color-base) / 0.7);">
                                {{ theme('landing_feature6_description') ?: 'Manage your servers effortlessly with our intuitive control panel designed for simplicity and power.' }}
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
{!! hook('pages.home2') !!}
{!! hook('pages.home3') !!}
    
    @if(theme('landing_show_cta', true))
    <section class="py-16">
        <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div class="lg:py-14 lg:px-20 p-8 lg:p-10 rounded-2xl flex items-center justify-between flex-col lg:flex-row" style="background: linear-gradient(135deg, hsl(var(--color-primary)) 0%, hsl(var(--color-primary) / 0.8) 100%); border-radius: var(--citadel-card-radius);">
                <div class="block text-center mb-8 lg:text-left lg:mb-0">
                    <h2 class="text-2xl sm:text-3xl lg:text-4xl text-white font-semibold mb-4 lg:mb-2">
                        {{ theme('landing_cta_title') ?: 'Ready to get started?' }}
                    </h2>
                    <p class="text-base sm:text-lg lg:text-xl text-white/80 max-w-2xl">
                        {{ theme('landing_cta_description') ?: 'Contact us to get help getting started or if you don\'t see what you are looking for.' }}
                    </p>
                </div>
                @php
                    $landingCtaLink = theme('landing_cta_btn_link') ?: (theme('footer_contact_link') ?: route('register'));
                    $landingCtaExternal = filter_var($landingCtaLink, FILTER_VALIDATE_URL) && ! str_starts_with($landingCtaLink, url('/'));
                @endphp
                <a href="{{ $landingCtaLink }}"
                   class="citadel-btn flex items-center gap-2 justify-center bg-background text-sm font-medium hover:bg-background-secondary focus:outline-none px-6 rounded-lg transition-all duration-200 w-full sm:w-auto shrink-0"
                   style="border-radius: var(--citadel-button-radius);"
                   @if($landingCtaExternal) target="_blank" rel="noopener noreferrer" @else wire:navigate @endif>
                    {{ theme('landing_cta_btn_text') ?: 'Get In Touch' }}
                    <svg class="w-4 h-4 transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 19 14">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.4" d="M1.75 7L16.4167 7M11.8333 12.5L16.6852 7.64818C16.9907 7.34263 17.1435 7.18985 17.1435 7C17.1435 6.81015 16.9907 6.65737 16.6852 6.35182L11.8333 1.5" />
                    </svg>
                </a>
            </div>
        </div>
    </section>
    @endif

    {!! hook('home.hero') !!}
</div>
