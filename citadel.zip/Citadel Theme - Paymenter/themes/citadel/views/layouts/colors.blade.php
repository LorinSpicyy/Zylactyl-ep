<style>
    :root {
        --citadel-font-family: "{{ theme('font_family', 'Poppins') }}";
        --citadel-card-radius: {{ (int) theme('card_border_radius', 8) }}px;
        --citadel-button-radius: {{ (int) theme('button_border_radius', 8) }}px;
        --citadel-button-py: {{ (int) theme('button_padding_y', 10) }}px;
        --citadel-content-width: {{ preg_match('/^\d+(\.\d+)?(px|rem|em|vw|%)$/', theme('content_width', '1440px')) ? theme('content_width', '1440px') : '1440px' }};
        
        --color-primary: {{ str_replace(',', '', preg_replace('/^hsl\((.+)\)$/', '$1', theme('primary', '229 100% 64%'))) }};
        --color-secondary: {{ str_replace(',', '', preg_replace('/^hsl\((.+)\)$/', '$1', theme('secondary', '237 33% 60%'))) }};

        @php
            $primary = str_replace(',', '', preg_replace('/^hsl\((.+)\)$/', '$1', theme('primary', '229 100% 64%')));
            [$h, $s, $l] = array_map('trim', explode(' ', $primary));
        @endphp
        
        
        --color-primary-h: {{ rtrim($h, 'deg') }};
        --color-primary-s: {{ rtrim($s, '%') }}%;
        --color-primary-l: {{ rtrim($l, '%') }}%;

        
        --color-neutral: {{ str_replace(',', '', preg_replace('/^hsl\((.+)\)$/', '$1', theme('neutral', '220 25% 85%'))) }};

        
        --color-base: {{ str_replace(',', '', preg_replace('/^hsl\((.+)\)$/', '$1', theme('base', '0 0% 0%'))) }};
        --color-muted: {{ str_replace(',', '', preg_replace('/^hsl\((.+)\)$/', '$1', theme('muted', '220 28% 25%'))) }};
        --color-inverted: {{ str_replace(',', '', preg_replace('/^hsl\((.+)\)$/', '$1', theme('inverted', '100 100% 100%'))) }};

        
        --color-success: 142 71% 45%;
        --color-error: 0 75% 60%;
        --color-warning: 25 95% 53%;
        --color-inactive: 0 0% 63%;
        --color-info: 210 100% 60%;

        
        --color-background: {{ str_replace(',', '', preg_replace('/^hsl\((.+)\)$/', '$1', theme('background', '100 100% 100%'))) }};
        --color-background-secondary: {{ str_replace(',', '', preg_replace('/^hsl\((.+)\)$/', '$1', theme('background-secondary', '0 0% 97%'))) }};
        --_ct-mode: 1;
    }

    .dark {
        
        --color-primary: {{ str_replace(',', '', preg_replace('/^hsl\((.+)\)$/', '$1', theme('dark-primary', '229 100% 64%'))) }};
        --color-secondary: {{ str_replace(',', '', preg_replace('/^hsl\((.+)\)$/', '$1', theme('dark-secondary', '237 33% 60%'))) }};

        @php
            $darkPrimary = str_replace(',', '', preg_replace('/^hsl\((.+)\)$/', '$1', theme('dark-primary', '229 100% 64%')));
            [$dh, $ds, $dl] = array_map('trim', explode(' ', $darkPrimary));
        @endphp
        
        
        --color-primary-h: {{ rtrim($dh, 'deg') }};
        --color-primary-s: {{ rtrim($ds, '%') }}%;
        --color-primary-l: {{ rtrim($dl, '%') }}%;

        
        --color-neutral: {{ str_replace(',', '', preg_replace('/^hsl\((.+)\)$/', '$1', theme('dark-neutral', '220 25% 29%'))) }};

        
        --color-base: {{ str_replace(',', '', preg_replace('/^hsl\((.+)\)$/', '$1', theme('dark-base', '100 100% 100%'))) }};
        --color-muted: {{ str_replace(',', '', preg_replace('/^hsl\((.+)\)$/', '$1', theme('dark-muted', '220 28% 25%'))) }};
        --color-inverted: {{ str_replace(',', '', preg_replace('/^hsl\((.+)\)$/', '$1', theme('dark-inverted', '220 14% 60%'))) }};

        
        --color-background: {{ str_replace(',', '', preg_replace('/^hsl\((.+)\)$/', '$1', theme('dark-background', '221 39% 11%'))) }};
        --color-background-secondary: {{ str_replace(',', '', preg_replace('/^hsl\((.+)\)$/', '$1', theme('dark-background-secondary', '217 33% 16%'))) }};
    }

    .page-title, .secondary-title, .nav-text, .normal-text, .nav-sub-text,
    .button-text, .small-text, .section-title-medium, .small-text-muted,
    .check-out-title, .check-out-title-semi, .radio-title, .radio-title-semi,
    .check-out-text, .check-out-text-small, .check-out-text-small-bold {
        font-family: var(--citadel-font-family, 'Poppins'), sans-serif !important;
    }

    body, input, button, select, textarea {
        font-family: var(--citadel-font-family, 'Poppins'), sans-serif;
    }


    body :is(.rounded, .rounded-sm, .rounded-md, .rounded-lg, .rounded-xl, .rounded-2xl, .rounded-3xl) {
        border-radius: var(--citadel-card-radius);
    }


    body :is(.rounded-t, .rounded-t-sm, .rounded-t-md, .rounded-t-lg, .rounded-t-xl, .rounded-t-2xl, .rounded-t-3xl) {
        border-top-left-radius: var(--citadel-card-radius);
        border-top-right-radius: var(--citadel-card-radius);
    }
    body :is(.rounded-b, .rounded-b-sm, .rounded-b-md, .rounded-b-lg, .rounded-b-xl, .rounded-b-2xl, .rounded-b-3xl) {
        border-bottom-left-radius: var(--citadel-card-radius);
        border-bottom-right-radius: var(--citadel-card-radius);
    }
    body :is(.rounded-l, .rounded-l-sm, .rounded-l-md, .rounded-l-lg, .rounded-l-xl, .rounded-l-2xl, .rounded-l-3xl) {
        border-top-left-radius: var(--citadel-card-radius);
        border-bottom-left-radius: var(--citadel-card-radius);
    }
    body :is(.rounded-r, .rounded-r-sm, .rounded-r-md, .rounded-r-lg, .rounded-r-xl, .rounded-r-2xl, .rounded-r-3xl) {
        border-top-right-radius: var(--citadel-card-radius);
        border-bottom-right-radius: var(--citadel-card-radius);
    }

    body button:is(.rounded, .rounded-sm, .rounded-md, .rounded-lg, .rounded-xl, .rounded-2xl, .rounded-3xl),
    body a:is(.rounded, .rounded-sm, .rounded-md, .rounded-lg, .rounded-xl, .rounded-2xl, .rounded-3xl),
    body input[type="submit"]:is(.rounded, .rounded-sm, .rounded-md, .rounded-lg, .rounded-xl, .rounded-2xl, .rounded-3xl),
    body input[type="button"]:is(.rounded, .rounded-sm, .rounded-md, .rounded-lg, .rounded-xl, .rounded-2xl, .rounded-3xl) {
        border-radius: var(--citadel-button-radius);
    }

    
    body .citadel-btn {
        padding-top: var(--citadel-button-py);
        padding-bottom: var(--citadel-button-py);
    }


    html {
        scrollbar-width: thin;
        scrollbar-color: hsl(var(--color-background-secondary)) hsl(var(--color-background));
    }

    html::-webkit-scrollbar {
        width: 5px;
        height: 5px;
    }

    html::-webkit-scrollbar-track {
        background: hsl(var(--color-background));
        border-radius: 10px;
    }

    html::-webkit-scrollbar-thumb {
        background: hsl(var(--color-background-secondary));
        border-radius: 10px;
    }

    html::-webkit-scrollbar-thumb:hover {
        background: hsl(var(--color-neutral));
    }

    html::-webkit-scrollbar-button {
        display: none;
    }

    html.dark::-webkit-scrollbar-track {
        background: hsl(var(--color-background));
    }

    html.dark::-webkit-scrollbar-thumb {
        background: hsl(var(--color-background-secondary));
    }

    html.dark::-webkit-scrollbar-thumb:hover {
        background: hsl(var(--color-neutral));
    }


    aside[aria-label="sidebar-panel"] .overflow-y-auto::-webkit-scrollbar-thumb {
        background: hsl(var(--color-base) / 0.18);
        border-radius: 10px;
    }
    aside[aria-label="sidebar-panel"] .overflow-y-auto::-webkit-scrollbar-thumb:hover {
        background: hsl(var(--color-base) / 0.38);
    }
    aside[aria-label="sidebar-panel"] .overflow-y-auto {
        scrollbar-color: hsl(var(--color-base) / 0.18) transparent;
    }
</style>