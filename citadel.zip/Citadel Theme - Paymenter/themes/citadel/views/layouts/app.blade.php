@php
    $colorSwitchingDisabled = theme('disable_color_switching');
    $defaultThemeIsDark = theme('default_color_theme', 'light') === 'dark';
@endphp
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" @if(in_array(app()->getLocale(), config('app.rtl_locales'))) dir="rtl" @endif
    x-data="{darkMode: @if($colorSwitchingDisabled){{ $defaultThemeIsDark ? 'true' : 'false' }}@else $persist({{ $defaultThemeIsDark ? 'true' : "window.matchMedia('(prefers-color-scheme: dark)').matches" }})@endif}"
    :class="{'dark': darkMode}">
    
<head>
    <script>
        (function () {
            try {
                var stored = localStorage.getItem('_x_darkMode');
                if (stored !== null && JSON.parse(stored) === true) {
                    document.documentElement.classList.add('dark');
                }
            } catch (e) {}
        })();
        document.addEventListener('livewire:navigated', function () {
            try {
                var stored = localStorage.getItem('_x_darkMode');
                if (stored !== null) {
                    if (JSON.parse(stored) === true) {
                        document.documentElement.classList.add('dark');
                    } else {
                        document.documentElement.classList.remove('dark');
                    }
                }
            } catch (e) {}
        });
    </script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    
    <title>
        @if(isset($title))
            {{ $title }} - {{ theme('seo_title') ?: config('app.name', 'Paymenter') }}
        @else
            {{ theme('seo_title') ?: config('app.name', 'Paymenter') }}
        @endif
    </title>
    
    @php
        $metaDescription = $description ?? theme('seo_description') ?? theme('site_description') ?? config('app.name') . ' - Professional hosting services';
    @endphp
    <meta name="description" content="{{ $metaDescription }}">
    
    @if(theme('seo_keywords'))
    <meta name="keywords" content="{{ theme('seo_keywords') }}">
    @endif
    
    @if(theme('seo_author'))
    <meta name="author" content="{{ theme('seo_author') }}">
    @endif
    
    <meta name="robots" content="{{ theme('seo_robots', 'index, follow') }}">
    
    <link rel="canonical" href="{{ (theme('seo_canonical_url') ?: config('app.url')) . request()->getPathInfo() }}">
    
    <meta property="og:type" content="website">
    <meta property="og:url" content="{{ url()->current() }}">
    <meta property="og:site_name" content="{{ config('app.name', 'Paymenter') }}">
    <meta property="og:title" content="{{ isset($title) ? $title . ' - ' . config('app.name') : (theme('seo_title') ?: config('app.name')) }}">
    <meta property="og:description" content="{{ $metaDescription }}">
    @if(isset($image) && $image)
    <meta property="og:image" content="{{ $image }}">
    @elseif(theme('seo_og_image'))
    <meta property="og:image" content="{{ theme('seo_og_image') }}">
    @endif
    @if(theme('seo_og_image') || isset($image))
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:image:alt" content="{{ isset($title) ? $title : config('app.name') }}">
    @endif
    
    <meta name="twitter:card" content="{{ theme('seo_twitter_card', 'summary_large_image') }}">
    @if(theme('seo_twitter_site'))
    <meta name="twitter:site" content="{{ theme('seo_twitter_site') }}">
    <meta name="twitter:creator" content="{{ theme('seo_twitter_site') }}">
    @endif
    <meta name="twitter:title" content="{{ isset($title) ? $title . ' - ' . config('app.name') : (theme('seo_title') ?: config('app.name')) }}">
    <meta name="twitter:description" content="{{ $metaDescription }}">
    @if(isset($image) && $image)
    <meta name="twitter:image" content="{{ $image }}">
    @elseif(theme('seo_og_image'))
    <meta name="twitter:image" content="{{ theme('seo_og_image') }}">
    @endif
    
    <meta name="language" content="{{ str_replace('_', '-', app()->getLocale()) }}">
    <meta name="revisit-after" content="7 days">
    <meta name="rating" content="general">
    
    <meta name="theme-color" content="{{ theme('primary') }}">
    <meta name="msapplication-TileColor" content="{{ theme('primary') }}">
    <meta name="renderer" content="citadel-ssr">
    
    @if (config('settings.favicon'))
    <link rel="icon" href="{{ Storage::url(config('settings.favicon')) }}">
    <link rel="apple-touch-icon" href="{{ Storage::url(config('settings.favicon')) }}">
    @endif
    
    @php
        $citadelFont = theme('font_family', 'Poppins');
        $citadelFontUrls = [
            'Poppins'           => 'https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap',
            'Inter'             => 'https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap',
            'Nunito'            => 'https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap',
            'Roboto'            => 'https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap',
            'DM Sans'           => 'https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&display=swap',
            'Plus Jakarta Sans' => 'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;0,800;1,200;1,300;1,400;1,500;1,600;1,700;1,800&display=swap',
            'Outfit'            => 'https://fonts.googleapis.com/css2?family=Outfit:wght@100;200;300;400;500;600;700;800;900&display=swap',
            'Manrope'           => 'https://fonts.googleapis.com/css2?family=Manrope:wght@200;300;400;500;600;700;800&display=swap',
            'Figtree'           => 'https://fonts.googleapis.com/css2?family=Figtree:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap',
            'Sora'              => 'https://fonts.googleapis.com/css2?family=Sora:wght@100;200;300;400;500;600;700;800&display=swap',
            'Lexend'            => 'https://fonts.googleapis.com/css2?family=Lexend:wght@100;200;300;400;500;600;700;800;900&display=swap',
            'Red Hat Display'   => 'https://fonts.googleapis.com/css2?family=Red+Hat+Display:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap',
            'Urbanist'          => 'https://fonts.googleapis.com/css2?family=Urbanist:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap',
            'Space Grotesk'     => 'https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap',
            'Be Vietnam Pro'    => 'https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap',
            'Mulish'            => 'https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap',
            'Lato'              => 'https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap',
            'Raleway'           => 'https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap',
            'Source Sans 3'     => 'https://fonts.googleapis.com/css2?family=Source+Sans+3:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap',
            'Work Sans'         => 'https://fonts.googleapis.com/css2?family=Work+Sans:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap',
        ];


        if (! isset($citadelFontUrls[$citadelFont])) {
            $citadelFont = 'Poppins';
            config(['settings.theme_citadel_font_family' => 'Poppins']);
        }
    @endphp
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="{{ $citadelFontUrls[$citadelFont] }}" rel="stylesheet">
    
    @livewireStyles
    @vite(['themes/' . config('settings.theme') . '/js/app.js', 'themes/' . config('settings.theme') . '/css/app.css'], config('settings.theme'))
    @include('layouts.colors')
    <style>
        :root { --banner-height: 0px; --citadel-utility-height: 0px; --citadel-hero-pad: 0px; }
        :root { --citadel-anchor-offset: calc(var(--banner-height, 0px) + var(--citadel-utility-height, 0px) + 6rem); }
        .citadel-anchor-target { scroll-margin-top: var(--citadel-anchor-offset, 6rem); }
        @if(theme('header_utility_bar', false))
        
        @media (min-width: 768px) { :root { --citadel-utility-height: 2.5rem; } }
        @endif
        @if(theme('header_style', 'header1') === 'header2')
        
        :root { --citadel-hero-pad: 6rem; }
        @media (min-width: 768px) { :root { --citadel-hero-pad: 7rem; } }
        @endif

        .product-description p {
            margin-top: 0.35em !important;
            margin-bottom: 0.35em !important;
            line-height: 1.6 !important;
        }
        .product-description li > p,
        .product-description li p {
            margin-top: 0 !important;
            margin-bottom: 0 !important;
            display: inline !important;
        }
        .product-description ul,
        .product-description ol {
            margin-top: 0.35em !important;
            margin-bottom: 0.35em !important;
            padding-left: 1.4em !important;
        }
        .product-description li {
            margin-top: 0.1em !important;
            margin-bottom: 0.1em !important;
            padding-left: 0.2em !important;
        }
        .product-description h1,
        .product-description h2,
        .product-description h3,
        .product-description h4 {
            margin-top: 0.75em !important;
            margin-bottom: 0.25em !important;
        }
        .product-description > *:first-child { margin-top: 0 !important; }
        .product-description > *:last-child  { margin-bottom: 0 !important; }

        
        html, body { overflow-x: clip !important; }
    </style>

    @if(theme('custom_css'))
    <style>{!! theme('custom_css') !!}</style>
    @endif

    {!! hook('head') !!}

    @if(theme('custom_head_code'))
    {!! theme('custom_head_code') !!}
    @endif
</head>

<body class="w-full bg-background text-base min-h-screen flex flex-col antialiased overflow-x-clip" x-cloak>
    @if(theme('custom_body_code'))
    {!! theme('custom_body_code') !!}
    @endif
    {!! hook('body') !!}
    @php
        $sidebarLayout = theme('sidebar_layout', 'default');
        $showSidebar = false;
        
        
        if ($sidebarLayout === 'all_pages' && auth()->check()) {
            
            $showSidebar = true;
        } elseif ($sidebarLayout === 'default' && isset($sidebar) && $sidebar) {
            
            $showSidebar = true;
        } elseif ($sidebarLayout === 'disabled') {

            $showSidebar = false;
        }

        
        $citadelHeaderStyle = theme('header_style', 'header1');
        if ($citadelHeaderStyle === 'header2') {

            $citadelMainTop = $showSidebar ? 'mt-24 md:mt-8' : 'mt-24 md:mt-28';
        } else {
            $citadelMainTop = $showSidebar ? 'mt-12 md:mt-16' : 'mt-12 md:mt-28';
        }

        
        $citadelIsAuthPage = request()->routeIs('login')
            || request()->routeIs('register')
            || request()->routeIs('password.request')
            || request()->routeIs('password.reset')
            || request()->routeIs('verify-email')
            || request()->routeIs('2fa');
    @endphp
    
    
    @if($citadelHeaderStyle === 'header2' && $showSidebar)
    <style>@media (min-width: 768px) { :root { --citadel-hero-pad: 0px; } }</style>
    @endif

    @unless(request()->routeIs('login') || request()->routeIs('register') || request()->routeIs('password.request') || request()->routeIs('password.reset') || request()->routeIs('verify-email') || request()->routeIs('2fa'))
    <x-announcement-banner />
    <x-navigation.utility-bar :showSidebar="$showSidebar" />
    <x-navigation :showSidebar="$showSidebar" />
    @endunless
    <div class="w-full flex flex-grow">
        @php
            
        @endphp
        
        @if ($showSidebar)
            <x-navigation.sidebar title="$title" />
        @endif
        
        <div class="{{ $showSidebar ? 'md:ml-72 rtl:ml-0 rtl:md:mr-72' : '' }} flex flex-col flex-grow min-h-screen" style="padding-top: {{ $citadelIsAuthPage ? '0px' : 'calc(var(--banner-height, 0px) + var(--citadel-utility-height, 0px))' }};">
            <main class="{{ request()->routeIs('login') || request()->routeIs('register') || request()->routeIs('password.request') || request()->routeIs('password.reset') || request()->routeIs('verify-email') || request()->routeIs('2fa') ? '' : 'container ' . $citadelMainTop . ' mx-auto ' . ($showSidebar ? 'px-4 sm:px-4 md:px-6 lg:px-6' : 'px-4 sm:px-6 md:px-8 lg:px-10') }} flex-grow"
                 @unless(request()->routeIs('login') || request()->routeIs('register') || request()->routeIs('password.request') || request()->routeIs('password.reset') || request()->routeIs('verify-email') || request()->routeIs('2fa')) style="max-width: var(--citadel-content-width, 1440px);" @endunless>
                {{ $slot }}
            </main>
            <x-notification />
            @unless(request()->routeIs('login') || request()->routeIs('register') || request()->routeIs('password.request') || request()->routeIs('password.reset') || request()->routeIs('verify-email') || request()->routeIs('2fa'))
            <div class="pt-8 mt-auto">
                <x-navigation.footer />
            </div>
            @endunless
        </div>
        <x-impersonating />
    </div>
    @livewireScriptConfig 
    {!! hook('footer') !!}
</body>

</html>
