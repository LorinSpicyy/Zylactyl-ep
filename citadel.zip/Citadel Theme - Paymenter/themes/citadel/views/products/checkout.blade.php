<div data-checkout-step="configure" class="pt-8 flex flex-col md:grid md:grid-cols-4 gap-6 min-h-screen">
    <style>
        
        [data-checkout-step="configure"]:has(.ovh-picker) [data-checkout-config="datacenter"],
        [data-checkout-step="configure"]:has(.ovh-picker) [data-checkout-config="os"],
        [data-checkout-step="configure"]:has(.ovh-picker) [data-checkout-config="option_selections"],
        [data-checkout-step="configure"]:has(.ovh-picker) [data-checkout-config="hostname"] {
            display: none !important;
        }

        
        [data-checkout-step="configure"]:has([data-extension-checkout-handles]) [data-checkout-config][data-extension-handled] {
            display: none !important;
        }
    </style>

    <div class="flex flex-col gap-4 w-full col-span-3">
        <h1 class="page-title mb-4">{{ __('citadel::citadel.products.checkout.title') }}</h1>
        
        
        @if ($errors->any())
            <div class="bg-red-50 border border-red-200 text-sm text-red-800 rounded-lg p-4 mb-6 dark:bg-red-800/10 dark:border-red-900 dark:text-red-500" 
                 role="alert" tabindex="-1" aria-labelledby="checkout-errors-label"
                 x-data="{ 
                     init() {
                         // Scroll to top when errors are present
                         this.$nextTick(() => {
                             window.scrollTo({ 
                                 top: 0, 
                                 behavior: 'smooth' 
                             });
                         });
                     }
                 }">
                <div class="flex">
                    <div class="shrink-0">
                        <svg class="shrink-0 size-4 mt-0.5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="10"></circle>
                            <path d="m15 9-6 6"></path>
                            <path d="m9 9 6 6"></path>
                        </svg>
                    </div>
                    <div class="ms-4">
                        <h3 id="checkout-errors-label" class="text-sm font-semibold">
                            A problem has been occurred while submitting your data.
                        </h3>
                        <div class="mt-2 text-sm text-red-700 dark:text-red-400">
                            <ul class="list-disc space-y-1 ps-5">
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        @endif
        
        @if(theme('pricing_card_icon_style', 'icon_top') == 'background')
            
            <div class="bg-background-secondary border border-neutral rounded-lg relative overflow-hidden mb-6 isolate">
                
                @if($product->image)
                    <div class="hidden md:block absolute inset-0 rounded-lg overflow-hidden z-0">
                        <img src="{{ Storage::url($product->image) }}" alt="{{ $product->name }}" 
                             class="w-full h-full object-cover">
                    </div>
                @endif
                
                
                <div class="absolute inset-0 bg-gradient-to-b from-background-secondary/75 via-background-secondary/90 to-background-secondary z-[1]"></div>
                
                
                <div class="relative z-[2] p-6">
                    
                    <h2 class="check-out-title mb-4">{{ $product->name }}</h2>
                    
                    <article class="product-description prose dark:prose-invert max-w-none">
                        {!! $product->description !!}
                    </article>
                </div>
            </div>
        @elseif(theme('pricing_card_icon_style', 'icon_top') == 'icon_right')
            
            <div class="bg-background-secondary border border-neutral rounded-lg p-6 mb-6 relative">
                <div class="flex items-start justify-between gap-8 relative">
                    <div class="flex-1 z-10">
                        
                        <h2 class="check-out-title mb-4">{{ $product->name }}</h2>
                        
                        <article class="product-description prose dark:prose-invert max-w-none">
                            {!! $product->description !!}
                        </article>
                    </div>
                    
                    
                    @if ($product->image)
                        <div class="hidden md:block absolute right-6 top-6 z-0">
                            <img src="{{ Storage::url($product->image) }}" alt="{{ $product->name }}" 
                                 class="w-32 h-32 object-cover object-center rounded-lg opacity-90">
                        </div>
                    @endif
                </div>
            </div>
        @else
            
            <div class="bg-background-secondary border border-neutral rounded-lg p-6 mb-6">
                
                <h2 class="check-out-title mb-4">{{ $product->name }}</h2>
                
                <article class="product-description prose dark:prose-invert max-w-none">
                    {!! $product->description !!}
                </article>
            </div>
        @endif
        @if ($product->availablePlans()->count() > 1)
            @php
                $saleBadgeLayout = (string) (theme('sale_checkout_badge_layout', 'corner') ?: 'corner');
            @endphp
            <div class="mb-6">
                <h3 class="check-out-title-semi mb-4 !font-normal">{{ __('citadel::citadel.products.checkout.choose_billing_cycle') }}</h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    @foreach ($product->availablePlans() as $availablePlan)
                        @php
                            $planSale = citadel_plan_sale($product, $availablePlan);
                        @endphp
                        <div wire:click="$set('plan_id', {{ $availablePlan->id }})" 
                             class="cursor-pointer p-4 border rounded-lg transition-all duration-200 relative overflow-hidden
                                    {{ $plan_id == $availablePlan->id ? 'border-primary/40 bg-primary/5' : 'border-neutral bg-background-secondary hover:border-neutral' }}">
                            
                            @if($planSale)
                                @if($saleBadgeLayout === 'circle')
                                    <div class="absolute top-2 right-2 z-[1] inline-flex items-center gap-1 rounded-full bg-primary text-white text-xs font-bold px-2.5 py-1 whitespace-nowrap shadow-sm">
                                        <svg class="w-3 h-3 flex-shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8 8H8.01M2 5.2L2 9.67451C2 10.1637 2 10.4083 2.05526 10.6385C2.10425 10.8425 2.18506 11.0376 2.29472 11.2166C2.4184 11.4184 2.59135 11.5914 2.93726 11.9373L10.6059 19.6059C11.7939 20.7939 12.388 21.388 13.0729 21.6105C13.6755 21.8063 14.3245 21.8063 14.927 21.6105C15.612 21.388 16.2061 20.7939 17.3941 19.6059L19.6059 17.3941C20.7939 16.2061 21.388 15.612 21.6105 14.927C21.8063 14.3245 21.8063 13.6755 21.6105 13.0729C21.388 12.388 20.7939 11.7939 19.6059 10.6059L11.9373 2.93726C11.5914 2.59135 11.4184 2.4184 11.2166 2.29472C11.0376 2.18506 10.8425 2.10425 10.6385 2.05526C10.4083 2 10.1637 2 9.67452 2L5.2 2C4.0799 2 3.51984 2 3.09202 2.21799C2.7157 2.40973 2.40973 2.71569 2.21799 3.09202C2 3.51984 2 4.07989 2 5.2ZM8.5 8C8.5 8.27614 8.27614 8.5 8 8.5C7.72386 8.5 7.5 8.27614 7.5 8C7.5 7.72386 7.72386 7.5 8 7.5C8.27614 7.5 8.5 7.72386 8.5 8Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                        {{ $planSale['badge'] }}
                                    </div>
                                @else
                                    <div class="absolute top-0 right-0 bg-gradient-to-br from-primary to-primary/80 text-white px-3 py-1 text-xs font-semibold rounded-bl-lg flex items-center gap-1">
                                        <svg class="w-3 h-3 flex-shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8 8H8.01M2 5.2L2 9.67451C2 10.1637 2 10.4083 2.05526 10.6385C2.10425 10.8425 2.18506 11.0376 2.29472 11.2166C2.4184 11.4184 2.59135 11.5914 2.93726 11.9373L10.6059 19.6059C11.7939 20.7939 12.388 21.388 13.0729 21.6105C13.6755 21.8063 14.3245 21.8063 14.927 21.6105C15.612 21.388 16.2061 20.7939 17.3941 19.6059L19.6059 17.3941C20.7939 16.2061 21.388 15.612 21.6105 14.927C21.8063 14.3245 21.8063 13.6755 21.6105 13.0729C21.388 12.388 20.7939 11.7939 19.6059 10.6059L11.9373 2.93726C11.5914 2.59135 11.4184 2.4184 11.2166 2.29472C11.0376 2.18506 10.8425 2.10425 10.6385 2.05526C10.4083 2 10.1637 2 9.67452 2L5.2 2C4.0799 2 3.51984 2 3.09202 2.21799C2.7157 2.40973 2.40973 2.71569 2.21799 3.09202C2 3.51984 2 4.07989 2 5.2ZM8.5 8C8.5 8.27614 8.27614 8.5 8 8.5C7.72386 8.5 7.5 8.27614 7.5 8C7.5 7.72386 7.72386 7.5 8 7.5C8.27614 7.5 8.5 7.72386 8.5 8Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                        {{ $planSale['badge'] }}
                                    </div>
                                @endif
                            @endif
                            
                            <h4 class="radio-title mb-1 !font-bold {{ $planSale ? 'pr-16' : '' }}">{{ $availablePlan->name }}</h4>
                            
                            
                            <div class="radio-title text-primary !font-medium flex items-baseline gap-1.5 flex-wrap">
                                @if($planSale)
                                    <span class="text-muted line-through text-sm font-normal">{{ $planSale['original'] }}</span>
                                @endif
                                <span>{{ $availablePlan->price()?->formatted->price ?? '—' }}
                                @if($availablePlan->type == 'recurring')
                                    @if($availablePlan->billing_period == 1)
                                        / {{ trans_choice(__('services.billing_cycles.' . $availablePlan->billing_unit), 1) }}
                                    @elseif($availablePlan->billing_period == 3 && $availablePlan->billing_unit == 'month')
                                        / {{ __('citadel::citadel.products.checkout.per_quarter') }}
                                    @elseif($availablePlan->billing_period == 6 && $availablePlan->billing_unit == 'month')
                                        / {{ __('citadel::citadel.products.checkout.per_6_months') }}
                                    @elseif($availablePlan->billing_period == 12 && $availablePlan->billing_unit == 'month')
                                        / {{ __('citadel::citadel.products.checkout.per_year') }}
                                    @else
                                        / {{ $availablePlan->billing_period }} {{ trans_choice(__('services.billing_cycles.' . $availablePlan->billing_unit), $availablePlan->billing_period) }}
                                    @endif
                                @elseif($availablePlan->type == 'one-time')
                                    ({{ __('citadel::citadel.products.checkout.one_time') }})
                                @endif</span>
                                @if($availablePlan->price()?->has_setup_fee)
                                    <span class="text-xs text-muted font-normal">+ {{ $availablePlan->price()->formatted->setup_fee }} {{ __('citadel::citadel.products.checkout.setup_fee') }}</span>
                                @endif
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        @endif

        @php
            
            $citadelTieredMap = [];
            $tieredJson = theme('tiered_config_options_data', '[]');
            $tieredRaw  = is_string($tieredJson) ? json_decode($tieredJson, true) : (is_array($tieredJson) ? $tieredJson : []);
            if (is_array($tieredRaw)) {
                foreach ($tieredRaw as $entry) {
                    $coId = isset($entry['config_option_id']) ? (int) $entry['config_option_id'] : 0;
                    if (! $coId) continue;
                    $tiers = [];
                    $assignedIds = [];
                    if (! empty($entry['tiers']) && is_array($entry['tiers'])) {
                        foreach ($entry['tiers'] as $tier) {
                            $optionIds = array_values(array_filter(array_map('intval', $tier['option_ids'] ?? [])));
                            if (empty($optionIds)) continue;
                            $tiers[] = [
                                'title'       => trim((string) ($tier['title'] ?? '')),
                                'description' => trim((string) ($tier['description'] ?? '')),
                                'tooltip'     => trim((string) ($tier['tooltip'] ?? '')),
                                'option_ids'  => $optionIds,
                            ];
                            $assignedIds = array_merge($assignedIds, $optionIds);
                        }
                    }
                    if (! empty($tiers)) {
                        $citadelTieredMap[$coId] = [
                            'tiers'        => $tiers,
                            'assigned_ids' => array_values(array_unique($assignedIds)),
                        ];
                    }
                }
            }

            
            $citadelOutOfStockMap = [];
            $oosJson = theme('out_of_stock_config_options_data', '[]');
            $oosRaw  = is_string($oosJson) ? json_decode($oosJson, true) : (is_array($oosJson) ? $oosJson : []);
            if (is_array($oosRaw)) {
                foreach ($oosRaw as $oosEntry) {
                    $oosCoId = isset($oosEntry['config_option_id']) ? (int) $oosEntry['config_option_id'] : 0;
                    if (! $oosCoId) continue;
                    $oosIds = array_values(array_filter(array_map('intval', $oosEntry['option_ids'] ?? [])));
                    if (! empty($oosIds)) {
                        $citadelOutOfStockMap[$oosCoId] = array_values(array_unique(array_merge($citadelOutOfStockMap[$oosCoId] ?? [], $oosIds)));
                    }
                }
            }
        @endphp

        @foreach ($product->configOptions as $configOption)
            @php
                $showPriceTag = $configOption->children->filter(fn ($value) => $value->price(billing_period: $plan->billing_period, billing_unit: $plan->billing_unit) && !$value->price(billing_period: $plan->billing_period, billing_unit: $plan->billing_unit)->is_free)->count() > 0;

                
                $citadelTiers = $citadelTieredMap[$configOption->id] ?? null;
                $citadelUnassignedIds = [];
                if ($citadelTiers) {
                    $allChildIds = $configOption->children->pluck('id')->map(fn ($id) => (int) $id)->all();
                    $citadelUnassignedIds = array_values(array_diff($allChildIds, $citadelTiers['assigned_ids']));
                }

                
                $citadelOosIds = $citadelOutOfStockMap[$configOption->id] ?? [];
                
                $envVarDescription = '';
                if ($configOption->env_variable) {
                    $varsJson = theme('env_var_descriptions_data', '[]');
                    $varsData = is_string($varsJson) ? json_decode($varsJson, true) : (is_array($varsJson) ? $varsJson : []);
                    foreach ($varsData as $varItem) {
                        if (!empty($varItem['name']) && strtolower(trim($varItem['name'])) === strtolower(trim($configOption->env_variable))) {
                            $envVarDescription = $varItem['description'] ?? '';
                            break;
                        }
                    }
                }
            @endphp
            
            @if ($configOption->type == 'select')
                @php
                    $selectItems = [];
                    if ($citadelTiers) {
                        foreach ($citadelTiers['tiers'] as $citadelTier) {
                            $tierChildren = $configOption->children->whereIn('id', $citadelTier['option_ids']);
                            if ($tierChildren->count()) {
                                $selectItems[] = ['type' => 'group', 'label' => $citadelTier['title'] ?: 'Tier'];
                                foreach ($tierChildren as $configOptionValue) {
                                    $priceObj = $configOptionValue->price(billing_period: $plan->billing_period, billing_unit: $plan->billing_unit);
                                    $priceStr = ($showPriceTag && ($priceObj?->available ?? false)) ? ' – ' . $priceObj : '';
                                    $selectItems[] = ['type' => 'option', 'value' => $configOptionValue->id, 'label' => trim($configOptionValue->name . $priceStr), 'oos' => in_array((int) $configOptionValue->id, $citadelOosIds, true)];
                                }
                            }
                        }
                        if (!empty($citadelUnassignedIds)) {
                            $tierChildren = $configOption->children->whereIn('id', $citadelUnassignedIds);
                            foreach ($tierChildren as $configOptionValue) {
                                $priceObj = $configOptionValue->price(billing_period: $plan->billing_period, billing_unit: $plan->billing_unit);
                                $priceStr = ($showPriceTag && ($priceObj?->available ?? false)) ? ' – ' . $priceObj : '';
                                $selectItems[] = ['type' => 'option', 'value' => $configOptionValue->id, 'label' => trim($configOptionValue->name . $priceStr), 'oos' => in_array((int) $configOptionValue->id, $citadelOosIds, true)];
                            }
                        }
                    } else {
                        foreach ($configOption->children as $configOptionValue) {
                            $priceObj = $configOptionValue->price(billing_period: $plan->billing_period, billing_unit: $plan->billing_unit);
                            $priceStr = ($showPriceTag && ($priceObj?->available ?? false)) ? ' – ' . $priceObj : '';
                            $selectItems[] = ['type' => 'option', 'value' => $configOptionValue->id, 'label' => trim($configOptionValue->name . $priceStr), 'oos' => in_array((int) $configOptionValue->id, $citadelOosIds, true)];
                        }
                    }
                @endphp
                <div class="mb-6">
                    <h3 class="check-out-title-semi mb-2 !font-normal">{{ $configOption->name }}{{ $configOption->required ? ' *' : '' }}</h3>
                    @if($envVarDescription)
                        <p class="small-text text-base mb-4 leading-relaxed !font-light">{{ $envVarDescription }}</p>
                    @endif
                    <div class="relative"
                         x-data="{
                             open: false,
                             selectedValue: $wire.entangle('configOptions.{{ $configOption->id }}'),
                             items: {{ json_encode($selectItems) }},
                             position: 'bottom',
                             init() {
                                 this.$watch('open', val => { if (val) this.calcPos(); });
                             },
                             calcPos() {
                                 const btn = this.$refs.btn;
                                 const list = this.$refs.list;
                                 if (!btn || !list) return;
                                 this.position = (btn.getBoundingClientRect().bottom + list.offsetHeight) > window.innerHeight ? 'top' : 'bottom';
                             },
                             get selectedLabel() {
                                 const opt = this.items.find(i => i.type === 'option' && i.value == this.selectedValue);
                                 return opt ? opt.label : '';
                             }
                         }"
                         @keydown.escape="open = false">
                        <button type="button"
                                x-ref="btn"
                                @click="open = !open"
                                :class="{ 'ring-2 ring-primary/20 border-primary': open }"
                                class="relative w-full min-h-[42px] py-2.5 pl-4 pr-10 text-left border rounded-lg cursor-pointer text-sm focus:outline-none transition-all {{ $errors->has('configOptions.'.$configOption->id) ? 'border-red-500 bg-red-500/30' : 'border-neutral bg-background-secondary hover:border-neutral-600 focus:ring-2 focus:ring-primary/20 focus:border-primary' }}">
                            <span x-text="selectedLabel" class="block truncate text-base"></span>
                            <span class="pointer-events-none absolute inset-y-0 right-3 flex items-center">
                                <svg class="w-4 h-4 text-muted" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z" clip-rule="evenodd"/>
                                </svg>
                            </span>
                        </button>
                        <ul x-ref="list"
                            x-show="open"
                            @click.away="open = false"
                            x-transition:enter="transition ease-out duration-150"
                            x-transition:enter-start="opacity-0 scale-95"
                            x-transition:enter-end="opacity-100 scale-100"
                            x-transition:leave="transition ease-in duration-100"
                            x-transition:leave-start="opacity-100 scale-100"
                            x-transition:leave-end="opacity-0 scale-95"
                            :class="{ 'bottom-full mb-2': position === 'top', 'top-full mt-2': position === 'bottom' }"
                            class="absolute z-50 w-full py-1 overflow-auto bg-background-secondary border border-neutral rounded-lg max-h-60 focus:outline-none text-sm"
                            x-cloak>
                            <template x-for="item in items" :key="'opt-' + (item.value !== undefined ? item.value : item.label)">
                                <li>
                                    <template x-if="item.type === 'group'">
                                        <span class="block px-3 pt-2 pb-1 text-xs font-semibold uppercase tracking-wider pointer-events-none text-base/50" x-text="item.label"></span>
                                    </template>
                                    <template x-if="item.type === 'option'">
                                        <span @click="if (!item.oos) { selectedValue = item.value; open = false }"
                                              :class="{ 'bg-primary/10 text-primary': item.value == selectedValue && !item.oos, 'opacity-50 cursor-not-allowed': item.oos, 'cursor-pointer hover:bg-neutral/50': !item.oos }"
                                              class="relative flex items-center justify-between py-2.5 pl-10 pr-4 select-none transition-colors">
                                            <span x-text="item.label"
                                                  :class="{ 'font-medium': item.value == selectedValue && !item.oos }"
                                                  class="block truncate text-base"></span>
                                            <span x-show="item.oos" class="ml-2 shrink-0 text-xs text-muted">Out of stock</span>
                                            <span x-show="item.value == selectedValue && !item.oos"
                                                  class="absolute inset-y-0 left-0 flex items-center pl-3 text-primary">
                                                <svg class="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                                                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
                                                </svg>
                                            </span>
                                        </span>
                                    </template>
                                </li>
                            </template>
                        </ul>
                    </div>
                    @error('configOptions.'.$configOption->id)
                        <p class="mt-2 text-sm text-red-600 flex items-center gap-2">
                            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
                            </svg>
                            {{ $message }}
                        </p>
                    @enderror
                </div>
            @elseif($configOption->type == 'radio')
                <div class="mb-6">
                    <h3 class="check-out-title-semi mb-2 !font-normal">{{ $configOption->name }}{{ $configOption->required ? ' *' : '' }}</h3>
                    @if($envVarDescription)
                        <p class="small-text text-base mb-4 leading-relaxed !font-light">{{ $envVarDescription }}</p>
                    @endif

                    @if($citadelTiers)
                        @foreach($citadelTiers['tiers'] as $citadelTier)
                            @php $tierChildren = $configOption->children->whereIn('id', $citadelTier['option_ids']); @endphp
                            @if($tierChildren->count())
                                <div class="mb-5">
                                    @if(!empty($citadelTier['title']))
                                        <div class="flex items-center gap-1.5 mb-1">
                                            <h4 class="text-base !font-semibold">{{ $citadelTier['title'] }}</h4>
                                            @if(!empty($citadelTier['tooltip']))
                                                @php $tierTooltipId = 'tier-tooltip-' . $configOption->id . '-' . $loop->index; @endphp
                                                <div class="relative inline-flex" x-data="{ open: false }">
                                                    <button type="button"
                                                        @mouseenter="open = true"
                                                        @mouseleave="open = false"
                                                        @click.prevent="open = !open"
                                                        class="text-muted hover:text-primary transition-colors focus:outline-none leading-none"
                                                        aria-label="More info">
                                                        <svg width="1em" height="1em" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M9.09 9C9.3251 8.33167 9.78915 7.76811 10.4 7.40913C11.0108 7.05016 11.7289 6.91894 12.4272 7.03871C13.1255 7.15849 13.7588 7.52152 14.2151 8.06353C14.6713 8.60553 14.9211 9.29152 14.92 10C14.92 12 11.92 13 11.92 13M12 17H12.01M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12Z" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                        </svg>
                                                    </button>
                                                    <div x-show="open"
                                                        x-transition:enter="transition ease-out duration-150"
                                                        x-transition:enter-start="opacity-0 scale-95"
                                                        x-transition:enter-end="opacity-100 scale-100"
                                                        x-transition:leave="transition ease-in duration-100"
                                                        x-transition:leave-start="opacity-100 scale-100"
                                                        x-transition:leave-end="opacity-0 scale-95"
                                                        @click.outside="open = false"
                                                        class="absolute z-30 left-6 top-1/2 -translate-y-1/2 w-[28rem] rounded-lg border border-neutral bg-background-secondary p-3 text-xs text-foreground leading-relaxed [&_strong]:font-semibold [&_em]:italic [&_p]:mb-1 [&_p:last-child]:mb-0"
                                                        style="display:none">
                                                        {!! \Illuminate\Support\Str::markdown($citadelTier['tooltip'], ['html_input' => 'escape', 'allow_unsafe_links' => false]) !!}
                                                    </div>
                                                </div>
                                            @endif
                                        </div>
                                    @endif
                                    @if(!empty($citadelTier['description']))
                                        <p class="small-text text-base mb-3 leading-relaxed !font-light">{{ $citadelTier['description'] }}</p>
                                    @endif
                                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                        @foreach($tierChildren as $configOptionValue)
                                            @include('products.partials.config-radio-card', ['configOption' => $configOption, 'configOptionValue' => $configOptionValue, 'plan' => $plan, 'showPriceTag' => $showPriceTag, 'configOptions' => $configOptions, 'outOfStockIds' => $citadelOosIds])
                                        @endforeach
                                    </div>
                                </div>
                            @endif
                        @endforeach

                        @if(!empty($citadelUnassignedIds))
                            @php $tierChildren = $configOption->children->whereIn('id', $citadelUnassignedIds); @endphp
                            @if($tierChildren->count())
                                <div class="mb-2">
                                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                        @foreach($tierChildren as $configOptionValue)
                                            @include('products.partials.config-radio-card', ['configOption' => $configOption, 'configOptionValue' => $configOptionValue, 'plan' => $plan, 'showPriceTag' => $showPriceTag, 'configOptions' => $configOptions, 'outOfStockIds' => $citadelOosIds])
                                        @endforeach
                                    </div>
                                </div>
                            @endif
                        @endif
                    @else
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            @foreach ($configOption->children as $configOptionValue)
                                @include('products.partials.config-radio-card', ['configOption' => $configOption, 'configOptionValue' => $configOptionValue, 'plan' => $plan, 'showPriceTag' => $showPriceTag, 'configOptions' => $configOptions, 'outOfStockIds' => $citadelOosIds])
                            @endforeach
                        </div>
                    @endif
                    @error('configOptions.'.$configOption->id)
                        <p class="mt-3 text-sm text-red-600 flex items-center gap-2">
                            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
                            </svg>
                            {{ $message }}
                        </p>
                    @enderror
                </div>
            @elseif($configOption->type == 'text' || $configOption->type == 'number')
                <div class="mb-6">
                    <h3 class="check-out-title-semi mb-2 !font-normal">{{ $configOption->name }}{{ $configOption->required ? ' *' : '' }}</h3>
                    @if($envVarDescription)
                        <p class="small-text text-base mb-4 leading-relaxed !font-light">{{ $envVarDescription }}</p>
                    @endif
                    <input type="{{ $configOption->type }}" 
                           wire:model.live="configOptions.{{ $configOption->id }}"
                           class="w-full min-h-[42px] px-4 py-2.5 border rounded-lg text-sm
                                  focus:outline-none transition-all duration-200 
                                  @error('configOptions.'.$configOption->id) 
                                      border-red-500 bg-red-500/30 focus:border-red-600 focus:ring-2 focus:ring-red-200
                                  @else 
                                      border-neutral bg-background-secondary focus:border-primary/40 hover:border-neutral
                                  @enderror"
                           placeholder="{{ $configOption->placeholder ?? '' }}" />
                    @error('configOptions.'.$configOption->id)
                        <p class="mt-2 text-sm text-red-600 flex items-center gap-2">
                            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
                            </svg>
                            {{ $message }}
                        </p>
                    @enderror
                </div>
            @elseif($configOption->type == 'checkbox')
                <div class="mb-6">
                    <h3 class="check-out-title-semi mb-2 !font-normal">{{ $configOption->name }}{{ $configOption->required ? ' *' : '' }}</h3>
                    @if($envVarDescription)
                        <p class="small-text text-base mb-4 leading-relaxed !font-light">{{ $envVarDescription }}</p>
                    @endif
                    <div class="flex items-center gap-3 p-3 border rounded-lg
                                @error('configOptions.'.$configOption->id) 
                                    border-red-500 bg-red-500/30
                                @else 
                                    border-neutral bg-background-secondary
                                @enderror">
                        <input type="checkbox" id="config_{{ $configOption->id }}"
                               wire:model.live="configOptions.{{ $configOption->id }}"
                               class="w-4 h-4 text-primary border border-neutral rounded focus:ring-primary/20 focus:ring-2 
                                      bg-background-secondary checked:bg-primary checked:border-primary 
                                      checked:text-white transition-all duration-200 accent-primary" />
                        <label for="config_{{ $configOption->id }}" class="normal-text cursor-pointer">
                            {{ $configOption->name }}
                        </label>
                    </div>
                    @error('configOptions.'.$configOption->id)
                        <p class="mt-2 text-sm text-red-600 flex items-center gap-2">
                            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
                            </svg>
                            {{ $message }}
                        </p>
                    @enderror
                </div>
            @elseif($configOption->type == 'slider')
                <div class="mb-6" wire:key="slider-{{ $configOption->id }}-{{ $plan->id }}">
                    <h3 class="check-out-title-semi mb-2 !font-normal">{{ $configOption->name }}{{ $configOption->required ? ' *' : '' }}</h3>
                    @if($envVarDescription)
                        <p class="small-text text-base mb-4 leading-relaxed !font-light">{{ $envVarDescription }}</p>
                    @endif
                    <div class="p-6 border border-neutral bg-background-secondary rounded-lg transition-all duration-200 hover:border-neutral">
                        <div x-data="{
                            options: @js($configOption->children->map(fn($child) => ['option' => $child->name, 'value' => $child->id, 'price' => ($showPriceTag && $child->price(billing_period: $plan->billing_period, billing_unit: $plan->billing_unit)?->available) ? (string)$child->price(billing_period: $plan->billing_period, billing_unit: $plan->billing_unit) : ''])),
                            showPriceTag: @js($showPriceTag),
                            selectedOption: 0,
                            backendOption: $wire.entangle('configOptions.{{ $configOption->id }}').live,
                            progressOption: '0%',
                            segmentsWidthOption: '0%',

                            init() {
                                const initialValue = this.$wire.get('configOptions.{{ $configOption->id }}');
                                const foundIndex = this.options.findIndex(option => option.value == initialValue);
                                if (foundIndex !== -1) {
                                    this.selectedOption = foundIndex;
                                }
                                this.updateSliderVisuals();
                                $watch('selectedOption', Alpine.debounce(() => this.backendOption = this.options[this.selectedOption].value, 300))
                            },

                            updateSliderVisuals() {
                                this.progressOption = `${(this.selectedOption / (this.options.length - 1)) * 100}%`;
                                this.segmentsWidthOption = `${100 / (this.options.length - 1)}%`;
                            },

                            setOptionValue(index) {
                                this.selectedOption = parseInt(index);
                                this.updateSliderVisuals();
                            }
                        }" class="flex flex-col gap-2 relative pt-6">
                            
                            <div class="relative flex items-center" :style="`--progress:${progressOption};--segments-width:${segmentsWidthOption}`" wire:ignore>
                                
                                <div class="
                                    absolute left-2.5 right-2.5 h-3 bg-neutral/20 rounded-full overflow-hidden transition-all duration-500 ease-in-out
                                    before:absolute before:inset-0 before:bg-primary before:rounded-full
                                    before:[mask-image:_linear-gradient(to_right,theme(colors.white),theme(colors.white)_var(--progress),transparent_var(--progress))]
                                    [&[x-cloak]]:hidden" aria-hidden="true"></div>
                                
                                
                                <div class="absolute left-2.5 right-2.5 flex justify-between items-center pointer-events-none h-3" aria-hidden="true">
                                    @foreach($configOption->children as $child)
                                        @if(!$loop->first && !$loop->last)
                                            <div class="w-0.5 h-2 bg-neutral/60 rounded-full transition-all duration-200"
                                                 :class="selectedOption >= {{ $loop->index }} ? 'bg-primary' : 'bg-neutral/60'"></div>
                                        @else
                                            <div></div>
                                        @endif
                                    @endforeach
                                </div>
                                
                                
                                <div class="absolute pointer-events-none transition-all duration-300 ease-out z-10" 
                                     :style="`left: calc(${progressOption} + 10px - ${progressOption === '0%' ? '0px' : progressOption === '100%' ? '50px' : '25px'})`">
                                    <div class="bg-primary text-white px-3 py-2 rounded-lg text-sm font-semibold whitespace-nowrap 
                                                transform -translate-y-10 relative" x-show="showPriceTag && options[selectedOption]?.price">
                                        <span x-text="options[selectedOption]?.price"></span>
                                    </div>
                                </div>
                                
                                <input class="
                                    relative appearance-none cursor-pointer w-full bg-transparent focus:outline-none transition-all duration-500 ease-in-out
                                    [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:h-7 [&::-webkit-slider-thumb]:w-4
                                    [&::-webkit-slider-thumb]:rounded-md [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:border [&::-webkit-slider-thumb]:border-neutral
                                    [&::-webkit-slider-thumb]:cursor-pointer [&::-webkit-slider-thumb]:transition-all [&::-webkit-slider-thumb]:duration-200
                                    [&::-webkit-slider-thumb]:focus:ring-2 [&::-webkit-slider-thumb]:focus:ring-primary/20
                                    [&::-moz-range-thumb]:h-7 [&::-moz-range-thumb]:w-4 [&::-moz-range-thumb]:rounded-md [&::-moz-range-thumb]:bg-white
                                    [&::-moz-range-thumb]:border [&::-moz-range-thumb]:border-neutral [&::-moz-range-thumb]:cursor-pointer
                                    [&::-moz-range-thumb]:transition-all [&::-moz-range-thumb]:duration-200
                                " type="range" min="0" :max="options.length - 1" x-model="selectedOption" @input="setOptionValue(selectedOption)" 
                                   aria-label="Option Slider" name="configOptions.{{ $configOption->id }}" id="configOptions.{{ $configOption->id }}" />
                            </div>
                            
                            
                            <div class="flex justify-between items-start pt-2">
                                @foreach($configOption->children as $child)
                                    <div class="flex flex-col items-center text-center cursor-pointer transition-all duration-200 hover:scale-105" 
                                         @click="setOptionValue({{ $loop->index }})">
                                        <span class="button-text mb-1">
                                            {{ $child->name }}
                                        </span>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            @else
                <x-form.configoption :config="$configOption" :name="'configOptions.' . $configOption->id" :showPriceTag="$showPriceTag" :plan="$plan">
                </x-form.configoption>
            @endif
        @endforeach


        @if (class_exists(\Paymenter\Extensions\Servers\OVH\OVH::class))
            {!! \Paymenter\Extensions\Servers\OVH\OVH::renderCheckoutPicker($product, $plan) !!}
        @endif

        @foreach ($this->getCheckoutConfig() as $configOption)
            @php 
                
                if (is_array($configOption)) {
                    $configOption = (object) $configOption;
                }
                
                
                if (!isset($configOption->name)) {
                    continue;
                }
                
                
                $envVarDescription = '';
                if (isset($configOption->name)) {
                    $varsJson = theme('env_var_descriptions_data', '[]');
                    $varsData = is_string($varsJson) ? json_decode($varsJson, true) : (is_array($varsJson) ? $varsJson : []);
                    foreach ($varsData as $varItem) {
                        if (!empty($varItem['name']) && strtolower(trim($varItem['name'])) === strtolower(trim($configOption->name))) {
                            $envVarDescription = $varItem['description'] ?? '';
                            break;
                        }
                    }
                }
            @endphp
            
            @if ($configOption->type == 'select')
                <div class="mb-6" data-checkout-config="{{ $configOption->name }}">
                    <h3 class="check-out-title-semi mb-4 !font-normal">{{ $configOption->label ?? $configOption->name }}{{ isset($configOption->required) && $configOption->required ? ' *' : '' }}</h3>
                    @if($envVarDescription)
                        <p class="small-text text-base mb-4 leading-relaxed !font-light">{{ $envVarDescription }}</p>
                    @endif
                    <select wire:model.live="checkoutConfig.{{ $configOption->name }}" 
                            class="w-full px-4 py-3 border rounded-lg
                                   focus:outline-none transition-all duration-200 
                                   @error('checkoutConfig.'.$configOption->name) 
                                       border-red-500 bg-red-500/30 focus:border-red-600 focus:ring-2 focus:ring-red-200
                                   @else 
                                       border-neutral bg-background-secondary focus:border-primary/40 hover:border-neutral
                                   @enderror">
                        @foreach ($configOption->options as $configOptionValue => $configOptionValueName)
                            <option value="{{ $configOptionValue }}">
                                {{ $configOptionValueName }}
                            </option>
                        @endforeach
                    </select>
                    @error('checkoutConfig.'.$configOption->name)
                        <p class="mt-2 text-sm text-red-600 flex items-center gap-2">
                            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
                            </svg>
                            {{ $message }}
                        </p>
                    @enderror
                </div>
            @elseif($configOption->type == 'radio')
            <div class="mb-6" data-checkout-config="{{ $configOption->name }}">
                <h3 class="check-out-title-semi mb-4 !font-normal">
                    {{ $configOption->label ?? $configOption->name }}{{ isset($configOption->required) && $configOption->required ? ' *' : '' }}
                </h3>
                
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    @foreach ($configOption->options as $configOptionValue => $configOptionValueName)
                        @php
                            $osIconPath = null;
                            $fileName = $configOptionValueName . '.svg'; 
                            $svgPath = public_path("assets/variables/{$fileName}");
                            
                            if (file_exists($svgPath)) {
                                $osIconPath = "/assets/variables/" . rawurlencode($configOptionValueName) . ".svg";
                            }
                        @endphp

                        <div wire:click="$set('checkoutConfig.{{ $configOption->name }}', '{{ $configOptionValue }}')"
                             class="cursor-pointer p-5 border rounded-lg transition-all duration-200 flex items-center justify-between
                                    @error('checkoutConfig.'.$configOption->name)
                                        border-red-500 bg-red-500/10 hover:border-red-600
                                    @else
                                        {{ (isset($checkoutConfig[$configOption->name]) && $checkoutConfig[$configOption->name] == $configOptionValue) ? 'border-primary bg-primary/5 ring-1 ring-primary' : 'border-neutral bg-background-secondary hover:border-primary/30' }}
                                    @enderror">
                            
                            <div class="flex flex-col">
                                <h4 class="radio-title !m-0 !font-bold text-base leading-tight">{{ $configOptionValueName }}</h4>
                            </div>

                            @if($osIconPath)
                                <div class="flex-shrink-0 ml-2">
                                    <img src="{{ $osIconPath }}" alt="{{ $configOptionValueName }}" class="w-10 h-10 object-contain block">
                                </div>
                            @endif

                            <input type="radio" id="{{ $configOptionValue }}" name="{{ $configOption->name }}"
                                wire:model.live="checkoutConfig.{{ $configOption->name }}"
                                value="{{ $configOptionValue }}" class="sr-only" />
                        </div>
                    @endforeach
                </div>
            </div>

            @elseif($configOption->type == 'text' || $configOption->type == 'number')
                <div class="mb-6" data-checkout-config="{{ $configOption->name }}">
                    <h3 class="check-out-title-semi mb-4 !font-normal">{{ $configOption->label ?? $configOption->name }}{{ isset($configOption->required) && $configOption->required ? ' *' : '' }}</h3>
                    @if($envVarDescription)
                        <p class="small-text text-base mb-4 leading-relaxed !font-light">{{ $envVarDescription }}</p>
                    @endif
                    <input type="{{ $configOption->type }}" 
                           wire:model.live="checkoutConfig.{{ $configOption->name }}"
                           class="w-full min-h-[42px] px-4 py-2.5 border rounded-lg text-sm
                                  focus:outline-none transition-all duration-200 
                                  @error('checkoutConfig.'.$configOption->name) 
                                      border-red-500 bg-red-500/30 focus:border-red-600 focus:ring-2 focus:ring-red-200
                                  @else 
                                      border-neutral bg-background-secondary focus:border-primary/40 hover:border-neutral
                                  @enderror"
                           placeholder="{{ $configOption->placeholder ?? '' }}" />
                    @error('checkoutConfig.'.$configOption->name)
                        <p class="mt-2 text-sm text-red-600 flex items-center gap-2">
                            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
                            </svg>
                            {{ $message }}
                        </p>
                    @enderror
                </div>
            @elseif($configOption->type == 'checkbox')
                <div class="mb-6" data-checkout-config="{{ $configOption->name }}">
                    <h3 class="check-out-title-semi mb-4 !font-normal">{{ $configOption->label ?? $configOption->name }}{{ isset($configOption->required) && $configOption->required ? ' *' : '' }}</h3>
                    @if($envVarDescription)
                        <p class="small-text text-base mb-4 leading-relaxed !font-light">{{ $envVarDescription }}</p>
                    @endif
                    <div class="flex items-center gap-3 p-3 border rounded-lg
                                @error('checkoutConfig.'.$configOption->name) 
                                    border-red-500 bg-red-500/30
                                @else 
                                    border-neutral bg-background-secondary
                                @enderror">
                        <input type="checkbox" id="checkout_{{ $configOption->name }}"
                               wire:model.live="checkoutConfig.{{ $configOption->name }}"
                               class="w-4 h-4 text-primary border border-neutral rounded focus:ring-primary/20 focus:ring-2 
                                      bg-background-secondary checked:bg-primary checked:border-primary 
                                      checked:text-white transition-all duration-200 accent-primary" />
                        <label for="checkout_{{ $configOption->name }}" class="normal-text cursor-pointer">
                            {{ $configOption->label ?? $configOption->name }}
                        </label>
                    </div>
                    @error('checkoutConfig.'.$configOption->name)
                        <p class="mt-2 text-sm text-red-600 flex items-center gap-2">
                            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
                            </svg>
                            {{ $message }}
                        </p>
                    @enderror
                </div>
            @else
                <div data-checkout-config="{{ $configOption->name }}">
                    <x-form.configoption :config="$configOption" :name="'checkoutConfig.' . $configOption->name">
                    </x-form.configoption>
                </div>
            @endif
        @endforeach
    </div>
    <div class="flex flex-col gap-4 w-full col-span-1 relative">
        <div class="sticky flex flex-col gap-4 h-fit mt-[77px]"
             wire:ignore.self
             x-data
             x-init="
                 const setTop = () => {
                     const nav = document.querySelector('nav[aria-label=\'primary-navigation\']');
                     const navBottom = nav ? nav.getBoundingClientRect().bottom : 0;
                     if (navBottom > 0) { $el.style.top = (navBottom + 8) + 'px'; }
                 };
                 setTop();
                 requestAnimationFrame(setTop);
                 window.addEventListener('load', setTop);
                 window.addEventListener('resize', setTop);
             ">
        <div id="order-summary" wire:ignore.self class="bg-background-secondary border border-neutral rounded-lg p-6 h-fit">
        <h2 class="check-out-title-semi !font-normal mb-4">
            {{ __('citadel::citadel.products.checkout.order_summary') }}
        </h2>
        
        <div class="space-y-3">
            
            @php $summarySale = citadel_plan_sale($product, $plan); @endphp
            <div class="flex justify-between items-center gap-2">
                <h4 class="normal-text !font-semibold !leading-5">
                    {{ $product->name }} {{ $plan->name }}
                </h4> 
                <span class="normal-text !font-semibold !leading-5 flex items-baseline gap-1.5 whitespace-nowrap">
                    @if($summarySale)
                        <span class="text-muted line-through text-xs font-normal">{{ $summarySale['original'] }}</span>
                    @endif
                    {{ $plan->price()?->formatted->price ?? '—' }}
                </span>
            </div>
            
            
            @foreach ($product->configOptions as $configOption)
                @if(isset($configOptions[$configOption->id]) && $configOptions[$configOption->id])
                    @php
                        $selectedOption = $configOption->children->find($configOptions[$configOption->id]);
                        $optionPrice = $selectedOption ? $selectedOption->price(billing_period: $plan->billing_period, billing_unit: $plan->billing_unit) : null;
                    @endphp
                    @if($selectedOption)
                    <div class="flex justify-between items-center">
                        <h4 class="normal-text !leading-5">{{ $configOption->name }}: {{ $selectedOption->name }}</h4>
                        <span class="normal-text !leading-5">
                            @if($optionPrice && !$optionPrice->is_free)
                                {{ $optionPrice }}
                            @else
                                {{ __('citadel::citadel.products.checkout.free') }}
                            @endif
                        </span>
                    </div>
                    @endif
                @endif
            @endforeach
            
            
            @foreach ($this->getCheckoutConfig() as $configOption)
                @php
                    
                    if (is_array($configOption)) {
                        $configOption = (object) $configOption;
                    }
                    
                    if (!isset($configOption->name)) {
                        continue;
                    }
                @endphp
                @if(isset($checkoutConfig[$configOption->name]) && $checkoutConfig[$configOption->name])
                    <div class="flex justify-between items-center">
                        <h4 class="normal-text !leading-5">{{ $configOption->label ?? $configOption->name }}</h4>
                        <span class="normal-text !leading-5">
                            @if($configOption->type == 'checkbox')
                                {{ $checkoutConfig[$configOption->name] ? 'Yes' : 'No' }}
                            @else
                                {{ $checkoutConfig[$configOption->name] }}
                            @endif
                        </span>
                    </div>
                @endif
            @endforeach
            
            
            @if ($total->setup_fee && $plan->type == 'recurring' && $plan->price())
            <div class="flex justify-between items-center">
                <h4 class="normal-text !leading-5">{{ __('citadel::citadel.products.checkout.setup_fee') }}</h4>
                <span class="normal-text !leading-5">{{ $plan->price()->formatted->setup_fee }}</span>
            </div>
            @endif
            
            
            <div class="pt-6 border-t border-neutral">
                <div class="flex flex-col gap-1">
                    <span class="normal-text !font-normal !leading-5">{{ __('citadel::citadel.products.checkout.total_due_today') }}</span> 
                    <div class="check-out-title-semi !font-bold !text-[32px]">
                        {{ $total }}
                    </div>
                </div>
                
                @if ($total->setup_fee && $plan->type == 'recurring')
                <div class="mt-3 pt-2 border-t border-neutral">
                    <div class="flex justify-between items-start">
                        <h4 class="normal-text flex-1 pr-2 !leading-5">{{ __('product.then_after_x', ['time' => $plan->billing_period . ' ' . trans_choice(__('services.billing_cycles.' . $plan->billing_unit), $plan->billing_period)]) }}:</h4> 
                        <span class="normal-text text-primary !leading-5">{{ $total->format($total->price) }}</span>
                    </div>
                </div>
                @endif
            </div>
        </div>
        
        @if (($product->stock > 0 || !$product->stock) && $product->price()?->available)
        <div class="mt-3">
            <x-button.primary wire:click="checkout" wire:loading.attr="disabled" class="w-full">
                <div class="flex items-center justify-center gap-2">
                    <x-ri-share-forward-fill class="size-4" />
                    <span>{{ __('product.checkout') }}</span>
                </div>
            </x-button.primary>
        </div>
        @endif

    </div>
    <x-checkout-support-card />
    </div>
    </div>
</div>
