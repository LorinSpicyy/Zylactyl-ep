<div data-product-display="detailed">
    <div class="pt-8 pb-4">
        <h1 class="text-2xl font-bold mb-6">{{ __('citadel::citadel.products.show.title') }}</h1>
    </div>

    @if(theme('pricing_card_icon_style', 'icon_top') == 'background')
    
    <div class="pt-8 relative overflow-hidden rounded-lg border border-neutral isolate">
        
        @if($product->image)
            <div class="absolute inset-0 rounded-lg overflow-hidden z-0">
                <img src="{{ Storage::url($product->image) }}" alt="{{ $product->name }}" 
                     class="w-full h-full object-cover">
            </div>
        @endif
        
        
        <div class="absolute inset-0 bg-gradient-to-b from-background-secondary/75 via-background-secondary/90 to-background-secondary z-[1]"></div>
        
        
        <div class="relative z-[2] p-8">
            @if ($product->stock === 0)
                <span class="text-xs font-medium me-2 px-2.5 py-0.5 rounded bg-red-900 text-red-300 w-fit mb-3">
                    {{ __('citadel::citadel.products.show.out_of_stock') }}
                </span>
            @elseif($product->stock > 0)
                <span class="text-xs font-medium me-2 px-2.5 py-0.5 rounded bg-green-900 text-green-300 w-fit mb-3">
                    {{ __('citadel::citadel.products.show.in_stock') }}
                </span>
            @endif
            
            <div class="flex flex-row justify-between items-start mb-4">
                <div>
                    <h2 class="text-3xl font-bold mb-2">{{ $product->name }}</h2>
                    <h3 class="text-xl font-semibold"><x-product-price :product="$product" price-class="" orig-class="text-base" /></h3>
                </div>
            </div>
            
            
            <div class="w-full h-px bg-neutral/60 mb-4"></div>
            
            <article class="my-4 prose dark:prose-invert">
                {!! $product->description !!}
            </article>

            @if ($product->stock !== 0 && $product->price()->available)
                <a href="{{ route('products.checkout', ['category' => $category, 'product' => $product->slug]) }}"
                    wire:navigate>
                    <x-button.primary>{{ __('citadel::citadel.products.show.add_to_cart') }}</x-button.primary>
                </a>
            @endif
        </div>
    </div>
@elseif(theme('pricing_card_icon_style', 'icon_top') == 'icon_right')
    
    <div class="pt-8 bg-background-secondary hover:bg-background-secondary/80 border border-neutral p-8 rounded-lg">
        @if ($product->stock === 0)
            <span class="text-xs font-medium me-2 px-2.5 py-0.5 rounded bg-red-900 text-red-300 w-fit mb-3">
                {{ __('product.out_of_stock', ['product' => $product->name]) }}
            </span>
        @elseif($product->stock > 0)
            <span class="text-xs font-medium me-2 px-2.5 py-0.5 rounded bg-green-900 text-green-300 w-fit mb-3">
                {{ __('product.in_stock') }}
            </span>
        @endif
        
        <div class="flex items-start justify-between gap-8 mb-6 relative">
            <div class="flex-1 z-10">
                <h2 class="text-3xl font-bold mb-2">{{ $product->name }}</h2>
                <h3 class="text-xl font-semibold mb-4"><x-product-price :product="$product" price-class="" orig-class="text-base" /></h3>
            </div>
            
            
            @if ($product->image)
                <div class="absolute right-0 top-0 z-0">
                    <img src="{{ Storage::url($product->image) }}" alt="{{ $product->name }}" 
                         class="w-32 h-32 object-cover object-center rounded-lg opacity-90">
                </div>
            @endif
        </div>
        
        
        <div class="w-full h-px bg-neutral/60 mb-4"></div>
        
        <article class="my-4 prose dark:prose-invert">
            {!! $product->description !!}
        </article>

        @if ($product->stock !== 0 && $product->price()->available)
            <a href="{{ route('products.checkout', ['category' => $category, 'product' => $product->slug]) }}"
                wire:navigate>
                <x-button.primary>{{ __('citadel::citadel.products.show.add_to_cart') }}</x-button.primary>
            </a>
        @endif
    </div>
@else
    
    <div class="pt-8 bg-background-secondary hover:bg-background-secondary/80 border border-neutral p-8 rounded-lg">
        @if ($product->stock === 0)
            <span class="text-xs font-medium me-2 px-2.5 py-0.5 rounded bg-red-900 text-red-300 w-fit mb-3">
                {{ __('citadel::citadel.products.show.out_of_stock') }}
            </span>
        @elseif($product->stock > 0)
            <span class="text-xs font-medium me-2 px-2.5 py-0.5 rounded bg-green-900 text-green-300 w-fit mb-3">
                {{ __('citadel::citadel.products.show.in_stock') }}
            </span>
        @endif
        
        
        <div class="flex items-center gap-6 mb-6">
            @if ($product->image)
                <img src="{{ Storage::url($product->image) }}" alt="{{ $product->name }}" 
                     class="w-20 h-20 object-cover object-center rounded-lg flex-shrink-0">
            @endif
            <div class="flex-1">
                <h2 class="text-3xl font-bold mb-2">{{ $product->name }}</h2>
                <h3 class="text-xl font-semibold"><x-product-price :product="$product" price-class="" orig-class="text-base" /></h3>
            </div>
        </div>
        
        
        <div class="w-full h-px bg-neutral/60 mb-4"></div>
        
        <article class="my-4 prose dark:prose-invert">
            {!! $product->description !!}
        </article>

        @if ($product->stock !== 0 && $product->price()->available)
            <a href="{{ route('products.checkout', ['category' => $category, 'product' => $product->slug]) }}"
                wire:navigate>
                <x-button.primary>{{ __('citadel::citadel.products.show.add_to_cart') }}</x-button.primary>
            </a>
        @endif
    </div>
@endif
</div>