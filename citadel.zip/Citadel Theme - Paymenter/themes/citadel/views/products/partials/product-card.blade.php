
@php
    $__ltp = theme('show_lowest_term_price', false) ? citadel_lowest_term_price($product) : null;
@endphp

@if(theme('pricing_card_icon_style', 'icon_top') == 'background')
    
    <div class="flex flex-col border border-neutral rounded-lg text-left relative overflow-hidden isolate">
        
        @if($product->image)
           
            <div class="absolute inset-px rounded-lg overflow-hidden z-0">
                <img src="{{ Storage::url($product->image) }}" alt="{{ $product->name }}"
                     class="w-full h-full object-cover">
            </div>
        @endif
        
        
        <div class="absolute inset-0 bg-gradient-to-b from-background-secondary/75 via-background-secondary/90 to-background-secondary z-[1]"></div>
        
        
        <div class="relative z-[2] p-6 flex flex-col h-full">
            
            <div class="mb-4">
                <h2 class="text-xl font-bold">{{ $product->name }}</h2>
            </div>
            
            
            <div class="text-base mb-4 text-left">
                <div class="text-sm font-medium mb-1 text-muted">{{ __('citadel::citadel.products.index.starting_at') }}</div>
                @php
                    $cheapestPlan = $__ltp ? $__ltp['plan'] : $product->availablePlans()->first();
                    $termText = null;
                    if ($cheapestPlan && $cheapestPlan->type == 'recurring') {
                        if ($cheapestPlan->billing_period == 1) {
                            $termText = __('citadel::citadel.products.index.per') . ' ' . trans_choice(__('services.billing_cycles.' . $cheapestPlan->billing_unit), 1);
                        } elseif ($cheapestPlan->billing_period == 3 && $cheapestPlan->billing_unit == 'month') {
                            $termText = __('citadel::citadel.products.index.per_quarter');
                        } elseif ($cheapestPlan->billing_period == 6 && $cheapestPlan->billing_unit == 'month') {
                            $termText = __('citadel::citadel.products.index.per_6_months');
                        } elseif ($cheapestPlan->billing_period == 12 && $cheapestPlan->billing_unit == 'month') {
                            $termText = __('citadel::citadel.products.index.per_year');
                        } else {
                            $termText = __('citadel::citadel.products.index.per') . ' ' . $cheapestPlan->billing_period . ' ' . trans_choice(__('services.billing_cycles.' . $cheapestPlan->billing_unit), $cheapestPlan->billing_period);
                        }
                    } elseif ($cheapestPlan && $cheapestPlan->type == 'one-time') {
                        $termText = __('citadel::citadel.products.index.one_time');
                    }
                @endphp
                <x-product-price :product="$product" price-class="text-2xl font-bold" :term="$termText" :price-override="$__ltp ? $__ltp['formatted'] : null" />
            </div>
            
            
            <div class="w-full h-px bg-neutral/60 mb-4"></div>
            
            
            @if($product->description)
                <div class="mb-3 flex-grow">
                    <article class="prose dark:prose-invert prose-sm max-w-none text-left py-1
                        [&_ul]:list-disc [&_ol]:list-decimal [&_li]:mb-0 [&_li]:text-sm [&_li]:leading-tight
                        [&_ul]:pl-4 [&_ol]:pl-4 [&_li]:pl-1 [&_p]:mb-0 [&_li_p]:mb-0 [&_ul]:space-y-0
                        [&_strong]:font-semibold [&_strong]:text-base">
                        {!! $product->description !!}
                    </article>
                </div>
            @endif
            
            
            @if (($product->stock > 0 || !$product->stock) && $product->price()->available && theme('direct_checkout', false))
                <a href="{{ route('products.checkout', ['category' => $cardCategory, 'product' => $product->slug]) }}"
                    wire:navigate class="mt-auto">
                    <x-button.primary class="w-full">{{ __('citadel::citadel.products.index.order_now') }}</x-button.primary>
                </a>
            @else
                <a href="{{ route('products.show', ['category' => $product->category, 'product' => $product->slug]) }}"
                    wire:navigate class="mt-auto">
                    <x-button.primary class="w-full">
                        {{ __('citadel::citadel.products.index.order_now') }}
                    </x-button.primary>
                </a>
            @endif
        </div>
    </div>
@else
    
    <div class="flex flex-col bg-background-secondary border border-neutral p-6 rounded-lg
        {{ in_array(theme('pricing_card_icon_style', 'icon_top'), ['icon_top']) ? 'text-center' : 'text-left' }}">
    @if(theme('pricing_card_icon_style', 'icon_top') == 'icon_top')
        
        @if ($product->image)
            <div class="flex justify-center mb-3">
                <img src="{{ Storage::url($product->image) }}" alt="{{ $product->name }}" 
                     class="w-12 h-12 object-cover object-center rounded-lg">
            </div>
        @endif
        
        
        <h2 class="text-xl font-bold mb-3">{{ $product->name }}</h2>
    @elseif(theme('pricing_card_icon_style', 'icon_top') == 'icon_top_left')
       
        <div class="flex items-center gap-3 mb-4">
            @if ($product->image)
                <img src="{{ Storage::url($product->image) }}" alt="{{ $product->name }}" 
                     class="w-12 h-12 object-cover object-center rounded-lg flex-shrink-0">
            @endif
            <h2 class="text-xl font-bold">{{ $product->name }}</h2>
        </div>
    @elseif(theme('pricing_card_icon_style', 'icon_top') == 'icon_right')
        
        <div class="flex items-end justify-between gap-4 mb-4 relative">
            <div class="flex-1 z-10 relative">
                
                <h2 class="text-xl font-bold mb-2">{{ $product->name }}</h2>
                
                
                <div class="text-left">
                    <div class="text-sm font-medium mb-1 text-muted">{{ __('citadel::citadel.products.index.starting_at') }}</div>
                    @php
                        $cheapestPlan = $__ltp ? $__ltp['plan'] : $product->availablePlans()->first();
                        $termText = null;
                        if ($cheapestPlan && $cheapestPlan->type == 'recurring') {
                            if ($cheapestPlan->billing_period == 1) {
                                $termText = __('citadel::citadel.products.index.per') . ' ' . trans_choice(__('services.billing_cycles.' . $cheapestPlan->billing_unit), 1);
                            } elseif ($cheapestPlan->billing_period == 3 && $cheapestPlan->billing_unit == 'month') {
                                $termText = __('citadel::citadel.products.index.per_quarter');
                            } elseif ($cheapestPlan->billing_period == 6 && $cheapestPlan->billing_unit == 'month') {
                                $termText = __('citadel::citadel.products.index.per_6_months');
                            } elseif ($cheapestPlan->billing_period == 12 && $cheapestPlan->billing_unit == 'month') {
                                $termText = __('citadel::citadel.products.index.per_year');
                            } else {
                                $termText = __('citadel::citadel.products.index.per') . ' ' . $cheapestPlan->billing_period . ' ' . trans_choice(__('services.billing_cycles.' . $cheapestPlan->billing_unit), $cheapestPlan->billing_period);
                            }
                        } elseif ($cheapestPlan && $cheapestPlan->type == 'one-time') {
                            $termText = __('citadel::citadel.products.index.one_time');
                        }
                    @endphp
                    <x-product-price :product="$product" price-class="text-2xl font-bold" :term="$termText" :price-override="$__ltp ? $__ltp['formatted'] : null" />
                </div>
            </div>
            
            
            @if ($product->image)
                <div class="absolute right-0 bottom-0 z-0">
                    <img src="{{ Storage::url($product->image) }}" alt="{{ $product->name }}" 
                         class="w-20 h-20 object-cover object-center rounded-lg opacity-90">
                </div>
            @endif
        </div>
        
        
        <div class="w-full h-px bg-neutral/60 mb-4"></div>
    @else
        
        <h2 class="text-xl font-bold mb-4">{{ $product->name }}</h2>
    @endif
    
    
    @if(theme('pricing_card_icon_style', 'icon_top') == 'icon_top_left')
        
        <div class="text-base mb-4 text-left">
            <div class="text-sm font-medium mb-1 text-muted">{{ __('citadel::citadel.products.index.starting_at') }}</div>
            @php
                $cheapestPlan = $__ltp ? $__ltp['plan'] : $product->availablePlans()->first();
                $termText = null;
                if ($cheapestPlan && $cheapestPlan->type == 'recurring') {
                    if ($cheapestPlan->billing_period == 1) {
                        $termText = __('citadel::citadel.products.index.per') . ' ' . trans_choice(__('services.billing_cycles.' . $cheapestPlan->billing_unit), 1);
                    } elseif ($cheapestPlan->billing_period == 3 && $cheapestPlan->billing_unit == 'month') {
                        $termText = __('citadel::citadel.products.index.per_quarter');
                    } elseif ($cheapestPlan->billing_period == 6 && $cheapestPlan->billing_unit == 'month') {
                        $termText = __('citadel::citadel.products.index.per_6_months');
                    } elseif ($cheapestPlan->billing_period == 12 && $cheapestPlan->billing_unit == 'month') {
                        $termText = __('citadel::citadel.products.index.per_year');
                    } else {
                        $termText = __('citadel::citadel.products.index.per') . ' ' . $cheapestPlan->billing_period . ' ' . trans_choice(__('services.billing_cycles.' . $cheapestPlan->billing_unit), $cheapestPlan->billing_period);
                    }
                } elseif ($cheapestPlan && $cheapestPlan->type == 'one-time') {
                    $termText = __('citadel::citadel.products.index.one_time');
                }
            @endphp
            <x-product-price :product="$product" price-class="text-2xl font-bold" :term="$termText" :price-override="$__ltp ? $__ltp['formatted'] : null" />
        </div>
        
        <div class="w-full h-px bg-neutral/60 mb-4"></div>
    @elseif(theme('pricing_card_icon_style', 'icon_top') == 'icon_top')
        
        <div class="text-2xl font-bold text-base mb-3">
            <span class="text-sm font-medium text-muted">{{ __('citadel::citadel.products.index.starting_at') }}</span><br>
            @php
                $cheapestPlan = $__ltp ? $__ltp['plan'] : $product->availablePlans()->first();
                $termText = null;
                if ($cheapestPlan && $cheapestPlan->type == 'recurring') {
                    if ($cheapestPlan->billing_period == 1) {
                        $termText = __('citadel::citadel.products.index.per') . ' ' . trans_choice(__('services.billing_cycles.' . $cheapestPlan->billing_unit), 1);
                    } elseif ($cheapestPlan->billing_period == 3 && $cheapestPlan->billing_unit == 'month') {
                        $termText = __('citadel::citadel.products.index.per_quarter');
                    } elseif ($cheapestPlan->billing_period == 6 && $cheapestPlan->billing_unit == 'month') {
                        $termText = __('citadel::citadel.products.index.per_6_months');
                    } elseif ($cheapestPlan->billing_period == 12 && $cheapestPlan->billing_unit == 'month') {
                        $termText = __('citadel::citadel.products.index.per_year');
                    } else {
                        $termText = __('citadel::citadel.products.index.per') . ' ' . $cheapestPlan->billing_period . ' ' . trans_choice(__('services.billing_cycles.' . $cheapestPlan->billing_unit), $cheapestPlan->billing_period);
                    }
                } elseif ($cheapestPlan && $cheapestPlan->type == 'one-time') {
                    $termText = __('citadel::citadel.products.index.one_time');
                }
            @endphp
            <x-product-price :product="$product" price-class="text-2xl font-bold" :term="$termText" :price-override="$__ltp ? $__ltp['formatted'] : null" />
        </div>
        
        <div class="w-full h-px bg-neutral/60 mb-3"></div>
    @endif

    
    @if($product->description)
        <div class="{{ in_array(theme('pricing_card_icon_style', 'icon_top'), ['icon_top_left', 'icon_right']) ? 'mb-4' : 'mb-3' }} flex-grow">
            @if(in_array(theme('pricing_card_icon_style', 'icon_top'), ['icon_top_left', 'icon_right']))
                
                <article class="prose dark:prose-invert prose-sm max-w-none text-left py-2
                    [&_ul]:list-disc [&_ol]:list-decimal [&_li]:mb-0 [&_li]:text-sm [&_li]:leading-tight
                    [&_ul]:pl-4 [&_ol]:pl-4 [&_li]:pl-1 [&_p]:mb-0 [&_li_p]:mb-0 [&_ul]:space-y-0
                    [&_strong]:font-semibold [&_strong]:text-base">
                    {!! $product->description !!}
                </article>
            @else
                
                <article class="prose dark:prose-invert prose-sm max-w-none text-left py-1
                    [&_ul]:list-disc [&_ol]:list-decimal [&_li]:mb-0 [&_li]:text-sm [&_li]:leading-tight
                    [&_ul]:pl-4 [&_ol]:pl-4 [&_li]:pl-1 [&_p]:mb-0 [&_li_p]:mb-0 [&_ul]:space-y-0
                    [&_strong]:font-semibold [&_strong]:text-base">
                    {!! $product->description !!}
                </article>
            @endif
        </div>
    @endif
    
    
    @if (($product->stock > 0 || !$product->stock) && $product->price()->available && theme('direct_checkout', false))
        <a href="{{ route('products.checkout', ['category' => $cardCategory, 'product' => $product->slug]) }}"
            wire:navigate class="mt-auto">
            <x-button.primary class="w-full">{{ __('citadel::citadel.products.index.order_now') }}</x-button.primary>
        </a>
    @else
        <a href="{{ route('products.show', ['category' => $product->category, 'product' => $product->slug]) }}"
            wire:navigate class="mt-auto">
            <x-button.primary class="w-full">
                {{ __('citadel::citadel.products.index.order_now') }}
            </x-button.primary>
        </a>
    @endif
    </div>
@endif
