@foreach($sidebarCategories as $sidebarCat)
    <div>
        <a href="{{ route('category.show', ['category' => $sidebarCat->slug]) }}" wire:navigate
            class="flex items-center gap-3 py-2.5 px-3 rounded-lg text-sm text-base hover:bg-neutral/50 transition-colors {{ $category->id == $sidebarCat->id ? 'bg-primary/10 text-primary font-medium' : '' }}">
            <x-ri-shopping-cart-fill class="size-4" />
            <span class="flex-1">{{ $sidebarCat->name }}</span>
            @if($category->id == $sidebarCat->id)
            <x-ri-check-fill class="size-4 text-primary" />
            @endif
        </a>

        @if($sidebarCat->children && $sidebarCat->children->count() > 0)
            <div class="ml-6 space-y-0.5 mt-0.5">
                @include('products.partials.sidebar-category', ['sidebarCategories' => $sidebarCat->children, 'category' => $category])
            </div>
        @endif
    </div>
@endforeach
