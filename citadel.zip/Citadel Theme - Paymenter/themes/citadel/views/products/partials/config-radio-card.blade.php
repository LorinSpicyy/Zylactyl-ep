@php
    
    $iconPath = null;
    $optionName = $configOptionValue->name;

    $possibleNames = [
        strtolower($optionName),
        strtoupper($optionName),
        $optionName,
        str_replace(' ', '', strtolower($optionName)),
        str_replace(' ', '-', strtolower($optionName)),
        str_replace(' ', '_', strtolower($optionName)),
        str_replace([',', ' '], '', strtolower($optionName)),
        str_replace([',', ' '], '-', strtolower($optionName)),
        str_replace([',', ' '], '_', strtolower($optionName)),
        preg_replace('/[^a-zA-Z0-9]/', '', strtolower($optionName)),
        preg_replace('/[^a-zA-Z0-9]/', '', strtoupper($optionName)),
        strtolower(explode(',', $optionName)[0]),
        strtolower(trim(explode(',', $optionName)[0])),
        strtolower(trim(explode(',', $optionName)[count(explode(',', $optionName)) - 1])),
        strtolower(str_replace([', usa', ', us', ' usa', ' us'], '', $optionName)),
        strtolower(str_replace([', uk', ' uk'], '', $optionName)),
    ];

    $possibleNames = array_filter(array_unique($possibleNames));

    foreach ($possibleNames as $name) {
        if (empty($name)) continue;

        $svgPath = public_path("assets/variables/{$name}.svg");
        if (file_exists($svgPath)) {
            $iconPath = "/assets/variables/" . rawurlencode($name) . ".svg";
            break;
        }
    }
@endphp

@php
    $isSelected = isset($configOptions[$configOption->id]) && $configOptions[$configOption->id] == $configOptionValue->id;
    $isOutOfStock = in_array((int) $configOptionValue->id, array_map('intval', $outOfStockIds ?? []), true);
@endphp
<div @if(!$isOutOfStock) wire:click="$set('configOptions.{{ $configOption->id }}', {{ $configOptionValue->id }})" @endif
     class="relative overflow-hidden p-4 border rounded-lg transition-all duration-200
            @if($isOutOfStock)
                cursor-not-allowed opacity-60 border-neutral bg-background-secondary
            @else
                cursor-pointer
                @error('configOptions.'.$configOption->id)
                    border-red-500 bg-red-500/30 hover:border-red-600
                @else
                    {{ $isSelected ? 'border-primary/40 bg-primary/5' : 'border-neutral bg-background-secondary hover:border-neutral' }}
                @enderror
            @endif">

    @if($isOutOfStock)
        <span class="pointer-events-none absolute top-2 right-2 z-10 inline-flex items-center rounded-md bg-neutral px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-muted">Out of stock</span>
    @elseif($isSelected)

        <span class="pointer-events-none absolute top-0 right-0 w-0 h-0 border-t-[34px] border-l-[34px] border-t-primary border-l-transparent" aria-hidden="true"></span>
        
        <svg class="pointer-events-none absolute top-[5px] right-[4px] w-[11px] h-[11px] text-white" aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="20 6 9 17 4 12"/>
        </svg>
    @endif

    <div class="flex justify-between items-center">
        <div class="flex flex-col">
            <h4 class="radio-title mb-1 !font-bold">{{ $configOptionValue->name }}</h4>

            @php
                
                $optionPlan = $configOptionValue->availablePlans()
                    ->where('billing_period', $plan->billing_period)
                    ->where('billing_unit', $plan->billing_unit)
                    ->first();
                if (!$optionPlan) {
                    $optionPlan = $configOptionValue->availablePlans()->first();
                }
                $optionPlanName = (theme('hide_variable_plan_names') ? null : ($optionPlan->name ?? null));
                
                if ($optionPlanName !== null) {
                    $cleanedPlanName = preg_replace('/[\s\x{00A0}\x{200B}-\x{200F}\x{202A}-\x{202E}\x{2060}\x{FEFF}]+/u', '', $optionPlanName);
                    if ($cleanedPlanName === '' || $cleanedPlanName === null || $cleanedPlanName === '-') {
                        $optionPlanName = null;
                    }
                }
                $optionPriceMaybe = $configOptionValue->price(billing_period: $plan->billing_period, billing_unit: $plan->billing_unit);
                $hasAvailablePrice = $showPriceTag && $optionPriceMaybe?->available;
            @endphp

            @if($hasAvailablePrice)
                @php
                    $optionPrice = $optionPriceMaybe;
                    $optionIsRecurring = $optionPlan && $optionPlan->type == 'recurring';

                    
                    $shortUnitMap = [
                        'day' => 'd',
                        'week' => 'wk',
                        'month' => 'mo',
                        'year' => 'yr',
                    ];
                    $shortUnit = $shortUnitMap[$plan->billing_unit] ?? $plan->billing_unit;

                    if ($plan->billing_period == 1) {
                        $shortTermLabel = $shortUnit;
                    } elseif ($plan->billing_period == 3 && $plan->billing_unit == 'month') {
                        $shortTermLabel = 'qtr';
                    } elseif ($plan->billing_period == 6 && $plan->billing_unit == 'month') {
                        $shortTermLabel = '6mo';
                    } elseif ($plan->billing_period == 12 && $plan->billing_unit == 'month') {
                        $shortTermLabel = 'yr';
                    } else {
                        $shortTermLabel = $plan->billing_period . $shortUnit;
                    }

                    $dividedPriceFormatted = null;
                    $dividedTermLabel = null;
                    if (theme('config_option_monthly_pricing') && $optionIsRecurring && !$optionPrice->is_free) {
                        if ($plan->billing_unit == 'year') {
                            $divisor = $plan->billing_period * 12;
                            $dividedTermLabel = 'mo';
                        } else {
                            $divisor = $plan->billing_period;
                            $dividedTermLabel = $shortUnit;
                        }
                        if ($divisor > 1) {
                            $dividedPrice = $optionPrice->price / $divisor;
                            $dividedPriceFormatted = $optionPrice->format(number_format($dividedPrice, 2, '.', ''));
                        }
                    }
                @endphp
                <div class="flex items-baseline gap-x-3 gap-y-1 flex-wrap {{ $optionPlanName ? 'justify-between' : 'justify-start' }}">
                    @if($optionPlanName)
                        <span class="text-xs text-muted !font-medium">{{ $optionPlanName }}</span>
                    @endif
                    @if($optionPrice->is_free)
                        
                    @else
                        <span class="text-xs text-primary !font-medium flex items-baseline gap-1 flex-wrap">
                            @if($dividedPriceFormatted)
                                <span>+{{ $dividedPriceFormatted }}<span class="text-muted">/{{ $dividedTermLabel }}</span></span>
                            @else
                                <span>+{{ $optionPrice->formatted->price }}@if($optionIsRecurring)<span class="text-muted">/{{ $shortTermLabel }}</span>@endif</span>
                            @endif
                            @if($optionPrice->has_setup_fee)
                                <span class="text-[10px] text-muted font-normal">+ {{ $optionPrice->formatted->setup_fee }} {{ __('citadel::citadel.products.checkout.setup_fee') }}</span>
                            @endif
                        </span>
                    @endif
                </div>
            @else
                @if($optionPlanName)
                    <div class="flex items-baseline gap-x-3 gap-y-1 flex-wrap justify-start">
                        <span class="text-xs text-muted !font-medium">{{ $optionPlanName }}</span>
                    </div>
                @endif
            @endif
        </div>

        @if($iconPath)
            <div class="flex-shrink-0 w-12 h-12 relative">
                <img src="{{ $iconPath }}" alt="{{ $configOptionValue->name }}" class="w-full h-full object-contain">
            </div>
        @endif
    </div>

    <input type="radio" id="{{ $configOptionValue->id }}" name="{{ $configOption->id }}"
        wire:model.live="configOptions.{{ $configOption->id }}"
        value="{{ $configOptionValue->id }}" class="sr-only" />
</div>
