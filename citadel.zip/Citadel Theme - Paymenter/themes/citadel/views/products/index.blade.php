<div data-catalog-view="grid" class="pt-8">
    
    <div class="mb-6">
        <h1 class="text-3xl font-bold">{{ $category->name }}</h1>
        @php
            $description = $category->description ?? '';


            $introText = preg_split('/\s*<(?:ul|ol|li|table|h[1-6]|blockquote|pre|hr)[>\s\/]/i', $description, 2)[0] ?? '';


            $introText = trim(strip_tags($introText));


            $introText = preg_split('/\n\s*(?:[-*+]\s|\d+\.\s|>\s|#{1,6}\s|```|\|)/m', $introText, 2)[0] ?? '';

            $introText = trim($introText);
        @endphp
        
        @if($introText)
        <article class="prose dark:prose-invert prose-base max-w-none text-muted">
            <p>{{ $introText }}</p>
        </article>
        @endif
    </div>
    
    
    <div class="grid md:grid-cols-4 gap-4">
        <div class="flex flex-col gap-2">
            
            <h2 class="text-xl font-semibold mb-3">{{ __('citadel::citadel.products.index.categories_heading') }}</h2>
            
            <div class="flex flex-col space-y-0.5">
                @include('products.partials.sidebar-category', ['sidebarCategories' => $categories, 'category' => $category])
            </div>
        </div>
    <div class="flex flex-col gap-6 col-span-3">

        @if($products->count() > 0)
        <div class="grid sm:grid-cols-2 md:grid-cols-3 gap-4 h-fit">
            @foreach ($products as $product)
                @include('products.partials.product-card', ['product' => $product, 'cardCategory' => $category])
            @endforeach
        </div>
        @endif


        @php
            
            $getAllDescendants = function($parentCat) use (&$getAllDescendants) {
                $descendants = collect();
                $children = $parentCat->children()->orderBy('sort')->get();
                foreach ($children as $child) {
                    $descendants->push($child);
                    $descendants = $descendants->merge($getAllDescendants($child));
                }
                return $descendants;
            };
            $allDescendantCategories = $getAllDescendants($category);
        @endphp

        @if($allDescendantCategories->count() > 0)
            @foreach($allDescendantCategories as $subCategory)
                @php
                    $subProducts = $subCategory->products()->where('hidden', false)->with(['category', 'plans.prices', 'configOptions.children.plans.prices'])->orderBy('sort')->get();
                @endphp
                @if($subProducts->count() > 0)
                    <div class="mt-2">
                        <div class="flex items-center gap-3 mb-4">
                            <h2 class="text-xl font-semibold">{{ $subCategory->name }}</h2>
                            <a href="{{ route('category.show', ['category' => $subCategory->slug]) }}" 
                               wire:navigate
                               class="text-sm text-primary hover:text-primary/80 transition-colors">
                                {{ __('citadel::citadel.products.index.view_all') }} →
                            </a>
                        </div>
                        @php
                            $subDesc = $subCategory->description ?? '';
                            $subIntro = preg_split('/\s*<(?:ul|ol|li|table|h[1-6]|blockquote|pre|hr)[>\s\/]/i', $subDesc, 2)[0] ?? '';
                            $subIntro = trim(strip_tags($subIntro));
                            $subIntro = preg_split('/\n\s*(?:[-*+]\s|\d+\.\s|>\s|#{1,6}\s|```|\|)/m', $subIntro, 2)[0] ?? '';
                            $subIntro = Str::limit(trim($subIntro), 150);
                        @endphp
                        @if($subIntro)
                            <p class="text-sm text-muted mb-4">{{ $subIntro }}</p>
                        @endif
                        <div class="grid sm:grid-cols-2 md:grid-cols-3 gap-4 h-fit">
                            @foreach ($subProducts as $product)
                                @include('products.partials.product-card', ['product' => $product, 'cardCategory' => $subCategory])
                            @endforeach
                        </div>
                    </div>
                @endif
            @endforeach
        @endif
    </div>
</div>
</div>
