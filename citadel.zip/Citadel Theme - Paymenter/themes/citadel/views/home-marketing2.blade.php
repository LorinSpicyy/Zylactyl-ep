

@php

    $marketing2Blocks = json_decode(theme('marketing2_blocks', '[]'), true);
    $marketing2Blocks = is_array($marketing2Blocks) ? $marketing2Blocks : [];
@endphp

@if (! empty($marketing2Blocks))
    <div class="w-full py-10">
        @foreach ($marketing2Blocks as $blockIndex => $block)
            @php
                $type = $block['type'] ?? null;
                $blockAnchor = (string) preg_replace('/\s+/', '-', ltrim(trim((string) ($block['anchor'] ?? '')), '#'));
            @endphp

            @if ($blockAnchor !== '')<div id="{{ $blockAnchor }}" class="citadel-anchor-target">@endif

            @if ($type === 'hero')
                @include('partials.custom-page-blocks.hero', ['block' => $block, 'category' => null, 'isFirstBlock' => ($blockIndex === 0)])
            @elseif ($type === 'products')
                @include('partials.custom-page-blocks.products', ['block' => $block, 'category' => null])
            @elseif ($type === 'features')
                @include('partials.custom-page-blocks.features', ['block' => $block])
            @elseif ($type === 'faq')
                @include('partials.custom-page-blocks.faq', ['block' => $block, 'index' => $blockIndex])
            @elseif ($type === 'content')
                @include('partials.custom-page-blocks.content', ['block' => $block])
            @elseif ($type === 'cta')
                @include('partials.custom-page-blocks.cta', ['block' => $block])
            @elseif ($type === 'custom')
                @include('partials.custom-page-blocks.custom', ['block' => $block])
            @endif

            @if ($blockAnchor !== '')</div>@endif
        @endforeach
    </div>
@else
@php
    $_heroLayout = 'split_view';
    $heroCategories = \App\Models\Category::whereNull('parent_id')
        ->where(function ($query) {
            $query->whereHas('children')
                ->orWhereHas('products', function ($query) {
                    $query->where('hidden', false);
                });
        })
        ->with(['products' => function ($query) {
            $query->where('hidden', false)
                  ->with(['plans.prices'])
                  ->orderBy('sort')
                  ->limit(1);
        }])
        ->orderBy('sort')
        ->limit(3)
        ->get();

    $firstCategory = $heroCategories->first();
    $firstProduct = $firstCategory?->products->first();
    $firstPlan = $firstProduct?->availablePlans()?->first();

    $startingPrice = '';
    $billingTerm = '';
    $heroSale = null;
    if ($firstProduct && $firstProduct->price()->available) {
        $startingPrice = $firstProduct->price()->formatted->price;
        $heroSale = citadel_product_sale($firstProduct);
        if ($firstPlan && $firstPlan->type == 'recurring') {
            if ($firstPlan->billing_period == 1) {
                $billingTerm = trans_choice(__('services.billing_cycles.' . $firstPlan->billing_unit), 1);
            } elseif ($firstPlan->billing_period == 3 && $firstPlan->billing_unit == 'month') {
                $billingTerm = __('citadel::citadel.plans.quarter');
            } elseif ($firstPlan->billing_period == 6 && $firstPlan->billing_unit == 'month') {
                $billingTerm = __('citadel::citadel.plans.6_months');
            } elseif ($firstPlan->billing_period == 12 && $firstPlan->billing_unit == 'month') {
                $billingTerm = __('citadel::citadel.plans.year');
            } else {
                $billingTerm = $firstPlan->billing_period . ' ' . trans_choice(__('services.billing_cycles.' . $firstPlan->billing_unit), $firstPlan->billing_period);
            }
        }
    }

    $heroRightContent = theme('marketing2_hero_right_content') ?: 'categories';
    $heroPresetImage = theme('marketing2_hero_preset_image') ?: 'hero';
@endphp

@if($heroRightContent === 'preset_image' && $heroPresetImage === 'hero')

    <div class="relative -mt-12 md:-mt-28 mb-0">

        <div class="absolute inset-0 left-[50%] right-[50%] -ml-[50vw] -mr-[50vw] w-screen min-h-[600px] md:min-h-[700px] flex justify-center overflow-hidden">
            <div class="w-full h-full max-w-[1920px]">
                @include('components.hero-svg')
            </div>
        </div>


        <section class="relative pt-40 pb-20 md:py-32 flex items-center min-h-[600px] md:min-h-[700px] z-10">
            <div class="w-full">
                <div class="flex justify-start">
                    <div class="w-full lg:w-1/2 text-left">

                        @if(theme('marketing2_show_trustpilot', true))
                            <div class="flex items-center gap-2 mb-6 text-sm sm:text-base" style="color: hsl(var(--color-base) / 0.9);">
                                <span>Rated <span class="font-bold">{{ theme('marketing2_trustpilot_rating') ?: theme('landing_trustpilot_rating') ?: 'Excellent' }}</span> on</span>
                                <img src="/assets/icons/trustpilot-light.png" alt="Trustpilot" class="h-5 sm:h-6 dark:hidden" />
                                <img src="/assets/icons/trustpilot-dark.png" alt="Trustpilot" class="h-5 sm:h-6 hidden dark:block" />
                            </div>
                        @endif


                        <h1 class="{{ theme('marketing2_title_size') ?: 'text-5xl sm:text-6xl lg:text-7xl' }} font-bold mb-6 leading-tight" style="color: hsl(var(--color-base));">
                            {!! Str::inlineMarkdown(theme('marketing2_title') ?: 'Powerful VPS Hosting and Web Hosting') !!}
                        </h1>


                        @if(theme('marketing2_description'))
                            <p class="{{ theme('marketing2_description_size') ?: 'text-base' }} mb-8 leading-relaxed" style="color: hsl(var(--color-base) / 0.8);">
                                {!! Str::inlineMarkdown(theme('marketing2_description')) !!}
                            </p>
                        @endif


                        @if(theme('marketing2_enable_button', true))
                            <div class="flex flex-col sm:flex-row gap-4">
                                @php
                                    $heroButtonLink = theme('marketing2_button_link') ?: ($firstCategory ? route('category.show', ['category' => $firstCategory->slug]) : route('home'));
                                    $heroButtonIsExternal = filter_var($heroButtonLink, FILTER_VALIDATE_URL) && !str_starts_with($heroButtonLink, url('/'));
                                @endphp
                                <a href="{{ $heroButtonLink }}"
                                   class="citadel-btn inline-flex items-center justify-center px-8 bg-primary text-white text-sm rounded-lg hover:opacity-90 transition-all font-medium"
                                   style="border-radius: var(--citadel-button-radius);"
                                   @if(!$heroButtonIsExternal) wire:navigate @else target="_blank" rel="noopener noreferrer" @endif>
                                    {{ theme('marketing2_button_text') ?: 'Get Started' }}
                                </a>

                                @if(theme('marketing2_show_starting_price', true) && $startingPrice)
                                    <div class="flex items-center gap-2 text-base flex-wrap" style="color: hsl(var(--color-base) / 0.8);">
                                        <span>{{ theme('marketing2_price_prefix') ?: 'Starting at Only' }}</span>
                                        @if($heroSale)<span class="line-through" style="color: hsl(var(--color-base) / 0.45);">{{ $heroSale['original'] }}</span>@endif
                                        <span class="font-semibold" style="color: hsl(var(--color-base));">{{ $startingPrice }}</span>@if($billingTerm)/{{ $billingTerm }}@endif
                                        @if($heroSale)<span class="inline-flex items-center gap-1 rounded-md text-sm font-semibold px-1.5 py-1 whitespace-nowrap" style="background-color: hsl(var(--color-primary)); color: white;"><svg class="w-3 h-3 flex-shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8 8H8.01M2 5.2L2 9.67451C2 10.1637 2 10.4083 2.05526 10.6385C2.10425 10.8425 2.18506 11.0376 2.29472 11.2166C2.4184 11.4184 2.59135 11.5914 2.93726 11.9373L10.6059 19.6059C11.7939 20.7939 12.388 21.388 13.0729 21.6105C13.6755 21.8063 14.3245 21.8063 14.927 21.6105C15.612 21.388 16.2061 20.7939 17.3941 19.6059L19.6059 17.3941C20.7939 16.2061 21.388 15.612 21.6105 14.927C21.8063 14.3245 21.8063 13.6755 21.6105 13.0729C21.388 12.388 20.7939 11.7939 19.6059 10.6059L11.9373 2.93726C11.5914 2.59135 11.4184 2.4184 11.2166 2.29472C11.0376 2.18506 10.8425 2.10425 10.6385 2.05526C10.4083 2 10.1637 2 9.67452 2L5.2 2C4.0799 2 3.51984 2 3.09202 2.21799C2.7157 2.40973 2.40973 2.71569 2.21799 3.09202C2 3.51984 2 4.07989 2 5.2ZM8.5 8C8.5 8.27614 8.27614 8.5 8 8.5C7.72386 8.5 7.5 8.27614 7.5 8C7.5 7.72386 7.72386 7.5 8 7.5C8.27614 7.5 8.5 7.72386 8.5 8Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>{{ $heroSale['badge'] }}</span>@endif
                                    </div>
                                @elseif(!theme('marketing2_show_starting_price', true) && theme('marketing2_enable_secondary_button'))
                                    @php
                                        $secondaryButtonLink = theme('marketing2_secondary_button_link') ?: route('home');
                                        $secondaryButtonIsExternal = filter_var($secondaryButtonLink, FILTER_VALIDATE_URL) && !str_starts_with($secondaryButtonLink, url('/'));
                                    @endphp
                                    <a href="{{ $secondaryButtonLink }}"
                                       class="inline-flex items-center justify-center px-8 py-3 bg-background-secondary border border-neutral rounded-lg hover:border-primary/30 transition-all font-medium"
                                       style="border-radius: var(--citadel-button-radius);"
                                       @if(!$secondaryButtonIsExternal) wire:navigate @else target="_blank" rel="noopener noreferrer" @endif>
                                        {{ theme('marketing2_secondary_button_text') ?: 'View All Plans' }}
                                    </a>
                                @endif
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </section>
    </div>
@else

    <section class="py-16 md:py-20">
        <div class="w-full">
            <div class="flex flex-col lg:flex-row gap-12 lg:gap-16 items-start">


                <div class="w-full lg:w-5/12 flex flex-col justify-center">

                    @if(theme('marketing2_show_trustpilot', true))
                        <div class="flex items-center gap-2 mb-5 text-sm" style="color: hsl(var(--color-base) / 0.8);">
                            <span>Rated <span class="font-bold" style="color: hsl(var(--color-base));">{{ theme('marketing2_trustpilot_rating') ?: theme('landing_trustpilot_rating') ?: 'Excellent' }}</span> on</span>
                            <img src="/assets/icons/trustpilot-light.png" alt="Trustpilot" class="h-5 dark:hidden" />
                            <img src="/assets/icons/trustpilot-dark.png" alt="Trustpilot" class="h-5 hidden dark:block" />
                        </div>
                    @endif


                    <h1 class="{{ theme('marketing2_title_size') ?: 'text-5xl sm:text-6xl lg:text-7xl' }} font-bold mb-8 leading-tight" style="color: hsl(var(--color-base));">
                        {!! Str::inlineMarkdown(theme('marketing2_title') ?: 'Powerful VPS Hosting and Web Hosting') !!}
                    </h1>


                    @if(theme('marketing2_description'))
                        <p class="{{ theme('marketing2_description_size') ?: 'text-base' }} mb-8 leading-relaxed" style="color: hsl(var(--color-base) / 0.7);">
                            {!! Str::inlineMarkdown(theme('marketing2_description')) !!}
                        </p>
                    @endif


                    @if(theme('marketing2_enable_button', true))
                        <div class="flex items-center gap-4 flex-wrap">
                            @php
                                $heroButtonLink = theme('marketing2_button_link') ?: ($firstCategory ? route('category.show', ['category' => $firstCategory->slug]) : route('home'));
                                $heroButtonIsExternal = filter_var($heroButtonLink, FILTER_VALIDATE_URL) && !str_starts_with($heroButtonLink, url('/'));
                            @endphp
                            <a href="{{ $heroButtonLink }}"
                               class="citadel-btn inline-flex items-center justify-center px-7 bg-primary text-white rounded-lg hover:opacity-90 transition-all font-medium text-sm"
                               style="border-radius: var(--citadel-button-radius);"
                               @if(!$heroButtonIsExternal) wire:navigate @else target="_blank" rel="noopener noreferrer" @endif>
                                {{ theme('marketing2_button_text') ?: 'Get Started' }}
                                <svg class="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3" />
                                </svg>
                            </a>

                            @if(theme('marketing2_show_starting_price', true) && $startingPrice)
                                <span class="text-sm" style="color: hsl(var(--color-base) / 0.6);">
                                    {{ theme('marketing2_price_prefix') ?: 'Starting at Only' }}
                                    @if($heroSale)<span class="line-through" style="color: hsl(var(--color-base) / 0.45);">{{ $heroSale['original'] }}</span> @endif<span class="font-semibold" style="color: hsl(var(--color-base));">{{ $startingPrice }}</span>@if($billingTerm)/{{ $billingTerm }}@endif@if($heroSale) <span class="inline-flex items-center gap-1 rounded-md text-sm font-semibold px-1.5 py-1 whitespace-nowrap align-middle" style="background-color: hsl(var(--color-primary)); color: white;"><svg class="w-3 h-3 flex-shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8 8H8.01M2 5.2L2 9.67451C2 10.1637 2 10.4083 2.05526 10.6385C2.10425 10.8425 2.18506 11.0376 2.29472 11.2166C2.4184 11.4184 2.59135 11.5914 2.93726 11.9373L10.6059 19.6059C11.7939 20.7939 12.388 21.388 13.0729 21.6105C13.6755 21.8063 14.3245 21.8063 14.927 21.6105C15.612 21.388 16.2061 20.7939 17.3941 19.6059L19.6059 17.3941C20.7939 16.2061 21.388 15.612 21.6105 14.927C21.8063 14.3245 21.8063 13.6755 21.6105 13.0729C21.388 12.388 20.7939 11.7939 19.6059 10.6059L11.9373 2.93726C11.5914 2.59135 11.4184 2.4184 11.2166 2.29472C11.0376 2.18506 10.8425 2.10425 10.6385 2.05526C10.4083 2 10.1637 2 9.67452 2L5.2 2C4.0799 2 3.51984 2 3.09202 2.21799C2.7157 2.40973 2.40973 2.71569 2.21799 3.09202C2 3.51984 2 4.07989 2 5.2ZM8.5 8C8.5 8.27614 8.27614 8.5 8 8.5C7.72386 8.5 7.5 8.27614 7.5 8C7.5 7.72386 7.72386 7.5 8 7.5C8.27614 7.5 8.5 7.72386 8.5 8Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>{{ $heroSale['badge'] }}</span>@endif
                                </span>
                            @elseif(!theme('marketing2_show_starting_price', true) && theme('marketing2_enable_secondary_button'))
                                @php
                                    $secondaryButtonLink = theme('marketing2_secondary_button_link') ?: route('home');
                                    $secondaryButtonIsExternal = filter_var($secondaryButtonLink, FILTER_VALIDATE_URL) && !str_starts_with($secondaryButtonLink, url('/'));
                                @endphp
                                <a href="{{ $secondaryButtonLink }}"
                                   class="inline-flex items-center justify-center px-7 py-3 bg-background-secondary border border-neutral rounded-lg hover:border-primary/30 transition-all font-medium text-sm"
                                   style="border-radius: var(--citadel-button-radius);"
                                   @if(!$secondaryButtonIsExternal) wire:navigate @else target="_blank" rel="noopener noreferrer" @endif>
                                    {{ theme('marketing2_secondary_button_text') ?: 'View All Plans' }}
                                </a>
                            @endif
                        </div>
                    @endif
                </div>


                <div class="w-full lg:w-5/12 lg:ml-auto">

                    @if($heroRightContent === 'preset_image' && $heroPresetImage === 'webhosting')

                        <div class="w-full flex items-center justify-center lg:justify-end">
                            @php
                                $svgPath = public_path("assets/images/hero/webhosting.svg");
                                
                                if (file_exists($svgPath)) {
                                    $svg = file_get_contents($svgPath);
                                    

                                    $colorReplacements = [
                                        ['#618635', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.9) calc(var(--color-primary-l) * 0.7))'],
                                        ['#7FAE46', 'hsl(var(--color-primary))'],
                                        ['#7BAE3C', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.98) calc(var(--color-primary-l) * 1.02))'],
                                        ['#9AC862', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.95) calc(var(--color-primary-l) * 0.85))'],
                                        ['#83BF3B', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.96) calc(var(--color-primary-l) * 1.05))'],
                                        ['#547130', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.85) calc(var(--color-primary-l) * 0.55))'],
                                        ['#85C03D', 'hsl(calc(var(--color-primary-h)) calc(var(--color-primary-s) * 0.96) calc(var(--color-primary-l) * 0.88))'],
                                    ];
                                    
                                    foreach ($colorReplacements as $replacement) {
                                        [$hexColor, $newColor] = $replacement;
                                        $svg = str_ireplace('fill="' . $hexColor . '"', 'fill="' . $newColor . '"', $svg);
                                        $svg = str_ireplace('stroke="' . $hexColor . '"', 'stroke="' . $newColor . '"', $svg);
                                        $svg = str_ireplace('stop-color="' . $hexColor . '"', 'stop-color="' . $newColor . '"', $svg);
                                    }
                                    

                                    $svg = preg_replace('/<svg/', '<svg class="w-full h-auto max-w-[500px] lg:max-w-full"', $svg, 1);
                                    
                                    echo $svg;
                                }
                            @endphp
                        </div>

                    @elseif($heroRightContent === 'custom_image' && theme('marketing2_hero_custom_image'))

                        <div class="w-full flex items-center justify-center lg:justify-end">
                            <img src="{{ Storage::url(theme('marketing2_hero_custom_image')) }}" alt="Hero" class="w-full h-auto max-w-[500px] lg:max-w-full object-contain" />
                        </div>

                    @else

                        @if($heroCategories->count() > 0)
                            <div class="flex flex-col gap-6 lg:gap-5">
                                @foreach($heroCategories as $index => $category)
                                    @php
                                        $catProduct = $category->products->first();
                                        $catPlan = $catProduct?->availablePlans()?->first();


                                        $introText = '';
                                        if ($category->description) {
                                            $description = strip_tags($category->description, '<ul><ol><li><p><strong><em><br>');
                                            preg_match('/^(.*?)(<ul>|<ol>|\n\n)/s', $description, $matches);
                                            $introText = trim(strip_tags($matches[1] ?? $description));
                                        }
                                    @endphp
                                    <a href="{{ route('category.show', ['category' => $category->slug]) }}" wire:navigate
                                       class="group flex items-center gap-6 p-4 rounded-xl transition-all duration-200 hover:bg-primary/[0.03]"
                                       style="border-radius: var(--citadel-card-radius);">


                                        <div class="flex items-start gap-6 flex-1 min-w-0">

                                            <span class="shrink-0 text-lg font-medium leading-[1.75rem]" style="color: hsl(var(--color-primary) / 0.3);">
                                                {{ str_pad($index + 1, 2, '0', STR_PAD_LEFT) }}
                                            </span>


                                            <div class="flex-1 min-w-0 max-w-[300px]">
                                                <h3 class="text-lg font-semibold mb-1 leading-[1.75rem] group-hover:text-primary transition-colors" style="color: hsl(var(--color-base));">
                                                    {{ $category->name }}
                                                </h3>
                                                @if($introText)
                                                    <p class="text-sm leading-relaxed line-clamp-2" style="color: hsl(var(--color-base) / 0.6);">
                                                        {{ $introText }}
                                                    </p>
                                                @endif
                                            </div>
                                        </div>


                                        <div class="shrink-0 flex items-center justify-center ml-auto">
                                            @if($category->image)
                                                <img src="{{ Storage::url($category->image) }}" alt="{{ $category->name }}" class="w-16 h-16 object-contain" />
                                            @else
                                                <svg class="w-16 h-16" style="color: hsl(var(--color-primary) / 0.5);" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                                                </svg>
                                            @endif
                                        </div>
                                    </a>
                                @endforeach
                            </div>
                        @endif
                    @endif
                </div>

            </div>
        </div>
    </section>
@endif


<section class="py-16 md:py-24">
    <div class="w-full">

        <div class="text-center mb-10">
            <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4" style="color: hsl(var(--color-base));">
                {{ theme('marketing2_bento_title') ?: 'Hosting features you will love' }}
            </h2>
            <p class="text-sm sm:text-base max-w-2xl mx-auto leading-relaxed" style="color: hsl(var(--color-base) / 0.6);">
                {{ theme('marketing2_bento_description') ?: 'Everything you need to power your online presence, backed by enterprise infrastructure.' }}
            </p>
        </div>


        <div class="flex flex-col gap-4">

            <div class="grid grid-cols-1 md:grid-cols-5 gap-4">

                <div class="md:col-span-2 bg-background-secondary border border-neutral rounded-lg p-4 flex flex-col overflow-hidden" style="border-radius: var(--citadel-card-radius);">
                    @if(theme('marketing2_bento1_image_source') === 'preset' && theme('marketing2_bento1_preset'))
                        <div class="rounded-md overflow-hidden mb-3 h-48" style="border-radius: var(--citadel-card-radius);">
                            <x-bento-svg :name="theme('marketing2_bento1_preset')" class="w-full h-full" />
                        </div>
                    @elseif(theme('marketing2_bento1_image_source') === 'custom' && theme('marketing2_bento1_image'))
                        <div class="rounded-md overflow-hidden mb-3" style="border-radius: var(--citadel-card-radius);">
                            <img src="{{ Storage::url(theme('marketing2_bento1_image')) }}" alt="{{ theme('marketing2_bento1_title') ?: 'Lightning Fast Servers' }}" class="w-full h-48 object-cover pointer-events-none" />
                        </div>
                    @endif
                    <h3 class="text-base font-semibold mb-1" style="color: hsl(var(--color-base));">
                        {{ theme('marketing2_bento1_title') ?: 'Lightning Fast Servers' }}
                    </h3>
                    <p class="text-sm leading-relaxed" style="color: hsl(var(--color-base) / 0.6);">
                        {{ theme('marketing2_bento1_description') ?: 'Enterprise-grade NVMe storage and high-frequency processors deliver blazing performance for your applications.' }}
                    </p>
                </div>


                <div class="md:col-span-3 bg-background-secondary border border-neutral rounded-lg p-4 flex flex-col overflow-hidden" style="border-radius: var(--citadel-card-radius);">
                    @if(theme('marketing2_bento2_image_source') === 'preset' && theme('marketing2_bento2_preset'))
                        <div class="rounded-md overflow-hidden mb-3 h-48" style="border-radius: var(--citadel-card-radius);">
                            <x-bento-svg :name="theme('marketing2_bento2_preset')" class="w-full h-full" />
                        </div>
                    @elseif(theme('marketing2_bento2_image_source') === 'custom' && theme('marketing2_bento2_image'))
                        <div class="rounded-md overflow-hidden mb-3" style="border-radius: var(--citadel-card-radius);">
                            <img src="{{ Storage::url(theme('marketing2_bento2_image')) }}" alt="{{ theme('marketing2_bento2_title') ?: '99.9% Uptime' }}" class="w-full h-48 object-cover pointer-events-none" />
                        </div>
                    @endif
                    <h3 class="text-base font-semibold mb-1" style="color: hsl(var(--color-base));">
                        {{ theme('marketing2_bento2_title') ?: '99.9% Uptime' }}
                    </h3>
                    <p class="text-sm leading-relaxed" style="color: hsl(var(--color-base) / 0.6);">
                        {{ theme('marketing2_bento2_description') ?: 'Fully redundant infrastructure ensures your services stay online around the clock.' }}
                    </p>
                </div>
            </div>


            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">

                <div class="bg-background-secondary border border-neutral rounded-lg p-4 flex flex-col overflow-hidden" style="border-radius: var(--citadel-card-radius);">
                    @if(theme('marketing2_bento3_image_source') === 'preset' && theme('marketing2_bento3_preset'))
                        <div class="rounded-md overflow-hidden mb-3 h-48" style="border-radius: var(--citadel-card-radius);">
                            <x-bento-svg :name="theme('marketing2_bento3_preset')" class="w-full h-full" />
                        </div>
                    @elseif(theme('marketing2_bento3_image_source') === 'custom' && theme('marketing2_bento3_image'))
                        <div class="rounded-md overflow-hidden mb-3" style="border-radius: var(--citadel-card-radius);">
                            <img src="{{ Storage::url(theme('marketing2_bento3_image')) }}" alt="{{ theme('marketing2_bento3_title') ?: 'DDoS Protection' }}" class="w-full h-48 object-cover pointer-events-none" />
                        </div>
                    @endif
                    <h3 class="text-base font-semibold mb-1" style="color: hsl(var(--color-base));">
                        {{ theme('marketing2_bento3_title') ?: 'DDoS Protection' }}
                    </h3>
                    <p class="text-sm leading-relaxed" style="color: hsl(var(--color-base) / 0.6);">
                        {{ theme('marketing2_bento3_description') ?: 'Advanced mitigation keeps your services safe from volumetric and application-layer attacks.' }}
                    </p>
                </div>


                <div class="bg-background-secondary border border-neutral rounded-lg p-4 flex flex-col overflow-hidden" style="border-radius: var(--citadel-card-radius);">
                    @if(theme('marketing2_bento4_image_source') === 'preset' && theme('marketing2_bento4_preset'))
                        <div class="rounded-md overflow-hidden mb-3 h-48" style="border-radius: var(--citadel-card-radius);">
                            <x-bento-svg :name="theme('marketing2_bento4_preset')" class="w-full h-full" />
                        </div>
                    @elseif(theme('marketing2_bento4_image_source') === 'custom' && theme('marketing2_bento4_image'))
                        <div class="rounded-md overflow-hidden mb-3" style="border-radius: var(--citadel-card-radius);">
                            <img src="{{ Storage::url(theme('marketing2_bento4_image')) }}" alt="{{ theme('marketing2_bento4_title') ?: '24/7 Expert Support' }}" class="w-full h-48 object-cover pointer-events-none" />
                        </div>
                    @endif
                    <h3 class="text-base font-semibold mb-1" style="color: hsl(var(--color-base));">
                        {{ theme('marketing2_bento4_title') ?: '24/7 Expert Support' }}
                    </h3>
                    <p class="text-sm leading-relaxed" style="color: hsl(var(--color-base) / 0.6);">
                        {{ theme('marketing2_bento4_description') ?: 'Our knowledgeable team is always available to help you with any questions or issues.' }}
                    </p>
                </div>


                <div class="bg-background-secondary border border-neutral rounded-lg p-4 flex flex-col overflow-hidden" style="border-radius: var(--citadel-card-radius);">
                    @if(theme('marketing2_bento5_image_source') === 'preset' && theme('marketing2_bento5_preset'))
                        <div class="rounded-md overflow-hidden mb-3 h-48" style="border-radius: var(--citadel-card-radius);">
                            <x-bento-svg :name="theme('marketing2_bento5_preset')" class="w-full h-full" />
                        </div>
                    @elseif(theme('marketing2_bento5_image_source') === 'custom' && theme('marketing2_bento5_image'))
                        <div class="rounded-md overflow-hidden mb-3" style="border-radius: var(--citadel-card-radius);">
                            <img src="{{ Storage::url(theme('marketing2_bento5_image')) }}" alt="{{ theme('marketing2_bento5_title') ?: 'Global Network' }}" class="w-full h-48 object-cover pointer-events-none" />
                        </div>
                    @endif
                    <h3 class="text-base font-semibold mb-1" style="color: hsl(var(--color-base));">
                        {{ theme('marketing2_bento5_title') ?: 'Global Network' }}
                    </h3>
                    <p class="text-sm leading-relaxed" style="color: hsl(var(--color-base) / 0.6);">
                        {{ theme('marketing2_bento5_description') ?: 'Strategically located data centers around the world ensure low latency for your users.' }}
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>


@php
    $plansSource = theme('marketing2_plans_source', 'top_categories');
    $plansButtonText = theme('marketing2_plans_button_text', 'Get Started');
    $plansTitle = theme('marketing2_plans_title', 'Simple, Transparent Pricing');
    $plansDescription = theme('marketing2_plans_description', '');
    $plansPopular = (int) theme('marketing2_plans_popular', 0);
    $plansIconStyle = theme('marketing2_plans_icon_style', 'none');

    
    $categoryIconOverrides = [];
    if (theme('override_category_icons')) {
        $iconsData = json_decode(theme('category_icons_data', '[]'), true) ?: [];
        foreach ($iconsData as $entry) {
            if (!empty($entry['category_id']) && !empty($entry['icon'])) {
                $categoryIconOverrides[(int) $entry['category_id']] = $entry['icon'];
            }
        }
    }

    if ($plansSource === 'specific_category') {
        $plansCategoryId = theme('marketing2_plans_category_id');
        $plansCategory = $plansCategoryId
            ? \App\Models\Category::where('id', $plansCategoryId)
                ->with(['products' => function ($query) {
                    $query->where('hidden', false)
                        ->with(['plans.prices'])
                        ->orderBy('sort')
                        ->limit(4);
                }])
                ->first()
            : null;
        $plansProducts = $plansCategory ? $plansCategory->products : collect();


        $availableTerms = [];
        $productPricesByTerm = [];
        if ($plansProducts->count() > 0) {
            foreach ($plansProducts as $prod) {
                foreach ($prod->availablePlans() as $plan) {
                    $termKey = $plan->billing_period . '_' . $plan->billing_unit . '_' . $plan->type;
                    if (!isset($availableTerms[$termKey])) {

                        $availableTerms[$termKey] = [
                            'key' => $termKey,
                            'label' => $plan->name,
                            'billing_period' => $plan->billing_period,
                            'billing_unit' => $plan->billing_unit,
                            'type' => $plan->type,
                        ];
                    }

                    $priceObj = $plan->price();
                    if ($priceObj && $priceObj->available) {
                        $planSale = citadel_plan_sale($prod, $plan);
                        $productPricesByTerm[$prod->id][$termKey] = [
                            'price' => (string) $priceObj->formatted->price,
                            'original' => $planSale['original'] ?? null,
                            'badge' => $planSale['badge'] ?? null,
                            'billing_period' => $plan->billing_period,
                            'billing_unit' => $plan->billing_unit,
                            'type' => $plan->type,
                        ];
                    }
                }
            }
            $availableTerms = array_values($availableTerms);
        }
    } else {
        $plansCategories = \App\Models\Category::whereNull('parent_id')
            ->where(function ($query) {
                $query->whereHas('children')
                    ->orWhereHas('products', function ($query) {
                        $query->where('hidden', false);
                    });
            })
            ->with(['products' => function ($query) {
                $query->where('hidden', false)
                    ->with(['plans.prices'])
                    ->orderBy('sort')
                    ->limit(1);
            }])
            ->orderBy('sort')
            ->limit(3)
            ->get();
    }
@endphp
<section class="py-16 md:py-24">
    <div class="w-full">

        <div class="text-center mb-12">
            <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4" style="color: hsl(var(--color-base));">
                {{ $plansTitle }}
            </h2>
            @if($plansDescription)
                <p class="text-sm sm:text-base max-w-2xl mx-auto leading-relaxed" style="color: hsl(var(--color-base) / 0.6);">
                    {{ $plansDescription }}
                </p>
            @endif
        </div>

        <style>
            .plans-check-list ul {
                list-style: none !important;
                padding-left: 0 !important;
            }
            .plans-check-list ul li {
                display: flex !important;
                align-items: flex-start !important;
                gap: 10px;
            }
            .plans-check-list ul li > p {
                display: inline !important;
                margin: 0 !important;
            }
            .plans-check-list ul li::before {
                content: '';
                flex-shrink: 0;
                display: block;
                width: 18px;
                min-width: 18px;
                height: 18px;
                margin-top: 2px;
                background-color: var(--check-color);
                -webkit-mask-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='18' height='18' viewBox='0 0 18 18' fill='none'%3E%3Ccircle cx='9' cy='9' r='7.5' stroke='currentColor' stroke-width='1.5'/%3E%3Cpath d='M6.75 9L8.25 10.5L11.25 7.5' stroke='currentColor' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
                mask-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='18' height='18' viewBox='0 0 18 18' fill='none'%3E%3Ccircle cx='9' cy='9' r='7.5' stroke='currentColor' stroke-width='1.5'/%3E%3Cpath d='M6.75 9L8.25 10.5L11.25 7.5' stroke='currentColor' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
                -webkit-mask-repeat: no-repeat;
                mask-repeat: no-repeat;
                -webkit-mask-size: contain;
                mask-size: contain;
            }
            .plans-check-list strong,
            .plans-check-list b {
                color: inherit !important;
            }
        </style>

        @if($plansSource === 'top_categories' && isset($plansCategories) && $plansCategories->count() > 0)

            <div class="max-w-7xl mx-auto">
                <div class="flex flex-wrap justify-center gap-5">
                @foreach($plansCategories as $catIndex => $planCategory)
                    @php
                        $catIsPopular = $plansPopular === ($catIndex + 1);
                        $catProduct = $planCategory->products->first();
                        $catPlan = $catProduct?->availablePlans()?->first();
                        $catPrice = '';
                        $catBillingTerm = '';
                        $catSale = null;
                        if ($catProduct && $catProduct->price()->available) {
                            $catLtp = theme('show_lowest_term_price', false) ? citadel_lowest_term_price($catProduct) : null;
                            if ($catLtp) {
                                $catPlan = $catLtp['plan'];
                                $catPrice = $catLtp['formatted'];
                            } else {
                                $catPrice = $catProduct->price()->formatted->price;
                                $catSale = citadel_product_sale($catProduct);
                            }
                            if ($catPlan && $catPlan->type == 'recurring') {
                                if ($catPlan->billing_period == 1) {
                                    $catBillingTerm = trans_choice(__('services.billing_cycles.' . $catPlan->billing_unit), 1);
                                } elseif ($catPlan->billing_period == 3 && $catPlan->billing_unit == 'month') {
                                    $catBillingTerm = __('citadel::citadel.plans.quarter');
                                } elseif ($catPlan->billing_period == 6 && $catPlan->billing_unit == 'month') {
                                    $catBillingTerm = __('citadel::citadel.plans.6_months');
                                } elseif ($catPlan->billing_period == 12 && $catPlan->billing_unit == 'month') {
                                    $catBillingTerm = __('citadel::citadel.plans.year');
                                } else {
                                    $catBillingTerm = $catPlan->billing_period . ' ' .
                                        trans_choice(__('services.billing_cycles.' . $catPlan->billing_unit), $catPlan->billing_period);
                                }
                            }
                        }


                        $catIconUrl = null;
                        $catIconIsCitadel = false;
                        $catIconName = null;
                        if (isset($categoryIconOverrides[$planCategory->id])) {
                            $catIconName = $categoryIconOverrides[$planCategory->id];
                            $catIconUrl = asset('assets/icons/citadel/' . $catIconName . '.svg');
                            $catIconIsCitadel = true;
                        } elseif ($planCategory->image) {
                            $catIconUrl = Storage::url($planCategory->image);
                        }
                        $hasIcon = $plansIconStyle !== 'none' && $catIconUrl;
                    @endphp
                    <div class="{{ $catIsPopular ? '' : 'bg-background-secondary' }} border rounded-xl {{ ($plansIconStyle === 'background' || $plansIconStyle === 'corner') && $hasIcon ? '' : 'p-6' }} flex flex-col w-full md:w-[calc(50%-0.625rem)] xl:w-[calc(25%-0.9375rem)] max-w-sm {{ $catIsPopular ? (($plansIconStyle === 'background' || $plansIconStyle === 'corner') && $hasIcon ? '' : 'py-10') : ($plansPopular ? (($plansIconStyle === 'background' || $plansIconStyle === 'corner') && $hasIcon ? '' : 'md:pt-10') : '') }} relative overflow-hidden"
                        style="border-color: {{ $catIsPopular ? 'hsl(var(--color-primary) / 0.5)' : 'hsl(var(--color-neutral))' }}; {{ $catIsPopular ? 'background-color: hsl(var(--color-primary));' : '' }} border-radius: var(--citadel-card-radius);">


                        @if($plansIconStyle === 'background' && $hasIcon)
                            <div class="relative w-full h-32 mb-0">
                                <div class="absolute inset-0 flex items-center justify-center">
                                    @if($catIconIsCitadel)
                                        <x-svg-icon name="citadel/{{ $catIconName }}" class="w-full h-full p-6 object-contain" />
                                    @else
                                        <img src="{{ $catIconUrl }}" alt="{{ $planCategory->name }}" class="w-full h-full object-cover" />
                                    @endif
                                </div>
                                <div class="absolute inset-0" style="background: linear-gradient(to top, {{ $catIsPopular ? 'hsl(var(--color-primary))' : 'hsl(var(--color-background-secondary))' }} 0%, {{ $catIsPopular ? 'hsl(var(--color-primary) / 0.85)' : 'hsl(var(--color-background-secondary) / 0.7)' }} 40%, {{ $catIsPopular ? 'hsl(var(--color-primary) / 0.3)' : 'hsl(var(--color-background-secondary) / 0.2)' }} 100%);"></div>
                            </div>
                            <div class="p-6 pt-0 flex flex-col flex-1">
                        @elseif($plansIconStyle === 'corner' && $hasIcon)
                            <div class="absolute -top-4 -right-4 w-36 h-36 opacity-15 rotate-12 pointer-events-none">
                                @if($catIconIsCitadel)
                                    <x-svg-icon name="citadel/{{ $catIconName }}" class="w-full h-full" />
                                @else
                                    <img src="{{ $catIconUrl }}" alt="" class="w-full h-full object-cover" />
                                @endif
                            </div>
                            <div class="p-6 {{ $catIsPopular ? 'py-10' : ($plansPopular ? 'md:pt-10' : '') }} flex flex-col flex-1 relative z-[1]">
                        @else
                            <div class="flex flex-col flex-1">
                        @endif

                        @if($catIsPopular)
                            <span class="absolute top-4 right-4 inline-flex items-center px-3 py-1 rounded-full text-xs font-bold z-[2]"
                                style="background-color: #fff; color: hsl(var(--color-primary));">
                                {{ __('citadel::citadel.plans.most_popular') }}
                            </span>
                        @endif


                        @if($plansIconStyle === 'top' && $hasIcon)
                            <div class="flex justify-center {{ $catIsPopular ? 'mt-6' : ($plansPopular ? 'md:mt-6' : '') }} mb-4">
                                @if($catIconIsCitadel)
                                    <x-svg-icon name="citadel/{{ $catIconName }}" class="w-16 h-16" />
                                @else
                                    <img src="{{ $catIconUrl }}" alt="{{ $planCategory->name }}" class="w-16 h-16 object-contain rounded-lg" style="{{ $catIsPopular ? 'filter: brightness(0) invert(1);' : '' }} border-radius: var(--citadel-card-radius);" />
                                @endif
                            </div>
                        @endif


                        @if($plansIconStyle === 'right' && $hasIcon)
                            <div class="flex items-center justify-between {{ $catIsPopular ? 'mt-6' : ($plansPopular ? 'md:mt-6' : '') }} mb-3">
                                <h3 class="text-2xl font-bold" style="color: {{ $catIsPopular ? '#fff' : 'hsl(var(--color-base))' }};">
                                    {{ $planCategory->name }}
                                </h3>
                                @if($catIconIsCitadel)
                                    <x-svg-icon name="citadel/{{ $catIconName }}" class="w-14 h-14 flex-shrink-0" />
                                @else
                                    <img src="{{ $catIconUrl }}" alt="{{ $planCategory->name }}" class="w-14 h-14 object-contain flex-shrink-0 rounded-lg" style="{{ $catIsPopular ? 'filter: brightness(0) invert(1);' : '' }} border-radius: var(--citadel-card-radius);" />
                                @endif
                            </div>
                        @else
                            <h3 class="text-2xl font-bold {{ $plansIconStyle !== 'top' ? ($catIsPopular ? 'mt-6' : ($plansPopular ? 'md:mt-6' : '')) : '' }} mb-3" style="color: {{ $catIsPopular ? '#fff' : 'hsl(var(--color-base))' }};">
                                {{ $planCategory->name }}
                            </h3>
                        @endif


                        @if($catPrice)
                            <div class="mb-6">
                                <p class="text-xs mb-2" style="color: {{ $catIsPopular ? 'rgba(255,255,255,0.7)' : 'hsl(var(--color-base) / 0.5)' }};">{{ __('citadel::citadel.plans.starting_at') }}</p>
                                <div class="flex items-baseline gap-1.5 flex-wrap">
                                    <span class="text-2xl font-semibold" style="color: {{ $catIsPopular ? '#fff' : 'hsl(var(--color-base))' }};">{{ $catPrice }}</span>
                                    @if($catBillingTerm)
                                        <span class="text-sm font-medium" style="color: {{ $catIsPopular ? 'rgba(255,255,255,0.7)' : 'hsl(var(--color-base) / 0.5)' }};">/{{ $catBillingTerm }}</span>
                                    @endif
                                </div>
                                @if($catSale)
                                    <div class="flex items-center gap-1.5 flex-wrap mt-1">
                                        <span class="text-sm font-medium line-through" style="color: {{ $catIsPopular ? 'rgba(255,255,255,0.7)' : 'hsl(var(--color-base) / 0.45)' }};">{{ $catSale['original'] }}</span>
                                        <span class="inline-flex items-center gap-1 rounded-md text-sm font-semibold px-1.5 py-1 whitespace-nowrap" style="background-color: hsl(var(--color-primary)); color: white;"><svg class="w-3 h-3 flex-shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8 8H8.01M2 5.2L2 9.67451C2 10.1637 2 10.4083 2.05526 10.6385C2.10425 10.8425 2.18506 11.0376 2.29472 11.2166C2.4184 11.4184 2.59135 11.5914 2.93726 11.9373L10.6059 19.6059C11.7939 20.7939 12.388 21.388 13.0729 21.6105C13.6755 21.8063 14.3245 21.8063 14.927 21.6105C15.612 21.388 16.2061 20.7939 17.3941 19.6059L19.6059 17.3941C20.7939 16.2061 21.388 15.612 21.6105 14.927C21.8063 14.3245 21.8063 13.6755 21.6105 13.0729C21.388 12.388 20.7939 11.7939 19.6059 10.6059L11.9373 2.93726C11.5914 2.59135 11.4184 2.4184 11.2166 2.29472C11.0376 2.18506 10.8425 2.10425 10.6385 2.05526C10.4083 2 10.1637 2 9.67452 2L5.2 2C4.0799 2 3.51984 2 3.09202 2.21799C2.7157 2.40973 2.40973 2.71569 2.21799 3.09202C2 3.51984 2 4.07989 2 5.2ZM8.5 8C8.5 8.27614 8.27614 8.5 8 8.5C7.72386 8.5 7.5 8.27614 7.5 8C7.5 7.72386 7.72386 7.5 8 7.5C8.27614 7.5 8.5 7.72386 8.5 8Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>{{ $catSale['badge'] }}</span>
                                    </div>
                                @endif
                            </div>
                        @endif


                        <a href="{{ route('category.show', ['category' => $planCategory->slug]) }}" wire:navigate
                            class="citadel-btn w-full inline-flex items-center justify-center px-4 rounded-lg text-sm font-medium transition-colors mb-6 {{ $catIsPopular ? 'hover:opacity-90' : ($plansPopular ? '' : 'hover:opacity-90') }}"
                            style="{{ $catIsPopular
                                ? 'background-color: #fff; color: hsl(var(--color-primary));'
                                : ($plansPopular
                                    ? 'background-color: hsl(var(--color-neutral)); color: hsl(var(--color-base)); border: 1.5px solid hsl(var(--color-neutral) / 0.6);'
                                    : 'background-color: hsl(var(--color-primary)); color: white;') }} border-radius: var(--citadel-button-radius);"
                            {{ !$catIsPopular && $plansPopular ? 'onmouseover=this.style.opacity="0.8" onmouseout=this.style.opacity="1"' : '' }}>
                            {{ $plansButtonText }}
                        </a>


                        <div class="border-t-2 mb-6 {{ ($plansIconStyle === 'background' || $plansIconStyle === 'corner') && $hasIcon ? 'relative w-full' : 'relative -left-6 w-[calc(100%+3rem)]' }}" style="border-color: {{ $catIsPopular ? 'rgba(255,255,255,0.2)' : 'hsl(var(--color-neutral) / 0.75)' }};"></div>


                        @if($planCategory->description)
                            @php
                                $catDescHtml = $planCategory->description;
                                preg_match_all('/<(ul|ol)\b[^>]*>.*?<\/\1>/is', $catDescHtml, $catListMatches);
                                $catDescLists = implode('', $catListMatches[0] ?? []);
                                $catDescText = trim(preg_replace('/<(ul|ol)\b[^>]*>.*?<\/\1>/is', '', $catDescHtml));
                            @endphp
                            <div class="flex-1">
                                @if($catDescText)
                                    <article class="prose dark:prose-invert prose-sm max-w-none text-left
                                        [&_p]:mb-2 [&_p]:text-sm [&_p]:leading-relaxed
                                        [&_strong]:font-semibold [&_strong]:text-sm"
                                        style="color: {{ $catIsPopular ? 'rgba(255,255,255,0.85)' : 'hsl(var(--color-base) / 0.7)' }};">
                                        {!! $catDescText !!}
                                    </article>
                                @endif
                                @if($catDescLists)
                                    <h4 class="text-sm font-semibold {{ $catDescText ? 'mt-4' : '' }} mb-4" style="color: {{ $catIsPopular ? 'rgba(255,255,255,0.9)' : 'hsl(var(--color-base) / 0.8)' }};">{{ __('citadel::citadel.plans.whats_included') }}</h4>
                                    <article class="prose dark:prose-invert prose-sm max-w-none text-left
                                        [&_ol]:list-decimal [&_li]:mb-1.5 [&_li]:text-sm [&_li]:leading-relaxed
                                        [&_ol]:pl-5 [&_p]:mb-2 [&_li_p]:mb-0 [&_ul]:space-y-1.5
                                        [&_strong]:font-semibold [&_strong]:text-sm [&_p]:text-sm [&_p]:leading-relaxed"
                                        style="color: {{ $catIsPopular ? 'rgba(255,255,255,0.85)' : 'hsl(var(--color-base) / 0.7)' }};">
                                        <div class="plans-check-list" style="--check-color: {{ $catIsPopular ? '#fff' : 'hsl(var(--color-primary))' }};">
                                            {!! $catDescLists !!}
                                        </div>
                                    </article>
                                @endif
                            </div>
                        @endif

                        </div> 
                    </div>
                @endforeach
                </div>
            </div>

        @elseif($plansSource === 'specific_category' && isset($plansProducts) && $plansProducts->count() > 0)

            <div class="max-w-7xl mx-auto" x-data="{
                selectedTerm: '{{ $availableTerms[0]['key'] ?? '' }}',
                terms: @js($availableTerms ?? []),
                prices: @js($productPricesByTerm ?? []),
                getPrice(productId) {
                    const p = this.prices[productId];
                    if (!p) return null;
                    return p[this.selectedTerm] || null;
                },
                getBillingLabel(productId) {
                    const price = this.getPrice(productId);
                    if (!price) return '';
                    if (price.type === 'one-time') return '{{ __('citadel::citadel.plans.one_time_payment') }}';
                    const period = parseInt(price.billing_period);
                    const unit = price.billing_unit;
                    if (period === 1 && unit === 'month') return '{{ __('citadel::citadel.plans.billed_every_month') }}';
                    if (period === 1 && unit === 'year') return '{{ __('citadel::citadel.plans.billed_every_year') }}';
                    if (period === 1 && unit === 'day') return '{{ __('citadel::citadel.plans.billed_every_day') }}';
                    if (period === 3 && unit === 'month') return '{{ __('citadel::citadel.plans.billed_every_quarter') }}';
                    if (period === 6 && unit === 'month') return '{{ __('citadel::citadel.plans.billed_every_6_months') }}';
                    if (period === 12 && unit === 'month') return '{{ __('citadel::citadel.plans.billed_every_year') }}';
                    if (period === 1) return '{{ __('citadel::citadel.plans.billed_every') }}'.replace(':period', unit);
                    return '{{ __('citadel::citadel.plans.billed_every') }}'.replace(':period', period + ' ' + unit + 's');
                },
                getTermLabel(key) {
                    const term = this.terms.find(t => t.key === key);
                    return term ? term.label : '';
                }
            }">

                @if(count($availableTerms) > 1)
                    <div class="flex justify-center mb-10">
                        <div class="inline-flex items-center rounded-xl p-1.5 gap-1.5" style="background-color: hsl(var(--color-neutral) / 0.25); border-radius: var(--citadel-card-radius);">
                            <template x-for="term in terms" :key="term.key">
                                <button type="button"
                                    @click="selectedTerm = term.key"
                                    :style="selectedTerm === term.key
                                        ? 'background-color: hsl(var(--color-primary) / 0.2); color: hsl(var(--color-primary)); border-color: hsl(var(--color-primary) / 0.4); border-radius: var(--citadel-button-radius);'
                                        : 'background-color: hsl(var(--color-neutral) / 0.15); color: hsl(var(--color-base) / 0.6); border-color: transparent; border-radius: var(--citadel-button-radius);'"
                                    class="px-5 py-2 rounded-lg text-sm font-semibold transition-all duration-200 cursor-pointer border"
                                    :class="selectedTerm === term.key ? '' : 'hover:opacity-80'"
                                    x-text="term.label">
                                </button>
                            </template>
                        </div>
                    </div>
                @endif

                <div class="flex flex-wrap justify-center gap-5">
                @foreach($plansProducts as $prodIndex => $planProduct)
                    @php
                        $prodIsPopular = $plansPopular === ($prodIndex + 1);


                        $prodIconUrl = null;
                        $prodIconIsCitadel = false;
                        $prodIconName = null;
                        if ($plansCategory) {
                            if (isset($categoryIconOverrides[$plansCategory->id])) {
                                $prodIconName = $categoryIconOverrides[$plansCategory->id];
                                $prodIconUrl = asset('assets/icons/citadel/' . $prodIconName . '.svg');
                                $prodIconIsCitadel = true;
                            } elseif ($plansCategory->image) {
                                $prodIconUrl = Storage::url($plansCategory->image);
                            }
                        }
                        $hasIcon = $plansIconStyle !== 'none' && $prodIconUrl;
                    @endphp
                    <div class="{{ $prodIsPopular ? '' : 'bg-background-secondary' }} border rounded-xl {{ ($plansIconStyle === 'background' || $plansIconStyle === 'corner') && $hasIcon ? '' : 'p-6' }} flex flex-col w-full md:w-[calc(50%-0.625rem)] xl:w-[calc(25%-0.9375rem)] max-w-sm {{ $prodIsPopular ? (($plansIconStyle === 'background' || $plansIconStyle === 'corner') && $hasIcon ? '' : 'py-10') : ($plansPopular ? (($plansIconStyle === 'background' || $plansIconStyle === 'corner') && $hasIcon ? '' : 'md:pt-10') : '') }} relative overflow-hidden"
                        style="border-color: {{ $prodIsPopular ? 'hsl(var(--color-primary) / 0.5)' : 'hsl(var(--color-neutral))' }}; {{ $prodIsPopular ? 'background-color: hsl(var(--color-primary));' : '' }} border-radius: var(--citadel-card-radius);">


                        @if($plansIconStyle === 'background' && $hasIcon)
                            <div class="relative w-full h-32 mb-0">
                                <div class="absolute inset-0 flex items-center justify-center">
                                    @if($prodIconIsCitadel)
                                        <x-svg-icon name="citadel/{{ $prodIconName }}" class="w-full h-full p-6 object-contain" />
                                    @else
                                        <img src="{{ $prodIconUrl }}" alt="{{ $planProduct->name }}" class="w-full h-full object-cover" />
                                    @endif
                                </div>
                                <div class="absolute inset-0" style="background: linear-gradient(to top, {{ $prodIsPopular ? 'hsl(var(--color-primary))' : 'hsl(var(--color-background-secondary))' }} 0%, {{ $prodIsPopular ? 'hsl(var(--color-primary) / 0.85)' : 'hsl(var(--color-background-secondary) / 0.7)' }} 40%, {{ $prodIsPopular ? 'hsl(var(--color-primary) / 0.3)' : 'hsl(var(--color-background-secondary) / 0.2)' }} 100%);"></div>
                            </div>
                            <div class="p-6 pt-0 flex flex-col flex-1">
                        @elseif($plansIconStyle === 'corner' && $hasIcon)
                            <div class="absolute -top-4 -right-4 w-36 h-36 opacity-15 rotate-12 pointer-events-none">
                                @if($prodIconIsCitadel)
                                    <x-svg-icon name="citadel/{{ $prodIconName }}" class="w-full h-full" />
                                @else
                                    <img src="{{ $prodIconUrl }}" alt="" class="w-full h-full object-cover" />
                                @endif
                            </div>
                            <div class="p-6 {{ $prodIsPopular ? 'py-10' : ($plansPopular ? 'md:pt-10' : '') }} flex flex-col flex-1 relative z-[1]">
                        @else
                            <div class="flex flex-col flex-1">
                        @endif

                        @if($prodIsPopular)
                            <span class="absolute top-4 right-4 inline-flex items-center px-3 py-1 rounded-full text-xs font-bold z-[2]"
                                style="background-color: #fff; color: hsl(var(--color-primary));">
                                {{ __('citadel::citadel.plans.most_popular') }}
                            </span>
                        @endif


                        @if($plansIconStyle === 'top' && $hasIcon)
                            <div class="flex justify-center {{ $prodIsPopular ? 'mt-6' : ($plansPopular ? 'md:mt-6' : '') }} mb-4">
                                @if($prodIconIsCitadel)
                                    <x-svg-icon name="citadel/{{ $prodIconName }}" class="w-16 h-16" />
                                @else
                                    <img src="{{ $prodIconUrl }}" alt="{{ $planProduct->name }}" class="w-16 h-16 object-contain rounded-lg" style="{{ $prodIsPopular ? 'filter: brightness(0) invert(1);' : '' }} border-radius: var(--citadel-card-radius);" />
                                @endif
                            </div>
                        @endif


                        @if($plansIconStyle === 'right' && $hasIcon)
                            <div class="flex items-center justify-between {{ $prodIsPopular ? 'mt-6' : ($plansPopular ? 'md:mt-6' : '') }} mb-3">
                                <h3 class="text-2xl font-bold" style="color: {{ $prodIsPopular ? '#fff' : 'hsl(var(--color-base))' }};">
                                    {{ $planProduct->name }}
                                </h3>
                                @if($prodIconIsCitadel)
                                    <x-svg-icon name="citadel/{{ $prodIconName }}" class="w-14 h-14 flex-shrink-0" />
                                @else
                                    <img src="{{ $prodIconUrl }}" alt="{{ $planProduct->name }}" class="w-14 h-14 object-contain flex-shrink-0 rounded-lg" style="{{ $prodIsPopular ? 'filter: brightness(0) invert(1);' : '' }} border-radius: var(--citadel-card-radius);" />
                                @endif
                            </div>
                        @else
                            <h3 class="text-2xl font-bold {{ $plansIconStyle !== 'top' ? ($prodIsPopular ? 'mt-6' : ($plansPopular ? 'md:mt-6' : '')) : '' }} mb-3" style="color: {{ $prodIsPopular ? '#fff' : 'hsl(var(--color-base))' }};">
                                {{ $planProduct->name }}
                            </h3>
                        @endif


                        <div class="mb-6">
                            <template x-if="getPrice({{ $planProduct->id }})">
                                <div>
                                    <div class="mb-1 flex items-baseline gap-2 flex-wrap">
                                        <span class="text-2xl font-semibold" style="color: {{ $prodIsPopular ? '#fff' : 'hsl(var(--color-base))' }};"
                                            x-text="getPrice({{ $planProduct->id }}).price"></span>
                                    </div>
                                    <div class="flex items-center gap-2 flex-wrap mb-1" x-show="getPrice({{ $planProduct->id }}).original || getPrice({{ $planProduct->id }}).badge">
                                        <span class="text-sm font-medium line-through" style="color: {{ $prodIsPopular ? 'rgba(255,255,255,0.7)' : 'hsl(var(--color-base) / 0.45)' }};"
                                            x-show="getPrice({{ $planProduct->id }}).original"
                                            x-text="getPrice({{ $planProduct->id }}).original"></span>
                                        <span class="inline-flex items-center gap-1 rounded-md text-sm font-semibold px-1.5 py-1 whitespace-nowrap"
                                            style="background-color: hsl(var(--color-primary)); color: white;"
                                            x-show="getPrice({{ $planProduct->id }}).badge">
                                            <svg class="w-3 h-3 flex-shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8 8H8.01M2 5.2L2 9.67451C2 10.1637 2 10.4083 2.05526 10.6385C2.10425 10.8425 2.18506 11.0376 2.29472 11.2166C2.4184 11.4184 2.59135 11.5914 2.93726 11.9373L10.6059 19.6059C11.7939 20.7939 12.388 21.388 13.0729 21.6105C13.6755 21.8063 14.3245 21.8063 14.927 21.6105C15.612 21.388 16.2061 20.7939 17.3941 19.6059L19.6059 17.3941C20.7939 16.2061 21.388 15.612 21.6105 14.927C21.8063 14.3245 21.8063 13.6755 21.6105 13.0729C21.388 12.388 20.7939 11.7939 19.6059 10.6059L11.9373 2.93726C11.5914 2.59135 11.4184 2.4184 11.2166 2.29472C11.0376 2.18506 10.8425 2.10425 10.6385 2.05526C10.4083 2 10.1637 2 9.67452 2L5.2 2C4.0799 2 3.51984 2 3.09202 2.21799C2.7157 2.40973 2.40973 2.71569 2.21799 3.09202C2 3.51984 2 4.07989 2 5.2ZM8.5 8C8.5 8.27614 8.27614 8.5 8 8.5C7.72386 8.5 7.5 8.27614 7.5 8C7.5 7.72386 7.72386 7.5 8 7.5C8.27614 7.5 8.5 7.72386 8.5 8Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                            <span x-text="getPrice({{ $planProduct->id }}).badge"></span>
                                        </span>
                                    </div>
                                    <span class="text-xs font-medium" style="color: {{ $prodIsPopular ? 'rgba(255,255,255,0.7)' : 'hsl(var(--color-base) / 0.5)' }};"
                                        x-text="getBillingLabel({{ $planProduct->id }})"></span>
                                </div>
                            </template>
                            <template x-if="!getPrice({{ $planProduct->id }})">
                                <div>
                                    <span class="text-xs" style="color: {{ $prodIsPopular ? 'rgba(255,255,255,0.5)' : 'hsl(var(--color-base) / 0.5)' }};">—</span>
                                </div>
                            </template>
                        </div>


                        <a href="{{ route('products.checkout', ['category' => $plansCategory, 'product' => $planProduct->slug]) }}" wire:navigate
                            class="citadel-btn w-full inline-flex items-center justify-center px-4 rounded-lg text-sm font-medium transition-colors mb-6 {{ $prodIsPopular ? 'hover:opacity-90' : ($plansPopular ? '' : 'hover:opacity-90') }}"
                            style="{{ $prodIsPopular
                                ? 'background-color: #fff; color: hsl(var(--color-primary));'
                                : ($plansPopular
                                    ? 'background-color: hsl(var(--color-neutral)); color: hsl(var(--color-base)); border: 1.5px solid hsl(var(--color-neutral) / 0.6);'
                                    : 'background-color: hsl(var(--color-primary)); color: white;') }} border-radius: var(--citadel-button-radius);"
                            {{ !$prodIsPopular && $plansPopular ? 'onmouseover=this.style.opacity="0.8" onmouseout=this.style.opacity="1"' : '' }}>
                            {{ $plansButtonText }}
                        </a>


                        <div class="border-t-2 mb-6 {{ ($plansIconStyle === 'background' || $plansIconStyle === 'corner') && $hasIcon ? 'relative w-full' : 'relative -left-6 w-[calc(100%+3rem)]' }}" style="border-color: {{ $prodIsPopular ? 'rgba(255,255,255,0.2)' : 'hsl(var(--color-neutral) / 0.75)' }};"></div>


                        @if($planProduct->description)
                            @php
                                $prodDescHtml = $planProduct->description;
                                preg_match_all('/<(ul|ol)\b[^>]*>.*?<\/\1>/is', $prodDescHtml, $prodListMatches);
                                $prodDescLists = implode('', $prodListMatches[0] ?? []);
                                $prodDescText = trim(preg_replace('/<(ul|ol)\b[^>]*>.*?<\/\1>/is', '', $prodDescHtml));
                            @endphp
                            <div class="flex-1">
                                @if($prodDescText)
                                    <article class="prose dark:prose-invert prose-sm max-w-none text-left
                                        [&_p]:mb-2 [&_p]:text-sm [&_p]:leading-relaxed
                                        [&_strong]:font-semibold [&_strong]:text-sm"
                                        style="color: {{ $prodIsPopular ? 'rgba(255,255,255,0.85)' : 'hsl(var(--color-base) / 0.7)' }};">
                                        {!! $prodDescText !!}
                                    </article>
                                @endif
                                @if($prodDescLists)
                                    <h4 class="text-sm font-semibold {{ $prodDescText ? 'mt-4' : '' }} mb-4" style="color: {{ $prodIsPopular ? 'rgba(255,255,255,0.9)' : 'hsl(var(--color-base) / 0.8)' }};">{{ __('citadel::citadel.plans.whats_included') }}</h4>
                                    <article class="prose dark:prose-invert prose-sm max-w-none text-left
                                        [&_ol]:list-decimal [&_li]:mb-1.5 [&_li]:text-sm [&_li]:leading-relaxed
                                        [&_ol]:pl-5 [&_p]:mb-2 [&_li_p]:mb-0 [&_ul]:space-y-1.5
                                        [&_strong]:font-semibold [&_strong]:text-sm [&_p]:text-sm [&_p]:leading-relaxed"
                                        style="color: {{ $prodIsPopular ? 'rgba(255,255,255,0.85)' : 'hsl(var(--color-base) / 0.7)' }};">
                                        <div class="plans-check-list" style="--check-color: {{ $prodIsPopular ? '#fff' : 'hsl(var(--color-primary))' }};">
                                            {!! $prodDescLists !!}
                                        </div>
                                    </article>
                                @endif
                            </div>
                        @endif

                        </div> 
                    </div>
                @endforeach
                </div>
            </div>
        @endif
    </div>
</section>


@php
    $featuresTitle = theme('marketing2_features_title', 'Every plan includes everything you need');
    $featuresDescription = theme('marketing2_features_description', 'Every plan comes fully loaded with all the essentials, powerful performance, reliable support, and zero hidden extras. Just pick your plan and get started.');
    $featuresIconBg = theme('marketing2_features_icon_bg', true);
    $featuresData = json_decode(theme('marketing2_features_data', '[]'), true) ?: [];
@endphp

@if(count($featuresData) > 0)
<section class="py-16 md:py-24">
    <div class="w-full">

        <div class="text-center mb-12">
            <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4" style="color: hsl(var(--color-base));">
                {{ $featuresTitle }}
            </h2>
            @if($featuresDescription)
                <p class="text-sm sm:text-base max-w-2xl mx-auto leading-relaxed" style="color: hsl(var(--color-base) / 0.6);">
                    {{ $featuresDescription }}
                </p>
            @endif
        </div>

        <div class="max-w-7xl mx-auto">
            <div class="flex flex-wrap justify-center gap-6">
                @foreach($featuresData as $feature)
                    @php
                        $fTitle = $feature['title'] ?? '';
                        $fDesc = $feature['description'] ?? '';
                        $fIconType = $feature['icon_type'] ?? 'citadel';
                        $fIconCitadel = $feature['icon_citadel'] ?? '';
                        $fIconRemix = $feature['icon_remix'] ?? '';
                    @endphp
                    @if($fTitle)
                        <div class="w-full sm:w-[calc(50%-0.75rem)] xl:w-[calc(25%-1.125rem)] p-6 rounded-xl text-center" style="border-radius: var(--citadel-card-radius);">


                            <div class="mx-auto mb-4 flex items-center justify-center {{ $featuresIconBg ? 'w-20 h-20 rounded-2xl' : '' }}"
                                @if($featuresIconBg) style="background-color: hsl(var(--color-primary) / 0.1); border-radius: var(--citadel-card-radius);" @endif>
                                @if($fIconType === 'citadel' && $fIconCitadel)
                                    <x-citadel-icon :name="$fIconCitadel" class="{{ $featuresIconBg ? 'w-16 h-16' : 'w-16 h-16' }}" />
                                @elseif($fIconType === 'remix' && $fIconRemix)
                                    <x-dynamic-component :component="$fIconRemix" class="{{ $featuresIconBg ? 'size-10' : 'size-12' }}" style="color: hsl(var(--color-primary));" />
                                @else
                                    <x-ri-checkbox-circle-line class="{{ $featuresIconBg ? 'size-10' : 'size-12' }}" style="color: hsl(var(--color-primary));" />
                                @endif
                            </div>


                            <h3 class="text-base font-semibold mb-2" style="color: hsl(var(--color-base));">
                                {{ $fTitle }}
                            </h3>


                            @if($fDesc)
                                <p class="text-sm leading-relaxed" style="color: hsl(var(--color-base) / 0.6);">
                                    {{ $fDesc }}
                                </p>
                            @endif
                        </div>
                    @endif
                @endforeach
            </div>
        </div>

    </div>
</section>
@endif


@php
    $reviewsTitle = theme('marketing2_reviews_title', 'What our customers say');
    $reviewsDescription = theme('marketing2_reviews_description', '');
    $reviewsData = json_decode(theme('marketing2_reviews_data', '[]'), true) ?: [];
@endphp

@if(count($reviewsData) > 0)
<section class="py-16 md:py-24 relative left-[50%] right-[50%] -ml-[50vw] -mr-[50vw] w-screen overflow-hidden">
    <div class="w-full">

        <div class="text-center mb-12 max-w-4xl mx-auto px-4">
            <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4" style="color: hsl(var(--color-base));">
                {{ $reviewsTitle }}
            </h2>
            @if($reviewsDescription)
                <p class="text-sm sm:text-base max-w-2xl mx-auto leading-relaxed" style="color: hsl(var(--color-base) / 0.6);">
                    {{ $reviewsDescription }}
                </p>
            @endif
        </div>

        @php
            $mid = (int) ceil(count($reviewsData) / 2);
            $row1 = array_slice($reviewsData, 0, $mid);
            $row2 = array_slice($reviewsData, $mid);
            if (empty($row2)) $row2 = $row1;
        @endphp


        <div class="group mb-4" style="--review-count: {{ count($row1) }};">
            <div class="flex gap-4 animate-scroll-left group-hover:[animation-play-state:paused]">
                @for($ri = 0; $ri < 2; $ri++)
                    @foreach($row1 as $review)
                        <div class="review-card flex-shrink-0 w-[350px] sm:w-[400px] p-6 rounded-2xl border border-neutral bg-background-secondary transition-all duration-300" style="border-radius: var(--citadel-card-radius);">
                            <div class="flex items-center gap-3 mb-4">
                                @if(!empty($review['image']))
                                    <img src="{{ asset('storage/' . $review['image']) }}" alt="{{ $review['name'] ?? '' }}"
                                         class="w-10 h-10 rounded-full object-cover flex-shrink-0"
                                         style="border: 2px solid hsl(var(--color-primary) / 0.2);" />
                                @else
                                    <div class="w-10 h-10 rounded-full flex-shrink-0 flex items-center justify-center text-sm font-semibold"
                                         style="background-color: hsl(var(--color-primary) / 0.15); color: hsl(var(--color-primary));">
                                        {{ strtoupper(substr($review['name'] ?? '?', 0, 1)) }}
                                    </div>
                                @endif
                                <span class="font-semibold text-sm" style="color: hsl(var(--color-base));">
                                    {{ $review['name'] ?? 'Anonymous' }}
                                </span>
                            </div>
                            <p class="text-sm leading-relaxed" style="color: hsl(var(--color-base) / 0.7);">
                                {{ $review['review'] ?? '' }}
                            </p>
                        </div>
                    @endforeach
                @endfor
            </div>
        </div>

        <div class="group" style="--review-count: {{ count($row2) }};">
            <div class="flex gap-4 animate-scroll-right group-hover:[animation-play-state:paused]">
                @for($ri = 0; $ri < 2; $ri++)
                    @foreach($row2 as $review)
                        <div class="review-card flex-shrink-0 w-[350px] sm:w-[400px] p-6 rounded-2xl border border-neutral bg-background-secondary transition-all duration-300" style="border-radius: var(--citadel-card-radius);">
                            <div class="flex items-center gap-3 mb-4">
                                @if(!empty($review['image']))
                                    <img src="{{ asset('storage/' . $review['image']) }}" alt="{{ $review['name'] ?? '' }}"
                                         class="w-10 h-10 rounded-full object-cover flex-shrink-0"
                                         style="border: 2px solid hsl(var(--color-primary) / 0.2);" />
                                @else
                                    <div class="w-10 h-10 rounded-full flex-shrink-0 flex items-center justify-center text-sm font-semibold"
                                         style="background-color: hsl(var(--color-primary) / 0.15); color: hsl(var(--color-primary));">
                                        {{ strtoupper(substr($review['name'] ?? '?', 0, 1)) }}
                                    </div>
                                @endif
                                <span class="font-semibold text-sm" style="color: hsl(var(--color-base));">
                                    {{ $review['name'] ?? 'Anonymous' }}
                                </span>
                            </div>
                            <p class="text-sm leading-relaxed" style="color: hsl(var(--color-base) / 0.7);">
                                {{ $review['review'] ?? '' }}
                            </p>
                        </div>
                    @endforeach
                @endfor
            </div>
        </div>

    </div>
</section>

<style>
    @keyframes scroll-left {
        0% { transform: translateX(0); }
        100% { transform: translateX(-50%); }
    }
    @keyframes scroll-right {
        0% { transform: translateX(-50%); }
        100% { transform: translateX(0); }
    }
    .animate-scroll-left {
        animation: scroll-left calc(var(--review-count, 4) * 8s) linear infinite;
        width: max-content;
    }
    .animate-scroll-right {
        animation: scroll-right calc(var(--review-count, 4) * 8s) linear infinite;
        width: max-content;
    }
    .review-card:hover {
        border-color: hsl(var(--color-primary) / 0.5);
        transform: scale(1.02);
    }
</style>
@endif


@php
    $faqTitle = theme('marketing2_faq_title', 'Frequently Asked Questions');
    $faqDescription = theme('marketing2_faq_description', '');
    $faqData = json_decode(theme('marketing2_faq_data', '[]'), true) ?: [];
@endphp

@if(count($faqData) > 0)
<section class="py-16 md:py-24">
    <div class="w-full">

        <div class="text-center mb-12">
            <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4" style="color: hsl(var(--color-base));">
                {{ $faqTitle }}
            </h2>
            @if($faqDescription)
                <p class="text-sm sm:text-base max-w-2xl mx-auto leading-relaxed" style="color: hsl(var(--color-base) / 0.6);">
                    {{ $faqDescription }}
                </p>
            @endif
        </div>

        <div class="max-w-3xl mx-auto flex flex-col gap-3" x-data="{ activeFaq: null }">
            @foreach($faqData as $faqIndex => $faq)
                @if(!empty($faq['question']))
                    <div class="rounded-2xl border border-neutral bg-background-secondary overflow-hidden transition-all duration-300" style="border-radius: var(--citadel-card-radius);">
                        <button class="w-full flex items-center justify-between gap-4 p-5 text-left cursor-pointer"
                                @click="activeFaq = activeFaq === {{ $faqIndex }} ? null : {{ $faqIndex }}">
                            <span class="font-semibold text-sm sm:text-base" style="color: hsl(var(--color-base));">
                                {{ $faq['question'] }}
                            </span>
                            <svg class="w-5 h-5 flex-shrink-0 transition-transform duration-300"
                                 :class="{ 'rotate-180': activeFaq === {{ $faqIndex }} }"
                                 style="color: hsl(var(--color-primary));"
                                 fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                            </svg>
                        </button>
                        <div x-show="activeFaq === {{ $faqIndex }}"
                             x-collapse
                             x-cloak>
                            <div class="px-5 pb-5">
                                <p class="text-sm leading-relaxed" style="color: hsl(var(--color-base) / 0.7);">
                                    {{ $faq['answer'] ?? '' }}
                                </p>
                            </div>
                        </div>
                    </div>
                @endif
            @endforeach
        </div>

    </div>
</section>
@endif

@php
    $ctaBgType = theme('marketing2_cta_bg_type', 'gradient');
    $ctaTitle = theme('marketing2_cta_title', 'Ready to get started?');
    $ctaDescription = theme('marketing2_cta_description', 'Join thousands of satisfied customers and take your business to the next level today.');
    $ctaBtn1Enabled = theme('marketing2_cta_btn1_enabled', true);
    $ctaBtn1Text = theme('marketing2_cta_btn1_text', 'Get Started');
    $ctaBtn1Link = theme('marketing2_cta_btn1_link', '/register');
    $ctaBtn2Enabled = theme('marketing2_cta_btn2_enabled', false);
    $ctaBtn2Text = theme('marketing2_cta_btn2_text', 'Contact Sales');
    $ctaBtn2Link = theme('marketing2_cta_btn2_link', '/contact');
    $ctaBgImage = theme('marketing2_cta_bg_image', '');
    $ctaCustomHtml = theme('marketing2_cta_custom_html', '');
    $ctaHasButtons = $ctaBtn1Enabled || $ctaBtn2Enabled;
    $ctaBtn1External = filter_var($ctaBtn1Link, FILTER_VALIDATE_URL) && ! str_starts_with($ctaBtn1Link, url('/'));
    $ctaBtn2External = filter_var($ctaBtn2Link, FILTER_VALIDATE_URL) && ! str_starts_with($ctaBtn2Link, url('/'));
@endphp

<section class="py-16 md:py-24">
    <div class="w-full">
        @if($ctaBgType === 'custom' && $ctaCustomHtml)
            {!! $ctaCustomHtml !!}
        @else
            <div class="relative rounded-3xl overflow-hidden px-6 sm:px-12 py-14 sm:py-20 text-center"
                @if($ctaBgType === 'image' && $ctaBgImage)
                    style="background-image: url('{{ Storage::url($ctaBgImage) }}'); background-size: cover; background-position: center; border-radius: var(--citadel-card-radius);"
                @else
                    style="background: linear-gradient(135deg, hsl(var(--color-primary)), hsl(var(--color-primary) / 0.8)); border-radius: var(--citadel-card-radius);"
                @endif
            >

                @if($ctaBgType === 'image' && $ctaBgImage)
                    <div class="absolute inset-0" style="background: hsl(var(--color-primary) / 0.75);"></div>
                @endif

                <div class="relative z-10">
                    @if($ctaTitle)
                        <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4" style="color: #ffffff;">
                            {{ $ctaTitle }}
                        </h2>
                    @endif

                    @if($ctaDescription)
                        <p class="text-sm sm:text-base max-w-2xl mx-auto leading-relaxed mb-8" style="color: #ffffff;">
                            {{ $ctaDescription }}
                        </p>
                    @endif

                    @if($ctaHasButtons)
                        <div class="flex flex-wrap gap-4 justify-center">
                            @if($ctaBtn1Enabled)
                                <a href="{{ $ctaBtn1Link }}"
                                   @if($ctaBtn1External) target="_blank" rel="noopener noreferrer" @else wire:navigate @endif
                                   class="citadel-btn inline-flex items-center px-8 rounded-xl font-medium text-sm transition-all duration-300 hover:scale-105"
                                   style="background-color: white; color: hsl(var(--color-primary)); border-radius: var(--citadel-button-radius);">
                                    {{ $ctaBtn1Text }}
                                </a>
                            @endif
                            @if($ctaBtn2Enabled)
                                <a href="{{ $ctaBtn2Link }}"
                                   @if($ctaBtn2External) target="_blank" rel="noopener noreferrer" @else wire:navigate @endif
                                   class="citadel-btn inline-flex items-center px-8 rounded-xl font-medium text-sm transition-all duration-300 hover:scale-105 border"
                                   style="border-color: white; color: white; background: transparent; border-radius: var(--citadel-button-radius);">
                                    {{ $ctaBtn2Text }}
                                </a>
                            @endif
                        </div>
                    @endif
                </div>
            </div>
        @endif
    </div>
</section>
@endif