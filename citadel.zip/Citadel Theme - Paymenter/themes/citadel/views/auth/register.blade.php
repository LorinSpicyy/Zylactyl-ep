
<div data-auth-flow="enrollment" class="min-h-screen flex">
    
    <div class="w-full lg:w-1/2 flex flex-col justify-between px-8 lg:px-16 py-8">
        
        <div class="flex items-center gap-3 mb-8">
            <x-logo class="h-8" />
            @if(!theme('logo_only_display'))
            <span class="text-xl font-semibold" style="color: hsl(var(--color-base));">{{ config('app.name') }}</span>
            @endif
        </div>

        
        <div class="flex-grow flex items-center justify-center">
            <form class="w-full max-w-md" wire:submit.prevent="submit" id="register"
                x-data="{
                    step: 1,
                    totalSteps: 2,
                    step1Fields: ['first_name', 'last_name', 'email', 'password', 'password_confirm'],
                    init() {
                        this.$watch('step', () => {});
                        const form = this.$el;
                        const observer = new MutationObserver(() => {
                            this.$nextTick(() => this.checkErrors());
                        });
                        observer.observe(form, { childList: true, subtree: true });
                    },
                    checkErrors() {
                        const form = this.$el;
                        const step1Container = form.querySelector('[data-step=\'1\']');
                        const step2Container = form.querySelector('[data-step=\'2\']');
                        if (!step1Container || !step2Container) return;
                        const step1Errors = step1Container.querySelectorAll('[id$=\'-error\']');
                        const step2Errors = step2Container.querySelectorAll('[id$=\'-error\']');
                        if (step1Errors.length > 0) {
                            this.step = 1;
                        } else if (step2Errors.length > 0) {
                            this.step = 2;
                        }
                    },
                    nextStep() {
                        let valid = true;
                        const fields = this.step1Fields;
                        for (const f of fields) {
                            const el = this.$el.querySelector('[name=\'' + f + '\']');
                            if (el && el.hasAttribute('required') && !el.value.trim()) {
                                valid = false;
                                el.focus();
                                break;
                            }
                        }
                        const pw = this.$el.querySelector('[name=\'password\']');
                        const pwc = this.$el.querySelector('[name=\'password_confirm\']');
                        if (valid && pw && pwc && pw.value !== pwc.value) {
                            pwc.focus();
                            valid = false;
                        }
                        if (valid) this.step = 2;
                    },
                    prevStep() { this.step = 1; }
                }">
                <div class="mb-8">
                    <h1 class="text-3xl font-bold mb-2" style="color: hsl(var(--color-base));">{{ __('auth.sign_up_title') }}</h1>
                    <p class="text-sm" style="color: hsl(var(--color-base) / 0.6);">{{ __('citadel::citadel.auth.register.subtitle') }}</p>
                </div>

                <div class="flex items-center justify-between mb-8">
                    <div class="flex items-center gap-2">
                        <button type="button" @click="step = 1"
                            class="flex items-center justify-center w-10 h-10 rounded-lg text-sm font-bold transition-all duration-300 cursor-pointer"
                            :class="step === 1 ? 'text-white bg-primary' : 'text-white/60 bg-primary/30'">
                            1
                        </button>
                        <button type="button" @click="if (step > 1) step = 2"
                            class="flex items-center justify-center w-10 h-10 rounded-lg text-sm font-bold transition-all duration-300"
                            :class="step === 2 ? 'text-white bg-primary cursor-pointer' : 'bg-primary/30 text-white/60 cursor-default'">
                            2
                        </button>
                    </div>
                    <button x-show="step === 2" x-transition type="button" @click="prevStep()"
                        class="flex items-center gap-1.5 text-sm font-medium transition-all duration-200 cursor-pointer hover:opacity-70"
                        style="color: hsl(var(--color-base) / 0.6);">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
                        {{ __('citadel::citadel.auth.register.back') }}
                    </button>
                </div>

                <div data-step="1" x-show="step === 1" x-transition:enter="transition ease-out duration-200" x-transition:enter-start="opacity-0 translate-x-4" x-transition:enter-end="opacity-100 translate-x-0">
                    <div class="space-y-5">
                        <div class="grid grid-cols-2 gap-4">
                            <x-form.input name="first_name" type="text" :label="__('general.input.first_name')"
                                :placeholder="__('general.input.first_name_placeholder')" wire:model="first_name" required />
                            <x-form.input name="last_name" type="text" :label="__('general.input.last_name')"
                                :placeholder="__('general.input.last_name_placeholder')" wire:model="last_name" required />
                        </div>

                        <x-form.input name="email" type="email" :label="__('general.input.email')"
                            :placeholder="__('general.input.email_placeholder')" required wire:model="email" />

                        <div class="grid grid-cols-2 gap-4">
                            <x-form.input name="password" type="password" :label="__('Password')" :placeholder="__('Your password')"
                                wire:model="password" required />
                            <x-form.input name="password_confirm" type="password" :label="__('citadel::citadel.auth.register.confirm_password')"
                                :placeholder="__('Confirm your password')" wire:model="password_confirmation" required />
                        </div>

                        <button type="button" @click="nextStep()"
                            class="w-full py-3 px-4 rounded-lg text-sm font-semibold text-white transition-all duration-200 hover:opacity-90 bg-primary cursor-pointer">
                            {{ __('citadel::citadel.auth.register.next') }}
                        </button>
                    </div>
                </div>

                <div data-step="2" x-show="step === 2" x-transition:enter="transition ease-out duration-200" x-transition:enter-start="opacity-0 translate-x-4" x-transition:enter-end="opacity-100 translate-x-0">
                    <div class="space-y-5">
                        <x-form.properties :custom_properties="$custom_properties" :properties="$properties" />
                    
                        @if(config('settings.tos'))
                            <x-form.checkbox wire:model="tos" name="tos" required>
                                {{ __('product.tos') }}
                                <a href="{{ config('settings.tos') }}" target="_blank" style="color: hsl(var(--color-primary));" class="hover:underline">
                                    {{ __('product.tos_link') }}
                                </a>
                            </x-form.checkbox>
                        @endif

                        <x-captcha :form="'register'" />

                        <x-button.primary class="w-full" type="submit">{{ __('citadel::citadel.auth.register.button') }}</x-button.primary>
                    </div>
                </div>

                <div class="text-center mt-6">
                    <span class="text-sm" style="color: hsl(var(--color-base) / 0.7);">{{ __('auth.already_have_account') }}</span>
                    <a class="text-sm font-medium hover:underline ml-1" style="color: hsl(var(--color-primary));" href="{{ route('login') }}">
                        {{ __('auth.sign_in') }}
                    </a>
                </div>
            </form>
        </div>

        
        <div class="mt-8">
            <p class="text-xs" style="color: hsl(var(--color-base) / 0.5);">
                {{ __('© :year :app_name. All rights reserved.', ['year' => date('Y'), 'app_name' => config('app.name')]) }}
            </p>
        </div>
    </div>

    
    <div class="hidden lg:flex lg:w-1/2 items-center justify-center p-4">
        @if(theme('auth_page_image'))
        <div class="w-full h-full overflow-hidden rounded-lg">
            <img src="{{ asset('storage/' . theme('auth_page_image')) }}" alt="Authentication" class="w-full h-full object-cover" />
        </div>
        @else
        <div class="w-full h-full overflow-hidden rounded-lg flex items-center justify-center" style="background: linear-gradient(135deg, hsl(var(--color-primary) / 0.1) 0%, hsl(var(--color-primary) / 0.05) 100%);">
            <div class="text-center px-8">
                <svg class="w-24 h-24 mx-auto mb-4" style="color: hsl(var(--color-primary) / 0.3);" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
                </svg>
                <p class="text-lg font-medium" style="color: hsl(var(--color-base) / 0.4);">Configure your authentication image in theme settings</p>
            </div>
        </div>
        @endif
    </div>
</div>