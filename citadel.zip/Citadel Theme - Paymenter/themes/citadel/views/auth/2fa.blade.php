
<div data-auth-flow="verification" class="min-h-screen flex">
    
    <div class="w-full lg:w-1/2 flex flex-col justify-between px-8 lg:px-16 py-8">
        
        <div class="flex items-center gap-3 mb-8">
            <x-logo class="h-8" />
            @if(!theme('logo_only_display'))
            <span class="text-xl font-semibold" style="color: hsl(var(--color-base));">{{ config('app.name') }}</span>
            @endif
        </div>

        
        <div class="flex-grow flex items-center justify-center">
            <form class="w-full max-w-md" wire:submit.prevent="verify">
                @csrf
                <div class="mb-8">
                    <h1 class="text-3xl font-bold mb-2" style="color: hsl(var(--color-base));">{{ __('auth.verify_2fa') }}</h1>
                    <p class="text-sm" style="color: hsl(var(--color-base) / 0.6);">{{ __('citadel::citadel.auth.two_factor.subtitle') }}</p>
                </div>

                <div class="space-y-5">
                    <x-form.input name="code" type="text" :label="__('account.input.two_factor_code')" :placeholder="__('account.input.two_factor_code_placeholder')" wire:model="code" required />

                    <x-button.primary class="w-full" type="submit">{{ __('auth.verify') }}</x-button.primary>
                </div>

                <div class="text-center mt-6">
                    <a class="text-sm font-medium hover:underline" style="color: hsl(var(--color-primary));" href="{{ route('login') }}" wire:navigate>
                        {{ __('citadel::citadel.auth.back_to_login') }}
                    </a>
                </div>
            </form>
        </div>

        
        <div class="mt-8">
            <p class="text-xs" style="color: hsl(var(--color-base) / 0.5);">
                {{ __('© :year :app_name. All rights reserved.', ['year' => date('Y'), 'app_name' => config('app.name')]) }}
            </p>
        </div>
    </div>

    
    <div class="hidden lg:flex lg:w-1/2 items-center justify-center p-4">
        @if(theme('auth_page_image'))
        <div class="w-full h-full overflow-hidden rounded-lg">
            <img src="{{ asset('storage/' . theme('auth_page_image')) }}" alt="Authentication" class="w-full h-full object-cover" />
        </div>
        @else
        <div class="w-full h-full overflow-hidden rounded-lg flex items-center justify-center" style="background: linear-gradient(135deg, hsl(var(--color-primary) / 0.1) 0%, hsl(var(--color-primary) / 0.05) 100%);">
            <div class="text-center px-8">
                <svg class="w-24 h-24 mx-auto mb-4" style="color: hsl(var(--color-primary) / 0.3);" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
                <p class="text-lg font-medium" style="color: hsl(var(--color-base) / 0.4);">Configure your authentication image in theme settings</p>
            </div>
        </div>
        @endif
    </div>
</div>