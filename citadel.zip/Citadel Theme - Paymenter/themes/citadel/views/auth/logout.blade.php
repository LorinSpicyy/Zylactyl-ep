<div>
    <button wire:click="logout" class="text-sm font-medium w-full text-left cursor-pointer">
        {{ __('auth.logout') }}
    </button>
</div>