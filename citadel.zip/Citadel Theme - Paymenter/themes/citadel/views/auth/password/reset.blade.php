
<div data-auth-flow="recovery" class="min-h-screen flex">
    
    <div class="w-full lg:w-1/2 flex flex-col justify-between px-8 lg:px-16 py-8">
        
        <div class="flex items-center gap-3 mb-8">
            <x-logo class="h-8" />
            @if(!theme('logo_only_display'))
            <span class="text-xl font-semibold" style="color: hsl(var(--color-base));">{{ config('app.name') }}</span>
            @endif
        </div>

        
        <div class="flex-grow flex items-center justify-center">
            <form class="w-full max-w-md" wire:submit="submit" id="reset">
                <div class="mb-8">
                    <h1 class="text-3xl font-bold mb-2" style="color: hsl(var(--color-base));">{{ __('auth.reset_password') }}</h1>
                    <p class="text-sm" style="color: hsl(var(--color-base) / 0.6);">{{ __('citadel::citadel.auth.password_reset.subtitle') }}</p>
                </div>

                <div class="space-y-5">
                    <x-form.input name="email" type="email" :label="__('auth.input.email_label')" :placeholder="__('auth.input.email')"
                        wire:model="email" required disabled />
                        
                    <x-form.input name="password" type="password" :label="__('Password')" :placeholder="__('Your password')"
                        wire:model="password" required />
                    <x-form.input name="password_confirm" type="password" :label="__('Password')"
                        :placeholder="__('Confirm your password')" wire:model="password_confirmation" required />

                    <x-captcha :form="'reset'" />

                    <x-button.primary class="w-full" type="submit">{{ __('auth.reset_password') }}</x-button.primary>
                </div>

                <div class="text-center mt-6">
                    <a class="text-sm font-medium hover:underline" style="color: hsl(var(--color-primary));" href="{{ route('login') }}" wire:navigate>
                        {{ __('citadel::citadel.auth.back_to_login') }}
                    </a>
                </div>
            </form>
        </div>

        
        <div class="mt-8">
            <p class="text-xs" style="color: hsl(var(--color-base) / 0.5);">
                {{ __('© :year :app_name. All rights reserved.', ['year' => date('Y'), 'app_name' => config('app.name')]) }}
            </p>
        </div>
    </div>

  
    <div class="hidden lg:flex lg:w-1/2 items-center justify-center p-4">
        @if(theme('auth_page_image'))
        <div class="w-full h-full overflow-hidden rounded-lg">
            <img src="{{ asset('storage/' . theme('auth_page_image')) }}" alt="Authentication" class="w-full h-full object-cover" />
        </div>
        @else
        <div class="w-full h-full overflow-hidden rounded-lg flex items-center justify-center" style="background: linear-gradient(135deg, hsl(var(--color-primary) / 0.1) 0%, hsl(var(--color-primary) / 0.05) 100%);">
            <div class="text-center px-8">
                <svg class="w-24 h-24 mx-auto mb-4" style="color: hsl(var(--color-primary) / 0.3);" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
                </svg>
                <p class="text-lg font-medium" style="color: hsl(var(--color-base) / 0.4);">Configure your authentication image in theme settings</p>
            </div>
        </div>
        @endif
    </div>
</div>