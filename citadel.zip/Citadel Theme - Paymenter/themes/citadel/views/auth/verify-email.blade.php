
<div data-auth-flow="confirmation" class="min-h-screen flex items-center justify-center px-8 py-8">
    <div class="w-full max-w-md">
        <div class="mb-8">
            <h1 class="text-3xl font-bold mb-2" style="color: hsl(var(--color-base));">{{ __('auth.verification.notice') }}</h1>
            <p class="text-sm" style="color: hsl(var(--color-base) / 0.6);">{{ __('auth.verification.check_your_email') }}</p>
        </div>

        <form class="space-y-5" wire:submit.prevent="submit" id="verify-email">
            <x-captcha :form="'verify-email'" />

            <div class="p-4 rounded-lg" style="background-color: hsl(var(--color-primary) / 0.1); border-left: 4px solid hsl(var(--color-primary));">
                <p class="text-sm" style="color: hsl(var(--color-base) / 0.8);">{{ __('auth.verification.not_received') }}</p>
            </div>

            <x-button.primary class="w-full" type="submit">{{ __('auth.verification.request_another') }}</x-button.primary>
        </form>

        <div class="text-center mt-6">
            <livewire:auth.logout />
        </div>
    </div>
</div>