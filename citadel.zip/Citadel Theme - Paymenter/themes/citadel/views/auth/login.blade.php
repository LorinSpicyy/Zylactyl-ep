
<div data-auth-flow="credentials" class="min-h-screen flex">
    
    <div class="w-full lg:w-1/2 flex flex-col justify-between px-8 lg:px-16 py-8">
        
        <div class="flex items-center gap-3 mb-8">
            <x-logo class="h-8" />
            @if(!theme('logo_only_display'))
            <span class="text-xl font-semibold" style="color: hsl(var(--color-base));">{{ config('app.name') }}</span>
            @endif
        </div>

        
        <div class="flex-grow flex items-center justify-center">
            <form class="w-full max-w-md" wire:submit="submit" id="login">
                <div class="mb-8">
                    <h1 class="text-3xl font-bold mb-2" style="color: hsl(var(--color-base));">{{ __('auth.sign_in_title') }}</h1>
                    <p class="text-sm" style="color: hsl(var(--color-base) / 0.6);">{{ __('citadel::citadel.auth.login.subtitle') }}</p>
                </div>

                <div class="space-y-5">
                    <x-form.input name="email" type="email" :label="__('general.input.email')"
                        :placeholder="__('general.input.email_placeholder')" wire:model="email" hideRequiredIndicator required />
                    
                    <x-form.input name="password" type="password" :label="__('general.input.password')"
                        :placeholder="__('general.input.password_placeholder')" required hideRequiredIndicator wire:model="password" />
                    
                    <div class="flex items-center justify-between">
                        <x-form.checkbox name="remember" :label="__('citadel::citadel.auth.login.remember_me')" wire:model="remember" />
                        <a class="text-sm hover:underline transition-colors" style="color: hsl(var(--color-primary));"
                            href="{{ route('password.request') }}">
                            {{ __('auth.forgot_password') }}
                        </a>
                    </div>

                    <x-captcha :form="'login'" />

                    <x-button.primary class="w-full" type="submit">{{ __('auth.sign_in') }}</x-button.primary>
                </div>

                @if (config('settings.oauth_github') || config('settings.oauth_google') || config('settings.oauth_discord'))
                <div class="mt-6">
                    <div class="relative flex items-center my-6">
                        <div class="flex-grow border-t" style="border-color: hsl(var(--color-base) / 0.2);"></div>
                        <span class="px-4 text-xs font-medium" style="color: hsl(var(--color-base) / 0.5);">
                            {{ __('auth.or_sign_in_with') }}
                        </span>
                        <div class="flex-grow border-t" style="border-color: hsl(var(--color-base) / 0.2);"></div>
                    </div>
                    
                    <div class="flex flex-wrap gap-3">
                        @foreach (['github', 'google', 'discord'] as $provider)
                        @if (config('settings.oauth_' . $provider))
                        <a href="{{ route('oauth.redirect', $provider) }}"
                            class="flex items-center justify-center px-4 h-10 border rounded-md transition-all"
                            style="border-color: hsl(var(--color-base) / 0.2); color: hsl(var(--color-base) / 0.8); background-color: hsl(var(--color-base) / 0.03);"
                            onmouseover="this.style.backgroundColor = 'hsl(var(--color-base) / 0.08)'"
                            onmouseout="this.style.backgroundColor = 'hsl(var(--color-base) / 0.03)'">
                            <img src="/assets/images/{{ $provider }}-dark.svg" alt="{{ $provider }}"
                                class="w-5 h-5 mr-2 dark:inline hidden">
                            <img src="/assets/images/{{ $provider }}-light.svg" alt="{{ $provider }}"
                                class="w-5 h-5 mr-2 inline dark:hidden">
                            {{ __(ucfirst($provider)) }}
                        </a>
                        @endif
                        @endforeach
                    </div>
                </div>
                @endif

                @if(!config('settings.registration_disabled', false))
                <div class="text-center mt-6">
                    <span class="text-sm" style="color: hsl(var(--color-base) / 0.7);">{{ __('auth.dont_have_account') }}</span>
                    <a class="text-sm font-medium hover:underline ml-1" style="color: hsl(var(--color-primary));" href="{{ route('register') }}">
                        {{ __('auth.sign_up') }}
                    </a>
                </div>
                @endif
            </form>
        </div>

        
        <div class="mt-8">
            <p class="text-xs" style="color: hsl(var(--color-base) / 0.5);">
                {{ __('© :year :app_name. All rights reserved.', ['year' => date('Y'), 'app_name' => config('app.name')]) }}
            </p>
        </div>
    </div>

   
    <div class="hidden lg:flex lg:w-1/2 items-center justify-center p-4">
        @if(theme('auth_page_image'))
        <div class="w-full h-full overflow-hidden rounded-lg">
            <img src="{{ asset('storage/' . theme('auth_page_image')) }}" alt="Authentication" class="w-full h-full object-cover" />
        </div>
        @else
        <div class="w-full h-full overflow-hidden rounded-lg flex items-center justify-center" style="background: linear-gradient(135deg, hsl(var(--color-primary) / 0.1) 0%, hsl(var(--color-primary) / 0.05) 100%);">
            <div class="text-center px-8">
                <svg class="w-24 h-24 mx-auto mb-4" style="color: hsl(var(--color-primary) / 0.3);" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
                <p class="text-lg font-medium" style="color: hsl(var(--color-base) / 0.4);">Configure your authentication image in theme settings</p>
            </div>
        </div>
        @endif
    </div>
</div>