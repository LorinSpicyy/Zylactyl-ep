
<div class="pt-8 pb-32 flex flex-col md:grid md:grid-cols-4 gap-6 min-h-screen" x-data="{
    scrollToAuth() {
        const authSection = document.querySelector('.guest-auth-section');
        if (authSection) {
            authSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    },
    highlightAuthFields() {
        
        const errorSection = document.querySelector('.guest-checkout-error');
        if (errorSection) {
            errorSection.style.display = 'block';
            
            window.scrollTo({ 
                top: 0, 
                behavior: 'smooth' 
            });
        }
        
        setTimeout(() => {
            
            const emailFields = document.querySelectorAll('.guest-auth-section input[type=email], .guest-auth-section input[name=email]');
            const passwordFields = document.querySelectorAll('.guest-auth-section input[type=password], .guest-auth-section input[name=password]');
            
            
            const authFields = [...emailFields, ...passwordFields];
            
            authFields.forEach(field => {
                
                const originalClasses = field.className;
                
                
                field.className = field.className
                    .replace('border-neutral', 'border-red-500')
                    .replace('focus:border-primary/40', 'focus:border-red-600')
                    .replace('hover:border-neutral', 'hover:border-red-600');
                
                
                if (!field.className.includes('bg-red-50')) {
                    field.className += ' bg-red-50';
                }
                
                
                if (!field.className.includes('focus:ring')) {
                    field.className += ' focus:ring-2 focus:ring-red-200';
                }
                
                
                field.addEventListener('focus', function() {
                    this.className = originalClasses;
                }, { once: true });
            });
        }, 500);
    }
}" @refresh-cart.window="setTimeout(() => $wire.$refresh(), 100)">
    <div class="flex flex-col gap-4 w-full col-span-3">
        @if (optional(Cart::items())->count() === 0)
            
            <div class="bg-background-secondary border border-neutral rounded-lg p-8 text-center mt-[77px]">
                <div class="flex flex-col items-center gap-4">
                    <svg class="w-16 h-16 text-neutral/40" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 3h2l.4 2M7 13h10l4-8H5.4m2.6 8L6 5H3m4 8a2 2 0 100 4 2 2 0 000-4zm10 0a2 2 0 100 4 2 2 0 000-4z"/>
                    </svg>
                    <h1 class="page-title text-center">
                        {{ __('product.empty_cart') }}
                    </h1>
                    <p class="card-content text-center text-muted max-w-md">
                        {{ __('citadel::citadel.cart.empty_cart_description') }}
                    </p>
                </div>
            </div>
        @else
            
            <h1 class="page-title mb-4">{{ __('citadel::citadel.cart.page_title') }}</h1>
            
            
            @if ($errors->any())
                <div class="bg-red-50 border border-red-200 text-sm text-red-800 rounded-lg p-4 mb-6 dark:bg-red-800/10 dark:border-red-900 dark:text-red-500" 
                     role="alert" tabindex="-1" aria-labelledby="cart-errors-label"
                     x-data="{ 
                         init() {
                             // Scroll to top when errors are present
                             this.$nextTick(() => {
                                 window.scrollTo({ 
                                     top: 0, 
                                     behavior: 'smooth' 
                                 });
                             });
                         }
                     }">
                    <div class="flex">
                        <div class="shrink-0">
                            <svg class="shrink-0 size-4 mt-0.5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="12" cy="12" r="10"></circle>
                                <path d="m15 9-6 6"></path>
                                <path d="m9 9 6 6"></path>
                            </svg>
                        </div>
                        <div class="ms-4">
                            <h3 id="cart-errors-label" class="text-sm font-semibold">
                                {{ __('citadel::citadel.cart.error_title') }}
                            </h3>
                            <div class="mt-2 text-sm text-red-700 dark:text-red-400">
                                <ul class="list-disc space-y-1 ps-5">
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            @endif

            
            @if (session('info'))
                <div class="bg-blue-50 border border-blue-200 text-sm text-blue-800 rounded-lg p-4 mb-6 dark:bg-blue-800/10 dark:border-blue-900 dark:text-blue-500" role="alert">
                    <div class="flex">
                        <div class="shrink-0">
                            <svg class="shrink-0 size-4 mt-0.5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="12" cy="12" r="10"></circle>
                                <path d="m9 12 2 2 4-4"></path>
                            </svg>
                        </div>
                        <div class="ms-4">
                            <h3 class="text-sm font-semibold">{{ __('citadel::citadel.cart.info_title') }}</h3>
                            <div class="mt-2 text-sm text-blue-700 dark:text-blue-400">
                                <p>{{ session('info') }}</p>
                            </div>
                        </div>
                    </div>
                </div>
            @endif

            
            @if (session('warning'))
                <div class="bg-yellow-50 border border-yellow-200 text-sm text-yellow-800 rounded-lg p-4 mb-6 dark:bg-yellow-800/10 dark:border-yellow-900 dark:text-yellow-500" role="alert">
                    <div class="flex">
                        <div class="shrink-0">
                            <svg class="shrink-0 size-4 mt-0.5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"></path>
                                <path d="M12 9v4"></path>
                                <path d="m12 17 .01 0"></path>
                            </svg>
                        </div>
                        <div class="ms-4">
                            <h3 class="text-sm font-semibold">{{ __('citadel::citadel.cart.warning_title') }}</h3>
                            <div class="mt-2 text-sm text-yellow-700 dark:text-yellow-400">
                                <p>{{ session('warning') }}</p>
                            </div>
                        </div>
                    </div>
                </div>
            @endif

            
            @error('tos')
                <div class="bg-red-50 border border-red-200 text-sm text-red-800 rounded-lg p-4 mb-6 dark:bg-red-800/10 dark:border-red-900 dark:text-red-500" 
                     role="alert" tabindex="-1" aria-labelledby="tos-error-label"
                     x-data="{ 
                         init() {
                             
                             this.$nextTick(() => {
                                 window.scrollTo({ 
                                     top: 0, 
                                     behavior: 'smooth' 
                                 });
                             });
                         }
                     }">
                    <div class="flex">
                        <div class="shrink-0">
                            <svg class="shrink-0 size-4 mt-0.5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="12" cy="12" r="10"></circle>
                                <path d="m15 9-6 6"></path>
                                <path d="m9 9 6 6"></path>
                            </svg>
                        </div>
                        <div class="ms-4">
                            <h3 id="tos-error-label" class="text-sm font-semibold">
                                {{ __('citadel::citadel.cart.tos_error_title') }}
                            </h3>
                            <div class="mt-2 text-sm text-red-700 dark:text-red-400">
                                <ul class="list-disc space-y-1 ps-5">
                                    <li>{{ $message }}</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            @enderror

            
            @guest
                <div class="guest-checkout-error bg-red-50 border border-red-200 text-sm text-red-800 rounded-lg p-4 mb-6 dark:bg-red-800/10 dark:border-red-900 dark:text-red-500" 
                     role="alert" tabindex="-1" aria-labelledby="cart-auth-errors-label"
                     style="display: none;"
                     x-data="{ 
                         init() {
                             
                             this.$nextTick(() => {
                                 window.scrollTo({ 
                                     top: 0, 
                                     behavior: 'smooth' 
                                 });
                             });
                         }
                     }">
                    <div class="flex">
                        <div class="shrink-0">
                            <svg class="shrink-0 size-4 mt-0.5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="12" cy="12" r="10"></circle>
                                <path d="m15 9-6 6"></path>
                                <path d="m9 9 6 6"></path>
                            </svg>
                        </div>
                        <div class="ms-4">
                            <h3 id="cart-auth-errors-label" class="text-sm font-semibold">
                                {{ __('citadel::citadel.cart.auth_required_title') }}
                            </h3>
                            <div class="mt-2 text-sm text-red-700 dark:text-red-400">
                                <ul class="list-disc space-y-1 ps-5">
                                    <li>{{ __('citadel::citadel.cart.auth_required_login') }}</li>
                                    <li>{{ __('citadel::citadel.cart.auth_required_fields') }}</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            @endguest

           
            @guest
                @if (session('guest_checkout_error'))
                    <div class="bg-red-50 border border-red-200 text-sm text-red-800 rounded-lg p-4 mb-6 dark:bg-red-800/10 dark:border-red-900 dark:text-red-500" 
                         role="alert" tabindex="-1" aria-labelledby="cart-auth-errors-label"
                         x-data="{ 
                             init() {
                                 // Scroll to top when errors are present
                                 this.$nextTick(() => {
                                     window.scrollTo({ 
                                         top: 0, 
                                         behavior: 'smooth' 
                                     });
                                 });
                             }
                         }">
                        <div class="flex">
                            <div class="shrink-0">
                                <svg class="shrink-0 size-4 mt-0.5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <circle cx="12" cy="12" r="10"></circle>
                                    <path d="m15 9-6 6"></path>
                                    <path d="m9 9 6 6"></path>
                                </svg>
                            </div>
                            <div class="ms-4">
                                <h3 id="cart-auth-errors-label" class="text-sm font-semibold">
                                    Authentication required to complete checkout.
                                </h3>
                                <div class="mt-2 text-sm text-red-700 dark:text-red-400">
                                    <ul class="list-disc space-y-1 ps-5">
                                        <li>Please login to your existing account or create a new account to continue</li>
                                        <li>Both email and password fields are required</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif
            @endguest
        @endif
        
        
        @if (optional(Cart::items())->count() > 0)
            @includeWhen(View::exists('upsells::components.spend-minimum-top'), 'upsells::components.spend-minimum-top', [
                'settings' => $upsellSettings ?? null,
                'spendMinimumUpsells' => $spendMinimumUpsells ?? null
            ])
            
            <div class="bg-background-secondary border border-neutral rounded-lg pt-4 px-6 pb-6">
                <h2 class="check-out-text-small-bold text-base !font-medium !leading-5 mb-3 mt-0">{{ __('citadel::citadel.cart.products_heading') }}</h2>
                <div class="-mx-6 border-t border-neutral mb-4"></div>
                
                <div class="space-y-0">
                    @foreach (Cart::items() as $item)
                        
                        @if(!$loop->first)
                            <div class="-mx-6 border-t border-neutral my-6"></div>
                        @endif
                        
                        <div class="flex flex-col lg:flex-row justify-between gap-6">
                            
                            <div class="flex-1">
                                <h3 class="secondary-title text-base !font-semibold mb-2">
                                    {{ $item->product->name }}
                                </h3>
                                
                                
                                @if($item->plan)
                                    <div class="mb-2">
                                        <span class="check-out-text-small-bold text-muted !font-normal !leading-5">Plan: </span>
                                        <span class="check-out-text-small-bold text-base !font-normal !leading-5">{{ $item->plan->name }}</span>
                                        @if($item->plan->billing_period)
                                            <span class="check-out-text-small-bold text-base !font-normal !leading-5">
                                                / {{ $item->plan->billing_period }} {{ trans_choice(__('services.billing_cycles.' . $item->plan->billing_unit), $item->plan->billing_period) }}
                                            </span>
                                        @endif
                                    </div>
                                @endif
                                
                                
                                @if($item->configOptions && $item->configOptions->count() > 0)
                                    <div class="space-y-1">
                                        @foreach ($item->configOptions as $option)
                                            <div class="flex items-center gap-2">
                                                <span class="check-out-text-small-bold text-muted !font-normal !leading-5">{{ $option->option_name }}:</span>
                                                <span class="check-out-text-small-bold text-base !font-normal !leading-5">{{ $option->value_name }}</span>
                                            </div>
                                        @endforeach
                                    </div>
                                @endif
                            </div>
                            
                            
                            <div class="flex flex-col lg:items-end justify-between gap-4 lg:min-w-[300px]">
                                
                                <div class="flex flex-wrap gap-1 lg:justify-end">
                                    
                                    @if ($item->product->allow_quantity == 'combined')
                                        <div class="flex items-center gap-2 bg-background border border-neutral rounded-lg p-1">
                                            <button wire:click="updateQuantity({{ $item->id }}, {{ $item->quantity - 1 }})"
                                                    class="w-8 h-8 flex items-center justify-center rounded border border-neutral bg-background-secondary hover:bg-primary/5 hover:border-primary/40 transition-all duration-200"
                                                    {{ $item->quantity <= 1 ? 'disabled' : '' }}>
                                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 12H4"/>
                                                </svg>
                                            </button>
                                            <span class="w-12 text-center order-summary-text font-medium">{{ $item->quantity }}</span>
                                            <button wire:click="updateQuantity({{ $item->id }}, {{ $item->quantity + 1 }})"
                                                    class="w-8 h-8 flex items-center justify-center rounded border border-neutral bg-background-secondary hover:bg-primary/5 hover:border-primary/40 transition-all duration-200">
                                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                                                </svg>
                                            </button>
                                        </div>
                                    @endif
                                    
                                    
                                    <a href="{{ route('products.checkout', [$item->product->category, $item->product, 'edit' => $item->id]) }}" wire:navigate>
                                        <button class="h-fit w-fit p-3 text-muted hover:text-primary transition-all duration-200 cursor-pointer">
                                            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                                                <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z"/>
                                            </svg>
                                        </button>
                                    </a>
                                    
                                    
                                    <button wire:click="removeProduct({{ $item->id }})" class="h-fit w-fit p-3 text-muted hover:text-red-500 transition-all duration-200 cursor-pointer">
                                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                                            <path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd"/>
                                        </svg>
                                    </button>
                                </div>
                                
                                
                                <div class="flex flex-col gap-1 lg:items-end">
                                    <span class="check-out-text-small-bold text-muted !font-normal !leading-5">
                                        @if($item->quantity > 1)
                                            Total ({{ $item->quantity }} items)
                                        @else
                                            Price
                                        @endif
                                    </span>
                                    <div class="secondary-title text-base !font-semibold">
                                        {{ $item->price->format($item->price->price * $item->quantity) }}
                                    </div>
                                    @if ($item->quantity > 1)
                                        <span class="check-out-text-small-bold text-muted !font-normal !leading-5">{{ $item->price }} each</span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        
                        @includeWhen(View::exists('upsells::components.cart-upsells'), 'upsells::components.cart-upsells', [
                            'item' => $item,
                            'settings' => $upsellSettings ?? null,
                            'getUpsellsForProduct' => $getUpsellsForProduct ?? null
                        ])
                    @endforeach
                </div>
                
                
                <div class="-mx-6 border-t border-neutral mt-6 pt-4 px-6">
                    <div class="flex justify-end">
                        
                        <a href="{{ route('home') }}" wire:navigate>
                            <button class="flex items-center gap-2 px-3 py-2 border border-neutral text-muted hover:text-primary hover:border-primary/40 transition-all duration-200 rounded-lg">
                                <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clip-rule="evenodd"/>
                                </svg>
                                <span class="check-out-text-small-bold !font-normal">Order More</span>
                            </button>
                        </a>
                    </div>
                </div>
            </div>
        @endif
        
        
        @if (optional(Cart::items())->count() > 0)
            <h3 class="check-out-title-semi text-base !font-normal mb-2">{{ __('citadel::citadel.cart.promo_code_heading') }}</h3>
            <div class="bg-background-secondary border border-neutral rounded-lg p-6">
                
                @error('coupon')
                    <div class="mb-4">
                        <x-alert type="error" :title="__('citadel::citadel.cart.promo_code_error_title')" :message="$message" />
                    </div>
                @enderror
                
                
                @if (session('coupon_applied'))
                    <div class="mb-4">
                        <x-alert type="success" :title="__('citadel::citadel.cart.promo_code_applied_title')" :message="session('coupon_applied')" />
                    </div>
                @endif
                
                @if(!$coupon)
                    <div class="space-y-3">
                        <div class="flex gap-3">
                            <div class="flex-1 relative">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <x-ri-coupon-3-fill class="size-4 text-muted" />
                                </div>
                                <input type="text" 
                                       wire:model="coupon" 
                                       placeholder="Enter promo code"
                                       class="w-full pl-10 pr-4 py-3 text-base border border-neutral bg-background rounded-lg
                                              focus:border-primary/40 focus:outline-none transition-all duration-200 
                                              hover:border-neutral" />
                            </div>
                            <x-button.primary wire:click="applyCoupon" class="!w-auto !py-3 px-3 text-sm whitespace-nowrap" wire:loading.attr="disabled">
                                <x-loading target="applyCoupon" />
                                <div wire:loading.remove wire:target="applyCoupon">
                                    Apply Code
                                </div>
                            </x-button.primary>
                        </div>
                    </div>
                @else
                    <div class="flex items-center justify-between p-3 bg-green-50 border border-green-200 rounded-lg">
                        <div class="flex items-center gap-2">
                            <svg class="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                            </svg>
                            <span class="check-out-text-small-bold !font-medium !leading-5 text-green-800">{{ is_object($coupon) ? $coupon->code : $coupon }}</span>
                        </div>
                        <button wire:click="removeCoupon" class="text-green-600 hover:text-green-800 transition-colors">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                            </svg>
                        </button>
                    </div>
                @endif
            </div>
        @endif
        
        
        @if (optional(Cart::items())->count() > 0 && $total->price > 0)
            <div x-data="{ 
                     init() {
                         
                         @auth
                             @if(optional(Cart::items())->count() > 0 && Auth::user()->credits()->where('currency_code', optional(Cart::get())->currency?->code ?? config('settings.currency'))->exists() && Auth::user()->credits()->where('currency_code', optional(Cart::get())->currency?->code ?? config('settings.currency'))->first()->amount > 0)
                                 if (!'{{ $gateway }}' || '{{ $gateway }}' === '' || '{{ $gateway }}' === null || '{{ $gateway }}' === '0') {
                                     this.$nextTick(() => {
                                         $wire.set('gateway', 'credits');
                                         $wire.set('use_credits', true);
                                     });
                                 }
                             @else
                                 
                                 if (!'{{ $gateway }}' || '{{ $gateway }}' === '' || '{{ $gateway }}' === null || '{{ $gateway }}' === '0') {
                                     @if(isset($this->gateways) && !empty($this->gateways) && count($this->gateways) > 0)
                                         this.$nextTick(() => {
                                             $wire.set('gateway', '{{ $this->gateways[0]->id }}');
                                             $wire.set('use_credits', false);
                                         });
                                     @endif
                                 }
                             @endif
                         @else
                             
                             if (!'{{ $gateway }}' || '{{ $gateway }}' === '' || '{{ $gateway }}' === null || '{{ $gateway }}' === '0') {
                                 @if(isset($this->gateways) && !empty($this->gateways) && count($this->gateways) > 0)
                                     this.$nextTick(() => {
                                         $wire.set('gateway', '{{ $this->gateways[0]->id }}');
                                         $wire.set('use_credits', false);
                                     });
                                 @endif
                             }
                         @endauth
                     }
                 }">
                <h3 class="check-out-title-semi text-base !font-normal mb-2 mt-6">{{ __('citadel::citadel.cart.payment_method_heading') }}</h3>
                
                
                @error('gateway')
                    <div class="mb-4">
                        <x-alert type="error" :title="__('citadel::citadel.cart.payment_method_error_title')" :message="$message" />
                    </div>
                @enderror
                
                @if (session('payment_error'))
                    <div class="mb-4">
                        <x-alert type="error" :title="__('citadel::citadel.cart.payment_failed_title')" :message="session('payment_error')" />
                    </div>
                @endif
                
                <div class="space-y-4">
                @if(theme('payment_method_style', 'dropdown') == 'dropdown')
                    
                    <div class="bg-background-secondary border border-neutral rounded-lg p-6">
                        <select wire:model.live="gateway" 
                                x-on:change="
                                    if ($event.target.value === 'credits') {
                                        $wire.set('use_credits', true);
                                    } else {
                                        $wire.set('use_credits', false);
                                    }
                                "
                                class="w-full px-4 py-3 text-base border border-neutral bg-background rounded-lg
                                       focus:border-primary/40 focus:outline-none transition-all duration-200 
                                       hover:border-neutral">
                            
                            @auth
                                @if(optional(Cart::items())->count() > 0 && Auth::user()->credits()->where('currency_code', optional(Cart::get())->currency?->code ?? config('settings.currency'))->exists() && Auth::user()->credits()->where('currency_code', optional(Cart::get())->currency?->code ?? config('settings.currency'))->first()->amount > 0)
                                    <option value="credits">
                                        Use Credits ({{ Auth::user()->credits()->where('currency_code', optional(Cart::get())->currency?->code ?? config('settings.currency'))->first()->formatted_amount }} available)
                                    </option>
                                @endif
                            @endauth
                            
                            
                            @if(isset($this->gateways) && is_array($this->gateways))
                                @foreach ($this->gateways as $paymentGateway)
                                    <option value="{{ $paymentGateway->id }}">{{ $paymentGateway->name }}</option>
                                @endforeach
                            @endif
                        </select>
                    </div>
                @elseif(theme('payment_method_style', 'dropdown') == 'cards')
                    
                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                        
                        @auth
                            @if(optional(Cart::items())->count() > 0 && Auth::user()->credits()->where('currency_code', optional(Cart::get())->currency?->code ?? config('settings.currency'))->exists() && Auth::user()->credits()->where('currency_code', optional(Cart::get())->currency?->code ?? config('settings.currency'))->first()->amount > 0)
                                <div x-on:click="$wire.set('gateway', 'credits'); $wire.set('use_credits', true)" 
                                     class="relative cursor-pointer p-3 border rounded-lg transition-all duration-200
                                            {{ $gateway === 'credits' ? 'border-primary/40 bg-primary/5' : 'border-neutral bg-background-secondary hover:border-neutral' }}">
                                    
                                    <div class="flex flex-col items-center justify-center h-full min-h-[80px]">
                                        <div class="flex-1 flex items-center justify-center mb-2 w-full">
                                            <x-ri-coins-fill class="w-12 h-auto {{ $gateway === 'credits' ? 'text-primary' : 'text-muted' }}" />
                                        </div>
                                        <div class="text-center">
                                            <h4 class="check-out-text-small-bold !font-medium !leading-5 {{ $gateway === 'credits' ? 'text-primary' : 'text-base' }}">Credits</h4>
                                            <p class="check-out-text-small-bold !font-normal !leading-5 text-muted mt-1">{{ Auth::user()->credits()->where('currency_code', optional(Cart::get())->currency?->code ?? config('settings.currency'))->first()->formatted_amount }} available</p>
                                        </div>
                                    </div>
                                    @if($gateway === 'credits')
                                        <div class="absolute top-2 right-2">
                                            <div class="w-5 h-5 bg-primary rounded-full flex items-center justify-center">
                                            <svg class="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                                                <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                                            </svg>
                                        </div>
                                    </div>
                                @endif
                                </div>
                            @endif
                        @endauth
                            
                            
                            @if(isset($this->gateways) && is_array($this->gateways))
                                @foreach ($this->gateways as $paymentGateway)
                                    @php
                                        
                                        $iconPath = null;
                                        $gatewayName = $paymentGateway->name;
                                    
                                    
                                    $possibleNames = [
                                        
                                        strtolower($gatewayName),
                                        strtoupper($gatewayName),
                                        $gatewayName,
                                        
                                        
                                        str_replace(' ', '', strtolower($gatewayName)),
                                        str_replace(' ', '-', strtolower($gatewayName)),
                                        str_replace(' ', '_', strtolower($gatewayName)),
                                        
                                        
                                        str_replace([',', ' '], '', strtolower($gatewayName)),
                                        str_replace([',', ' '], '-', strtolower($gatewayName)),
                                        str_replace([',', ' '], '_', strtolower($gatewayName)),
                                        
                                        
                                        preg_replace('/[^a-zA-Z0-9]/', '', strtolower($gatewayName)),
                                        preg_replace('/[^a-zA-Z0-9]/', '', strtoupper($gatewayName)),
                                    ];
                                    
                                    
                                    $possibleNames = array_filter(array_unique($possibleNames));
                                    
                                    foreach ($possibleNames as $name) {
                                        if (empty($name)) continue;
                                        
                                        $svgPath = public_path("assets/gateways/{$name}.svg");
                                        if (file_exists($svgPath)) {
                                            $iconPath = "/assets/gateways/{$name}.svg";
                                            break;
                                        }
                                    }
                                @endphp
                                
                                <div x-on:click="$wire.set('gateway', '{{ $paymentGateway->id }}'); $wire.set('use_credits', false)" 
                                     class="relative cursor-pointer p-3 border rounded-lg transition-all duration-200
                                            {{ $gateway == $paymentGateway->id ? 'border-primary/40 bg-primary/5' : 'border-neutral bg-background-secondary hover:border-neutral' }}
                                            {{ theme('gateway_card_display', 'logo_and_name') == 'cover' ? 'overflow-hidden' : '' }}">
                                    
                                    @if(theme('gateway_card_display', 'logo_and_name') == 'cover' && ((function_exists('citadel_demo_gateway_icon') ? citadel_demo_gateway_icon($gatewayName, 'cover') : null) ?? $iconPath))
                                        
                                        <div class="absolute inset-0">
                                            <img src="{{ (function_exists('citadel_demo_gateway_icon') ? citadel_demo_gateway_icon($gatewayName, 'cover') : null) ?? $iconPath }}" alt="{{ $paymentGateway->name }}" class="w-full h-full object-cover">
                                        </div>
                                        <div class="relative flex items-center justify-center h-full min-h-[80px]">
                                            
                                        </div>
                                    @elseif(theme('gateway_card_display', 'logo_and_name') == 'logo_only' && ((function_exists('citadel_demo_gateway_icon') ? citadel_demo_gateway_icon($gatewayName, 'logo_only') : null) ?? $iconPath))
                                        
                                        <div class="flex items-center justify-center h-full min-h-[80px]">
                                            <img src="{{ (function_exists('citadel_demo_gateway_icon') ? citadel_demo_gateway_icon($gatewayName, 'logo_only') : null) ?? $iconPath }}" alt="{{ $paymentGateway->name }}" class="h-12 w-auto object-contain">
                                        </div>
                                    @elseif($iconPath)
                                        
                                        <div class="flex flex-col items-center justify-center h-full min-h-[80px]">
                                            <div class="flex-1 flex items-center justify-center mb-2 w-full">
                                                <img src="{{ $iconPath }}" alt="{{ $paymentGateway->name }}" class="h-12 w-auto object-contain">
                                            </div>
                                            <h4 class="check-out-text-small-bold !font-medium !leading-5 text-center {{ $gateway == $paymentGateway->id ? 'text-primary' : 'text-base' }}">{{ $paymentGateway->name }}</h4>
                                        </div>
                                    @else
                                        
                                        <div class="flex items-center justify-center h-full min-h-[80px]">
                                            <h4 class="check-out-text-small-bold !font-medium !leading-5 text-center {{ $gateway == $paymentGateway->id ? 'text-primary' : 'text-base' }}">{{ $paymentGateway->name }}</h4>
                                        </div>
                                    @endif
                                    @if($gateway == $paymentGateway->id)
                                        <div class="absolute top-2 right-2">
                                            <div class="w-5 h-5 bg-primary rounded-full flex items-center justify-center">
                                                <svg class="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                                                </svg>
                                            </div>
                                        </div>
                                    @endif
                                </div>
                            @endforeach
                            @endif
                    </div>
                @elseif(theme('payment_method_style', 'dropdown') == 'select')
                    
                    <div class="bg-transparent border-0 p-0">
                        <div class="bg-background-secondary border border-neutral rounded-lg">
                            
                            @auth
                                @if(optional(Cart::items())->count() > 0 && Auth::user()->credits()->where('currency_code', optional(Cart::get())->currency?->code ?? config('settings.currency'))->exists() && Auth::user()->credits()->where('currency_code', optional(Cart::get())->currency?->code ?? config('settings.currency'))->first()->amount > 0)
                                    <div x-on:click="$wire.set('gateway', 'credits'); $wire.set('use_credits', true)" 
                                         class="relative cursor-pointer p-3 transition-all duration-200 rounded-t-lg last:rounded-b-lg
                                                {{ $gateway === 'credits' ? 'bg-primary/5 border border-primary/40 z-10' : 'bg-background-secondary hover:bg-background border-b border-neutral last:border-b-0' }}">
                                        <div class="flex items-center justify-between">
                                            <div class="flex-1">
                                                <h4 class="check-out-text-small-bold !font-medium !leading-5 {{ $gateway === 'credits' ? 'text-primary' : 'text-base' }}">
                                                    Credits - {{ Auth::user()->credits()->where('currency_code', optional(Cart::get())->currency?->code ?? config('settings.currency'))->first()->formatted_amount }} available
                                                </h4>
                                            </div>
                                            <div class="flex items-center ml-4">
                                                @if($gateway === 'credits')
                                                    <div class="w-6 h-6 bg-primary rounded-full flex items-center justify-center mr-3">
                                                        <svg class="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                                                            <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                                                        </svg>
                                                    </div>
                                            @endif
                                            <x-ri-coins-fill class="w-8 h-8 {{ $gateway === 'credits' ? 'text-primary' : 'text-muted' }}" />
                                        </div>
                                    </div>
                                </div>
                            @endif
                        @endauth                            
                            @if(isset($this->gateways) && is_array($this->gateways))
                                @foreach ($this->gateways as $paymentGateway)
                                    @php
                                        
                                        $iconPath = null;
                                        $gatewayName = $paymentGateway->name;
                                    
                                    
                                    $possibleNames = [
                                        
                                        strtolower($gatewayName),
                                        strtoupper($gatewayName),
                                        $gatewayName,
                                        
                                        
                                        str_replace(' ', '', strtolower($gatewayName)),
                                        str_replace(' ', '-', strtolower($gatewayName)),
                                        str_replace(' ', '_', strtolower($gatewayName)),
                                        
                                        
                                        str_replace([',', ' '], '', strtolower($gatewayName)),
                                        str_replace([',', ' '], '-', strtolower($gatewayName)),
                                        str_replace([',', ' '], '_', strtolower($gatewayName)),
                                        
                                        
                                        preg_replace('/[^a-zA-Z0-9]/', '', strtolower($gatewayName)),
                                        preg_replace('/[^a-zA-Z0-9]/', '', strtoupper($gatewayName)),
                                    ];
                                    
                                    
                                    $possibleNames = array_filter(array_unique($possibleNames));
                                    
                                    foreach ($possibleNames as $name) {
                                        if (empty($name)) continue;
                                        
                                        $svgPath = public_path("assets/gateways/{$name}.svg");
                                        if (file_exists($svgPath)) {
                                            $iconPath = "/assets/gateways/{$name}.svg";
                                            break;
                                        }
                                    }
                                @endphp
                                
                                <div x-on:click="$wire.set('gateway', '{{ $paymentGateway->id }}'); $wire.set('use_credits', false)" 
                                     class="relative cursor-pointer p-3 transition-all duration-200 last:rounded-b-lg
                                            @guest
                                                @if($loop->first) rounded-t-lg @endif
                                            @else
                                                @if(optional(Cart::items())->count() === 0 || !Auth::user()->credits()->where('currency_code', optional(Cart::get())->currency?->code ?? config('settings.currency'))->exists() || Auth::user()->credits()->where('currency_code', optional(Cart::get())->currency?->code ?? config('settings.currency'))->first()->amount <= 0)
                                                    @if($loop->first) rounded-t-lg @endif
                                                @endif
                                            @endguest
                                            {{ $gateway == $paymentGateway->id ? 'bg-primary/5 border border-primary/40 z-10' : 'bg-background-secondary hover:bg-background border-b border-neutral last:border-b-0' }}">
                                    <div class="flex items-center justify-between">
                                        <div class="flex-1">
                                            <h4 class="check-out-text-small-bold !font-medium !leading-5 {{ $gateway == $paymentGateway->id ? 'text-primary' : 'text-base' }}">{{ $paymentGateway->name }}</h4>
                                        </div>
                                        <div class="flex items-center ml-4">
                                            @if($gateway == $paymentGateway->id)
                                                <div class="w-6 h-6 bg-primary rounded-full flex items-center justify-center mr-3">
                                                    <svg class="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                                                        <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                                                    </svg>
                                                </div>
                                            @endif
                                            @if($iconPath)
                                                <img src="{{ $iconPath }}" alt="{{ $paymentGateway->name }}" class="h-8 w-auto object-contain">
                                            @else
                                                <x-ri-bank-card-fill class="w-8 h-8 {{ $gateway == $paymentGateway->id ? 'text-primary' : 'text-muted' }}" />
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                            @endif
                        </div>
                    </div>
                @endif
            </div>
            </div>
        @endif

        
        @guest
            <div class="mt-6 guest-auth-section" x-data="{ 
                authOption: 'login',
                showLogin: true, 
                showRegister: false,
                init() {
                    this.$watch('authOption', (value) => {
                        this.showLogin = value === 'login';
                        this.showRegister = value === 'register';
                    });
                }
            }">
                <h3 class="check-out-title-semi text-base !font-normal mb-4">{{ __('citadel::citadel.cart.account_options_heading') }}</h3>
                
                
                <div class="bg-background-secondary border border-neutral rounded-t-lg transition-all duration-200 cursor-pointer"
                     @click="authOption = 'login'">
                    <div class="flex items-center p-4 w-full">
                        <div class="flex items-center gap-3 w-full">
                            <div class="w-4 h-4 border border-primary/30 rounded-full flex items-center justify-center transition-colors">
                                <div class="w-2 h-2 bg-white rounded-full transition-opacity" 
                                     x-bind:class="{ 'opacity-100': authOption === 'login', 'opacity-0': authOption !== 'login' }"></div>
                            </div>
                            <div class="flex-1 text-left">
                                <h5 class="check-out-text-small-bold text-base !font-medium !leading-5">Login to Existing Account</h5>
                                <p class="small-text text-muted !font-light !leading-5">Access your account and order history</p>
                            </div>
                            <x-ri-arrow-down-s-line class="w-4 h-4 text-muted transition-transform duration-200"
                                                   x-bind:class="{ 'rotate-180': showLogin }" />
                        </div>
                    </div>
                    
                    
                    <div x-show="showLogin" x-collapse>
                        <div class="px-6 pb-6 pt-4 border-t border-neutral">
                            
                            @if (session('login_error') || $errors->has('email') || $errors->has('password'))
                                <div class="mb-4 bg-red-50 border border-red-200 text-sm text-red-800 rounded-lg p-4 dark:bg-red-800/10 dark:border-red-900 dark:text-red-500" role="alert">
                                    <div class="flex">
                                        <div class="shrink-0">
                                            <svg class="shrink-0 size-4 mt-0.5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                <circle cx="12" cy="12" r="10"></circle>
                                                <path d="m15 9-6 6"></path>
                                                <path d="m9 9 6 6"></path>
                                            </svg>
                                        </div>
                                        <div class="ms-4">
                                            <h3 class="text-sm font-semibold">Login Failed</h3>
                                            <div class="mt-2 text-sm text-red-700 dark:text-red-400">
                                                @if (session('login_error'))
                                                    <p>{{ session('login_error') }}</p>
                                                @else
                                                    <ul class="list-disc space-y-1 ps-5">
                                                        @if ($errors->has('email'))
                                                            <li>{{ $errors->first('email') }}</li>
                                                        @endif
                                                        @if ($errors->has('password'))
                                                            <li>{{ $errors->first('password') }}</li>
                                                        @endif
                                                    </ul>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endif
                            
                            <livewire:cart.login />
                        </div>
                    </div>
                </div>
                
                
                <div class="bg-background-secondary border border-neutral border-t-0 rounded-b-lg transition-all duration-200 cursor-pointer"
                     @click="authOption = 'register'">
                    <div class="flex items-center p-4 w-full">
                        <div class="flex items-center gap-3 w-full">
                            <div class="w-4 h-4 border border-primary/30 rounded-full flex items-center justify-center transition-colors">
                                <div class="w-2 h-2 bg-white rounded-full transition-opacity" 
                                     x-bind:class="{ 'opacity-100': authOption === 'register', 'opacity-0': authOption !== 'register' }"></div>
                            </div>
                            <div class="flex-1 text-left">
                                <h5 class="check-out-text-small-bold text-base !font-medium !leading-5">Create New Account</h5>
                                <p class="small-text text-muted !font-light !leading-5">Get access to order tracking and account features</p>
                            </div>
                            <x-ri-arrow-down-s-line class="w-4 h-4 text-muted transition-transform duration-200"
                                                   x-bind:class="{ 'rotate-180': showRegister }" />
                        </div>
                    </div>
                    
                    
                    <div x-show="showRegister" x-collapse>
                        <div class="px-6 pb-6 pt-4 border-t border-neutral">
                            
                            @if (session('register_error') || $errors->has('first_name') || $errors->has('last_name') || $errors->has('email') || $errors->has('password') || $errors->has('password_confirmation'))
                                <div class="mb-4 bg-red-50 border border-red-200 text-sm text-red-800 rounded-lg p-4 dark:bg-red-800/10 dark:border-red-900 dark:text-red-500" role="alert">
                                    <div class="flex">
                                        <div class="shrink-0">
                                            <svg class="shrink-0 size-4 mt-0.5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                <circle cx="12" cy="12" r="10"></circle>
                                                <path d="m15 9-6 6"></path>
                                                <path d="m9 9 6 6"></path>
                                            </svg>
                                        </div>
                                        <div class="ms-4">
                                            <h3 class="text-sm font-semibold">Registration Failed</h3>
                                            <div class="mt-2 text-sm text-red-700 dark:text-red-400">
                                                @if (session('register_error'))
                                                    <p>{{ session('register_error') }}</p>
                                                @else
                                                    <ul class="list-disc space-y-1 ps-5">
                                                        @if ($errors->has('first_name'))
                                                            <li>{{ $errors->first('first_name') }}</li>
                                                        @endif
                                                        @if ($errors->has('last_name'))
                                                            <li>{{ $errors->first('last_name') }}</li>
                                                        @endif
                                                        @if ($errors->has('email'))
                                                            <li>{{ $errors->first('email') }}</li>
                                                        @endif
                                                        @if ($errors->has('password'))
                                                            <li>{{ $errors->first('password') }}</li>
                                                        @endif
                                                        @if ($errors->has('password_confirmation'))
                                                            <li>{{ $errors->first('password_confirmation') }}</li>
                                                        @endif
                                                    </ul>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endif
                            
                            <livewire:cart.register />
                        </div>
                    </div>
                </div>
            </div>
        @endguest
    </div>
    
    
    <div class="flex flex-col gap-4 w-full col-span-1 relative">
        @if (optional(Cart::items())->count() > 0)

            @includeWhen(View::exists('upsells::components.spend-minimum-sidebar'), 'upsells::components.spend-minimum-sidebar', [
                'settings' => $upsellSettings ?? null,
                'spendMinimumUpsells' => $spendMinimumUpsells ?? null
            ])
        @endif
        
        <div class="sticky flex flex-col gap-4 h-fit mt-[77px]"
             wire:ignore.self
             x-data
             x-init="
                 const setTop = () => {
                     const nav = document.querySelector('nav[aria-label=\'primary-navigation\']');
                     const navBottom = nav ? nav.getBoundingClientRect().bottom : 0;
                     if (navBottom > 0) { $el.style.top = (navBottom + 8) + 'px'; }
                 };
                 setTop();
                 requestAnimationFrame(setTop);
                 window.addEventListener('load', setTop);
                 window.addEventListener('resize', setTop);
             ">
        <div id="order-summary" class="bg-background-secondary border border-neutral rounded-lg p-6 h-fit">
                <h2 class="check-out-title-semi text-base !font-normal !leading-5 mb-6">
                    {{ __('citadel::citadel.cart.order_summary_heading') }}
                </h2>
                
                @if (optional(Cart::items())->count() > 0)
                    
                    <div class="space-y-3 mb-6">
                    @foreach (Cart::items() as $item)
                        <div class="flex justify-between items-start py-2 border-b border-neutral last:border-b-0">
                            <div class="flex-1">
                                <h4 class="check-out-text-small-bold text-base !font-semibold !leading-5">{{ $item->product->name }}</h4>
                                <p class="check-out-text-small-bold text-muted !font-normal !leading-5 mt-1">
                                    {{ $item->plan->name }} 
                                    @if($item->plan->billing_period > 0)
                                        - {{ $item->plan->billing_period }} {{ Str::plural($item->plan->billing_unit, $item->plan->billing_period) }}
                                    @else
                                        - One Time
                                    @endif
                                </p>
                            </div>
                            <div class="text-right">
                                <span class="check-out-text-small-bold text-base !font-normal !leading-5">{{ $item->price }}</span>
                            </div>
                        </div>
                    @endforeach
                </div>
                
                
                <div class="space-y-3 mb-6">
                    @php
                        $totalDiscount = Cart::items()->sum(fn($item) => $item->price->discount * $item->quantity);
                    @endphp
                    
                    @if ($coupon && $totalDiscount > 0)
                        <div class="flex justify-between items-center !leading-5">
                            <h4 class="check-out-text-small-bold text-base !font-semibold !leading-5 flex items-center gap-2">
                                <span class="text-primary">{{ __('citadel::citadel.cart.discount') }}:</span>
                                <span class="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full font-medium">{{ is_object($coupon) ? $coupon->code : $coupon }}</span>
                            </h4>
                            <span class="check-out-text-small-bold text-primary !font-normal !leading-5">-{{ $total->format($totalDiscount) }}</span>
                        </div>
                    @endif
                    
                    <div class="flex justify-between items-center !leading-5">
                        <h4 class="check-out-text-small-bold text-base !font-semibold !leading-5">{{ __('invoices.subtotal') }}:</h4>
                        <span class="check-out-text-small-bold text-base !font-normal !leading-5">{{ $total->format($total->price - $total->tax) }}</span>
                    </div>
                    
                    @if ($total->tax > 0)
                        <div class="flex justify-between items-center !leading-5">
                            <h4 class="check-out-text-small-bold text-base !font-semibold !leading-5">{{ \App\Classes\Settings::tax()->name }} ({{ \App\Classes\Settings::tax()->rate }}%):</h4>
                            <span class="check-out-text-small-bold text-base !font-normal !leading-5">{{ $total->formatted->tax }}</span>
                        </div>
                    @endif
                    
                    
                    <div class="pt-3 border-t border-neutral">
                        <div class="flex flex-col gap-2">
                            <span class="check-out-text-small-bold text-base !font-normal !leading-5">{{ __('citadel::citadel.cart.total_due_today') }}</span>
                            <div class="text-base !font-bold !text-[28px] !leading-5">{{ $total }}</div>
                        </div>
                    </div>
                </div>
                
                
                @if(config('settings.tos'))
                    <div class="flex items-start gap-3 pt-4 border-t border-neutral">
                        <input type="checkbox" id="tos"
                               wire:model="tos"
                               class="mt-0.5 w-4 h-4 text-primary border border-neutral rounded focus:ring-primary/20 focus:ring-2 
                                      bg-background checked:bg-primary checked:border-primary 
                                      checked:text-white transition-all duration-200 accent-primary
                                      @error('tos') border-red-500 @enderror" />
                        <label for="tos" class="check-out-text-small-bold text-base !font-normal !leading-5 cursor-pointer">
                            {{ __('product.tos') }}
                            <a href="{{ config('settings.tos') }}" target="_blank" class="text-primary hover:text-primary/80">
                                {{ __('product.tos_link') }}
                            </a>
                        </label>
                    </div>
                @endif
                
                
                @error('checkout')
                    <div class="pt-4 @if(config('settings.tos')) @else border-t border-neutral @endif">
                        <x-alert type="error" :title="__('citadel::citadel.cart.checkout_error_title')" :message="$message" />
                    </div>
                @enderror
                
                @if (session('checkout_error'))
                    <div class="pt-4 @if(config('settings.tos')) @else border-t border-neutral @endif">
                        <x-alert type="error" :title="__('citadel::citadel.cart.checkout_failed_title')" :message="session('checkout_error')" />
                    </div>
                @endif
                
                
                <div class="pt-4 @if(config('settings.tos')) @else border-t border-neutral @endif">
                    @auth
                        <x-button.primary wire:click="checkout" class="w-full" wire:loading.attr="disabled">
                            <div class="flex items-center justify-center gap-2">
                                <x-loading target="checkout" />
                                <div wire:loading.remove wire:target="checkout" class="flex items-center gap-2">
                                    <x-ri-share-forward-fill class="size-4" />
                                    <span>{{ __('product.checkout') }}</span>
                                </div>
                            </div>
                        </x-button.primary>
                    @else
                        <x-button.primary 
                            x-on:click="
                                scrollToAuth(); 
                                highlightAuthFields();
                            " 
                            class="w-full">
                            <div class="flex items-center justify-center gap-2">
                                <x-ri-share-forward-fill class="size-4" />
                                <span>{{ __('product.checkout') }}</span>
                            </div>
                        </x-button.primary>
                    @endauth
                </div>
                @else
                    
                    <div class="space-y-3 mb-6">
                        <div class="pt-3 border-t border-neutral">
                            <div class="flex flex-col gap-2">
                                <span class="check-out-text-small-bold text-base !font-normal !leading-5">{{ __('citadel::citadel.cart.total_due_today') }}</span>
                                <div class="text-base !font-bold !text-[28px] !leading-5">{{ config('settings.currency_sign') }}0.00</div>
                            </div>
                        </div>
                    </div>
                @endif
            </div>
        <x-checkout-support-card />
        </div>
    </div>
</div>
