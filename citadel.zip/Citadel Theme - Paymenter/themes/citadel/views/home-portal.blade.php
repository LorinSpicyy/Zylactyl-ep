<div role="main">
    <div class="flex flex-col gap-6 pt-12 pb-8">
        
        @if(theme('home_page_text'))
        <div class="mx-auto container bg-background-secondary border border-neutral rounded-lg p-6" style="border-radius: var(--citadel-card-radius);">
            <article class="prose dark:prose-invert max-w-full">
                {!! Str::markdown(theme('home_page_text'), [
                'allow_unsafe_links' => false,
                'renderer' => [
                    'soft_break' => "<br>"
                ]]) !!}
            </article>
        </div>
        @endif

        
        <div class="mx-auto container rounded-md grid grid-cols-1 md:grid-cols-3 gap-6">
            
            @php
                $showIcons = theme('home_portal_show_icons');


                $card1Title = theme('home_card1_customize') ? (theme('home_card1_title') ?: 'Contact Us') : 'Contact Us';
                $card1Desc = theme('home_card1_customize') ? (theme('home_card1_description') ?: 'Get in touch with our support team. We\'re here to help you with any questions or concerns.') : 'Get in touch with our support team. We\'re here to help you with any questions or concerns.';
                $card1Button = theme('home_card1_customize') ? (theme('home_card1_button_text') ?: 'Get Support') : 'Get Support';
                $card1Link = theme('home_card1_customize') ? (theme('home_card1_link') ?: theme('footer_contact_link')) : theme('footer_contact_link');
                $card1External = $card1Link && !str_starts_with($card1Link, url('/'));
                $card1IconType = theme('home_card1_icon_type', 'citadel');
                $card1IconCitadel = theme('home_card1_icon_citadel', '');
                $card1IconRemix = theme('home_card1_icon_remix', '');


                $card2Title = theme('home_card2_customize') ? (theme('home_card2_title') ?: 'Services') : 'Services';
                $card2Desc = theme('home_card2_customize') ? (theme('home_card2_description') ?: 'Explore our range of services and solutions. Find the perfect plan that fits your needs.') : 'Explore our range of services and solutions. Find the perfect plan that fits your needs.';
                $card2Button = theme('home_card2_customize') ? (theme('home_card2_button_text') ?: 'View Services') : 'View Services';
                $card2Link = theme('home_card2_customize') ? (theme('home_card2_link') ?: theme('footer_services_link')) : theme('footer_services_link');
                $card2External = $card2Link && !str_starts_with($card2Link, url('/'));
                $card2IconType = theme('home_card2_icon_type', 'citadel');
                $card2IconCitadel = theme('home_card2_icon_citadel', '');
                $card2IconRemix = theme('home_card2_icon_remix', '');


                $card3Title = theme('home_card3_customize') ? (theme('home_card3_title') ?: 'Get Started') : 'Get Started';
                $card3Desc = theme('home_card3_customize') ? (theme('home_card3_description') ?: 'Create your account and start using our services today') : 'Create your account and start using our services today';
                $card3Button = theme('home_card3_customize') ? (theme('home_card3_button_text') ?: 'Get Started') : 'Get Started';
                $card3Link = theme('home_card3_customize') ? (theme('home_card3_link') ?: route('register')) : route('register');
                $card3External = $card3Link && !str_starts_with($card3Link, url('/'));
                $card3IconType = theme('home_card3_icon_type', 'citadel');
                $card3IconCitadel = theme('home_card3_icon_citadel', '');
                $card3IconRemix = theme('home_card3_icon_remix', '');
            @endphp

            @foreach([
                ['title' => $card1Title, 'desc' => $card1Desc, 'button' => $card1Button, 'link' => $card1Link, 'external' => $card1External, 'iconType' => $card1IconType, 'iconCitadel' => $card1IconCitadel, 'iconRemix' => $card1IconRemix],
                ['title' => $card2Title, 'desc' => $card2Desc, 'button' => $card2Button, 'link' => $card2Link, 'external' => $card2External, 'iconType' => $card2IconType, 'iconCitadel' => $card2IconCitadel, 'iconRemix' => $card2IconRemix],
                ['title' => $card3Title, 'desc' => $card3Desc, 'button' => $card3Button, 'link' => $card3Link, 'external' => $card3External, 'iconType' => $card3IconType, 'iconCitadel' => $card3IconCitadel, 'iconRemix' => $card3IconRemix],
            ] as $card)
                @if($card['link'])
                <a href="{{ $card['link'] }}" {{ $card['external'] ? 'target="_blank"' : 'wire:navigate' }} class="group">
                    <div class="h-full bg-background-secondary border border-neutral hover:border-primary/30 rounded-lg p-6 transition-all duration-300 hover:-translate-y-1 relative overflow-hidden" style="border-radius: var(--citadel-card-radius);">
                        
                        <div class="absolute inset-0 bg-primary/0 group-hover:bg-primary/5 transition-all duration-300 pointer-events-none"></div>
                        
                        <div class="flex flex-col items-center text-center gap-4 relative z-10">

                            @if($showIcons)
                                @if($card['iconType'] === 'citadel' && $card['iconCitadel'])
                                    <x-citadel-icon :name="$card['iconCitadel']" class="w-14 h-14" />
                                @elseif($card['iconType'] === 'remix' && $card['iconRemix'])
                                    <div class="flex items-center justify-center w-16 h-16 rounded-xl" style="background-color: hsl(var(--color-primary) / 0.1); border-radius: var(--citadel-card-radius);">
                                        <x-dynamic-component :component="$card['iconRemix']" class="size-8" style="color: hsl(var(--color-primary));" />
                                    </div>
                                @else
                                    <div class="flex items-center justify-center w-16 h-16 rounded-xl" style="background-color: hsl(var(--color-primary) / 0.1); border-radius: var(--citadel-card-radius);">
                                        <x-ri-arrow-right-line class="size-8" style="color: hsl(var(--color-primary));" />
                                    </div>
                                @endif
                            @endif
                            
                            <h3 class="text-xl font-semibold" style="color: hsl(var(--color-base));">{{ $card['title'] }}</h3>
                            
                            
                            <p class="text-sm" style="color: hsl(var(--color-base) / 0.7);">
                                {{ $card['desc'] }}
                            </p>
                            
                            
                            <div class="mt-2 flex items-center gap-2 text-primary group-hover:gap-3 transition-all">
                                <span class="text-sm font-medium">{{ $card['button'] }}</span>
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3" />
                                </svg>
                            </div>
                        </div>
                    </div>
                </a>
                @endif
            @endforeach
        </div>
    </div>
</div>
{!! hook('home.hero') !!}