@php
    use Illuminate\Support\Str;

    $page = $page ?? [];
    $blocks = $page['blocks'] ?? [];
    $categoryId = $page['category_id'] ?? null;

    $category = null;
    if ($categoryId) {
        try {
            $category = \App\Models\Category::find($categoryId);
        } catch (\Throwable $e) {}
    }

    
    $headerTitle = $page['title'] ?? ($category->name ?? 'Page');
    $headerDescription = $page['description'] ?? '';
@endphp

<x-app-layout>
    <x-slot name="title">{{ $headerTitle }}</x-slot>

    @if (! empty($headerDescription))
        @push('head')
            <meta name="description" content="{{ Str::limit(strip_tags($headerDescription), 160) }}">
        @endpush
    @endif


    <div class="w-full py-10">

        
        @foreach ($blocks as $blockIndex => $block)
            @php
                $type = $block['type'] ?? null;
                $blockAnchor = (string) preg_replace('/\s+/', '-', ltrim(trim((string) ($block['anchor'] ?? '')), '#'));
            @endphp

            @if ($blockAnchor !== '')<div id="{{ $blockAnchor }}" class="citadel-anchor-target">@endif

            @if ($type === 'hero')
                @include('partials.custom-page-blocks.hero', ['block' => $block, 'category' => $category, 'isFirstBlock' => ($blockIndex === 0)])
            @elseif ($type === 'products')
                @include('partials.custom-page-blocks.products', ['block' => $block, 'category' => $category])
            @elseif ($type === 'features')
                @include('partials.custom-page-blocks.features', ['block' => $block])
            @elseif ($type === 'faq')
                @include('partials.custom-page-blocks.faq', ['block' => $block, 'index' => $blockIndex])
            @elseif ($type === 'content')
                @include('partials.custom-page-blocks.content', ['block' => $block])
            @elseif ($type === 'cta')
                @include('partials.custom-page-blocks.cta', ['block' => $block])
            @elseif ($type === 'custom')
                @include('partials.custom-page-blocks.custom', ['block' => $block])
            @endif

            @if ($blockAnchor !== '')</div>@endif
        @endforeach
    </div>
</x-app-layout>
