<div>
    <div class="mb-4">
        <h3 class="secondary-title mb-1">{{ __('citadel::citadel.account.avatar.section_title') }}</h3>
        <p class="normal-text text-base/60 text-sm">{{ __('citadel::citadel.account.avatar.section_description') }}</p>
    </div>

    <div class="bg-background-secondary border border-neutral rounded-lg overflow-hidden">
        <div class="px-6 py-6">
            <div class="flex flex-col sm:flex-row sm:items-center gap-6">

                
                <div class="shrink-0">
                    @if ($avatar)
                        <img src="{{ $avatar->temporaryUrl() }}"
                             alt="{{ __('citadel::citadel.account.avatar.section_title') }}"
                             class="size-24 rounded-full border border-neutral object-cover" />
                    @else
                        <img src="{{ $currentAvatarUrl }}"
                             alt="{{ auth()->user()->name }}"
                             class="size-24 rounded-full border border-neutral object-cover" />
                    @endif
                </div>

                
                <div class="flex-1 w-full">
                    <div class="flex flex-wrap items-center gap-3">

                        
                        <label
                            class="inline-flex items-center gap-2 justify-center bg-background-secondary text-sm font-semibold border border-neutral hover:bg-background-secondary/80 py-2.5 px-4 rounded-lg transition-all duration-200 cursor-pointer"
                            style="border-radius: var(--citadel-button-radius);">
                            <x-ri-upload-2-line class="size-4" />
                            <span>{{ $avatar ? __('citadel::citadel.account.avatar.change') : __('citadel::citadel.account.avatar.choose') }}</span>
                            <input type="file"
                                   wire:model="avatar"
                                   accept="image/jpeg,image/png,image/webp"
                                   class="hidden" />
                        </label>

                        
                        @if ($avatar)
                            <button type="button"
                                    wire:click="save"
                                    wire:loading.attr="disabled"
                                    class="inline-flex items-center gap-2 justify-center text-white text-sm font-semibold py-2.5 px-4 rounded-lg transition-all duration-200 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                                    style="background-color: hsl(var(--color-primary)); border-radius: var(--citadel-button-radius);">
                                <span wire:loading.remove wire:target="save">{{ __('citadel::citadel.account.avatar.save') }}</span>
                                <span wire:loading wire:target="save" class="flex items-center gap-2">
                                    <x-ri-loader-5-fill class="size-4 fill-current animate-spin" />
                                </span>
                            </button>
                        @endif

                        
                        @if ($hasCustomAvatar && ! $avatar)
                            <button type="button"
                                    wire:click="remove"
                                    wire:loading.attr="disabled"
                                    class="inline-flex items-center gap-2 justify-center text-sm font-semibold border border-neutral text-base/70 hover:text-red-500 hover:border-red-500/40 py-2.5 px-4 rounded-lg transition-all duration-200 cursor-pointer disabled:opacity-50"
                                    style="border-radius: var(--citadel-button-radius);">
                                <x-ri-delete-bin-6-line class="size-4" />
                                {{ __('citadel::citadel.account.avatar.remove') }}
                            </button>
                        @endif
                    </div>

                    <p class="normal-text text-base/50 text-sm mt-3">{{ __('citadel::citadel.account.avatar.hint') }}</p>

                    @error('avatar')
                        <p class="text-sm text-red-500 mt-2">{{ $message }}</p>
                    @enderror

                    
                    <div wire:loading wire:target="avatar" class="text-sm text-base/60 mt-2">
                        {{ __('citadel::citadel.account.avatar.choose') }}…
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
