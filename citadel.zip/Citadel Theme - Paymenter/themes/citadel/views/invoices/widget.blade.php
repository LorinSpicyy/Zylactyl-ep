{{-- @lazy: deferred-invoice --}}
<div>
    <div class="bg-background-secondary border border-neutral rounded-lg">
        

        <div class="px-4 sm:px-6 py-4 border-b border-neutral">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div class="flex items-center gap-3 sm:gap-4 flex-wrap">
                    <h2 class="secondary-title">{{ __('citadel::citadel.dashboard.invoices_widget') }}</h2>
                    

                    <div class="relative" x-data="{ open: false }">
                        <button 
                            @click="open = !open" 
                            @click.away="open = false"
                            class="inline-flex items-center gap-2 px-3 py-1.5 bg-background border border-neutral rounded-md text-sm font-medium hover:bg-primary/5 transition-colors duration-200">
                            <span>
                                @if(!isset($status) || !$status)
                                    {{ __('citadel::citadel.invoices.index.all_invoices') }}
                                @elseif($status === 'paid')
                                    {{ __('citadel::citadel.invoices.index.paid') }}
                                @elseif($status === 'pending')
                                    {{ __('citadel::citadel.invoices.index.pending') }}
                                @elseif($status === 'cancelled')
                                    {{ __('citadel::citadel.invoices.index.cancelled') }}
                                @else
                                    {{ __('citadel::citadel.invoices.index.all_invoices') }}
                                @endif
                            </span>
                            <x-ri-arrow-down-s-line class="size-4 transition-transform duration-200" x-bind:class="open ? 'rotate-180' : ''" />
                        </button>
                        
                        <div x-show="open" 
                             x-transition:enter="transition ease-out duration-200"
                             x-transition:enter-start="opacity-0 scale-95"
                             x-transition:enter-end="opacity-100 scale-100"
                             x-transition:leave="transition ease-in duration-150"
                             x-transition:leave-start="opacity-100 scale-100"
                             x-transition:leave-end="opacity-0 scale-95"
                             class="absolute top-full left-0 mt-1 w-40 bg-background-secondary border border-neutral rounded-lg z-20 overflow-hidden">
                            <div class="py-1">
                                <button wire:click="setStatus('all')" @click="open = false" 
                                        class="w-full text-left px-3 py-2 text-sm hover:bg-primary/5 transition-colors duration-200 {{ (!isset($status) || !$status) ? 'bg-primary/10 text-primary' : '' }}">
                                    {{ __('citadel::citadel.invoices.index.all_invoices') }}
                                </button>
                                <button wire:click="setStatus('paid')" @click="open = false" 
                                        class="w-full text-left px-3 py-2 text-sm hover:bg-primary/5 transition-colors duration-200 {{ (isset($status) && $status === 'paid') ? 'bg-primary/10 text-primary' : '' }}">
                                    {{ __('citadel::citadel.invoices.index.paid') }}
                                </button>
                                <button wire:click="setStatus('pending')" @click="open = false" 
                                        class="w-full text-left px-3 py-2 text-sm hover:bg-primary/5 transition-colors duration-200 {{ (isset($status) && $status === 'pending') ? 'bg-primary/10 text-primary' : '' }}">
                                    {{ __('citadel::citadel.invoices.index.pending') }}
                                </button>
                                <button wire:click="setStatus('cancelled')" @click="open = false" 
                                        class="w-full text-left px-3 py-2 text-sm hover:bg-primary/5 transition-colors duration-200 {{ (isset($status) && $status === 'cancelled') ? 'bg-primary/10 text-primary' : '' }}">
                                    {{ __('citadel::citadel.invoices.index.cancelled') }}
                                </button>
                            </div>
                        </div>
                    </div>
                    

                    @if(!$compact)
                    <div class="relative" x-data="{ open: false }">
                        <button 
                            @click="open = !open" 
                            @click.away="open = false"
                            class="inline-flex items-center gap-2 px-3 py-1.5 bg-background border border-neutral rounded-md text-sm font-medium hover:bg-primary/5 transition-colors duration-200">
                            <span>
                                @if(!isset($sortBy) || $sortBy === 'newest')
                                    {{ __('citadel::citadel.invoices.index.newest') }}
                                @elseif($sortBy === 'oldest')
                                    {{ __('citadel::citadel.invoices.index.oldest') }}
                                @endif
                            </span>
                            <x-ri-arrow-down-s-line class="size-4 transition-transform duration-200" x-bind:class="open ? 'rotate-180' : ''" />
                        </button>
                        
                        <div x-show="open" 
                             x-transition:enter="transition ease-out duration-200"
                             x-transition:enter-start="opacity-0 scale-95"
                             x-transition:enter-end="opacity-100 scale-100"
                             x-transition:leave="transition ease-in duration-150"
                             x-transition:leave-start="opacity-100 scale-100"
                             x-transition:leave-end="opacity-0 scale-95"
                             class="absolute top-full left-0 mt-1 w-32 bg-background-secondary border border-neutral rounded-lg z-20 overflow-hidden">
                            <div class="py-1">
                                <button wire:click="setSortBy('newest')" @click="open = false" 
                                        class="w-full text-left px-3 py-2 text-sm hover:bg-primary/5 transition-colors duration-200 {{ (!isset($sortBy) || $sortBy === 'newest') ? 'bg-primary/10 text-primary' : '' }}">
                                    {{ __('citadel::citadel.invoices.index.newest') }}
                                </button>
                                <button wire:click="setSortBy('oldest')" @click="open = false" 
                                        class="w-full text-left px-3 py-2 text-sm hover:bg-primary/5 transition-colors duration-200 {{ (isset($sortBy) && $sortBy === 'oldest') ? 'bg-primary/10 text-primary' : '' }}">
                                    {{ __('citadel::citadel.invoices.index.oldest') }}
                                </button>
                            </div>
                        </div>
                    </div>
                    @endif
                </div>
                
                <a href="{{ route('invoices') }}" wire:navigate class="hidden sm:inline-flex items-center gap-1.5 text-sm font-medium text-base/60 hover:text-primary transition-colors duration-200">
                    <span>{{ $compact ? __('citadel::citadel.invoices.index.view_all') : __('citadel::citadel.services.show.view_all_invoices') }}</span>
                    <x-ri-arrow-right-line class="size-4" />
                </a>
            </div>
        </div>
        

        <div class="{{ $compact ? 'hidden' : 'hidden sm:block' }} px-6 py-3 border-b border-neutral bg-background-secondary/30">
            <div class="flex items-center">
                <div style="width: 140px;">
                    <span class="text-xs text-base/60 font-semibold uppercase">{{ __('citadel::citadel.invoices.index.invoice_column') }}</span>
                </div>
                <div class="flex-1">
                    <span class="text-xs text-base/60 font-semibold uppercase">{{ __('citadel::citadel.invoices.index.items_column') }}</span>
                </div>
                <div style="width: 120px;">
                    <span class="text-xs text-base/60 font-semibold uppercase">{{ __('citadel::citadel.invoices.index.date_column') }}</span>
                </div>
                <div style="width: 120px;">
                    <span class="text-xs text-base/60 font-semibold uppercase">{{ __('citadel::citadel.invoices.index.total_column') }}</span>
                </div>
                <div style="width: 140px;">
                    <span class="text-xs text-base/60 font-semibold uppercase">{{ __('citadel::citadel.invoices.index.status_column') }}</span>
                </div>
                <div style="width: 40px;"></div>
            </div>
        </div>
        

        <div class="divide-y divide-neutral overflow-hidden rounded-b-lg" wire:loading.class="opacity-50 pointer-events-none" wire:target="setStatus,setSortBy">
            
            <div wire:loading wire:target="setStatus,setSortBy" class="absolute inset-0 bg-background-secondary/50 flex items-center justify-center z-10">
                <div class="bg-background border border-neutral rounded-lg p-4">
                    <div class="flex items-center gap-3">
                        <svg class="animate-spin size-5 text-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        <span class="text-sm font-medium">{{ __('citadel::citadel.invoices.index.filtering') }}</span>
                    </div>
                </div>
            </div>
            
            @forelse ($invoices as $invoice)
                <a href="{{ route('invoices.show', $invoice) }}" wire:navigate class="block px-4 sm:px-6 py-3 sm:py-4 relative group hover:bg-primary/5 transition-colors duration-200">

                    <div class="{{ $compact ? 'hidden' : 'hidden sm:flex' }} items-center">
                        <div style="width: 140px;">
                            <span class="font-medium text-sm">{{ $invoice->number }}</span>
                        </div>
                        <div class="flex-1">
                            <p class="text-sm text-base/80">
                                @foreach ($invoice->items as $item)
                                    {{ $item->description }}@if(!$loop->last), @endif
                                @endforeach
                            </p>
                        </div>
                        <div style="width: 120px;">
                            <span class="text-sm text-base/80">{{ $invoice->created_at->format('M d, Y') }}</span>
                        </div>
                        <div style="width: 120px;">
                            <span class="font-semibold text-sm">{{ $invoice->formattedTotal }}</span>
                        </div>
                        <div style="width: 140px;">
                            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium
                                @if ($invoice->status == 'paid') text-success bg-success/20
                                @elseif($invoice->status == 'cancelled') text-info bg-info/20
                                @else text-warning bg-warning/20
                                @endif">
                                @if ($invoice->status == 'paid')
                                    <x-ri-checkbox-circle-fill class="size-3" />
                                @elseif($invoice->status == 'cancelled')
                                    <x-ri-forbid-fill class="size-3" />
                                @elseif($invoice->status == 'pending')
                                    <x-ri-error-warning-fill class="size-3" />
                                @endif
                                <span class="capitalize">{{ $invoice->status }}</span>
                            </div>
                        </div>
                        <div style="width: 40px;" class="flex justify-center">
                            <x-ri-arrow-right-line class="size-5 text-base/40 group-hover:text-base/60 group-hover:translate-x-1 transition-all duration-200" />
                        </div>
                    </div>

                    <div class="{{ $compact ? 'flex' : 'flex sm:hidden' }} items-center gap-3">
                        <div class="flex-1 min-w-0">
                            <div class="flex items-center gap-2 mb-1">
                                <span class="font-medium text-sm">{{ $invoice->number }}</span>
                                <span class="text-base/40">&middot;</span>
                                <span class="font-semibold text-sm">{{ $invoice->formattedTotal }}</span>
                            </div>
                            <p class="text-xs text-base/60 truncate">
                                @foreach ($invoice->items as $item)
                                    {{ $item->description }}@if(!$loop->last), @endif
                                @endforeach
                            </p>
                        </div>
                        <div class="flex items-center gap-2 shrink-0">
                            <div class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium
                                @if ($invoice->status == 'paid') text-success bg-success/20
                                @elseif($invoice->status == 'cancelled') text-info bg-info/20
                                @else text-warning bg-warning/20
                                @endif">
                                @if ($invoice->status == 'paid')
                                    <x-ri-checkbox-circle-fill class="size-3" />
                                @elseif($invoice->status == 'cancelled')
                                    <x-ri-forbid-fill class="size-3" />
                                @elseif($invoice->status == 'pending')
                                    <x-ri-error-warning-fill class="size-3" />
                                @endif
                                <span class="capitalize">{{ $invoice->status }}</span>
                            </div>
                            <x-ri-arrow-right-s-line class="size-4 text-base/40" />
                        </div>
                    </div>
                </a>
            @empty
                <div class="px-6 py-12 text-center">
                    <div class="inline-flex items-center justify-center size-16 bg-primary/10 rounded-full mb-4">
                        <x-ri-bill-line class="size-8 text-primary" />
                    </div>
                    <h3 class="font-semibold text-lg mb-2">{{ __('citadel::citadel.invoices.widget.no_invoices_title') }}</h3>
                    <p class="text-base/60 text-sm">{{ __('citadel::citadel.invoices.widget.no_invoices_description') }}</p>
                </div>
            @endforelse
        </div>
    </div>
</div>
