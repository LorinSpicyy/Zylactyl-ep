<div data-poll-behavior="adaptive" @if ($checkPayment) wire:poll.5s="checkPaymentStatus" @endif>
    
    @if ($this->pay)
        <div class="fixed inset-0 z-50 bg-background-primary/95 backdrop-blur-sm overflow-y-auto">
            <div class="min-h-screen flex items-center justify-center p-4">
                <div class="w-full max-w-2xl bg-background-secondary rounded-xl border border-neutral p-6">
                   
                    <div class="flex items-center justify-between mb-6 pb-4 border-b border-neutral">
                        <div>
                            <h2 class="text-2xl font-bold">{{ __('invoices.payment_for_invoice', ['number' => $invoice->number ?? $invoice->id]) }}</h2>
                            <p class="text-base/60 mt-1">Amount: {{ $invoice->formattedRemaining }}</p>
                        </div>
                        <button wire:confirm="{{ __('citadel::citadel.invoices.show.confirm_exit') }}" wire:click="exitPay" class="text-base/60 hover:text-primary transition-colors">
                            <x-ri-close-fill class="size-8" />
                        </button>
                    </div>
                    
                    
                    <div class="mt-6">
                        {{ $this->pay }}
                    </div>
                </div>
            </div>
        </div>
    @endif

    
    <div class="mb-8 pt-8">
        <h1 class="page-title">{{ __('citadel::citadel.invoices.show.title') }}</h1>
        <p class="normal-text text-base/60 mt-2">
            {{ __('citadel::citadel.invoices.show.subtitle') }}
        </p>
    </div>

    
    <div class="flex flex-col lg:grid lg:grid-cols-4 gap-6">
        
        <div class="lg:col-span-3">
            
            <div class="flex flex-col p-4 sm:p-10 bg-background-secondary rounded-xl border border-neutral relative">
                
                
                <div class="absolute top-4 right-4 sm:top-6 sm:right-6 flex flex-col items-end gap-4">
                    <div class="inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold
                        @if ($invoice->status == 'paid') text-success bg-success/20
                        @elseif($invoice->status == 'cancelled') text-info bg-info/20
                        @else text-warning bg-warning/20
                        @endif">
                        @if ($invoice->status == 'paid')
                            <x-ri-checkbox-circle-fill class="size-4" />
                        @elseif($invoice->status == 'cancelled')
                            <x-ri-forbid-fill class="size-4" />
                        @elseif($invoice->status == 'pending')
                            <x-ri-error-warning-fill class="size-4" />
                        @endif
                        <span class="capitalize">{{ $invoice->status }}</span>
                    </div>
                    
                    
                    <div class="text-end">
                        <h3 class="text-xs font-semibold uppercase mb-2">{{ __('citadel::citadel.invoices.show.bill_from') }}</h3>
                        <address class="not-italic text-base/80 text-xs leading-relaxed">
                            {!! nl2br(e(config('settings.bill_to_text', config('settings.company_name')))) !!}
                        </address>
                    </div>
                </div>
                
                
                
                <div class="grid grid-cols-2 gap-8 min-h-[180px]">
                    <div>
                        
                        <div class="flex items-center gap-3">
                            <x-logo class="size-10" />
                            <h1 class="text-lg md:text-xl font-semibold">{{ config('settings.company_name') }}</h1>
                        </div>
                    </div>
                    
                    <div>
                        
                    </div>
                </div>
                

                
                <div class="mt-8 space-y-1">
                    <div class="flex items-baseline gap-2">
                        <span class="text-sm font-semibold uppercase">{{ __('citadel::citadel.invoices.show.invoice_number') }}</span>
                        <span class="text-base font-semibold">{{ $invoice->number }}</span>
                    </div>
                    <div class="flex items-baseline gap-2">
                        <span class="text-sm font-medium">{{ __('citadel::citadel.invoices.show.invoice_date') }}</span>
                        <span class="text-sm">{{ $invoice->created_at->format('M d, Y') }}</span>
                    </div>
                    @if($invoice->due_at)
                    <div class="flex items-baseline gap-2">
                        <span class="text-sm font-medium">{{ __('citadel::citadel.invoices.show.due_date') }}</span>
                        <span class="text-sm">{{ $invoice->due_at->format('M d, Y') }}</span>
                    </div>
                    @endif
                </div>
                

                
                <div class="mt-8">
                    <div class="flex items-baseline gap-2 mb-2">
                        <h3 class="text-sm font-semibold uppercase">{{ __('citadel::citadel.invoices.show.bill_to') }}</h3>
                        <span class="text-base font-semibold">{{ $invoice->user->name }}</span>
                    </div>
                    <address class="not-italic text-base/60 text-sm">
                        @foreach($invoice->user->properties()->with('parent_property')->whereHas('parent_property', function ($query) {
                            $query->where('show_on_invoice', true);
                        })->get() as $property)
                            {{ $property->value }}<br>
                        @endforeach
                    </address>
                </div>
                

                
                <div class="mt-6">
                    <div class="border border-neutral p-4 rounded-lg space-y-4">
                        <div class="hidden sm:grid sm:grid-cols-5">
                            <div class="sm:col-span-2 text-xs font-medium text-base/60 uppercase">{{ __('citadel::citadel.invoices.show.item') }}</div>
                            <div class="text-start text-xs font-medium text-base/60 uppercase">{{ __('citadel::citadel.invoices.show.qty') }}</div>
                            <div class="text-start text-xs font-medium text-base/60 uppercase">{{ __('citadel::citadel.invoices.show.price') }}</div>
                            <div class="text-end text-xs font-medium text-base/60 uppercase">{{ __('citadel::citadel.invoices.show.amount') }}</div>
                        </div>

                        <div class="hidden sm:block border-b border-neutral"></div>

                        @foreach ($invoice->items as $item)
                        <div class="grid grid-cols-3 sm:grid-cols-5 gap-2">
                            <div class="col-span-full sm:col-span-2">
                                <h5 class="sm:hidden text-xs font-medium text-base/60 uppercase">{{ __('citadel::citadel.invoices.show.item') }}</h5>
                                @if(in_array($item->reference_type, ['App\Models\Service', 'App\Models\ServiceUpgrade']))
                                    <a href="{{ route('services.show', $item->reference_type == 'App\Models\Service' ? $item->reference_id : $item->reference->service_id) }}"
                                        class="font-medium hover:underline underline-offset-2">{{ $item->description }}</a>
                                @else
                                    <p class="font-medium">{{ $item->description }}</p>
                                @endif
                            </div>
                            <div>
                                <h5 class="sm:hidden text-xs font-medium text-base/60 uppercase">{{ __('citadel::citadel.invoices.show.qty') }}</h5>
                                <p>{{ $item->quantity }}</p>
                            </div>
                            <div>
                                <h5 class="sm:hidden text-xs font-medium text-base/60 uppercase">{{ __('citadel::citadel.invoices.show.price') }}</h5>
                                <p>{{ $item->formattedPrice }}</p>
                            </div>
                            <div>
                                <h5 class="sm:hidden text-xs font-medium text-base/60 uppercase">{{ __('citadel::citadel.invoices.show.amount') }}</h5>
                                <p class="sm:text-end">{{ $item->formattedTotal }}</p>
                            </div>
                        </div>

                        @if(!$loop->last)
                        <div class="sm:hidden border-b border-neutral"></div>
                        @endif
                        @endforeach
                    </div>
                </div>


                
                <div class="mt-8 flex sm:justify-end">
                    <div class="w-full max-w-2xl sm:text-end space-y-2">
                        <div class="grid grid-cols-2 sm:grid-cols-1 gap-3 sm:gap-2">
                            @if ($invoice->formattedTotal->tax > 0)
                            <dl class="grid sm:grid-cols-5 gap-x-3">
                                <dt class="col-span-3 font-semibold">{{ __('citadel::citadel.invoices.show.subtotal') }}</dt>
                                <dd class="col-span-2 text-base/60">{{ $invoice->formattedTotal->format($invoice->formattedTotal->price - $invoice->formattedTotal->tax) }}</dd>
                            </dl>
                            <dl class="grid sm:grid-cols-5 gap-x-3">
                                <dt class="col-span-3 font-semibold">{{ \App\Classes\Settings::tax()->name }} ({{ \App\Classes\Settings::tax()->rate }}%):</dt>
                                <dd class="col-span-2 text-base/60">{{ $invoice->formattedTotal->formatted->tax }}</dd>
                            </dl>
                            @endif
                            <dl class="grid sm:grid-cols-5 gap-x-3">
                                <dt class="col-span-3 font-semibold text-lg">{{ __('citadel::citadel.invoices.show.total') }}</dt>
                                <dd class="col-span-2 text-base font-semibold text-lg">{{ $invoice->formattedTotal }}</dd>
                            </dl>
                        </div>
                    </div>
                </div>
                

                
                @if ($invoice->transactions->isNotEmpty())
                    <div class="mt-8 sm:mt-12">
                        <h4 class="text-lg font-semibold mb-4">{{ __('invoices.transactions') }}</h4>
                        <div class="border border-neutral rounded-lg overflow-hidden">
                            <div class="overflow-x-auto">
                                <table class="w-full">
                                    <thead class="bg-background-secondary/50">
                                        <tr>
                                            <th scope="col" class="px-4 py-3 text-xs font-semibold tracking-wider text-left uppercase text-base/60">
                                                {{ __('invoices.date') }}
                                            </th>
                                            <th scope="col" class="px-4 py-3 text-xs font-semibold tracking-wider text-left uppercase text-base/60">
                                                {{ __('invoices.transaction_id') }}
                                            </th>
                                            <th scope="col" class="px-4 py-3 text-xs font-semibold tracking-wider text-left uppercase text-base/60">
                                                {{ __('invoices.gateway') }}
                                            </th>
                                            <th scope="col" class="px-4 py-3 text-xs font-semibold tracking-wider text-left uppercase text-base/60">
                                                {{ __('invoices.amount') }}
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-neutral">
                                        @foreach ($invoice->transactions as $transaction)
                                            <tr class="hover:bg-primary/5">
                                                <td class="px-4 py-3 font-normal whitespace-nowrap">
                                                    {{ $transaction->created_at->format('M d, Y H:i') }}
                                                </td>
                                                <td class="px-4 py-3 font-normal whitespace-nowrap">
                                                    {{ $transaction->transaction_id }}
                                                </td>
                                                <td class="px-4 py-3 font-normal whitespace-nowrap">
                                                    {{ $transaction->gateway?->name }}
                                                </td>
                                                <td class="px-4 py-3 font-normal whitespace-nowrap">
                                                    {{ $transaction->formattedAmount }}
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                @endif
                

                
                <div class="mt-12 pt-6 border-t border-neutral">
                    <h3 class="text-lg font-semibold mb-2">{{ __('citadel::citadel.invoices.show.thank_you_title') }}</h3>
                    <p class="text-sm text-base/70">
                        {{ __('citadel::citadel.invoices.show.thank_you_message') }}
                    </p>
                </div>
                

            </div>
            

            
            <div class="mt-6 flex justify-end gap-x-3">
                <button wire:click="downloadPDF" wire:loading.attr="disabled" class="citadel-btn flex items-center gap-2 justify-center bg-primary text-white text-sm font-medium hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:ring-offset-2 px-4 rounded-lg transition-all duration-200 cursor-pointer disabled:cursor-not-allowed disabled:opacity-50 disabled:bg-primary/50">
                    <span wire:loading.remove wire:target="downloadPDF">
                        <x-ri-download-line class="shrink-0 size-4" />
                    </span>
                    <span wire:loading wire:target="downloadPDF">
                        <x-ri-loader-5-fill class="shrink-0 size-4 animate-spin" />
                    </span>
                    <span wire:loading.remove wire:target="downloadPDF">{{ __('citadel::citadel.invoices.show.download_invoice') }}</span>
                    <span wire:loading wire:target="downloadPDF">{{ __('citadel::citadel.invoices.show.downloading') }}</span>
                </button>
            </div>
            
        </div>
        

        
        <div class="lg:col-span-1">
            <div class="bg-background-secondary border border-neutral rounded-lg p-6 sticky top-6">
                
                
                <div class="mb-4 pb-4 border-b border-neutral">
                    <div class="flex flex-col gap-1">
                        <span class="text-sm text-base/60">{{ __('citadel::citadel.invoices.show.amount_due') }}</span>
                        <div class="text-3xl font-bold">
                            @if($invoice->status == 'paid')
                                {{ $invoice->formattedTotal->format(0) }}
                            @else
                                {{ $invoice->formattedTotal }}
                            @endif
                        </div>
                    </div>
                </div>

                @if ($invoice->status == 'pending')
                    @if($checkPayment || $invoice->transactions->where('status', \App\Enums\InvoiceTransactionStatus::Processing)->where('created_at', '>=', now()->subDays(1))->count() > 0)
                        <div class="text-yellow-500 mb-6 text-lg text-center flex items-center justify-center">
                            {{ __('invoices.payment_processing') }}
                            <x-ri-loader-5-fill aria-hidden="true" class="size-6 ms-2 fill-yellow-600 animate-spin" />
                        </div>
                    @else
                        
                        @php
                        $credit = Auth::user()->credits()
                            ->where('currency_code', $invoice->currency_code)
                            ->where('amount', '>', 0)
                            ->first();
                        $itemHasCredit = $invoice->items()->where('reference_type', App\Models\Credit::class)->exists();
                        @endphp

                        <div class="mb-3">
                            <h3 class="text-sm font-semibold text-base/70">{{ __('citadel::citadel.invoices.show.pay_with') }}</h3>
                        </div>

                        <div class="space-y-2">
                            
                            @if(config('settings.credits_enabled') && $credit && !$itemHasCredit)
                            <div wire:click="$set('selectedMethod', 'credit')"
                                wire:loading.class="opacity-50 pointer-events-none" wire:target="selectedMethod,processPayment"
                                class="flex items-center justify-between p-3 bg-background border border-neutral rounded-lg cursor-pointer transition-all {{ $selectedMethod === 'credit' ? 'border-primary/50 ring-2 ring-primary/10 bg-primary/5' : 'hover:border-primary/50' }}">
                                <div class="flex items-center gap-3">
                                    <div class="text-primary">
                                        <x-ri-copper-coin-line class="size-5" />
                                    </div>
                                    <div>
                                        <div class="font-medium text-sm">{{ __('citadel::citadel.invoices.show.account_credit') }}</div>
                                        <div class="text-xs text-base/60">{{ __('citadel::citadel.invoices.show.available_credit') }} {{ $credit->formattedAmount }}</div>
                                    </div>
                                </div>
                                <div class="size-5 rounded-full border flex items-center justify-center {{ $selectedMethod === 'credit' ? 'border-primary bg-primary' : 'border-neutral-focus' }}">
                                    @if($selectedMethod === 'credit')
                                    <x-ri-check-line class="size-3 text-white" />
                                    @endif
                                </div>
                            </div>
                            @endif

                           
                            @if($this->savedPaymentMethods && $this->savedPaymentMethods->count() > 0)
                                @foreach($this->savedPaymentMethods as $method)
                                <div wire:click="$set('selectedMethod', '{{ $method->ulid }}')"
                                    class="flex items-center justify-between p-3 bg-background border border-neutral rounded-lg cursor-pointer transition-all {{ $selectedMethod === $method->ulid ? 'border-primary/50 ring-2 ring-primary/10 bg-primary/5' : 'hover:border-primary/50' }}"
                                    wire:loading.class="opacity-50 pointer-events-none" wire:target="selectedMethod,processPayment">
                                    <div class="flex items-center gap-3">
                                        <div class="shrink-0">
                                            @switch(strtolower($method->type))
                                            @case('visa')
                                            <x-icons.visa class="size-8" /> @break
                                            @case('mastercard')
                                            <x-icons.mastercard class="size-8" /> @break
                                            @case('amex')
                                            <x-icons.amex class="size-8" /> @break
                                            @case('american express')
                                            <x-icons.american-express class="size-8" /> @break
                                            @case('discover')
                                            <x-icons.discover class="size-8" /> @break
                                            @case('paypal')
                                            <x-icons.paypal class="size-8" /> @break
                                            @case('sepa_debit')
                                            <x-icons.sepa class="size-8" /> @break
                                            @case('ideal')
                                            <x-icons.ideal class="size-8" /> @break
                                            @case('bancontact')
                                            <x-icons.bancontact class="size-8" /> @break
                                            @case('sofort')
                                            <x-icons.sofort class="size-8" /> @break
                                            @case('us_bank_account')
                                            @case('bacs_debit')
                                            @case('au_becs_debit')
                                            <x-icons.bank-debit class="size-8" /> @break
                                            @default
                                            <x-ri-bank-card-line class="size-5 text-primary" />
                                            @endswitch
                                        </div>
                                        <div>
                                            <div class="font-medium text-sm">{{ $method->name }}</div>
                                            @if($method->expiry)
                                            <div class="text-xs text-base/50">
                                                Expires: {{ \Carbon\Carbon::parse($method->expiry)->format('m/Y') }}
                                            </div>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="size-5 rounded-full border flex items-center justify-center {{ $selectedMethod === $method->ulid ? 'border-primary bg-primary' : 'border-neutral-focus' }}">
                                        @if($selectedMethod === $method->ulid)
                                        <x-ri-check-line class="size-3 text-white" />
                                        @endif
                                    </div>
                                </div>
                                @endforeach
                            @endif

                            
                            @if($this->gateways && count($this->gateways) > 0)
                                @if($this->savedPaymentMethods && $this->savedPaymentMethods->count() > 0)
                                <div x-data="{ showGateways: false }">
                                    <button @click="showGateways = !showGateways"
                                        class="flex items-center justify-between w-full p-3 text-left rounded-lg border border-neutral transition-colors hover:border-primary/50">
                                        <span class="text-sm font-medium">{{ __('invoices.pay_with_one_time_method') }}</span>
                                        <x-ri-arrow-down-s-line class="size-5 text-base/50 transition-transform duration-200"
                                            x-bind:class="{ 'rotate-180': showGateways }" />
                                    </button>
                                    
                                    <div x-show="showGateways" x-transition class="mt-2 space-y-2">
                                        @foreach($this->gateways as $gateway)
                                        <div wire:click="$set('selectedMethod', 'gateway-{{ $gateway->id }}')"
                                            class="flex items-center justify-between p-3 bg-background border border-neutral rounded-lg cursor-pointer transition-all {{ $selectedMethod === 'gateway-' . $gateway->id ? 'border-primary/50 ring-2 ring-primary/10 bg-primary/5' : 'hover:border-primary/50' }}"
                                            wire:loading.class="opacity-50 pointer-events-none" wire:target="selectedMethod,processPayment">
                                            <div class="flex items-center gap-3">
                                                <div class="bg-background-secondary border border-neutral rounded-lg overflow-hidden flex items-center justify-center size-8 shrink-0">
                                                    @if($gateway->meta?->icon)
                                                    <img src="{{ $gateway->meta->icon }}" alt="{{ $gateway->name }}" class="size-8 object-contain" />
                                                    @else
                                                    <x-ri-secure-payment-line class="size-4 text-primary" />
                                                    @endif
                                                </div>
                                                <div>
                                                    <p class="font-medium text-sm">{{ $gateway->name }}</p>
                                                    <p class="text-xs text-base/50">{{ __('invoices.one_time_payment') }}</p>
                                                </div>
                                            </div>
                                            <div class="size-5 rounded-full border flex items-center justify-center {{ $selectedMethod === 'gateway-' . $gateway->id ? 'border-primary bg-primary' : 'border-neutral-focus' }}">
                                                @if($selectedMethod === 'gateway-' . $gateway->id)
                                                <x-ri-check-line class="size-3 text-white" />
                                                @endif
                                            </div>
                                        </div>
                                        @endforeach
                                    </div>
                                </div>
                                @else
                                @foreach($this->gateways as $gateway)
                                <div wire:click="$set('selectedMethod', 'gateway-{{ $gateway->id }}')"
                                    class="flex items-center justify-between p-3 bg-background border border-neutral rounded-lg cursor-pointer transition-all {{ $selectedMethod === 'gateway-' . $gateway->id ? 'border-primary/50 ring-2 ring-primary/10 bg-primary/5' : 'hover:border-primary/50' }}"
                                    wire:loading.class="opacity-50 pointer-events-none" wire:target="selectedMethod,processPayment">
                                    <div class="flex items-center gap-3">
                                        <div class="bg-background-secondary border border-neutral rounded-lg overflow-hidden flex items-center justify-center size-8 shrink-0">
                                            @if($gateway->meta?->icon)
                                            <img src="{{ $gateway->meta->icon }}" alt="{{ $gateway->name }}" class="size-8 object-contain" />
                                            @else
                                            <x-ri-secure-payment-line class="size-4 text-primary" />
                                            @endif
                                        </div>
                                        <div>
                                            <p class="font-medium text-sm">{{ $gateway->name }}</p>
                                            <p class="text-xs text-base/50">{{ __('invoices.one_time_payment') }}</p>
                                        </div>
                                    </div>
                                    <div class="size-5 rounded-full border flex items-center justify-center {{ $selectedMethod === 'gateway-' . $gateway->id ? 'border-primary bg-primary' : 'border-neutral-focus' }}">
                                        @if($selectedMethod === 'gateway-' . $gateway->id)
                                        <x-ri-check-line class="size-3 text-white" />
                                        @endif
                                    </div>
                                </div>
                                @endforeach
                                @endif
                            @endif

                            
                            @if($selectedMethod && $selectedMethod !== 'credit' && !str_starts_with($selectedMethod, 'gateway-') && $this->recurringServices()->exists())
                            <div class="pt-2">
                                <x-form.toggle :label="__('invoices.use_for_recurring')" wire:model.live="setAsDefault" />
                            </div>
                            @endif

                            
                            <div class="pt-4">
                                <x-button.primary class="w-full" wire:click="processPayment" wire:loading.attr="disabled" :disabled="!$selectedMethod">
                                    <x-loading target="processPayment" />
                                    <div wire:loading.remove wire:target="processPayment">
                                        @if($selectedMethod === 'credit' && $credit && $credit->amount >= $invoice->formattedRemaining->total)
                                        {{ __('invoices.apply_credits_and_pay') }}
                                        @elseif($selectedMethod === 'credit' && $credit)
                                        {{ __('invoices.apply_credit_and_continue', ['amount' => $credit->formattedAmount]) }}
                                        @else
                                        {{ __('invoices.pay_now', ['amount' => $invoice->formattedRemaining]) }}
                                        @endif
                                    </div>
                                </x-button.primary>
                            </div>
                        </div>
                    @endif
                @else
                    
                    <x-button.primary disabled class="w-full opacity-50 cursor-not-allowed">
                        {{ __('citadel::citadel.invoices.show.pay_invoice') }}
                    </x-button.primary>
                @endif
            </div>
        </div>
        
    </div>
   

</div>
