<div>
    
    <div class="mb-8 pt-8">
        <h1 class="page-title">{{ __('citadel::citadel.dashboard.title') }}</h1>
        <p class="normal-text text-base/60 mt-2">
            {{ __('citadel::citadel.dashboard.dashboard_description') }}
        </p>
    </div>

    @php
        $_overviewPanel = true;
        $showProfileCard = theme('enable_profile_card', true);
        $showSecondaryCard = theme('enable_secondary_card', true);
        $showSidebar = $showProfileCard || $showSecondaryCard;
    @endphp
    
    <div class="grid grid-cols-1 {{ $showSidebar ? 'lg:grid-cols-7' : '' }} gap-6 mb-8">
        
        @if($showSidebar)
        <div class="lg:col-span-2 hidden lg:block">
            @if(theme('enable_profile_card', true))
            @php
                $profileBg = theme('profile_card_background', 'overlay');
                $profileTextColor = theme('profile_card_text_color', 'dark');
                $isLightText = $profileTextColor === 'light';
                
                $hidePicture = theme('profile_card_hide_picture');
                $hideDetails = theme('profile_card_hide_details');
                $hideAddress = theme('profile_card_hide_address');
                $hideBalance = theme('profile_card_hide_balance');
                $allHidden = $hidePicture && $hideDetails && $hideAddress && $hideBalance;
                
                $profileCardStyle = '';
                if ($profileBg === 'gradient') {
                    $gAngle = theme('profile_card_gradient_angle', '30');
                    $g1 = theme('profile_card_gradient_color_1', 'hsl(249, 100%, 62%)');
                    $g2 = theme('profile_card_gradient_color_2', 'hsl(225, 100%, 72%)');
                    $g3 = theme('profile_card_gradient_color_3', 'hsl(195, 100%, 72%)');
                    $g4 = theme('profile_card_gradient_color_4', 'hsl(255, 100%, 62%)');
                    $profileCardStyle = 'background: linear-gradient(' . $gAngle . 'deg, ' . $g1 . ' 0%, ' . $g2 . ' 33%, ' . $g3 . ' 66%, ' . $g4 . ' 100%);';
                } elseif ($profileBg === 'solid') {
                    $profileCardStyle = 'background-image: linear-gradient(-225deg, hsl(var(--color-primary) / 0.9) 0%, hsl(var(--color-primary)) 48%, hsl(var(--color-primary) / 0.7) 100%);';
                }
            @endphp
            @if(!$allHidden)
            <div class="bg-background-secondary border border-neutral rounded-lg p-6 relative overflow-hidden" @if($profileCardStyle) style="{{ $profileCardStyle }}" @endif>
                
                @if($profileBg === 'overlay')
                <div class="absolute inset-0 pointer-events-none">
                    <div class="absolute inset-0 bg-gradient-to-t from-primary/20 via-primary/5 to-transparent"></div>
                </div>
                @endif
                
                
                <a href="{{ route('account') }}" wire:navigate class="absolute top-3 right-3 p-1.5 rounded-lg {{ $isLightText ? 'text-white/70 hover:text-white hover:bg-white/10' : 'text-base/50 hover:text-base hover:bg-black/5' }} transition-all duration-200 z-10">
                    <x-ri-edit-2-fill class="size-4" />
                </a>
                
                <div class="flex flex-col relative z-10">
                    
                    @if(!theme('profile_card_hide_picture'))
                    <img src="{{ citadel_avatar_url(auth()->user()) }}" 
                         alt="{{ auth()->user()->name }}" 
                         class="size-20 rounded-full border {{ $isLightText ? 'border-white/20' : 'border-neutral' }} mb-4" />
                    @endif
                    
                    @if(!theme('profile_card_hide_details'))
                    <h3 class="secondary-title mb-1 {{ $isLightText ? '!text-white' : '' }}">{{ auth()->user()->name }}</h3>
                    <p class="small-text {{ $isLightText ? 'text-white/70' : 'text-base/50' }} mb-4">{{ auth()->user()->email }}</p>
                    @endif
                    
                    
                    @php
                        $properties = auth()->user()->properties()->with('parent_property')->whereHas('parent_property')->get();
                        $address = $properties->firstWhere('key', 'address')?->value;
                        $city = $properties->firstWhere('key', 'city')?->value;
                        $state = $properties->firstWhere('key', 'state')?->value;
                        $zip = $properties->firstWhere('key', 'zip')?->value;
                        $country = $properties->firstWhere('key', 'country')?->value;
                        
                        $hasAddress = $address || $city || $state || $zip || $country;
                    @endphp
                    
                    @if(!theme('profile_card_hide_address'))
                    @if($hasAddress)
                        <div class="space-y-0.5">
                            @if($address)
                                <p class="small-text {{ $isLightText ? 'text-white/80' : 'text-base/70' }}">{{ $address }}</p>
                            @endif
                            @if($city || $state || $zip)
                                <p class="small-text {{ $isLightText ? 'text-white/80' : 'text-base/70' }}">
                                    @if($city){{ $city }}@endif@if($city && ($state || $zip)), @endif
                                    @if($state){{ $state }}@endif
                                    @if($zip) {{ $zip }}@endif
                                </p>
                            @endif
                            @if($country)
                                <p class="small-text {{ $isLightText ? 'text-white/80' : 'text-base/70' }}">{{ $country }}</p>
                            @endif
                        </div>
                    @endif
                    @endif
                    
                    
                    @if(!theme('profile_card_hide_balance'))
                    @if(config('settings.credits_enabled'))
                        
                        <div class="w-full border-t {{ $isLightText ? 'border-white/20' : 'border-neutral' }} my-4"></div>
                        
                        <a href="{{ route('account.credits') }}" wire:navigate class="w-full block">
                            <div class="w-full space-y-3 transition-all duration-200 hover:opacity-80 cursor-pointer">
                                @if(auth()->user()->credits->count() > 0)
                                    @foreach(auth()->user()->credits as $credit)
                                    <div class="flex justify-between items-center">
                                        <span class="normal-text {{ $isLightText ? 'text-white/70' : 'text-base/60' }}">{{ __('citadel::citadel.dashboard.balance') }} ({{ $credit->currency->code }})</span>
                                        <span class="text-3xl font-bold {{ $isLightText ? 'text-white' : '' }}">{{ $credit->formattedAmount }}</span>
                                    </div>
                                    @endforeach
                                @else
                                    <div class="flex justify-between items-center">
                                        <span class="normal-text {{ $isLightText ? 'text-white/70' : 'text-base/60' }}">{{ __('citadel::citadel.dashboard.balance') }}</span>
                                        <span class="text-3xl font-bold {{ $isLightText ? 'text-white' : '' }}">$0.00</span>
                                    </div>
                                @endif
                            </div>
                        </a>
                    @endif
                    @endif
                </div>
            </div>
            @endif {{--  --}}
            @endif {{--  --}}
            
            

            @if($showSecondaryCard)
            @if(!theme('enable_secondary_multiple'))

            @php
                $secondaryCardType = theme('secondary_card_type', 'discord');
            @endphp

            @if($secondaryCardType === 'discord' && theme('discord_invite_link'))
            @php $discordDesign = theme('discord_card_design', 'classic'); @endphp


            @if($discordDesign === 'classic')
            <a href="{{ theme('discord_invite_link') }}" target="_blank" class="block mt-6 group">
                <div class="relative overflow-hidden rounded-lg p-6 bg-[#5865f2] transition-transform duration-200 hover:scale-[1.02]">
                    <div class="relative z-10 flex items-center justify-between">
                        <div class="flex-1">
                            <h3 class="text-lg font-semibold text-white transition-all duration-200 group-hover:brightness-125 mb-1">{{ __('citadel::citadel.dashboard.discord_title') }}</h3>
                            <p class="text-sm text-white/80 transition-all duration-200 group-hover:brightness-125">{{ __('citadel::citadel.dashboard.discord_subtitle') }}</p>
                        </div>
                        <x-ri-discord-fill class="size-10 text-white transition-all duration-200 group-hover:brightness-125 flex-shrink-0 ml-4" />
                    </div>
                </div>
            </a>


            @elseif($discordDesign === 'button')
            <a href="{{ theme('discord_invite_link') }}" target="_blank" class="citadel-discord-btn mt-6">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 16 16">
                    <path d="M13.545 2.907a13.227 13.227 0 0 0-3.257-1.011.05.05 0 0 0-.052.025c-.141.25-.297.577-.406.833a12.19 12.19 0 0 0-3.658 0 8.258 8.258 0 0 0-.412-.833.051.051 0 0 0-.052-.025c-1.125.194-2.22.534-3.257 1.011a.041.041 0 0 0-.021.018C.356 6.024-.213 9.047.066 12.032c.001.014.01.028.021.037a13.276 13.276 0 0 0 3.995 2.02.05.05 0 0 0 .056-.019c.308-.42.582-.863.818-1.329a.05.05 0 0 0-.01-.059.051.051 0 0 0-.018-.011 8.875 8.875 0 0 1-1.248-.595.05.05 0 0 1-.02-.066.051.051 0 0 1 .015-.019c.084-.063.168-.129.248-.195a.05.05 0 0 1 .051-.007c2.619 1.196 5.454 1.196 8.041 0a.052.052 0 0 1 .053.007c.08.066.164.132.248.195a.051.051 0 0 1-.004.085 8.254 8.254 0 0 1-1.249.594.05.05 0 0 0-.03.03.052.052 0 0 0 .003.041c.24.465.515.909.817 1.329a.05.05 0 0 0 .056.019 13.235 13.235 0 0 0 4.001-2.02.049.049 0 0 0 .021-.037c.334-3.451-.559-6.449-2.366-9.106a.034.034 0 0 0-.02-.019Zm-8.198 7.307c-.789 0-1.438-.724-1.438-1.612 0-.889.637-1.613 1.438-1.613.807 0 1.45.73 1.438 1.613 0 .888-.637 1.612-1.438 1.612Zm5.316 0c-.788 0-1.438-.724-1.438-1.612 0-.889.637-1.613 1.438-1.613.807 0 1.451.73 1.438 1.613 0 .888-.631 1.612-1.438 1.612Z"/>
                </svg>
                {{ __('citadel::citadel.dashboard.discord_title') }}
            </a>


            @elseif($discordDesign === 'glass')
            <a href="{{ theme('discord_invite_link') }}" target="_blank" class="block mt-6">
                <div class="group relative p-4 rounded-lg border border-[#6e78f7]/30 bg-[#5865f2]/80 hover:bg-[#4752c4]/80 transition-colors duration-300 ease-out cursor-pointer overflow-hidden">
                    <div class="relative z-10 flex items-center gap-4">
                        <div class="p-3 rounded-lg bg-white/25 group-hover:bg-white/30 transition-colors duration-300">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512" class="w-7 h-7 fill-current text-white group-hover:text-white/90 transition-colors duration-300">
                                <path d="M524.531 69.836a1.5 1.5 0 0 0-.764-.7A485.065 485.065 0 0 0 404.081 32.03a1.816 1.816 0 0 0-1.923.91 337.461 337.461 0 0 0-14.9 30.6 447.848 447.848 0 0 0-134.426 0 309.541 309.541 0 0 0-15.135-30.6 1.89 1.89 0 0 0-1.924-.91 483.689 483.689 0 0 0-119.688 37.107 1.712 1.712 0 0 0-.788.676C39.068 183.651 18.186 294.69 28.43 404.354a2.016 2.016 0 0 0 .765 1.375 487.666 487.666 0 0 0 146.825 74.189 1.9 1.9 0 0 0 2.063-.676A348.2 348.2 0 0 0 208.12 430.4a1.86 1.86 0 0 0-1.019-2.588 321.173 321.173 0 0 1-45.868-21.853 1.885 1.885 0 0 1-.185-3.126 251.047 251.047 0 0 0 9.109-7.137 1.819 1.819 0 0 1 1.9-.256c96.229 43.917 200.41 43.917 295.5 0a1.812 1.812 0 0 1 1.924.233 234.533 234.533 0 0 0 9.132 7.16 1.884 1.884 0 0 1-.162 3.126 301.407 301.407 0 0 1-45.89 21.83 1.875 1.875 0 0 0-1 2.611 391.055 391.055 0 0 0 30.014 48.815 1.864 1.864 0 0 0 2.063.7A486.048 486.048 0 0 0 610.7 405.729a1.882 1.882 0 0 0 .765-1.352c12.264-126.783-20.532-236.912-86.934-334.541zM222.491 337.58c-28.972 0-52.844-26.587-52.844-59.239s23.409-59.241 52.844-59.241c29.665 0 53.306 26.82 52.843 59.239 0 32.654-23.41 59.241-52.843 59.241zm195.38 0c-28.971 0-52.843-26.587-52.843-59.239s23.409-59.241 52.843-59.241c29.667 0 53.307 26.820 52.844 59.239 0 32.654-23.177 59.241-52.844 59.241z"/>
                            </svg>
                        </div>
                        <div class="flex-1 text-left">
                            <p class="text-white font-bold text-lg transition-colors duration-300">{{ __('citadel::citadel.dashboard.discord_title') }}</p>
                            <p class="text-white/70 text-sm group-hover:text-white/80 transition-colors duration-300">{{ __('citadel::citadel.dashboard.discord_subtitle') }}</p>
                        </div>
                        <div class="opacity-40 group-hover:opacity-100 group-hover:translate-x-1 transition-all duration-300">
                            <svg viewBox="0 0 24 24" stroke="currentColor" fill="none" class="w-5 h-5 text-white">
                                <path d="M9 5l7 7-7 7" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"></path>
                            </svg>
                        </div>
                    </div>
                </div>
            </a>


            @elseif($discordDesign === 'banner')
            <a href="{{ theme('discord_invite_link') }}" target="_blank" class="block mt-6 group">
                <div class="relative overflow-hidden rounded-lg bg-indigo-50 dark:bg-indigo-950 transition-transform duration-200 hover:scale-[1.02]">
                    <img src="{{ asset('assets/images/discord.svg') }}" alt="Join our Discord" class="w-full h-auto" />
                </div>
            </a>

            @elseif($discordDesign === 'card')
            @php
                $scTagline  = theme('discord_card_tagline', 'Join 3,000+ members');
                $scTitle    = theme('discord_card_title_custom', 'Get Support on Discord');
                $scDesc     = theme('discord_card_desc_custom', 'Join our community for quick help, updates, and more.');
                $scBtnText  = theme('discord_card_btn_text', 'Join Our Discord');
                $scIcon     = theme('discord_card_icon', 'support');
            @endphp
            <div class="mt-6 bg-background-secondary border border-neutral rounded-lg p-5 flex flex-col gap-4">
                <div>
                    @if($scTagline)
                    <p class="text-xs font-medium mb-2 text-muted-foreground">{{ $scTagline }}</p>
                    @endif
                    @if($scTitle)
                    <h3 class="text-base font-semibold text-foreground">{{ $scTitle }}</h3>
                    @endif
                    @if($scDesc)
                    <p class="mt-1 text-sm text-muted-foreground">{{ $scDesc }}</p>
                    @endif
                </div>
                <a href="{{ theme('discord_invite_link') }}" target="_blank" class="citadel-btn w-full flex items-center justify-center gap-2 px-4 rounded-lg bg-[#5865f2] hover:bg-[#4752c4] text-white font-medium text-sm transition-colors duration-200">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 16 16"><path d="M13.545 2.907a13.227 13.227 0 0 0-3.257-1.011.05.05 0 0 0-.052.025c-.141.25-.297.577-.406.833a12.19 12.19 0 0 0-3.658 0 8.258 8.258 0 0 0-.412-.833.051.051 0 0 0-.052-.025c-1.125.194-2.22.534-3.257 1.011a.041.041 0 0 0-.021.018C.356 6.024-.213 9.047.066 12.032c.001.014.01.028.021.037a13.276 13.276 0 0 0 3.995 2.02.05.05 0 0 0 .056-.019c.308-.42.582-.863.818-1.329a.05.05 0 0 0-.01-.059.051.051 0 0 0-.018-.011 8.875 8.875 0 0 1-1.248-.595.05.05 0 0 1-.02-.066.051.051 0 0 1 .015-.019c.084-.063.168-.129.248-.195a.05.05 0 0 1 .051-.007c2.619 1.196 5.454 1.196 8.041 0a.052.052 0 0 1 .053.007c.08.066.164.132.248.195a.051.051 0 0 1-.004.085 8.254 8.254 0 0 1-1.249.594.05.05 0 0 0-.03.03.052.052 0 0 0 .003.041c.24.465.515.909.817 1.329a.05.05 0 0 0 .056.019 13.235 13.235 0 0 0 4.001-2.02.049.049 0 0 0 .021-.037c.334-3.451-.559-6.449-2.366-9.106a.034.034 0 0 0-.02-.019Zm-8.198 7.307c-.789 0-1.438-.724-1.438-1.612 0-.889.637-1.613 1.438-1.613.807 0 1.45.73 1.438 1.613 0 .888-.637 1.612-1.438 1.612Zm5.316 0c-.788 0-1.438-.724-1.438-1.612 0-.889.637-1.613 1.438-1.613.807 0 1.451.73 1.438 1.613 0 .888-.631 1.612-1.438 1.612Z"/></svg>
                    {{ $scBtnText }}
                </a>
            </div>
            @endif

            @elseif($secondaryCardType === 'custom_html' && theme('secondary_card_custom_html'))
            <div class="mt-6 rounded-lg overflow-hidden">
                {!! theme('secondary_card_custom_html') !!}
            </div>

            @elseif($secondaryCardType === 'custom_card')
            @php
                $scDesign = theme('secondary_card_design', 'top_border');
                $scTitle = theme('secondary_card_title', '');
                $scDesc = theme('secondary_card_description', '');
                $scBtnText = theme('secondary_card_button_text', '');
                $scBtnLink = theme('secondary_card_button_link', '');
                $scImage = theme('secondary_card_image', '');
                $scImageUrl = $scImage ? asset('storage/' . $scImage) : '';
            @endphp

            @if($scTitle || $scDesc || $scBtnText)
            <div class="mt-6">

                @if($scDesign === 'top_border')
                <div class="relative flex flex-col bg-background-secondary border border-neutral border-t-4 rounded-lg overflow-hidden" style="border-top-color: hsl(var(--color-primary));">
                    @if($scImageUrl)
                    <div class="absolute inset-0">
                        <img src="{{ $scImageUrl }}" alt="" class="w-full h-full object-cover" />
                        <div class="absolute inset-0 bg-background-secondary/90 dark:bg-background-secondary/95"></div>
                    </div>
                    @endif
                    <div class="relative z-10 p-5">
                        @if($scTitle)
                        <h3 class="font-semibold" style="color: hsl(var(--color-base));">{{ $scTitle }}</h3>
                        @endif
                        @if($scDesc)
                        <p class="mt-2 text-sm" style="color: hsl(var(--color-base) / 0.6);">{{ $scDesc }}</p>
                        @endif
                        @if($scBtnText && $scBtnLink)
                        <a href="{{ $scBtnLink }}" wire:navigate class="mt-3 inline-flex items-center gap-x-1 text-sm font-semibold transition-colors duration-200 hover:underline" style="color: hsl(var(--color-primary));">
                            {{ $scBtnText }}
                            <svg class="shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>
                        </a>
                        @endif
                    </div>
                </div>


                @elseif($scDesign === 'image_bg')
                <div class="relative bg-background-secondary border border-neutral rounded-lg overflow-hidden" style="min-height: 200px;">
                    @if($scImageUrl)
                    <img src="{{ $scImageUrl }}" alt="" class="w-full h-full absolute inset-0 object-cover" />
                    <div class="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/70"></div>
                    @endif
                    <div class="relative z-10 p-5 flex flex-col justify-between h-full" style="min-height: 200px;">
                        <div>
                            @if($scTitle)
                            <h3 class="font-semibold text-white">{{ $scTitle }}</h3>
                            @endif
                            @if($scDesc)
                            <p class="mt-1 text-sm text-white/80">{{ $scDesc }}</p>
                            @endif
                        </div>
                        @if($scBtnText && $scBtnLink)
                        <a href="{{ $scBtnLink }}" wire:navigate class="mt-4 inline-flex items-center gap-x-1 text-sm font-semibold text-white hover:underline transition-colors duration-200">
                            {{ $scBtnText }}
                            <svg class="shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>
                        </a>
                        @endif
                    </div>
                </div>


                @elseif($scDesign === 'icon_card')
                <div class="flex flex-col bg-background-secondary border border-neutral rounded-lg overflow-hidden">
                    <div class="p-5">
                        <div class="flex items-center gap-3 mb-2">
                            @if($scImageUrl)
                            <img src="{{ $scImageUrl }}" alt="" class="size-10 rounded-lg object-cover flex-shrink-0" />
                            @endif
                            @if($scTitle)
                            <h3 class="font-semibold" style="color: hsl(var(--color-base));">{{ $scTitle }}</h3>
                            @endif
                        </div>
                        @if($scDesc)
                        <p class="mt-1 text-sm" style="color: hsl(var(--color-base) / 0.6);">{{ $scDesc }}</p>
                        @endif
                        @if($scBtnText && $scBtnLink)
                        <a href="{{ $scBtnLink }}" wire:navigate class="mt-3 inline-flex items-center gap-x-1 text-sm font-semibold transition-colors duration-200 hover:underline" style="color: hsl(var(--color-primary));">
                            {{ $scBtnText }}
                            <svg class="shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>
                        </a>
                        @endif
                    </div>
                </div>
                @endif
            </div>
            @endif
            @endif

            @else

            @php
                $secondaryCardsJson = theme('secondary_cards_data', '[]');
                $secondaryCards = is_string($secondaryCardsJson) ? json_decode($secondaryCardsJson, true) : (is_array($secondaryCardsJson) ? $secondaryCardsJson : []);
            @endphp

            @foreach($secondaryCards as $card)
            @php $cardType = $card['type'] ?? 'discord'; @endphp


            @if($cardType === 'discord' && theme('discord_invite_link'))
            @php $mDiscordDesign = $card['discord_card_design'] ?? 'classic'; @endphp

            @if($mDiscordDesign === 'classic')
            <a href="{{ theme('discord_invite_link') }}" target="_blank" class="block mt-6 group">
                <div class="relative overflow-hidden rounded-lg p-6 bg-[#5865f2] transition-transform duration-200 hover:scale-[1.02]">
                    <div class="relative z-10 flex items-center justify-between">
                        <div class="flex-1">
                            <h3 class="text-lg font-semibold text-white transition-all duration-200 group-hover:brightness-125 mb-1">{{ __('citadel::citadel.dashboard.discord_title') }}</h3>
                            <p class="text-sm text-white/80 transition-all duration-200 group-hover:brightness-125">{{ __('citadel::citadel.dashboard.discord_subtitle') }}</p>
                        </div>
                        <x-ri-discord-fill class="size-10 text-white transition-all duration-200 group-hover:brightness-125 flex-shrink-0 ml-4" />
                    </div>
                </div>
            </a>
            @elseif($mDiscordDesign === 'button')
            <a href="{{ theme('discord_invite_link') }}" target="_blank" class="citadel-discord-btn mt-6">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 16 16">
                    <path d="M13.545 2.907a13.227 13.227 0 0 0-3.257-1.011.05.05 0 0 0-.052.025c-.141.25-.297.577-.406.833a12.19 12.19 0 0 0-3.658 0 8.258 8.258 0 0 0-.412-.833.051.051 0 0 0-.052-.025c-1.125.194-2.22.534-3.257 1.011a.041.041 0 0 0-.021.018C.356 6.024-.213 9.047.066 12.032c.001.014.01.028.021.037a13.276 13.276 0 0 0 3.995 2.02.05.05 0 0 0 .056-.019c.308-.42.582-.863.818-1.329a.05.05 0 0 0-.01-.059.051.051 0 0 0-.018-.011 8.875 8.875 0 0 1-1.248-.595.05.05 0 0 1-.02-.066.051.051 0 0 1 .015-.019c.084-.063.168-.129.248-.195a.05.05 0 0 1 .051-.007c2.619 1.196 5.454 1.196 8.041 0a.052.052 0 0 1 .053.007c.08.066.164.132.248.195a.051.051 0 0 1-.004.085 8.254 8.254 0 0 1-1.249.594.05.05 0 0 0-.03.03.052.052 0 0 0 .003.041c.24.465.515.909.817 1.329a.05.05 0 0 0 .056.019 13.235 13.235 0 0 0 4.001-2.02.049.049 0 0 0 .021-.037c.334-3.451-.559-6.449-2.366-9.106a.034.034 0 0 0-.02-.019Zm-8.198 7.307c-.789 0-1.438-.724-1.438-1.612 0-.889.637-1.613 1.438-1.613.807 0 1.45.73 1.438 1.613 0 .888-.637 1.612-1.438 1.612Zm5.316 0c-.788 0-1.438-.724-1.438-1.612 0-.889.637-1.613 1.438-1.613.807 0 1.451.73 1.438 1.613 0 .888-.631 1.612-1.438 1.612Z"/>
                </svg>
                {{ __('citadel::citadel.dashboard.discord_title') }}
            </a>
            @elseif($mDiscordDesign === 'glass')
            <a href="{{ theme('discord_invite_link') }}" target="_blank" class="block mt-6">
                <div class="group relative p-4 rounded-lg border border-[#6e78f7]/30 bg-[#5865f2]/80 hover:bg-[#4752c4]/80 transition-colors duration-300 ease-out cursor-pointer overflow-hidden">
                    <div class="relative z-10 flex items-center gap-4">
                        <div class="p-3 rounded-lg bg-white/25 group-hover:bg-white/30 transition-colors duration-300">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512" class="w-7 h-7 fill-current text-white group-hover:text-white/90 transition-colors duration-300">
                                <path d="M524.531 69.836a1.5 1.5 0 0 0-.764-.7A485.065 485.065 0 0 0 404.081 32.03a1.816 1.816 0 0 0-1.923.91 337.461 337.461 0 0 0-14.9 30.6 447.848 447.848 0 0 0-134.426 0 309.541 309.541 0 0 0-15.135-30.6 1.89 1.89 0 0 0-1.924-.91 483.689 483.689 0 0 0-119.688 37.107 1.712 1.712 0 0 0-.788.676C39.068 183.651 18.186 294.69 28.43 404.354a2.016 2.016 0 0 0 .765 1.375 487.666 487.666 0 0 0 146.825 74.189 1.9 1.9 0 0 0 2.063-.676A348.2 348.2 0 0 0 208.12 430.4a1.86 1.86 0 0 0-1.019-2.588 321.173 321.173 0 0 1-45.868-21.853 1.885 1.885 0 0 1-.185-3.126 251.047 251.047 0 0 0 9.109-7.137 1.819 1.819 0 0 1 1.9-.256c96.229 43.917 200.41 43.917 295.5 0a1.812 1.812 0 0 1 1.924.233 234.533 234.533 0 0 0 9.132 7.16 1.884 1.884 0 0 1-.162 3.126 301.407 301.407 0 0 1-45.89 21.83 1.875 1.875 0 0 0-1 2.611 391.055 391.055 0 0 0 30.014 48.815 1.864 1.864 0 0 0 2.063.7A486.048 486.048 0 0 0 610.7 405.729a1.882 1.882 0 0 0 .765-1.352c12.264-126.783-20.532-236.912-86.934-334.541zM222.491 337.58c-28.972 0-52.844-26.587-52.844-59.239s23.409-59.241 52.844-59.241c29.665 0 53.306 26.82 52.843 59.239 0 32.654-23.41 59.241-52.843 59.241zm195.38 0c-28.971 0-52.843-26.587-52.843-59.239s23.409-59.241 52.843-59.241c29.667 0 53.307 26.820 52.844 59.239 0 32.654-23.177 59.241-52.844 59.241z"/>
                            </svg>
                        </div>
                        <div class="flex-1 text-left">
                            <p class="text-white font-bold text-lg transition-colors duration-300">{{ __('citadel::citadel.dashboard.discord_title') }}</p>
                            <p class="text-white/70 text-sm group-hover:text-white/80 transition-colors duration-300">{{ __('citadel::citadel.dashboard.discord_subtitle') }}</p>
                        </div>
                        <div class="opacity-40 group-hover:opacity-100 group-hover:translate-x-1 transition-all duration-300">
                            <svg viewBox="0 0 24 24" stroke="currentColor" fill="none" class="w-5 h-5 text-white">
                                <path d="M9 5l7 7-7 7" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"></path>
                            </svg>
                        </div>
                    </div>
                </div>
            </a>
            @elseif($mDiscordDesign === 'banner')
            <a href="{{ theme('discord_invite_link') }}" target="_blank" class="block mt-6 group">
                <div class="relative overflow-hidden rounded-lg bg-indigo-50 dark:bg-indigo-950 transition-transform duration-200 hover:scale-[1.02]">
                    <img src="{{ asset('assets/images/discord.svg') }}" alt="Join our Discord" class="w-full h-auto" />
                </div>
            </a>

            @elseif($mDiscordDesign === 'card')
            @php
                $mTagline  = $card['discord_tagline'] ?? 'Join 3,000+ members';
                $mTitle    = $card['discord_title_custom'] ?? 'Get Support on Discord';
                $mDesc     = $card['discord_desc_custom'] ?? 'Join our community for quick help, updates, and more.';
                $mBtnText  = $card['discord_btn_text'] ?? 'Join Our Discord';
                $mIcon     = $card['discord_icon'] ?? 'support';
            @endphp
            <div class="mt-6 bg-background-secondary border border-neutral rounded-lg p-5 flex flex-col gap-4">
                <div>
                    @if($mTagline)
                    <p class="text-xs font-medium mb-2 text-muted-foreground">{{ $mTagline }}</p>
                    @endif
                    @if($mTitle)
                    <h3 class="text-base font-semibold text-foreground">{{ $mTitle }}</h3>
                    @endif
                    @if($mDesc)
                    <p class="mt-1 text-sm text-muted-foreground">{{ $mDesc }}</p>
                    @endif
                </div>
                <a href="{{ theme('discord_invite_link') }}" target="_blank" class="citadel-btn w-full flex items-center justify-center gap-2 px-4 rounded-lg bg-[#5865f2] hover:bg-[#4752c4] text-white font-medium text-sm transition-colors duration-200">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 16 16"><path d="M13.545 2.907a13.227 13.227 0 0 0-3.257-1.011.05.05 0 0 0-.052.025c-.141.25-.297.577-.406.833a12.19 12.19 0 0 0-3.658 0 8.258 8.258 0 0 0-.412-.833.051.051 0 0 0-.052-.025c-1.125.194-2.22.534-3.257 1.011a.041.041 0 0 0-.021.018C.356 6.024-.213 9.047.066 12.032c.001.014.01.028.021.037a13.276 13.276 0 0 0 3.995 2.02.05.05 0 0 0 .056-.019c.308-.42.582-.863.818-1.329a.05.05 0 0 0-.01-.059.051.051 0 0 0-.018-.011 8.875 8.875 0 0 1-1.248-.595.05.05 0 0 1-.02-.066.051.051 0 0 1 .015-.019c.084-.063.168-.129.248-.195a.05.05 0 0 1 .051-.007c2.619 1.196 5.454 1.196 8.041 0a.052.052 0 0 1 .053.007c.08.066.164.132.248.195a.051.051 0 0 1-.004.085 8.254 8.254 0 0 1-1.249.594.05.05 0 0 0-.03.03.052.052 0 0 0 .003.041c.24.465.515.909.817 1.329a.05.05 0 0 0 .056.019 13.235 13.235 0 0 0 4.001-2.02.049.049 0 0 0 .021-.037c.334-3.451-.559-6.449-2.366-9.106a.034.034 0 0 0-.02-.019Zm-8.198 7.307c-.789 0-1.438-.724-1.438-1.612 0-.889.637-1.613 1.438-1.613.807 0 1.45.73 1.438 1.613 0 .888-.637 1.612-1.438 1.612Zm5.316 0c-.788 0-1.438-.724-1.438-1.612 0-.889.637-1.613 1.438-1.613.807 0 1.451.73 1.438 1.613 0 .888-.631 1.612-1.438 1.612Z"/></svg>
                    {{ $mBtnText }}
                </a>
            </div>
            @endif


            @elseif($cardType === 'custom_html' && ($card['custom_html'] ?? ''))
            <div class="mt-6 rounded-lg overflow-hidden">
                {!! $card['custom_html'] !!}
            </div>


            @elseif($cardType === 'custom_card')
            @php
                $mcDesign = $card['card_design'] ?? 'top_border';
                $mcTitle = $card['title'] ?? '';
                $mcDesc = $card['description'] ?? '';
                $mcBtnText = $card['button_text'] ?? '';
                $mcBtnLink = $card['button_link'] ?? '';
                $mcImage = $card['image'] ?? '';
                $mcImageUrl = $mcImage ? asset('storage/' . $mcImage) : '';
            @endphp

            @if($mcTitle || $mcDesc || $mcBtnText)
            <div class="mt-6">
                @if($mcDesign === 'top_border')
                <div class="relative flex flex-col bg-background-secondary border border-neutral border-t-4 rounded-lg overflow-hidden" style="border-top-color: hsl(var(--color-primary));">
                    @if($mcImageUrl)
                    <div class="absolute inset-0">
                        <img src="{{ $mcImageUrl }}" alt="" class="w-full h-full object-cover" />
                        <div class="absolute inset-0 bg-background-secondary/90 dark:bg-background-secondary/95"></div>
                    </div>
                    @endif
                    <div class="relative z-10 p-5">
                        @if($mcTitle)
                        <h3 class="font-semibold" style="color: hsl(var(--color-base));">{{ $mcTitle }}</h3>
                        @endif
                        @if($mcDesc)
                        <p class="mt-2 text-sm" style="color: hsl(var(--color-base) / 0.6);">{{ $mcDesc }}</p>
                        @endif
                        @if($mcBtnText && $mcBtnLink)
                        <a href="{{ $mcBtnLink }}" wire:navigate class="mt-3 inline-flex items-center gap-x-1 text-sm font-semibold transition-colors duration-200 hover:underline" style="color: hsl(var(--color-primary));">
                            {{ $mcBtnText }}
                            <svg class="shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>
                        </a>
                        @endif
                    </div>
                </div>
                @elseif($mcDesign === 'image_bg')
                <div class="relative bg-background-secondary border border-neutral rounded-lg overflow-hidden" style="min-height: 200px;">
                    @if($mcImageUrl)
                    <img src="{{ $mcImageUrl }}" alt="" class="w-full h-full absolute inset-0 object-cover" />
                    <div class="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/70"></div>
                    @endif
                    <div class="relative z-10 p-5 flex flex-col justify-between h-full" style="min-height: 200px;">
                        <div>
                            @if($mcTitle)
                            <h3 class="font-semibold text-white">{{ $mcTitle }}</h3>
                            @endif
                            @if($mcDesc)
                            <p class="mt-1 text-sm text-white/80">{{ $mcDesc }}</p>
                            @endif
                        </div>
                        @if($mcBtnText && $mcBtnLink)
                        <a href="{{ $mcBtnLink }}" wire:navigate class="mt-4 inline-flex items-center gap-x-1 text-sm font-semibold text-white hover:underline transition-colors duration-200">
                            {{ $mcBtnText }}
                            <svg class="shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>
                        </a>
                        @endif
                    </div>
                </div>
                @elseif($mcDesign === 'icon_card')
                <div class="flex flex-col bg-background-secondary border border-neutral rounded-lg overflow-hidden">
                    <div class="p-5">
                        <div class="flex items-center gap-3 mb-2">
                            @if($mcImageUrl)
                            <img src="{{ $mcImageUrl }}" alt="" class="size-10 rounded-lg object-cover flex-shrink-0" />
                            @endif
                            @if($mcTitle)
                            <h3 class="font-semibold" style="color: hsl(var(--color-base));">{{ $mcTitle }}</h3>
                            @endif
                        </div>
                        @if($mcDesc)
                        <p class="mt-1 text-sm" style="color: hsl(var(--color-base) / 0.6);">{{ $mcDesc }}</p>
                        @endif
                        @if($mcBtnText && $mcBtnLink)
                        <a href="{{ $mcBtnLink }}" wire:navigate class="mt-3 inline-flex items-center gap-x-1 text-sm font-semibold transition-colors duration-200 hover:underline" style="color: hsl(var(--color-primary));">
                            {{ $mcBtnText }}
                            <svg class="shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>
                        </a>
                        @endif
                    </div>
                </div>
                @endif
            </div>
            @endif
            @endif

            @endforeach
            @endif
            @endif {{--  --}}

        </div>
        @endif {{--  --}}

        
        <div class="{{ $showSidebar ? 'lg:col-span-5' : 'lg:col-span-1' }} space-y-6">
            

            @php
                $alertsJson = theme('dashboard_alerts_data', '[]');
                $dashboardAlerts = is_string($alertsJson) ? json_decode($alertsJson, true) : (is_array($alertsJson) ? $alertsJson : []);
                

                $showUnpaidNotice = theme('unpaid_invoice_notice', true);
                $unpaidInvoices = null;
                $unpaidCount = 0;
                if ($showUnpaidNotice && Auth::check()) {
                    $unpaidInvoices = Auth::user()->invoices()->where('status', 'pending')->get();
                    $unpaidCount = $unpaidInvoices->count();
                }
                

                $show2faNotice = theme('tfa_notification', false);
                $has2fa = Auth::check() ? !empty(Auth::user()->tfa_secret) : true;

                
                $noticeKeys = [];
                if ($showUnpaidNotice && $unpaidCount > 0 && $unpaidInvoices) {
                    $unpaidIds = $unpaidInvoices->pluck('id')->sort()->implode(',');
                    $noticeKeys[] = 'notice_' . md5('unpaid_' . $unpaidIds);
                }
                if ($show2faNotice && !$has2fa) {
                    $noticeKeys[] = 'notice_2fa_' . Auth::id();
                }
                foreach ($dashboardAlerts as $i => $alert) {
                    if (!empty($alert['title'])) {
                        $noticeKeys[] = 'alert_' . md5(($alert['title'] ?? '') . ($alert['description'] ?? '') . $i);
                    }
                }
            @endphp

            @if($unpaidCount > 0 || ($show2faNotice && !$has2fa) || !empty($dashboardAlerts))
                <div x-data="{ visible: {{ Js::from($noticeKeys) }}.some(k => localStorage.getItem(k) !== 'true') }" x-show="visible" class="space-y-3">

                    @foreach($dashboardAlerts as $alertIndex => $alert)
                        @php
                            $alertColor = $alert['color'] ?? 'hsl(229, 100%, 64%)';
                            $alertIcon = $alert['icon'] ?? 'information-line';
                            $alertTitle = $alert['title'] ?? '';
                            $alertDesc = $alert['description'] ?? '';
                            $alertDismissible = $alert['dismissible'] ?? true;
                            $alertButtons = ($alert['enable_buttons'] ?? false) ? ($alert['buttons'] ?? []) : [];
                            $alertHash = md5($alertTitle . $alertDesc . $alertIndex);
                        @endphp
                        @if($alertTitle)
                        <div x-data="{ dismissed: localStorage.getItem('alert_{{ $alertHash }}') === 'true' }"
                             x-show="!dismissed"
                             x-transition:enter="transition ease-out duration-200"
                             x-transition:enter-start="opacity-0 -translate-y-2"
                             x-transition:enter-end="opacity-100 translate-y-0"
                             x-transition:leave="transition ease-in duration-150"
                             x-transition:leave-start="opacity-100 translate-y-0"
                             x-transition:leave-end="opacity-0 -translate-y-2"
                             class="rounded-lg border p-4 relative"
                             style="background-color: color-mix(in srgb, {{ $alertColor }} 10%, transparent); border-color: color-mix(in srgb, {{ $alertColor }} 25%, transparent);"
                             role="alert">
                            <div class="flex">
                                <div class="shrink-0" style="color: {{ $alertColor }};">
                                    <x-dynamic-component :component="'ri-' . $alertIcon" class="shrink-0 size-5 mt-0.5" />
                                </div>
                                <div class="ms-3 flex-1">
                                    <h3 class="font-semibold text-foreground">
                                        {{ $alertTitle }}
                                    </h3>
                                    @if($alertDesc)
                                        <div class="mt-1 text-sm text-muted-foreground">
                                            {{ $alertDesc }}
                                        </div>
                                    @endif
                                    @if(!empty($alertButtons))
                                        <div class="mt-3">
                                            <div class="flex gap-x-3">
                                                @foreach($alertButtons as $btn)
                                                    <a href="{{ $btn['link'] ?? '#' }}" 
                                                       target="_blank"
                                                       class="inline-flex items-center gap-x-2 text-sm font-semibold rounded-lg border border-transparent hover:opacity-80 transition-opacity"
                                                       style="color: {{ $alertColor }};">
                                                        {{ $btn['text'] ?? 'Button' }}
                                                    </a>
                                                @endforeach
                                            </div>
                                        </div>
                                    @endif
                                </div>
                                @if($alertDismissible)
                                    <button @click="dismissed = true; localStorage.setItem('alert_{{ $alertHash }}', 'true')"
                                            class="absolute top-2 right-2 p-1 rounded-full hover:bg-black/10 dark:hover:bg-white/10 transition-colors cursor-pointer"
                                            aria-label="Dismiss">
                                        <svg class="size-4 text-muted-foreground hover:text-foreground transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                                        </svg>
                                    </button>
                                @endif
                            </div>
                        </div>
                        @endif
                    @endforeach


                    @if($showUnpaidNotice && $unpaidCount > 0)
                        @php
                            $unpaidIds = $unpaidInvoices->pluck('id')->sort()->implode(',');
                            $unpaidHash = md5('unpaid_' . $unpaidIds);
                        @endphp
                        <div x-data="{ dismissed: localStorage.getItem('notice_{{ $unpaidHash }}') === 'true' }"
                             x-show="!dismissed"
                             x-transition:enter="transition ease-out duration-200"
                             x-transition:enter-start="opacity-0 -translate-y-2"
                             x-transition:enter-end="opacity-100 translate-y-0"
                             x-transition:leave="transition ease-in duration-150"
                             x-transition:leave-start="opacity-100 translate-y-0"
                             x-transition:leave-end="opacity-0 -translate-y-2"
                             class="rounded-lg border p-4 relative"
                             style="background-color: color-mix(in srgb, hsl(35, 100%, 55%) 10%, transparent); border-color: color-mix(in srgb, hsl(35, 100%, 55%) 25%, transparent);"
                             role="alert">
                            <div class="flex items-center">
                                <div class="shrink-0" style="color: hsl(35, 100%, 55%);">
                                    <x-ri-error-warning-line class="shrink-0 size-5" />
                                </div>
                                <div class="ms-3 flex-1">
                                    <h3 class="font-semibold text-foreground">
                                        {{ __('citadel::citadel.dashboard.unpaid_notice_title', ['count' => $unpaidCount]) }}
                                    </h3>
                                    <div class="mt-0.5 text-sm text-muted-foreground">
                                        {{ __('citadel::citadel.dashboard.unpaid_notice_description') }}
                                    </div>
                                </div>
                                <a href="{{ route('invoices') }}" 
                                   target="_blank"
                                   class="hidden md:inline-flex items-center gap-x-1.5 text-sm font-semibold rounded-lg border border-transparent hover:opacity-80 transition-opacity shrink-0 ml-4"
                                   style="color: hsl(35, 100%, 55%);">
                                    {{ __('citadel::citadel.dashboard.unpaid_notice_button') }}
                                    <svg class="size-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                                </a>
                                <button @click="dismissed = true; localStorage.setItem('notice_{{ $unpaidHash }}', 'true')"
                                        class="absolute top-2 right-2 p-1 rounded-full hover:bg-black/10 dark:hover:bg-white/10 transition-colors cursor-pointer"
                                        aria-label="Dismiss">
                                    <svg class="size-4 text-muted-foreground hover:text-foreground transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    @endif


                    @if($show2faNotice && !$has2fa)
                        <div x-data="{ dismissed: localStorage.getItem('notice_2fa_{{ Auth::id() }}') === 'true' }"
                             x-show="!dismissed"
                             x-transition:enter="transition ease-out duration-200"
                             x-transition:enter-start="opacity-0 -translate-y-2"
                             x-transition:enter-end="opacity-100 translate-y-0"
                             x-transition:leave="transition ease-in duration-150"
                             x-transition:leave-start="opacity-100 translate-y-0"
                             x-transition:leave-end="opacity-0 -translate-y-2"
                             class="rounded-lg border p-4 relative"
                             style="background-color: color-mix(in srgb, hsl(229, 100%, 64%) 10%, transparent); border-color: color-mix(in srgb, hsl(229, 100%, 64%) 25%, transparent);"
                             role="alert">
                            <div class="flex items-center">
                                <div class="shrink-0" style="color: hsl(229, 100%, 64%);">
                                    <x-ri-shield-keyhole-line class="shrink-0 size-5" />
                                </div>
                                <div class="ms-3 flex-1">
                                    <h3 class="font-semibold text-foreground">
                                        {{ __('citadel::citadel.dashboard.tfa_notice_title') }}
                                    </h3>
                                    <div class="mt-0.5 text-sm text-muted-foreground">
                                        {{ __('citadel::citadel.dashboard.tfa_notice_description') }}
                                    </div>
                                </div>
                                <a href="{{ route('account.security') }}" 
                                   target="_blank"
                                   class="hidden md:inline-flex items-center gap-x-1.5 text-sm font-semibold rounded-lg border border-transparent hover:opacity-80 transition-opacity shrink-0 ml-4"
                                   style="color: hsl(229, 100%, 64%);">
                                    {{ __('citadel::citadel.dashboard.tfa_notice_button') }}
                                    <svg class="size-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                                </a>
                                <button @click="dismissed = true; localStorage.setItem('notice_2fa_{{ Auth::id() }}', 'true')"
                                        class="absolute top-2 right-2 p-1 rounded-full hover:bg-black/10 dark:hover:bg-white/10 transition-colors cursor-pointer"
                                        aria-label="Dismiss">
                                    <svg class="size-4 text-muted-foreground hover:text-foreground transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    @endif
                </div>
            @endif
            
            @if(theme('enable_dashboard_banner') && theme('dashboard_banner') === 'welcome_with_image')
                
                @php
                    $bannerImageRaw = theme('dashboard_banner_image_url');
                    $bannerImage = $bannerImageRaw ? asset('storage/' . $bannerImageRaw) : '';
                    $bannerTitle = theme('dashboard_banner_title');
                    $bannerDescription = theme('dashboard_banner_description');
                    $bannerButtonText = theme('dashboard_banner_button_text');
                    $bannerButtonLink = theme('dashboard_banner_button_link');
                    $bannerOverlay = theme('dashboard_banner_overlay', 'primary');
                    $bannerBtnPos = theme('dashboard_banner_button_position', 'bottom');
                    $bannerDismissible = theme('dashboard_banner_dismissible', false);
                    
                    
                    $hasContent = $bannerTitle || $bannerDescription || ($bannerButtonText && $bannerButtonLink);
                    $minHeight = $hasContent ? 'min-h-[120px]' : 'min-h-[80px]';
                @endphp
                <div 
                    x-data="{ bannerVisible: true }"
                    x-show="bannerVisible"
                    x-transition:leave="transition ease-in duration-200"
                    x-transition:leave-start="opacity-100 scale-100"
                    x-transition:leave-end="opacity-0 scale-95"
                    class="relative rounded-lg p-8 text-white overflow-hidden {{ $minHeight }}"
                >
                    
                    @if($bannerImage)
                    <div class="absolute inset-0 bg-cover bg-center bg-no-repeat" style="background-image: url('{{ $bannerImage }}');"></div>
                    @endif
                    
                    
                    @if($bannerOverlay === 'dark')
                    <div class="absolute inset-0 {{ $bannerImage ? 'bg-gradient-to-b from-black/60 via-black/40 to-black/70' : 'bg-gradient-to-b from-gray-800 via-gray-700 to-gray-800' }}"></div>
                    @else
                    <div class="absolute inset-0 {{ $bannerImage ? 'bg-gradient-to-r from-primary to-primary/70' : 'bg-primary' }}"></div>
                    @endif

                    @if($bannerDismissible)
                    <button 
                        @click="bannerVisible = false" 
                        class="absolute top-3 right-3 z-10 p-1 rounded-full text-white/50 hover:text-white transition-colors duration-200"
                        aria-label="Dismiss banner"
                    >
                        <svg class="size-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                        </svg>
                    </button>
                    @endif
                    
                    
                    @if($hasContent)
                        <div class="relative z-10 flex {{ $bannerBtnPos === 'right' ? 'flex-col md:flex-row md:items-center md:justify-between gap-4 md:gap-6' : 'flex-col items-start justify-start' }}">
                            <div class="text-left {{ $bannerBtnPos === 'right' ? 'md:flex-1' : 'max-w-2xl' }}">
                                @if($bannerTitle)
                                    <h2 class="text-3xl font-bold mb-2 text-white">{{ $bannerTitle }}</h2>
                                @endif
                                
                                @if($bannerDescription)
                                    <p class="text-white/90 text-lg {{ $bannerBtnPos === 'bottom' && $bannerButtonText && $bannerButtonLink ? 'mb-4' : '' }}">{{ $bannerDescription }}</p>
                                @endif
                                
                                @if($bannerBtnPos === 'bottom' && $bannerButtonText && $bannerButtonLink)
                                    <a href="{{ $bannerButtonLink }}" wire:navigate class="citadel-btn inline-flex items-center px-6 {{ $bannerOverlay === 'dark' ? 'bg-white text-gray-900 hover:bg-white/90' : 'bg-white text-primary hover:bg-white/90' }} font-medium text-sm rounded-lg transition-colors duration-200">
                                        {{ $bannerButtonText }}
                                    </a>
                                @endif
                            </div>
                            @if($bannerBtnPos === 'right' && $bannerButtonText && $bannerButtonLink)
                                <a href="{{ $bannerButtonLink }}" wire:navigate class="citadel-btn self-start inline-flex items-center px-6 {{ $bannerOverlay === 'dark' ? 'bg-white text-gray-900 hover:bg-white/90' : 'bg-white text-primary hover:bg-white/90' }} font-medium text-sm rounded-lg transition-colors duration-200 flex-shrink-0">
                                    {{ $bannerButtonText }}
                                </a>
                            @endif
                        </div>
                    @endif
                </div>
            @elseif(theme('enable_dashboard_banner') && theme('dashboard_banner') === 'custom_html')
                
                @if(theme('dashboard_banner_custom_html'))
                    <div class="rounded-lg overflow-hidden">
                        {!! theme('dashboard_banner_custom_html') !!}
                    </div>
                @endif
            @endif
            
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
                
                
                <a href="{{ route('services') }}" 
                   wire:navigate 
                   class="bg-background-secondary border border-neutral rounded-lg p-4 transition-all duration-200 cursor-pointer w-full relative overflow-hidden group">
                    
                    <div class="absolute inset-0 bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-200"></div>
                    @if(theme('dashboard_stat_card_icons'))
                    <div class="absolute -bottom-4 -right-4 w-30 h-30 rotate-[6deg] opacity-60 pointer-events-none group-hover:opacity-85 group-hover:scale-110 transition-all duration-200">
                        <x-citadel-icon name="cube" class="w-full h-full" />
                    </div>
                    @endif
                    <div class="relative z-10 @if(theme('dashboard_stat_card_icons')) text-left pr-24 @else text-center @endif">
                        <p class="text-5xl font-bold mb-2">{{ Auth::user()->services()->where('status', 'active')->count() }}</p>
                        <p class="normal-text text-base/60">{{ __('citadel::citadel.dashboard.active_services') }}</p>
                    </div>
                </a>

                
                <a href="{{ route('invoices') }}" 
                   wire:navigate 
                   class="bg-background-secondary border border-neutral rounded-lg p-4 transition-all duration-200 cursor-pointer w-full relative overflow-hidden group">
                    
                    <div class="absolute inset-0 bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-200"></div>
                    @if(theme('dashboard_stat_card_icons'))
                    <div class="absolute -bottom-4 -right-4 w-30 h-30 rotate-[6deg] opacity-60 pointer-events-none group-hover:opacity-85 group-hover:scale-110 transition-all duration-200">
                        <x-citadel-icon name="invoice" class="w-full h-full" />
                    </div>
                    @endif
                    <div class="relative z-10 @if(theme('dashboard_stat_card_icons')) text-left pr-24 @else text-center @endif">
                        <p class="text-5xl font-bold mb-2">{{ Auth::user()->invoices()->where('status', 'pending')->count() }}</p>
                        <p class="normal-text text-base/60">{{ __('citadel::citadel.dashboard.unpaid_invoices') }}</p>
                    </div>
                </a>

               
                <a href="{{ route('tickets') }}" 
                   wire:navigate 
                   class="bg-background-secondary border border-neutral rounded-lg p-4 transition-all duration-200 cursor-pointer w-full relative overflow-hidden group">
                    
                    <div class="absolute inset-0 bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-200"></div>
                    @if(theme('dashboard_stat_card_icons'))
                    <div class="absolute -bottom-4 -right-4 w-30 h-30 rotate-[6deg] opacity-60 pointer-events-none group-hover:opacity-85 group-hover:scale-110 transition-all duration-200">
                        <x-citadel-icon name="support" class="w-full h-full" />
                    </div>
                    @endif
                    <div class="relative z-10 @if(theme('dashboard_stat_card_icons')) text-left pr-24 @else text-center @endif">
                        <p class="text-5xl font-bold mb-2">{{ Auth::user()->tickets()->where('status', '!=', 'closed')->count() }}</p>
                        <p class="normal-text text-base/60">{{ __('citadel::citadel.dashboard.open_tickets') }}</p>
                    </div>
                </a>
                
            </div>
            
            
            
            
            <livewire:services.widget :limit="3" />

            @php $compactWidgets = theme('dashboard_widget_layout') === 'compact'; @endphp

            @if($compactWidgets)
            
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <livewire:invoices.widget :limit="3" :compact="true" />
                <livewire:tickets.widget :limit="3" :compact="true" />
            </div>
            @else
            @if(!theme('hide_invoices_widget'))
            <livewire:invoices.widget :limit="3" />
            @endif

            @if(!theme('hide_tickets_widget'))
            <livewire:tickets.widget :limit="3" />
            @endif
            @endif
            
        </div> 
    </div> 

    
    <div class="mt-6">
        {!! hook('pages.dashboard') !!}
    </div>
</div>
