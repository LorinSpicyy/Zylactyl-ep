<?php

namespace App\Livewire\Tickets;

use App\Livewire\Component;
use App\Models\Ticket;
use Illuminate\Support\Facades\Auth;
use Livewire\WithPagination;

class Index extends Component
{
    use WithPagination;

    public $status = null;
    public $sortBy = 'newest';
    public $perPage = 10;

    public function mount()
    {

        $this->status = $this->status ?? null;
        $this->sortBy = $this->sortBy ?? 'newest';
        $this->perPage = $this->perPage ?? 10;
    }

    public function setStatus($status)
    {
        $this->status = $status;
        $this->resetPage();
    }

    public function setSortBy($sortBy)
    {
        $this->sortBy = $sortBy;
        $this->resetPage();
    }

    public function render()
    {
        $query = Ticket::where('user_id', Auth::id());

        
        if ($this->status) {
            $query->where('status', $this->status);
        }

        
        if ($this->sortBy === 'oldest') {
            $query->orderBy('created_at', 'asc');
        } else {
            $query->orderBy('created_at', 'desc');
        }

        return view('tickets.index', [
            'tickets' => $query->paginate($this->perPage),
        ])->layoutData([
            'title' => 'Tickets',
            'sidebar' => true,
        ]);
    }
}
