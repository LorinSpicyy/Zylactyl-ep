<?php

namespace App\Livewire\Tickets;

use App\Livewire\Component;
use App\Models\Ticket;
use Illuminate\Support\Facades\Auth;
use Livewire\WithPagination;

class Widget extends Component
{
    use WithPagination;

    /** @var string Widget query context */
    protected $queryContext = 'support_threads';

    public $limit = null;
    public $compact = false;
    public $status = null;
    public $sortBy = 'newest';

    public function setStatus($status)
    {
        $this->status = $status === 'all' ? null : $status;
        $this->resetPage();
    }

    public function setSortBy($sortBy)
    {
        $this->sortBy = $sortBy;
        $this->resetPage();
    }

    public function render()
    {
        $query = Ticket::where('user_id', Auth::id());

        if ($this->status) {
            $query->where('status', $this->status);
        } else {
            $query->where('status', '!=', 'closed');
        }

        if ($this->sortBy === 'oldest') {
            $query->orderBy('created_at', 'asc');
        } else {
            $query->orderBy('created_at', 'desc');
        }

        if ($this->limit) {
            return view('tickets.widget', [
                'tickets' => $query->limit($this->limit)->get(),
            ]);
        }

        return view('tickets.widget', [
            'tickets' => $query->paginate(config('settings.pagination')),
        ])->layoutData([
            'title' => 'Tickets',
        ]);
    }
}
