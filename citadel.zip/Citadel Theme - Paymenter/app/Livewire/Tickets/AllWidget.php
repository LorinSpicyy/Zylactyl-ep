<?php

namespace App\Livewire\Tickets;

use App\Livewire\Component;
use App\Models\Ticket;
use Illuminate\Support\Facades\Auth;

class AllWidget extends Component
{
    public $limit = null;
    public $status = null;
    public $sortBy = 'newest';

    public function setStatus($status)
    {
        $this->status = $status === 'all' ? null : $status;
    }

    public function setSortBy($sortBy)
    {
        $this->sortBy = $sortBy;
    }

    public function render()
    {
        $query = Ticket::where('user_id', Auth::id());

        if ($this->status) {
            $query->where('status', $this->status);
        }

        if ($this->sortBy === 'oldest') {
            $query->orderBy('created_at', 'asc');
        } else {
            $query->orderBy('created_at', 'desc');
        }

        if ($this->limit) {
            $tickets = $query->limit($this->limit)->get();
        } else {
            $tickets = $query->paginate(config('settings.pagination'));
        }

        return view('tickets.widget', [
            'tickets' => $tickets,
        ]);
    }
}
