<?php

namespace App\Livewire\Account;

use App\Livewire\Component;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Livewire\Attributes\Validate;
use Livewire\WithFileUploads;

class AvatarUpload extends Component
{
    use WithFileUploads;


    #[Validate('nullable|image|mimes:jpeg,jpg,png,webp|max:2048')]
    public $avatar = null;

    public function mount(): void
    {
        abort_unless(Auth::check(), 403);
    }

    public function save(): void
    {
        abort_unless(Auth::check(), 403);

        $this->validate([
            'avatar' => ['required', 'image', 'mimes:jpeg,jpg,png,webp', 'max:2048'],
        ]);

        $user = Auth::user();

        
        $ext = strtolower((string) ($this->avatar->guessExtension() ?: $this->avatar->getClientOriginalExtension()));
        if (! in_array($ext, citadel_avatar_extensions(), true)) {
            $ext = 'png';
        }

        
        $this->deleteExisting($user->id);

        
        $this->avatar->storeAs('citadel/avatars', $user->id . '.' . $ext, 'public');

        $this->avatar = null;

        $this->notify(__('citadel::citadel.account.avatar.updated'), 'success');

        
        $this->redirect(route('account'), navigate: true);
    }

    public function remove(): void
    {
        abort_unless(Auth::check(), 403);

        $this->deleteExisting(Auth::id());
        $this->avatar = null;

        $this->notify(__('citadel::citadel.account.avatar.removed'), 'success');

        $this->redirect(route('account'), navigate: true);
    }


    protected function deleteExisting($id): void
    {
        $disk = Storage::disk('public');
        foreach (citadel_avatar_extensions() as $ext) {
            $path = "citadel/avatars/{$id}.{$ext}";
            if ($disk->exists($path)) {
                $disk->delete($path);
            }
        }
    }

    public function render()
    {
        return view('account.avatar-upload', [
            'hasCustomAvatar' => citadel_custom_avatar_path(Auth::user()) !== null,
            'currentAvatarUrl' => citadel_avatar_url(Auth::user()),
        ]);
    }
}
