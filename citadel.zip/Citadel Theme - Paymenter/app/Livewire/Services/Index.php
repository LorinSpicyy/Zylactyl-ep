<?php

namespace App\Livewire\Services;

use App\Livewire\Component;
use Illuminate\Support\Facades\Auth;
use Livewire\WithPagination;

class Index extends Component
{
    use WithPagination;

    public $status = null;
    public $sortBy = 'newest';
    public $perPage = 10;

    public function mount()
    {
        $this->status = $this->status ?? null;
        $this->sortBy = $this->sortBy ?? 'newest';
        $this->perPage = $this->perPage ?? 10;
    }

    public function render()
    {
        $query = Auth::user()->services();


        if ($this->status) {
            $query->where('status', $this->status);
        }

        if ($this->sortBy === 'oldest') {
            $query->orderBy('created_at', 'asc');
        } else {
            $query->orderBy('created_at', 'desc'); 
        }

        return view('services.index', [
            'services' => $query->paginate($this->perPage),
        ])->layoutData([
            'title' => 'Services',
            'sidebar' => true,
        ]);
    }

    public function setStatus($status)
    {
        $this->status = $status === 'all' ? null : $status;
        $this->resetPage();
    }

    public function setSortBy($sortBy)
    {
        $this->sortBy = $sortBy;
        $this->resetPage();
    }

    public function updatedPerPage()
    {
        $this->resetPage();
    }
}