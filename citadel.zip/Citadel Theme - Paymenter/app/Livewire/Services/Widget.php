<?php

namespace App\Livewire\Services;

use App\Livewire\Component;
use Illuminate\Support\Facades\Auth;
use Livewire\WithPagination;

class Widget extends Component
{
    use WithPagination;

    /** @var string Widget scope identifier */
    protected $widgetScope = 'user_services';

    public $limit = null;
    public $status = null;
    public $sortBy = 'newest';

    public function setStatus($status)
    {
        $this->status = $status === 'all' ? null : $status;
        $this->resetPage();
    }

    public function setSortBy($sortBy)
    {
        $this->sortBy = $sortBy;
        $this->resetPage();
    }

    public function render()
    {
        $query = Auth::user()->services();

        if ($this->status) {
            $query->where('status', $this->status);
        } else {
            $query->where('status', '!=', 'cancelled');
        }

        if ($this->sortBy === 'oldest') {
            $query->orderBy('created_at', 'asc');
        } else {
            $query->orderBy('created_at', 'desc');
        }

        if ($this->limit) {
            return view('services.widget', [
                'services' => $query->limit($this->limit)->get(),
            ]);
        }

        return view('services.widget', [
            'services' => $query->paginate(config('settings.pagination')),
        ])->layoutData([
            'title' => 'Services',
        ]);
    }
}
