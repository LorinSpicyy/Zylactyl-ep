<?php

namespace App\Livewire\Services;

use App\Livewire\Component;
use Illuminate\Support\Facades\Auth;

class AllWidget extends Component
{
    public $limit = null;
    public $status = null;
    public $sortBy = 'newest';

    public function render()
    {
        
        $query = Auth::user()->services();

        
        if ($this->status) {
            $query->where('status', $this->status);
        }

        
        if ($this->sortBy === 'oldest') {
            $query->orderBy('created_at', 'asc');
        } else {
            $query->orderBy('created_at', 'desc'); 
        }

       
        if ($this->limit) {
            $services = $query->limit($this->limit)->get();
        } else {
            $services = $query->paginate(config('settings.pagination'));
        }

        
        if (!$this->limit) {
            return view('services.index', [
                'services' => $services,
            ])->layoutData([
                'title' => 'Services',
                'sidebar' => true,
            ]);
        }

        return view('services.widget', [
            'services' => $services,
        ]);
    }

    public function setStatus($status)
    {
        $this->status = $status === 'all' ? null : $status;
    }

    public function setSortBy($sortBy)
    {
        $this->sortBy = $sortBy;
    }
}
