<?php

namespace App\Livewire\Services;

use App\Helpers\ExtensionHelper;
use App\Livewire\Component;
use App\Models\Service;
use App\Models\Invoice;
use App\Models\InvoiceItem;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Livewire\Attributes\Locked;
use Livewire\Attributes\Url;

class Show extends Component
{
    public Service $service;

    #[Locked]
    public $buttons = [];

    #[Locked]
    public $views = [];

    #[Locked]
    public $fields = [];

    #[Url('tab', except: false), Locked]
    public $currentView;

    #[Url('cancel', except: false)]
    public bool $showCancel = false;

    public bool $showBillingAgreement = false;

    public $selectedMethod;

    #[Url('renew', except: false)]
    public bool $showRenew = false;

    public int $renewMonths = 1;

    
    public bool $editLabel = false;

    public ?string $label = null;

    public function mount()
    {
        $this->label = $this->service->label;

        if ($this->service->status == Service::STATUS_ACTIVE) {
            $actions = [];
            try {
                $actions = ExtensionHelper::getActions($this->service);
            } catch (Exception $e) {
            }

            foreach ($actions as $action) {
                if ($action['type'] == 'button') {
                    $this->buttons[] = $action;
                } elseif ($action['type'] == 'view') {
                    $this->views[] = $action;
                } elseif ($action['type'] == 'text') {
                    $this->fields[] = $action;
                }
            }
            $this->currentView = $this->currentView ?? ($this->views[0]['name'] ?? null);
        }
    }

    public function clearBillingAgreement()
    {
        $this->service->billing_agreement_id = null;
        $this->service->save();
        $this->selectedMethod = null;
    }

    public function updateLabel()
    {
        $this->validate([
            'label' => 'nullable|string|max:255',
        ]);

        $this->service->label = $this->label;
        $this->service->save();

        $this->editLabel = false;
        $this->notify(__('services.update_label') . ' ✓', 'success');
    }

    public function changeView($view)
    {
        if (!$view) {
            return;
        }
        if ($this->currentView === $view || !in_array($view, array_column($this->views, 'name'))) {
            return $this->skipRender();
        }
        $this->currentView = $view;
    }

    public function updatedShowCancel($value)
    {
        if (!$this->service->cancellable) {
            $this->notify('This service cannot be cancelled', 'error');
            $this->showCancel = false;

            return;
        }
    }

    public function updatedShowRenew($value)
    {
        if (!$this->isRenewable()) {
            $this->notify(__('services.service_not_renewable'), 'error');
            $this->showRenew = false;
            return;
        }
    }

    public function isRenewable()
    {

        return $this->service->status === Service::STATUS_ACTIVE 
            && $this->service->plan->type === 'recurring'
            && $this->service->expires_at !== null;
    }

    public function renewService()
    {
        if (!$this->isRenewable()) {
            $this->notify(__('services.service_not_renewable'), 'error');
            return;
        }

        $months = $this->renewMonths;

        if (!in_array($months, [1, 3, 6, 12])) {
            $this->notify('Invalid renewal term selected.', 'error');
            return;
        }


        $hasPendingRenewal = InvoiceItem::where('reference_id', $this->service->id)
            ->where('reference_type', Service::class)
            ->where('description', 'like', '%Renewal%')
            ->whereHas('invoice', fn ($q) => $q->where('status', 'pending'))
            ->exists();

        if ($hasPendingRenewal) {
            $this->notify(__('services.renewal_pending'), 'error');
            return;
        }

        DB::beginTransaction();

        try {
            $invoice = Invoice::create([
                'user_id' => $this->service->user_id,
                'currency_code' => $this->service->currency_code,
                'status' => 'pending',
                'due_at' => now()->addDays(7),
            ]);

            $price = $this->service->price * $months;

            $invoiceItem = InvoiceItem::create([
                'invoice_id' => $invoice->id,
                'description' => "Renewal for {$months} month(s) - Service #{$this->service->id} ({$this->service->product->name})",
                'quantity' => 1,
                'price' => $price,
                'reference_type' => Service::class,
                'reference_id' => $this->service->id,
            ]);

            DB::commit();


            $invoice->refresh();

            $this->notify(__('services.renewal_success'), 'success');
            $this->showRenew = false;

            return $this->redirect(route('invoices.show', $invoice) . '?pay');
        } catch (\Exception $e) {
            DB::rollback();
            $this->notify(__('services.renewal_error'), 'error');
        }
    }

    public function getRenewalPriceForMonths($months)
    {
        $totalPrice = $this->service->price * $months;
        return new \App\Classes\Price(['price' => $totalPrice, 'currency' => $this->service->currency]);
    }

    public function goto($function)
    {

        if (!in_array($function, array_column($this->buttons, 'function'))) {
            $this->notify('This action is not allowed', 'error');

            return;
        }
        $result = ExtensionHelper::callService($this->service, $function);

        if (!is_string($result)) {
            return $result;
        }
        $this->redirect($result);
    }

    public function render()
    {
        $view = null;
        $previousView = $this->currentView;

        if ($this->currentView) {
            try {

                $currentViewObj = $this->views[array_search($this->currentView, array_column($this->views, 'name'))] ?? null;
                if (!$currentViewObj) {
                    throw new Exception('View not found');
                }
                $view = ExtensionHelper::getView($this->service, $currentViewObj);
            } catch (Exception $e) {
                if ($previousView !== $this->views[0]['name'] ?? null) {
                    $this->notify('Got an error while trying to load the view', 'error');
                }
                $this->currentView = $this->views[0]['name'] ?? null;
            }
        }

        return view('services.show', ['extensionView' => $view])->layoutData([
            'title' => 'Services',
            'sidebar' => true,
        ]);
    }
}
