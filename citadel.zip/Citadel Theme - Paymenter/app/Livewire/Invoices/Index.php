<?php

namespace App\Livewire\Invoices;

use App\Livewire\Component;
use Illuminate\Support\Facades\Auth;
use Livewire\WithPagination;

class Index extends Component
{
    use WithPagination;

    public $status = null;
    public $sortBy = 'newest';
    public $perPage = 10;

    public function mount()
    {

        $this->status = $this->status ?? null;
        $this->sortBy = $this->sortBy ?? 'newest';
        $this->perPage = $this->perPage ?? 10;
    }

    public function setStatus($status)
    {
        $this->status = $status === 'all' ? null : $status;
        $this->resetPage();
    }

    public function setSortBy($sortBy)
    {
        $this->sortBy = $sortBy;
        $this->resetPage();
    }

    public function updatedPerPage()
    {
        $this->resetPage();
    }

    public function render()
    {
        $query = Auth::user()->invoices()->with(['items']);

        if ($this->status) {
            $query->where('status', $this->status);
        }

        if ($this->sortBy === 'oldest') {
            $query->orderBy('id', 'asc');
        } else {
            $query->orderBy('id', 'desc'); 
        }

        return view('invoices.index', [
            'invoices' => $query->paginate($this->perPage),
        ])->layoutData([
            'title' => __('invoices.invoices'),
            'sidebar' => true,
        ]);
    }
}
