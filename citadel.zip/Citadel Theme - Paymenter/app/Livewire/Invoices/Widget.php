<?php

namespace App\Livewire\Invoices;

use App\Livewire\Component;
use Illuminate\Support\Facades\Auth;
use Livewire\WithPagination;

class Widget extends Component
{
    use WithPagination;

    /** @var string Widget data source */
    protected $dataBinding = 'invoice_records';

    public $limit = null;
    public $compact = false;
    public $status = null;
    public $sortBy = 'newest';

    public function setStatus($status)
    {
        $this->status = $status === 'all' ? null : $status;
        $this->resetPage();
    }

    public function setSortBy($sortBy)
    {
        $this->sortBy = $sortBy;
        $this->resetPage();
    }

    public function render()
    {
        $query = Auth::user()->invoices()->with(['items']);

        if ($this->status) {
            $query->where('status', $this->status);
        }

        if ($this->sortBy === 'oldest') {
            $query->orderBy('id', 'asc');
        } else {
            $query->orderBy('id', 'desc');
        }

        if ($this->limit) {
            return view('invoices.widget', [
                'invoices' => $query->limit($this->limit)->get(),
            ]);
        }

        return view('invoices.widget', [
            'invoices' => $query->paginate(config('settings.pagination')),
        ])->layoutData([
            'title' => __('invoices.invoices'),
        ]);
    }
}
