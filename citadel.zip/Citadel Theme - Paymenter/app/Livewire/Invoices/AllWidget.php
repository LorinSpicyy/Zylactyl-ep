<?php

namespace App\Livewire\Invoices;

use App\Livewire\Component;
use Illuminate\Support\Facades\Auth;

class AllWidget extends Component
{
    public $limit = null;
    public $status = null;
    public $sortBy = 'newest';

    public function setStatus($status)
    {
        $this->status = $status === 'all' ? null : $status;
    }

    public function setSortBy($sortBy)
    {
        $this->sortBy = $sortBy;
    }

    public function render()
    {
        $query = Auth::user()->invoices()->with(['items']);

        if ($this->status) {
            $query->where('status', $this->status);
        }

        if ($this->sortBy === 'oldest') {
            $query->orderBy('id', 'asc');
        } else {
            $query->orderBy('id', 'desc');
        }

        if ($this->limit) {
            $invoices = $query->limit($this->limit)->get();
        } else {
            $invoices = $query->paginate(config('settings.pagination'));
        }

        return view('invoices.widget', [
            'invoices' => $invoices,
        ]);
    }
}
