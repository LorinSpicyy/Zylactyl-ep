<?php

namespace App\Services\Service;

use App\Jobs\Server\CreateJob;
use App\Jobs\Server\UnsuspendJob;
use App\Models\Service;

class RenewServiceService
{

    public function handle(Service $service): void
    {

        $renewalInvoiceItem = $service->invoices()
            ->where('status', 'paid')
            ->latest()
            ->first()
            ?->items()
            ->where('reference_id', $service->id)
            ->where('reference_type', Service::class)
            ->where('description', 'like', '%Renewal for%')
            ->latest()
            ->first();

        if ($renewalInvoiceItem) {

            preg_match('/Renewal for (\d+) month/', $renewalInvoiceItem->description, $matches);
            $months = isset($matches[1]) ? (int)$matches[1] : 1;


            $currentExpiry = $service->expires_at ?: now();
            

            $baseDate = $currentExpiry->isFuture() ? $currentExpiry : now();
            $newExpiry = $baseDate->copy()->addMonths($months);
            

            $service->expires_at = $newExpiry;
            

            if ($service->status === Service::STATUS_SUSPENDED) {
                $service->status = Service::STATUS_ACTIVE;
                

                if ($service->product->server) {
                    UnsuspendJob::dispatch($service);
                }
            }
            
            $service->save();
        } else {

            if ($service->product->server) {
                if ($service->status == Service::STATUS_SUSPENDED) {
                    UnsuspendJob::dispatch($service);
                } elseif ($service->status == Service::STATUS_PENDING) {
                    CreateJob::dispatch($service);
                }
            }
            $service->status = Service::STATUS_ACTIVE;
            $service->expires_at = $service->calculateNextDueDate();
            $service->save();
        }
    }
}
