@php
    $pages = array_values($this->cpPages);
    $catNames = $this->categoryNameMap();
@endphp

<div style="display:flex;flex-direction:column;gap:0.85rem;">
    @forelse ($pages as $i => $page)
        @php
            $isProduct = ($page['page_type'] ?? 'custom') === 'product';
            $title = trim((string) ($page['title'] ?? ''));
            if ($title === '') {
                if ($isProduct) {
                    $catId = $page['category_id'] ?? null;
                    $title = ($catId && isset($catNames[(int) $catId])) ? $catNames[(int) $catId] : 'Untitled product page';
                } else {
                    $title = 'Untitled page';
                }
            }
            $enabled = (bool) ($page['enabled'] ?? true);
        @endphp

        <div style="border:1px solid rgba(107,114,128,0.25);border-radius:0.75rem;padding:1rem 1.1rem;display:flex;flex-direction:column;gap:0.75rem;">
            <div style="display:flex;align-items:center;gap:0.6rem;flex-wrap:wrap;">
                <span style="font-weight:700;font-size:1rem;">{{ $title }}</span>
                <x-filament::badge :color="$isProduct ? 'info' : 'gray'" size="sm">
                    {{ $isProduct ? 'Product' : 'Custom' }}
                </x-filament::badge>
                <x-filament::badge :color="$enabled ? 'success' : 'warning'" size="sm">
                    {{ $enabled ? 'Published' : 'Draft' }}
                </x-filament::badge>
            </div>

            <div style="display:flex;gap:0.5rem;flex-wrap:wrap;align-items:center;">
                {{ ($this->cpEditPageAction)(['index' => $i]) }}
                @if ($enabled)
                    {{ ($this->cpUnpublishAction)(['index' => $i]) }}
                @else
                    {{ ($this->cpPublishAction)(['index' => $i]) }}
                @endif
                {{ ($this->cpDeletePageAction)(['index' => $i]) }}
            </div>
        </div>
    @empty
        <div style="padding:2.5rem 1.5rem;text-align:center;border:2px dashed rgba(107,114,128,0.3);border-radius:0.75rem;">
            <p style="margin:0 0 1rem;color:rgba(107,114,128,0.95);font-size:0.95rem;">No custom pages yet. Create your first one.</p>
        </div>
    @endforelse

    <div style="margin-top:0.35rem;">
        {{ $this->cpAddPageAction }}
    </div>
</div>
