@php
    use Filament\Support\Enums\Width;

    $livewire ??= null;
    $renderHookScopes = $livewire?->getRenderHookScopes();
    $maxContentWidth ??= (filament()->getMaxContentWidth() ?? Width::SevenExtraLarge);

    if (is_string($maxContentWidth)) {
        $maxContentWidth = Width::tryFrom($maxContentWidth) ?? $maxContentWidth;
    }

    $sidebarItems = [
        ['key' => 'general', 'label' => 'General', 'icon' => 'ri-settings-3-line', 'activeIcon' => 'ri-settings-3-fill'],
        ['key' => 'colors', 'label' => 'Colors', 'icon' => 'ri-palette-line', 'activeIcon' => 'ri-palette-fill'],
        ['key' => 'customization', 'label' => 'Customization', 'icon' => 'ri-pencil-ai-line', 'activeIcon' => 'ri-pencil-ai-fill'],
        ['key' => 'custom-pages', 'label' => 'Custom Pages', 'icon' => 'ri-file-add-line', 'activeIcon' => 'ri-file-add-fill'],
        ['key' => 'header-footer', 'label' => 'Header & Footer', 'icon' => 'ri-layout-2-line', 'activeIcon' => 'ri-layout-2-fill'],
        ['key' => 'home-page', 'label' => 'Home Page', 'icon' => 'ri-home-line', 'activeIcon' => 'ri-home-fill'],
        ['key' => 'plans', 'label' => 'Plans', 'icon' => 'ri-price-tag-3-line', 'activeIcon' => 'ri-price-tag-3-fill'],
        ['key' => 'dashboard', 'label' => 'Dashboard', 'icon' => 'ri-dashboard-line', 'activeIcon' => 'ri-dashboard-fill'],
        ['key' => 'announcement', 'label' => 'Announcement', 'icon' => 'ri-megaphone-line', 'activeIcon' => 'ri-megaphone-fill'],
        ['key' => 'discounts', 'label' => 'Discounts', 'icon' => 'ri-percent-line', 'activeIcon' => 'ri-percent-fill'],
        ['key' => 'variables', 'label' => 'Variables', 'icon' => 'ri-code-s-slash-line', 'activeIcon' => 'ri-code-s-slash-fill'],
        ['key' => 'cards', 'label' => 'Cards', 'icon' => 'ri-bank-card-line', 'activeIcon' => 'ri-bank-card-fill'],
        ['key' => 'seo', 'label' => 'SEO', 'icon' => 'ri-search-eye-line', 'activeIcon' => 'ri-search-eye-fill'],
        ['key' => 'other', 'label' => 'Other', 'icon' => 'ri-more-2-line', 'activeIcon' => 'ri-more-2-fill'],
    ];
@endphp

<x-filament-panels::layout.base :livewire="$livewire" class="citadel-editor-layout">
    <div
        x-data="{
            activeTab: (() => {
                var raw = new URLSearchParams(window.location.search).get('tab') || 'general';
                return raw.split('::')[0];
            })(),
            sidebarOpen: false,
            dirtyTabs: {},
            markDirty() {
                this.dirtyTabs[this.activeTab] = true;
            },
            anyDirty() {
                var d = this.dirtyTabs;
                return Object.keys(d).some(function (k) { return d[k]; });
            },
            _syncActiveTab(key) {
                try {
                    var el = document.querySelector('.fi-sc-tabs');
                    var root = el ? el.closest('[wire\\:id]') : null;
                    if (root && window.Livewire) {
                        var comp = window.Livewire.find(root.getAttribute('wire:id'));
                        if (comp && typeof comp.get === 'function' && typeof comp.get('citadelActiveTab') !== 'undefined') {
                            comp.set('citadelActiveTab', key, false);
                        }
                    }
                } catch (e) {}
            },
            _tabKeyMap: {},
            _findFullKey(simpleKey) {
                if (this._tabKeyMap[simpleKey]) return this._tabKeyMap[simpleKey];
                var tabsEl = document.querySelector('.fi-sc-tabs');
                if (!tabsEl) return simpleKey;
                var input = tabsEl.querySelector('input[type=hidden]');
                if (input) {
                    try {
                        var keys = JSON.parse(input.value);
                        for (var i = 0; i < keys.length; i++) {
                            var base = keys[i].split('::')[0];
                            this._tabKeyMap[base] = keys[i];
                        }
                    } catch(e) {}
                }
                return this._tabKeyMap[simpleKey] || simpleKey;
            },
            switchTab(key) {
                if (key !== this.activeTab && this.dirtyTabs[this.activeTab] && !window.confirm('You have unsaved changes on this page. If you move to another page they will not be saved. Continue?')) {
                    return;
                }
                this.activeTab = key;
                this.sidebarOpen = false;
                this._syncActiveTab(key);
                var fullKey = this._findFullKey(key);
                var tabsEl = document.querySelector('.fi-sc-tabs');
                if (tabsEl && typeof Alpine !== 'undefined') {
                    var data = Alpine.$data(tabsEl);
                    if (data) {
                        data.tab = fullKey;
                    }
                }
                var url = new URL(window.location);
                url.searchParams.set('tab', fullKey);
                history.replaceState({}, '', url);
            },

            previewDevice: 'desktop',
            previewLoading: false,
            _previewTabUrlMap: {
                'general': '/',
                'colors': '/',
                'customization': '/',
                'custom-pages': '/',
                'header-footer': '/',
                'home-page': '/',
                'plans': '/',
                'dashboard': '/dashboard',
                'announcement': '/',
                'discounts': '/',
                'variables': '/',
                'cards': '/services',
                'seo': '/',
                'other': '/',
            },
            getPreviewUrl() {
                return this._previewTabUrlMap[this.activeTab] || '/';
            },
            refreshPreview() {
                this.previewLoading = true;
                var iframe = this.$refs.previewFrame;
                if (iframe) {
                    try {
                        var currentUrl = iframe.contentWindow.location.href;
                        iframe.src = currentUrl.split('?')[0] + '?_preview=' + Date.now();
                    } catch(e) {
                        iframe.src = this.getPreviewUrl() + '?_preview=' + Date.now();
                    }
                }
            },
            setDevice(device) {
                this.previewDevice = device;
            },
            navigatePreview(url) {
                if (!url) return;
                this.previewLoading = true;
                var iframe = this.$refs.previewFrame;
                if (iframe) {
                    iframe.src = url + (url.indexOf('?') > -1 ? '&' : '?') + '_preview=' + Date.now();
                }
            }
        }"
        x-init="
            $nextTick(() => { _syncActiveTab(activeTab); });

            if (window.Livewire && typeof window.Livewire.hook === 'function') {
                window.Livewire.hook('commit', ({ component }) => {
                    try {
                        var el = document.querySelector('.fi-sc-tabs');
                        var root = el ? el.closest('[wire\\:id]') : null;
                        if (root && component && component.id === root.getAttribute('wire:id')) {
                            markDirty();
                        }
                    } catch (err) {}
                });
            }

            window.addEventListener('popstate', () => {
                var raw = new URLSearchParams(window.location.search).get('tab') || 'general';
                var target = raw.split('::')[0];
                if (target !== activeTab && dirtyTabs[activeTab] && !window.confirm('You have unsaved changes on this page. If you move to another page they will not be saved. Continue?')) {
                    var back = new URL(window.location);
                    back.searchParams.set('tab', _findFullKey(activeTab));
                    history.pushState({}, '', back);
                    return;
                }
                activeTab = target;
                _syncActiveTab(target);
            });

            $watch('activeTab', (val) => {
                if ($refs.previewFrame) {
                    $refs.previewFrame.src = getPreviewUrl();
                }
            });

            document.addEventListener('citadel-settings-saved', (e) => {
                if (e && e.detail && e.detail.full) {
                    dirtyTabs = {};
                } else {
                    dirtyTabs[activeTab] = false;
                    dirtyTabs['custom-pages'] = false;
                }
                setTimeout(() => refreshPreview(), 300);
            });

            window.addEventListener('citadel-preview-url', (e) => {
                navigatePreview((e && e.detail && e.detail.url) ? e.detail.url : null);
            });

            window.addEventListener('beforeunload', (e) => {
                if (anyDirty()) { e.preventDefault(); e.returnValue = ''; }
            });
        "
        class="citadel-layout-wrapper"
    >
        <aside
            x-bind:class="{ 'citadel-sidebar-open': sidebarOpen }"
            class="citadel-sidebar"
        >
            <div class="citadel-sidebar-logo">
                <div class="citadel-sidebar-logo-icon">
                    {{ \Filament\Support\generate_icon_html('ri-palette-fill', size: \Filament\Support\Enums\IconSize::Large) }}
                </div>
            </div>

            <nav class="citadel-sidebar-nav">
                <ul class="citadel-sidebar-nav-list">
                    @foreach ($sidebarItems as $item)
                        <li class="citadel-nav-item-wrapper">
                            <button
                                x-on:click="switchTab('{{ $item['key'] }}')"
                                x-bind:class="{ 'citadel-nav-item-active': activeTab === '{{ $item['key'] }}' }"
                                class="citadel-nav-item"
                            >
                                <span class="citadel-nav-icon" x-show="activeTab !== '{{ $item['key'] }}'">
                                    {{ \Filament\Support\generate_icon_html($item['icon'], size: \Filament\Support\Enums\IconSize::Large) }}
                                </span>
                                <span class="citadel-nav-icon" x-show="activeTab === '{{ $item['key'] }}'" x-cloak>
                                    {{ \Filament\Support\generate_icon_html($item['activeIcon'], size: \Filament\Support\Enums\IconSize::Large) }}
                                </span>
                            </button>
                            <div class="citadel-nav-tooltip">{{ $item['label'] }}</div>
                        </li>
                    @endforeach
                </ul>
            </nav>


            <div class="citadel-sidebar-footer">
                <div class="citadel-nav-item-wrapper">
                    <a href="/admin" class="citadel-exit-btn">
                        {{ \Filament\Support\generate_icon_html('ri-arrow-left-line', size: \Filament\Support\Enums\IconSize::Large) }}
                    </a>
                    <div class="citadel-nav-tooltip">Back to Admin</div>
                </div>
            </div>
        </aside>

        <div class="citadel-main-ctn">
            <div class="citadel-mobile-header">
                <div class="citadel-mobile-title">
                    {{ \Filament\Support\generate_icon_html('ri-palette-fill', size: \Filament\Support\Enums\IconSize::Large) }}
                    <span>Citadel Editor</span>
                </div>
                <button x-on:click="sidebarOpen = !sidebarOpen" class="citadel-mobile-toggle">
                    {{ \Filament\Support\generate_icon_html('ri-menu-line', size: \Filament\Support\Enums\IconSize::Large) }}
                </button>
            </div>

            <div
                x-show="sidebarOpen"
                x-on:click="sidebarOpen = false"
                x-transition.opacity.300ms
                class="citadel-sidebar-overlay"
            ></div>

            {{ \Filament\Support\Facades\FilamentView::renderHook(\Filament\View\PanelsRenderHook::CONTENT_BEFORE, scopes: $renderHookScopes) }}

            <main
                @class([
                    'fi-main citadel-main',
                ])
                x-on:input="$event.isTrusted && markDirty()"
                x-on:change="$event.isTrusted && markDirty()"
                x-on:focusout="$event.isTrusted && markDirty()"
            >
                {{ \Filament\Support\Facades\FilamentView::renderHook(\Filament\View\PanelsRenderHook::CONTENT_START, scopes: $renderHookScopes) }}

                {{ $slot }}

                {{ \Filament\Support\Facades\FilamentView::renderHook(\Filament\View\PanelsRenderHook::CONTENT_END, scopes: $renderHookScopes) }}
            </main>

            {{ \Filament\Support\Facades\FilamentView::renderHook(\Filament\View\PanelsRenderHook::CONTENT_AFTER, scopes: $renderHookScopes) }}
            {{ \Filament\Support\Facades\FilamentView::renderHook(\Filament\View\PanelsRenderHook::FOOTER, scopes: $renderHookScopes) }}
        </div>

        <div class="citadel-right-panel">
            <div class="citadel-preview-toolbar">
                <div class="citadel-preview-toolbar-left"></div>

                <div class="citadel-preview-toolbar-center">
                    <button
                        x-on:click="setDevice('mobile')"
                        x-bind:class="{ 'citadel-device-active': previewDevice === 'mobile' }"
                        class="citadel-device-btn"
                        title="Mobile"
                    >
                        {{ \Filament\Support\generate_icon_html('ri-smartphone-line', size: \Filament\Support\Enums\IconSize::Small) }}
                    </button>
                    <button
                        x-on:click="setDevice('tablet')"
                        x-bind:class="{ 'citadel-device-active': previewDevice === 'tablet' }"
                        class="citadel-device-btn"
                        title="Tablet"
                    >
                        {{ \Filament\Support\generate_icon_html('ri-tablet-line', size: \Filament\Support\Enums\IconSize::Small) }}
                    </button>
                    <button
                        x-on:click="setDevice('desktop')"
                        x-bind:class="{ 'citadel-device-active': previewDevice === 'desktop' }"
                        class="citadel-device-btn"
                        title="Desktop"
                    >
                        {{ \Filament\Support\generate_icon_html('ri-computer-line', size: \Filament\Support\Enums\IconSize::Small) }}
                    </button>
                </div>

                <div class="citadel-preview-toolbar-right">
                    <button x-on:click="refreshPreview()" class="citadel-preview-refresh-btn" title="Refresh Preview">
                        {{ \Filament\Support\generate_icon_html('ri-refresh-line', size: \Filament\Support\Enums\IconSize::Small) }}
                    </button>
                </div>
            </div>

            <div x-show="previewLoading" x-transition.opacity class="citadel-preview-loading">
                <div class="citadel-preview-loading-bar"></div>
            </div>


            <div class="citadel-preview-frame-ctn">
                <div
                    class="citadel-preview-frame-wrapper"
                    x-bind:class="{
                        'citadel-preview-mobile': previewDevice === 'mobile',
                        'citadel-preview-tablet': previewDevice === 'tablet',
                        'citadel-preview-desktop': previewDevice === 'desktop',
                    }"
                >
                    <iframe
                        x-ref="previewFrame"
                        x-bind:src="getPreviewUrl()"
                        x-on:load="previewLoading = false"
                        class="citadel-preview-iframe"
                        sandbox="allow-same-origin allow-scripts allow-forms allow-popups"
                    ></iframe>
                </div>
            </div>
        </div>
    </div>

    <style>

        html:has(.citadel-editor-layout),
        html:has(.citadel-editor-layout) body {
            overflow-x: clip;
        }


        .citadel-editor-layout .fi-sidebar,
        .citadel-editor-layout .fi-topbar,
        .citadel-editor-layout .fi-layout,
        .citadel-editor-layout .fi-layout > .fi-sidebar-close-overlay {
            display: none !important;
        }


        .citadel-editor-layout .fi-sc-tabs > .fi-tabs {
            display: none !important;
        }


        .citadel-editor-layout .fi-page > .fi-page-header-main-ctn > .fi-header {
            display: none !important;
        }


        .citadel-editor-layout .fi-page > .fi-page-header-main-ctn > .fi-header-heading {
            display: none !important;
        }


        .citadel-editor-layout .fi-page {
            padding-top: 0 !important;
        }


        .citadel-editor-layout .fi-page-header-main-ctn {
            padding-top: 0 !important;
            padding-bottom: 0 !important;
        }


        .citadel-editor-layout .fi-page-content {
            gap: 0.5rem !important;
        }


        .citadel-editor-layout .fi-sc-tabs.fi-contained .fi-sc-tabs-tab.fi-active {
            padding: 0.5rem !important;
        }


        .citadel-editor-layout .fi-section:not(.fi-section-not-contained):not(.fi-aside) > .fi-section-content-ctn > .fi-section-content {
            padding: 0.75rem !important;
        }


        .citadel-editor-layout .fi-section:not(.fi-section-not-contained):not(.fi-aside) > .fi-section-header {
            padding: 0.625rem 0.75rem !important;
        }


        .citadel-editor-layout .fi-sc-tabs.fi-contained {
            background: transparent !important;
            box-shadow: none !important;
            --tw-ring-shadow: 0 0 #0000 !important;
            --tw-shadow: 0 0 #0000 !important;
            --tw-ring-color: transparent !important;
            border-radius: 0 !important;
            ring: none !important;
        }


        .citadel-layout-wrapper {
            display: flex;
            height: 100vh;
            max-height: 100vh;
            position: relative;
            overflow: hidden;
        }

        .citadel-sidebar {
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            width: 60px;
            display: flex;
            flex-direction: column;
            align-items: center;
            background: var(--gray-50);
            border-right: 1px solid rgb(0 0 0 / 0.1);
            z-index: 40;
            transition: transform 300ms ease;
            overflow: visible;
        }

        .dark .citadel-sidebar {
            background: var(--gray-950);
            border-right-color: rgb(255 255 255 / 0.1);
        }


        .citadel-sidebar-logo {
            padding: 0.875rem 0;
            display: flex;
            justify-content: center;
            width: 100%;
            border-bottom: 1px solid rgb(255 255 255 / 0.15);
        }

        .citadel-sidebar-logo-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            border-radius: 0.625rem;
            background-color: rgb(0 0 0 / 0.06);
            color: var(--gray-700);
            flex-shrink: 0;
        }

        .dark .citadel-sidebar-logo-icon {
            background-color: rgb(255 255 255 / 0.1);
            color: var(--gray-300);
        }

        .citadel-sidebar-logo-icon svg {
            width: 20px;
            height: 20px;
        }


        .citadel-sidebar-nav {
            flex: 1;
            padding: 0.5rem 0;
            width: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .citadel-sidebar-nav-list {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 2px;
            width: 100%;
        }

        .citadel-nav-item-wrapper {
            position: relative;
            display: flex;
            justify-content: center;
            width: 100%;
        }

        .citadel-nav-item {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            border-radius: 0.625rem;
            border: none;
            background: transparent;
            color: var(--gray-500);
            cursor: pointer;
            transition: all 150ms ease;
            outline: none;
            padding: 0;
        }

        .citadel-nav-item:hover {
            background-color: rgb(0 0 0 / 0.06);
            color: var(--gray-900);
        }

        .dark .citadel-nav-item:hover {
            background-color: rgb(255 255 255 / 0.1);
            color: var(--gray-100);
        }

        .citadel-nav-item:focus-visible {
            box-shadow: 0 0 0 2px rgb(0 0 0 / 0.15);
        }

        .dark .citadel-nav-item:focus-visible {
            box-shadow: 0 0 0 2px rgb(255 255 255 / 0.25);
        }

        .citadel-nav-item-active {
            background-color: rgb(0 0 0 / 0.08) !important;
            color: var(--gray-900) !important;
        }

        .dark .citadel-nav-item-active {
            background-color: rgb(255 255 255 / 0.12) !important;
            color: #fff !important;
        }

        .citadel-nav-icon {
            display: flex;
            align-items: center;
            flex-shrink: 0;
        }

        .citadel-nav-icon svg {
            width: 1.25rem;
            height: 1.25rem;
        }

        .citadel-nav-tooltip {
            position: absolute;
            left: 100%;
            top: 50%;
            background: var(--gray-50);
            color: var(--gray-700);
            font-size: 0.8125rem;
            font-weight: 600;
            padding: 0.4375rem 0.875rem 0.4375rem 0.75rem;
            border-radius: 0 0.5rem 0.5rem 0;
            white-space: nowrap;
            pointer-events: none;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-50%) translateX(-6px);
            transition: opacity 150ms ease, transform 150ms ease, visibility 0s 150ms;
            z-index: 9999;
            box-shadow: 4px 0 12px rgb(0 0 0 / 0.15);
            letter-spacing: 0.01em;
        }

        .dark .citadel-nav-tooltip {
            background: var(--gray-950);
            color: var(--gray-200);
            box-shadow: 4px 0 12px rgb(0 0 0 / 0.3);
        }

        .citadel-nav-item-wrapper:hover .citadel-nav-tooltip {
            opacity: 1;
            visibility: visible;
            transform: translateY(-50%) translateX(0);
            transition: opacity 150ms ease, transform 150ms ease, visibility 0s 0s;
        }

        .citadel-sidebar-footer {
            padding: 0.5rem 0 0.875rem;
            width: 100%;
            display: flex;
            justify-content: center;
            border-top: 1px solid rgb(0 0 0 / 0.1);
        }

        .dark .citadel-sidebar-footer {
            border-top-color: rgb(255 255 255 / 0.1);
        }

        .citadel-exit-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            border-radius: 0.625rem;
            background: rgb(239 68 68 / 0.1);
            color: rgb(239 68 68);
            text-decoration: none;
            transition: all 150ms ease;
            cursor: pointer;
        }

        .citadel-exit-btn:hover {
            background-color: rgb(239 68 68 / 0.2);
            color: rgb(220 38 38);
        }

        .dark .citadel-exit-btn {
            background: rgb(248 113 113 / 0.1);
            color: rgb(248 113 113);
        }

        .dark .citadel-exit-btn:hover {
            background-color: rgb(248 113 113 / 0.2);
            color: rgb(252 165 165);
        }

        .citadel-exit-btn svg {
            width: 1.25rem;
            height: 1.25rem;
            flex-shrink: 0;
        }

        .citadel-main-ctn {
            width: 420px;
            min-width: 420px;
            max-width: 420px;
            margin-left: 60px;
            height: 100vh;
            display: flex;
            flex-direction: column;
            border-right: 1px solid rgb(0 0 0 / 0.1);
            overflow-y: auto;
        }

        .dark .citadel-main-ctn {
            border-right-color: rgb(255 255 255 / 0.1);
        }

        .citadel-editor-layout .fi-main {
            max-width: 100% !important;
            width: 100% !important;
        }

        .citadel-main {
            padding: 0.25rem 0.5rem 1rem;
        }

        .citadel-right-panel {
            flex: 1;
            height: 100vh;
            max-height: 100vh;
            display: flex;
            flex-direction: column;
            position: relative;
            overflow: hidden;
        }

        .citadel-preview-toolbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.5rem 0.75rem;
            border-bottom: 1px solid rgb(0 0 0 / 0.1);
            gap: 0.5rem;
            flex-shrink: 0;
        }

        .dark .citadel-preview-toolbar {
            border-bottom-color: rgb(255 255 255 / 0.1);
        }

        .citadel-preview-toolbar-left,
        .citadel-preview-toolbar-center,
        .citadel-preview-toolbar-right {
            display: flex;
            align-items: center;
            gap: 0.25rem;
        }

        .citadel-device-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 30px;
            height: 30px;
            border: none;
            background: transparent;
            color: rgb(0 0 0 / 0.4);
            cursor: pointer;
            border-radius: 0.375rem;
            transition: all 150ms ease;
            padding: 0;
        }

        .dark .citadel-device-btn {
            color: rgb(255 255 255 / 0.4);
        }

        .citadel-device-btn:hover {
            background-color: rgb(0 0 0 / 0.06);
            color: rgb(0 0 0 / 0.7);
        }

        .dark .citadel-device-btn:hover {
            background-color: rgb(255 255 255 / 0.1);
            color: rgb(255 255 255 / 0.7);
        }

        .citadel-device-active {
            background-color: rgb(0 0 0 / 0.08) !important;
            color: rgb(0 0 0 / 0.8) !important;
        }

        .dark .citadel-device-active {
            background-color: rgb(255 255 255 / 0.15) !important;
            color: #fff !important;
        }

        .citadel-device-btn svg {
            width: 1rem;
            height: 1rem;
        }

        .citadel-preview-refresh-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 30px;
            height: 30px;
            border: none;
            background: transparent;
            color: rgb(0 0 0 / 0.4);
            cursor: pointer;
            border-radius: 0.375rem;
            transition: all 150ms ease;
            padding: 0;
            text-decoration: none;
        }

        .dark .citadel-preview-refresh-btn {
            color: rgb(255 255 255 / 0.4);
        }

        .citadel-preview-refresh-btn:hover {
            background-color: rgb(0 0 0 / 0.06);
            color: rgb(0 0 0 / 0.7);
        }

        .dark .citadel-preview-refresh-btn:hover {
            background-color: rgb(255 255 255 / 0.1);
            color: rgb(255 255 255 / 0.7);
        }

        .citadel-preview-refresh-btn svg {
            width: 1rem;
            height: 1rem;
        }

        .citadel-preview-loading {
            position: absolute;
            top: 42px;
            left: 0;
            right: 0;
            height: 2px;
            z-index: 10;
            overflow: hidden;
        }

        .citadel-preview-loading-bar {
            width: 30%;
            height: 100%;
            background-color: var(--primary-500);
            animation: citadel-loading-slide 1s ease-in-out infinite;
        }

        @keyframes citadel-loading-slide {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(400%); }
        }

        .citadel-preview-frame-ctn {
            flex: 1;
            min-height: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
            overflow: hidden;
        }

        .citadel-preview-frame-wrapper {
            transition: all 300ms ease;
            display: flex;
            max-height: 100%;
            max-width: 100%;
            border-radius: 0.75rem;
            overflow: hidden;
            box-shadow: 0 4px 24px rgb(0 0 0 / 0.12);
        }

        .citadel-preview-desktop {
            aspect-ratio: 16 / 10;
            height: 100%;
        }

        .citadel-preview-tablet {
            aspect-ratio: 4 / 3;
            height: 100%;
        }

        .citadel-preview-mobile {
            aspect-ratio: 9 / 19.5;
            height: 100%;
            border-radius: 1.25rem;
        }

        .citadel-preview-iframe {
            width: 100%;
            height: 100%;
            border: none;
            background: #fff;
        }

        .dark .citadel-preview-iframe {
            background: #0f0f1a;
        }

        .citadel-mobile-header {
            display: none;
            position: sticky;
            top: 0;
            z-index: 30;
            padding: 0.75rem 1rem;
            background-color: var(--gray-50);
            border-bottom: 1px solid var(--gray-200);
            align-items: center;
            justify-content: space-between;
        }

        .dark .citadel-mobile-header {
            background-color: var(--gray-900);
            border-bottom-color: var(--gray-700);
        }

        .citadel-mobile-toggle {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            border: none;
            background: transparent;
            color: var(--gray-600);
            cursor: pointer;
            border-radius: 0.375rem;
        }

        .dark .citadel-mobile-toggle {
            color: var(--gray-400);
        }

        .citadel-mobile-toggle:hover {
            background-color: var(--gray-100);
        }

        .dark .citadel-mobile-toggle:hover {
            background-color: var(--gray-800);
        }

        .citadel-mobile-toggle svg {
            width: 1.5rem;
            height: 1.5rem;
        }

        .citadel-mobile-title {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9375rem;
            font-weight: 700;
            color: var(--gray-950);
        }

        .dark .citadel-mobile-title {
            color: #fff;
        }

        .citadel-mobile-title svg {
            width: 1.25rem;
            height: 1.25rem;
            color: var(--primary-500);
        }


        .citadel-sidebar-overlay {
            display: none;
            position: fixed;
            inset: 0;
            z-index: 35;
            background-color: rgb(0 0 0 / 0.5);
        }

        @media (max-width: 1023px) {
            .citadel-sidebar {
                transform: translateX(-100%);
                z-index: 40;
            }

            .citadel-sidebar.citadel-sidebar-open {
                transform: translateX(0);
            }

            .citadel-main-ctn {
                margin-left: 0;
                width: 100%;
                min-width: 0;
                max-width: 100%;
                border-right: none;
            }

            .citadel-right-panel {
                display: none;
            }

            .citadel-mobile-header {
                display: flex;
            }

            .citadel-sidebar-overlay {
                display: block;
            }
        }

        .citadel-icon-picker.fi-fo-radio {
            display: grid !important;
            grid-template-columns: repeat(5, auto) !important;
            gap: 6px !important;
            justify-content: start;
            padding-top: 10px;
        }

        
        .citadel-icon-picker--grid-3.fi-fo-radio {
            grid-template-columns: repeat(3, 1fr) !important;
            justify-content: stretch !important;
            width: 100% !important;
        }

        .citadel-icon-picker--grid-3 .fi-fo-radio-label {
            width: 100% !important;
            aspect-ratio: 1 / 1;
        }

        .citadel-icon-picker--grid-3 .fi-fo-radio-label-text,
        .citadel-icon-picker--grid-3 .fi-fo-radio-label-text > * {
            width: 100% !important;
            height: 100% !important;
        }

        .citadel-icon-picker--grid-3 .fi-fo-radio-label-text img {
            width: 60% !important;
            height: 60% !important;
        }


        .citadel-icon-picker input[type="radio"] {
            display: none !important;
            position: absolute !important;
            width: 0 !important;
            height: 0 !important;
            overflow: hidden !important;
        }


        .citadel-icon-picker .fi-fo-radio-label {
            cursor: pointer;
            border-radius: 10px;
            border: 2px solid transparent;
            padding: 2px;
            transition: border-color 0.15s ease, box-shadow 0.15s ease;
            display: flex !important;
            align-items: center;
            justify-content: center;
            gap: 0 !important;
            margin: 0 !important;
        }

        .citadel-icon-picker .fi-fo-radio-label:hover {
            border-color: var(--gray-300);
        }

        :is(.dark) .citadel-icon-picker .fi-fo-radio-label:hover {
            border-color: var(--gray-600);
        }


        .citadel-icon-picker .fi-fo-radio-label:has(input:checked) {
            border-color: var(--primary-500);
            box-shadow: 0 0 0 1px var(--primary-500);
        }


        .citadel-icon-picker .fi-fo-radio-label-text {
            padding: 0 !important;
            margin: 0 !important;
        }


        .citadel-icon-picker .fi-fo-radio-label-text p {
            margin: 0 !important;
            padding: 0 !important;
            line-height: 0 !important;
        }


        .citadel-image-radio.fi-fo-radio {
            display: grid !important;
            grid-template-columns: repeat(var(--cols-lg, 2), 1fr) !important;
            gap: 10px !important;
            padding-top: 20px;
        }


        .citadel-image-radio input[type="radio"] {
            display: none !important;
            position: absolute !important;
            width: 0 !important;
            height: 0 !important;
            overflow: hidden !important;
        }


        .citadel-image-radio .fi-fo-radio-label {
            cursor: pointer;
            border-radius: 10px;
            border: 2px solid var(--gray-200);
            padding: 0 !important;
            margin: 0 !important;
            gap: 0 !important;
            transition: border-color 0.15s ease, box-shadow 0.15s ease;
            display: flex !important;
            flex-direction: column;
            align-items: stretch;
            overflow: hidden;
        }

        :is(.dark) .citadel-image-radio .fi-fo-radio-label {
            border-color: var(--gray-700);
        }

        .citadel-image-radio .fi-fo-radio-label:hover {
            border-color: var(--gray-400);
        }

        :is(.dark) .citadel-image-radio .fi-fo-radio-label:hover {
            border-color: var(--gray-500);
        }


        .citadel-image-radio .fi-fo-radio-label:has(input:checked) {
            border-color: var(--primary-500);
            box-shadow: 0 0 0 1px var(--primary-500);
        }


        .citadel-image-radio .fi-fo-radio-label-text {
            padding: 0 !important;
            margin: 0 !important;
        }

        .citadel-image-radio .fi-fo-radio-label-text p {
            margin: 0 !important;
            padding: 0 !important;
        }


        .citadel-image-radio-card {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0;
        }

        .citadel-image-radio-card img {
            width: 100%;
            height: auto;
            object-fit: cover;
            object-position: top;
            display: block;
            border-radius: 8px 8px 0 0;
        }

        .citadel-image-radio-card > span {
            display: block;
            padding: 8px 0;
            font-size: 0.8rem;
            font-weight: 600;
            text-align: center;
            color: var(--gray-700);
        }

        :is(.dark) .citadel-image-radio-card > span {
            color: var(--gray-300);
        }

        
        .citadel-image-radio-card--overlay {
            position: relative;
            overflow: hidden;
        }

        .citadel-image-radio-text-overlay {
            position: absolute;
            inset: 0;
            display: flex;
            flex-direction: column;
            justify-content: flex-end;
            align-items: flex-start;
            padding: 0.75rem 1rem;
            background: transparent;
            opacity: 0;
            transition: background 0.2s ease, opacity 0.2s ease;
            pointer-events: none;
        }

        .citadel-image-radio-card--overlay:hover .citadel-image-radio-text-overlay {
            background: linear-gradient(to top, rgba(0,0,0,0.75) 0%, rgba(0,0,0,0.25) 60%, transparent 100%);
            opacity: 1;
        }

        .fi-fo-radio-label:has(input:checked) .citadel-image-radio-text-overlay {
            background: linear-gradient(to top, rgba(0,0,0,0.65) 0%, rgba(0,0,0,0.15) 60%, transparent 100%);
            opacity: 1;
        }

        .citadel-overlay-title {
            color: #fff;
            font-size: 0.82rem;
            font-weight: 700;
            line-height: 1.3;
            margin: 0 0 0.2rem;
            text-shadow: 0 1px 4px rgba(0,0,0,0.5);
            text-align: left;
        }

        .citadel-overlay-desc {
            color: rgba(255,255,255,0.88);
            font-size: 0.72rem;
            font-weight: 400;
            line-height: 1.4;
            margin: 0;
            text-shadow: 0 1px 3px rgba(0,0,0,0.4);
            text-align: left;
        }

        
        .citadel-theme-radio-card {
            display: flex;
            flex-direction: row;
            align-items: center;
            gap: 0.75rem;
            padding: 0.875rem 1rem;
        }

        .citadel-theme-radio-icon {
            width: 2.25rem;
            height: 2.25rem;
            flex-shrink: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--gray-100);
            border-radius: 7px;
            color: var(--gray-500);
            transition: background 0.15s ease, color 0.15s ease;
        }

        :is(.dark) .citadel-theme-radio-icon {
            background: var(--gray-800);
            color: var(--gray-400);
        }

        .citadel-theme-radio-card > span {
            color: var(--gray-700);
            font-size: 0.875rem;
            font-weight: 600;
            padding: 0;
            display: block;
        }

        :is(.dark) .citadel-theme-radio-card > span {
            color: var(--gray-300);
        }

        .citadel-theme-radio .fi-fo-radio-label:has(input:checked) .citadel-theme-radio-card > span {
            color: var(--gray-900);
        }

        :is(.dark) .citadel-theme-radio .fi-fo-radio-label:has(input:checked) .citadel-theme-radio-card > span {
            color: var(--gray-100);
        }

        
        .citadel-preset-card {
            display: flex;
            flex-direction: column;
            align-items: stretch;
        }

        .citadel-preset-swatches {
            display: flex;
            flex-direction: row;
            height: 56px;
            border-radius: 8px 8px 0 0;
            overflow: hidden;
        }

        .citadel-preset-swatch {
            flex: 1;
        }

        .citadel-preset-card > span {
            display: block;
            padding: 8px 0;
            font-size: 0.8rem;
            font-weight: 600;
            text-align: center;
            color: var(--gray-700);
        }

        :is(.dark) .citadel-preset-card > span {
            color: var(--gray-300);
        }


        .citadel-editor-layout .fi-fo-slider-container {
            padding-left: 10px;
            padding-right: 10px;
        }

        .citadel-editor-layout .noUi-target {
            margin-left: 10px;
            margin-right: 10px;
        }
    </style>
</x-filament-panels::layout.base>
