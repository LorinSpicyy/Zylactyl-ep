@php
    $page = $this->cpEditingIndex !== null ? ($this->data['cp_editing'] ?? []) : [];
    $title = trim((string) ($page['title'] ?? ''));
    $title = $title !== '' ? $title : ($this->cpEditingIsNew ? 'New page' : 'Untitled page');
@endphp

<div style="display:flex;align-items:center;justify-content:space-between;gap:1rem;flex-wrap:wrap;border-bottom:1px solid rgba(107,114,128,0.2);padding-bottom:1rem;margin-bottom:0.25rem;">
    <div style="display:flex;align-items:center;gap:0.85rem;min-width:0;">
        {{ $this->cpBackAction }}
        <span style="font-weight:700;font-size:1.05rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">{{ $title }}</span>
    </div>
    <div style="display:flex;gap:0.5rem;">
        {{ $this->cpDiscardAction }}
    </div>
</div>
