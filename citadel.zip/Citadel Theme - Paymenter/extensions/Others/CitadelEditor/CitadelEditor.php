<?php

namespace Paymenter\Extensions\Others\CitadelEditor;

use App\Attributes\ExtensionMeta;
use App\Classes\Extension\Extension;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\View;

#[ExtensionMeta(
    name: 'Citadel Editor',
    description: 'Visual editor for the Citadel theme.',
    version: '1.0.1',
    author: 'Citadel',
)]
class CitadelEditor extends Extension
{
    /**
     *
     * @param  array  $values
     * @return array
     */
    public function getConfig($values = [])
    {
        return [];
    }


    public function boot()
    {
        View::addNamespace('citadel-editor', __DIR__ . '/resources/views');

        $current = (int) config('livewire.payload.max_nesting_depth', 10);
        if ($current < 50) {
            config(['livewire.payload.max_nesting_depth' => 50]);
        }

        Event::listen('permissions', function () {
            return [
                'admin.citadel_editor.view' => 'View Citadel Editor',
                'admin.citadel_editor.update' => 'Update Citadel Editor',
            ];
        });
    }

    public function installed()
    {
        parent::installed();
        $this->ensureSettingsValueCapacity();
    }

    public function upgraded($oldVersion = null)
    {
        parent::upgraded($oldVersion);
        $this->ensureSettingsValueCapacity();
    }

    private function ensureSettingsValueCapacity(): void
    {
        try {
            if (! Schema::hasTable('settings')) {
                return;
            }
            Schema::table('settings', function (Blueprint $table) {
                $table->longText('value')->nullable()->change();
            });
        } catch (\Throwable $e) {
            Log::warning('[CitadelEditor] Could not widen settings.value column: ' . $e->getMessage());
        }
    }
}
