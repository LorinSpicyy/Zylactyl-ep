<?php

namespace Paymenter\Extensions\Others\CitadelEditor\Admin\Pages;

use App\Models\Setting;
use Exception;
use Filament\Actions\Action;
use Filament\Forms\Components\ColorPicker;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Placeholder;
use Filament\Forms\Components\MarkdownEditor;
use Filament\Forms\Components\RichEditor;
use Filament\Forms\Components\Radio;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Slider;
use Spatie\Color\Factory as ColorFactory;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\HtmlString;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Infolists\Components\TextEntry;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Schemas\Components\Actions;
use Filament\Schemas\Components\Form;
use Filament\Schemas\Components\Group;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\View;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Components\Tabs\Tab;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Components\Utilities\Set;
use Filament\Schemas\Schema;

class CitadelEditorPage extends Page implements HasForms
{
    use InteractsWithForms;

    protected string $view = 'citadel-editor::admin.pages.citadel-editor';

    protected static string $layout = 'citadel-editor::admin.layouts.citadel-editor-layout';

    protected static string|\BackedEnum|null $navigationIcon = 'ri-palette-line';

    protected static string|\BackedEnum|null $activeNavigationIcon = 'ri-palette-fill';

    protected static ?string $navigationLabel = 'Citadel Editor';

    protected static ?string $title = 'Citadel Editor';

    protected static ?string $slug = 'citadel-editor';

    protected static ?int $navigationSort = 100;

    public static string|\UnitEnum|null $navigationGroup = 'Configuration';

    public ?array $data = [];


    public array $cpPages = [];

    public ?int $cpEditingIndex = null;

    public bool $cpEditingIsNew = false;

    public ?string $citadelActiveTab = null;

    public static function getNavigationItems(): array
    {
        try {
            return parent::getNavigationItems();
        } catch (\Throwable $e) {
            Log::warning('[CitadelEditor] Navigation failed, route not defined. Is the extension enabled?', [
                'error' => $e->getMessage(),
            ]);

            return [];
        }
    }

    public static function canAccess(): bool
    {
        try {
            return Auth::check() && Auth::user()->hasPermission('admin.citadel_editor.view');
        } catch (\Throwable $e) {
            return false;
        }
    }

    private function prefix(): string
    {
        return 'theme_citadel_';
    }

    private function managedSettings(): array
    {
        return [
            'general' => [
                [
                    'name' => 'sidebar_layout',
                    'label' => 'Sidebar Layout',
                    'type' => 'image_radio',
                    'options' => [
                        'all_pages' => 'Sidebar on All Pages',
                        'disabled' => 'Header Only',
                        'default' => 'Default Layout',
                    ],
                    'overlay_options' => [
                        'all_pages' => [
                            'title' => 'Sidebar on All Pages',
                            'description' => 'When enabled, the sidebar will be displayed on all pages, including the home page and order pages.',
                        ],
                        'disabled' => [
                            'title' => 'Header Only',
                            'description' => 'When enabled, the sidebar will be replaced with a header navigation bar across all pages.',
                        ],
                        'default' => [
                            'title' => 'Default Layout',
                            'description' => 'Pages that use a sidebar by default will keep it. All other pages will use the header instead.',
                        ],
                    ],
                    'images' => [
                        'all_pages' => 'ext://assets/icons/sidebar.svg',
                        'disabled' => 'ext://assets/icons/header.svg',
                        'default' => 'ext://assets/icons/sidebar.svg',
                    ],
                    'columns' => 1,
                    'default' => 'default',
                    'description' => 'Choose when to display the sidebar navigation',
                    'section' => 'Sidebar Layout',
                    'overlay_text' => true,
                ],
                [
                    'name' => 'discord_invite_link',
                    'label' => 'Discord Invite Link',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'Enter your Discord invite link (e.g., https://discord.gg/your-invite). Leave empty to hide the Discord card on dashboard.',
                    'section' => 'Site Info',
                ],
            ],
            'colors' => [
                [
                    'name' => 'primary',
                    'label' => 'Primary - Brand Color (Light)',
                    'type' => 'color',
                    'default' => 'hsl(220, 90%, 41%)',
                    'section' => 'Light Mode Colors',
                ],
                [
                    'name' => 'secondary',
                    'label' => 'Secondary - Brand Color (Light)',
                    'type' => 'color',
                    'default' => 'hsl(220, 76%, 48%)',
                    'section' => 'Light Mode Colors',
                ],
                [
                    'name' => 'neutral',
                    'label' => 'Borders, Accents... (Light)',
                    'type' => 'color',
                    'default' => 'hsl(0, 0%, 89%)',
                    'section' => 'Light Mode Colors',
                ],
                [
                    'name' => 'base',
                    'label' => 'Base - Text Color (Light)',
                    'type' => 'color',
                    'default' => 'hsl(0, 0%, 0%)',
                    'section' => 'Light Mode Colors',
                ],
                [
                    'name' => 'muted',
                    'label' => 'Muted - Text Color (Light)',
                    'type' => 'color',
                    'default' => 'hsl(220, 5%, 13%)',
                    'section' => 'Light Mode Colors',
                ],
                [
                    'name' => 'inverted',
                    'label' => 'Inverted - Text Color (Light)',
                    'type' => 'color',
                    'default' => 'hsl(100, 100%, 100%)',
                    'section' => 'Light Mode Colors',
                ],
                [
                    'name' => 'background',
                    'label' => 'Background - Color (Light)',
                    'type' => 'color',
                    'default' => 'hsl(210, 40%, 98%)',
                    'section' => 'Light Mode Colors',
                ],
                [
                    'name' => 'background-secondary',
                    'label' => 'Background - Secondary Color (Light)',
                    'type' => 'color',
                    'default' => 'hsl(0, 0%, 100%)',
                    'section' => 'Light Mode Colors',
                ],
                [
                    'name' => 'dark-primary',
                    'label' => 'Primary - Brand Color (Dark)',
                    'type' => 'color',
                    'default' => 'hsl(220, 90%, 41%)',
                    'section' => 'Dark Mode Colors',
                ],
                [
                    'name' => 'dark-secondary',
                    'label' => 'Secondary - Brand Color (Dark)',
                    'type' => 'color',
                    'default' => 'hsl(220, 76%, 48%)',
                    'section' => 'Dark Mode Colors',
                ],
                [
                    'name' => 'dark-neutral',
                    'label' => 'Borders, Accents... (Dark)',
                    'type' => 'color',
                    'default' => 'hsl(0, 0%, 15%)',
                    'section' => 'Dark Mode Colors',
                ],
                [
                    'name' => 'dark-base',
                    'label' => 'Base - Text Color (Dark)',
                    'type' => 'color',
                    'default' => 'hsl(100, 100%, 100%)',
                    'section' => 'Dark Mode Colors',
                ],
                [
                    'name' => 'dark-muted',
                    'label' => 'Muted - Text Color (Dark)',
                    'type' => 'color',
                    'default' => 'hsl(220, 0%, 80%)',
                    'section' => 'Dark Mode Colors',
                ],
                [
                    'name' => 'dark-inverted',
                    'label' => 'Inverted - Text Color (Dark)',
                    'type' => 'color',
                    'default' => 'hsl(220, 14%, 60%)',
                    'section' => 'Dark Mode Colors',
                ],
                [
                    'name' => 'dark-background',
                    'label' => 'Background - Color (Dark)',
                    'type' => 'color',
                    'default' => 'hsl(240, 10%, 4%)',
                    'section' => 'Dark Mode Colors',
                ],
                [
                    'name' => 'dark-background-secondary',
                    'label' => 'Background - Secondary Color (Dark)',
                    'type' => 'color',
                    'default' => 'hsl(60, 2%, 12%)',
                    'section' => 'Dark Mode Colors',
                ],
                [
                    'name' => 'default_color_theme',
                    'label' => 'Default Color Theme',
                    'type' => 'select',
                    'options' => [
                        'light' => 'Light',
                        'dark' => 'Dark',
                    ],
                    'default' => 'light',
                    'description' => 'The default color theme when a user first visits the site',
                    'section' => 'Color Preferences',
                    'overlay_text' => true,
                ],
                [
                    'name' => 'disable_color_switching',
                    'label' => 'Disable Color Switching',
                    'type' => 'checkbox',
                    'default' => false,
                    'description' => 'Remove the light/dark mode toggle from the navigation bar',
                    'section' => 'Color Preferences',
                ],
            ],
            'customization' => [
                [
                    'name' => 'font_family',
                    'label' => 'Font Family',
                    'type' => 'select',
                    'default' => 'Poppins',
                    'section' => 'Typography',
                ],
                [
                    'name' => 'card_border_radius',
                    'label' => 'Card Border Radius',
                    'type' => 'range',
                    'default' => '8',
                    'database_type' => 'string',
                    'section' => 'Border Radius',
                ],
                [
                    'name' => 'button_border_radius',
                    'label' => 'Button Border Radius',
                    'type' => 'range',
                    'default' => '8',
                    'database_type' => 'string',
                    'section' => 'Border Radius',
                ],
                [
                    'name' => 'content_width',
                    'label' => 'Content Area Width',
                    'type' => 'text',
                    'default' => '1440px',
                    'section' => 'Layout',
                ],
                [
                    'name' => 'button_padding_y',
                    'label' => 'Button Height',
                    'type' => 'range',
                    'default' => '10',
                    'database_type' => 'string',
                    'section' => 'Buttons',
                ],
            ],
            'custom_pages' => [
                [
                    'name' => 'custom_pages_data',
                    'label' => 'Custom Pages',
                    'type' => 'repeater',
                    'default' => '[]',
                    'database_type' => 'string',
                    'section' => 'Custom Pages',
                ],
            ],
            'header_footer' => [
                [
                    'name' => 'header_style',
                    'label' => 'Header Style',
                    'type' => 'image_radio',
                    'default' => 'header1',
                    'database_type' => 'string',
                    'section' => 'Header Style',
                ],
                [
                    'name' => 'header_sticky',
                    'label' => 'Sticky Header',
                    'type' => 'checkbox',
                    'default' => true,
                    'database_type' => 'boolean',
                    'description' => 'Keep the whole header (and utility bar) pinned to the top while scrolling. Turn off to let it scroll away with the page. Applies to both header styles.',
                    'section' => 'Header Style',
                ],
                [
                    'name' => 'header_utility_bar',
                    'label' => 'Top Utility Bar',
                    'type' => 'checkbox',
                    'default' => false,
                    'database_type' => 'boolean',
                    'description' => 'Show a slim bar above the header holding the language, currency and theme switchers (moves them out of the navbar). Desktop only.',
                    'section' => 'Header Style',
                    'live' => true,
                ],
                [
                    'name' => 'header_utility_bar_bg',
                    'label' => 'Utility Bar Background (Light Mode)',
                    'type' => 'color',
                    'default' => '',
                    'database_type' => 'string',
                    'description' => 'Background colour for the utility bar in light mode. Leave empty to use the theme background.',
                    'section' => 'Header Style',
                ],
                [
                    'name' => 'header_utility_bar_bg_dark',
                    'label' => 'Utility Bar Background (Dark Mode)',
                    'type' => 'color',
                    'default' => '',
                    'database_type' => 'string',
                    'description' => 'Background colour for the utility bar in dark mode. Leave empty to reuse the light-mode colour (or the theme background).',
                    'section' => 'Header Style',
                ],
                [
                    'name' => 'header_utility_items_data',
                    'label' => 'Utility Bar Items',
                    'type' => 'repeater',
                    'default' => '[]',
                    'database_type' => 'string',
                    'section' => 'Header Style',
                ],
                [
                    'name' => 'nav_items_data',
                    'label' => 'Header Navigation Items',
                    'type' => 'repeater',
                    'default' => '[{"type":"store"},{"type":"dashboard"},{"type":"support","dropdown_items":[{"label":"Knowledgebase","url":"","new_tab":true,"icon":"ri-book-shelf-fill"},{"label":"Blog","url":"","new_tab":true,"icon":"ri-book-marked-fill"},{"label":"Status","url":"","new_tab":true,"icon":"ri-heart-pulse-fill"}]}]',
                    'database_type' => 'string',
                    'section' => 'Header Navigation',
                ],
                [
                    'name' => 'site_description',
                    'label' => 'Site Description',
                    'type' => 'markdown',
                    'default' => '',
                    'description' => 'A brief description of your site shown in the footer. Supports Markdown formatting.',
                    'section' => 'Footer Info',
                ],
                [
                    'name' => 'copyright_message',
                    'label' => 'Copyright Message',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'Custom footer copyright. Use {year} for the current year and {company} for the company name. Leave empty for the default.',
                    'section' => 'Footer Info',
                ],
                [
                    'name' => 'payment_method_icons',
                    'label' => 'Payment Method Icons',
                    'type' => 'multi_file',
                    'default' => '[]',
                    'description' => 'Upload payment method icons for the footer (e.g. Visa, Mastercard, PayPal). Recommended: SVG or PNG with transparent background.',
                    'section' => 'Footer Info',
                ],
                [
                    'name' => 'footer_payment_disable_bg',
                    'label' => 'Disable Payment Icon Background',
                    'type' => 'checkbox',
                    'default' => true,
                    'database_type' => 'boolean',
                    'description' => 'Show the payment method icons on their own, without the box/background behind each one.',
                    'section' => 'Footer Info',
                ],
                [
                    'name' => 'footer_company_items_data',
                    'label' => 'Company Column Links',
                    'type' => 'repeater',
                    'default' => '[{"label":"Services","url":"/services"},{"label":"Contact Us","url":"/tickets"}]',
                    'database_type' => 'string',
                    'section' => 'Footer - Company Column',
                ],
                [
                    'name' => 'footer_legal_items_data',
                    'label' => 'Legal Column Links',
                    'type' => 'repeater',
                    'default' => '[{"label":"Terms of Service","url":"#"},{"label":"Privacy Policy","url":"#"}]',
                    'database_type' => 'string',
                    'section' => 'Footer - Legal Column',
                ],
                [
                    'name' => 'sidebar_items_data',
                    'label' => 'Sidebar Items',
                    'type' => 'repeater',
                    'default' => '[{"type":"dashboard","label":"","icon":"dashbord"},{"type":"services","label":"","icon":"server"},{"type":"billing","label":"","icon":"billing"},{"type":"store","label":"","icon":"store"},{"type":"support","label":"","icon":"support","dropdown_items":[{"label":"Knowledgebase","url":"","new_tab":true,"icon":"ri-book-shelf-fill"},{"label":"Blog","url":"","new_tab":true,"icon":"ri-book-marked-fill"},{"label":"Status","url":"","new_tab":true,"icon":"ri-heart-pulse-fill"}]},{"type":"account","label":"","icon":"account"}]',
                    'database_type' => 'string',
                    'section' => 'Sidebar',
                ],

                
                [
                    'name' => 'social_youtube',
                    'label' => 'YouTube URL',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'Enter your YouTube channel URL (e.g., https://youtube.com/@channel)',
                    'section' => 'Social Media',
                ],
                [
                    'name' => 'social_x',
                    'label' => 'X (Twitter) URL',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'Enter your X (Twitter) profile URL (e.g., https://x.com/username)',
                    'section' => 'Social Media',
                ],
                [
                    'name' => 'social_instagram',
                    'label' => 'Instagram URL',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'Enter your Instagram profile URL (e.g., https://instagram.com/username)',
                    'section' => 'Social Media',
                ],
                [
                    'name' => 'social_tiktok',
                    'label' => 'TikTok URL',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'Enter your TikTok profile URL (e.g., https://tiktok.com/@username)',
                    'section' => 'Social Media',
                ],
                [
                    'name' => 'social_linkedin',
                    'label' => 'LinkedIn URL',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'Enter your LinkedIn profile or company URL (e.g., https://linkedin.com/in/username)',
                    'section' => 'Social Media',
                ],
                [
                    'name' => 'social_github',
                    'label' => 'GitHub URL',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'Enter your GitHub profile URL (e.g., https://github.com/username)',
                    'section' => 'Social Media',
                ],
            ],
            'home_page' => [
                [
                    'name' => 'home_layout',
                    'label' => 'Home Page Layout',
                    'type' => 'image_radio',
                    'options' => [
                        'portal'     => 'Portal Layout',
                        'marketing2' => 'Marketing Style',
                        'landing'    => 'Marketing Style',
                        'custom'     => 'Custom Layout',
                        'disabled'   => 'Disable Home Page',
                    ],
                    'overlay_text' => true,
                    'overlay_options' => [
                        'portal' => [
                            'title'       => 'Portal Layout',
                            'description' => 'A clean client portal with quick-action service cards. Best for hosting panels.',
                        ],
                        'marketing2' => [
                            'title'       => 'Marketing Style',
                            'description' => 'The most customizable marketing layout, bento grid, category showcase, plans, reviews & FAQ.',
                        ],
                        'landing' => [
                            'title'       => 'Marketing Style',
                            'description' => 'A minimal marketing design with a hero, feature sections, pricing plans, and a CTA.',
                        ],
                        'custom' => [
                            'title'       => 'Custom Layout',
                            'description' => 'Get a custom landing page built specifically for your brand and goals.',
                        ],
                        'disabled' => [
                            'title'       => 'Disable Home Page',
                            'description' => 'Turn off the home page and redirect every visitor to a link you choose.',
                        ],
                    ],
                    'images' => [
                        'portal'     => 'ext://assets/icons/portal.svg',
                        'marketing2' => 'ext://assets/icons/mar1.svg',
                        'landing'    => 'ext://assets/icons/mar2.svg',
                        'custom'     => 'ext://assets/icons/custom.svg',
                        'disabled'   => 'assets/admin/home/disable.svg',
                    ],
                    'columns' => 1,
                    'default' => 'portal',
                    'description' => 'Choose the layout style for the home page',
                    'live' => true,
                ],

                [

                    'name' => 'marketing2_blocks',
                    'label' => 'Home Sections',
                    'type' => 'repeater',
                    'default' => '[]',
                    'database_type' => 'string',
                    'section' => 'Home Sections',
                ],

                [
                    'name' => 'home_disabled_redirect',
                    'label' => 'Redirect URL',
                    'type' => 'text',
                    'default' => '',
                    'database_type' => 'string',
                    'description' => 'Anyone who visits the home page is automatically redirected here. Use a full URL (e.g. https://example.com) or an internal path (e.g. /login).',
                    'section' => 'Disabled Home Page',
                    'visible_when' => 'disabled',
                ],

                [
                    'name' => 'home_page_text',
                    'label' => 'Home Page Text',
                    'type' => 'markdown',
                    'default' => 'Welcome to Paymenter!',
                    'description' => 'Welcome message displayed at the top of the portal home page',
                    'visible_when' => 'portal',
                ],
                [
                    'name' => 'home_portal_show_icons',
                    'label' => 'Show Icons on Cards',
                    'type' => 'checkbox',
                    'default' => false,
                    'description' => 'Display icons above each card title',
                    'visible_when' => 'portal',
                    'live' => true,
                ],


                [
                    'name' => 'home_card1_customize',
                    'label' => 'Customize Card 1',
                    'type' => 'checkbox',
                    'default' => false,
                    'description' => 'Override the default Contact card with custom content',
                    'visible_when' => 'portal',
                    'live' => true,
                ],
                [
                    'name' => 'home_card1_title',
                    'label' => 'Card 1 Title',
                    'type' => 'text',
                    'default' => 'Contact Us',
                    'visible_when' => 'portal',
                    'visible_when_field' => 'home_card1_customize',
                    'visible_when_value' => true,
                ],
                [
                    'name' => 'home_card1_description',
                    'label' => 'Card 1 Description',
                    'type' => 'text',
                    'default' => 'Get in touch with our support team. We\'re here to help you with any questions or concerns.',
                    'visible_when' => 'portal',
                    'visible_when_field' => 'home_card1_customize',
                    'visible_when_value' => true,
                ],
                [
                    'name' => 'home_card1_button_text',
                    'label' => 'Card 1 Button Text',
                    'type' => 'text',
                    'default' => 'Get Support',
                    'visible_when' => 'portal',
                    'visible_when_field' => 'home_card1_customize',
                    'visible_when_value' => true,
                ],
                [
                    'name' => 'home_card1_link',
                    'label' => 'Card 1 Link',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'URL for this card. Leave empty to use the contact link from General settings.',
                    'visible_when' => 'portal',
                    'visible_when_field' => 'home_card1_customize',
                    'visible_when_value' => true,
                ],
                [
                    'name' => 'home_card1_icon_type',
                    'label' => 'Card 1 Icon Type',
                    'type' => 'select',
                    'options' => [
                        'citadel' => 'Citadel Icons',
                        'remix' => 'Remix Icons',
                    ],
                    'default' => 'citadel',
                    'visible_when' => 'portal',
                    'visible_when_field' => 'home_portal_show_icons',
                    'visible_when_value' => true,
                    'live' => true,
                ],
                [
                    'name' => 'home_card1_icon_citadel',
                    'label' => 'Card 1 Citadel Icon',
                    'type' => 'citadel_icon_picker',
                    'default' => '',
                    'visible_when' => 'portal',
                    'visible_when_field' => 'home_portal_show_icons',
                    'visible_when_value' => true,
                    'visible_when_field_2' => 'home_card1_icon_type',
                    'visible_when_value_2' => 'citadel',
                ],
                [
                    'name' => 'home_card1_icon_remix',
                    'label' => 'Card 1 Remix Icon',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'Enter a Remix Icon name (e.g., ri-customer-service-2-line)',
                    'visible_when' => 'portal',
                    'visible_when_field' => 'home_portal_show_icons',
                    'visible_when_value' => true,
                    'visible_when_field_2' => 'home_card1_icon_type',
                    'visible_when_value_2' => 'remix',
                ],


                [
                    'name' => 'home_card2_customize',
                    'label' => 'Customize Card 2',
                    'type' => 'checkbox',
                    'default' => false,
                    'description' => 'Override the default Services card with custom content',
                    'visible_when' => 'portal',
                    'live' => true,
                ],
                [
                    'name' => 'home_card2_title',
                    'label' => 'Card 2 Title',
                    'type' => 'text',
                    'default' => 'Services',
                    'visible_when' => 'portal',
                    'visible_when_field' => 'home_card2_customize',
                    'visible_when_value' => true,
                ],
                [
                    'name' => 'home_card2_description',
                    'label' => 'Card 2 Description',
                    'type' => 'text',
                    'default' => 'Explore our range of services and solutions. Find the perfect plan that fits your needs.',
                    'visible_when' => 'portal',
                    'visible_when_field' => 'home_card2_customize',
                    'visible_when_value' => true,
                ],
                [
                    'name' => 'home_card2_button_text',
                    'label' => 'Card 2 Button Text',
                    'type' => 'text',
                    'default' => 'View Services',
                    'visible_when' => 'portal',
                    'visible_when_field' => 'home_card2_customize',
                    'visible_when_value' => true,
                ],
                [
                    'name' => 'home_card2_link',
                    'label' => 'Card 2 Link',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'URL for this card. Leave empty to use the services link from General settings.',
                    'visible_when' => 'portal',
                    'visible_when_field' => 'home_card2_customize',
                    'visible_when_value' => true,
                ],
                [
                    'name' => 'home_card2_icon_type',
                    'label' => 'Card 2 Icon Type',
                    'type' => 'select',
                    'options' => [
                        'citadel' => 'Citadel Icons',
                        'remix' => 'Remix Icons',
                    ],
                    'default' => 'citadel',
                    'visible_when' => 'portal',
                    'visible_when_field' => 'home_portal_show_icons',
                    'visible_when_value' => true,
                    'live' => true,
                ],
                [
                    'name' => 'home_card2_icon_citadel',
                    'label' => 'Card 2 Citadel Icon',
                    'type' => 'citadel_icon_picker',
                    'default' => '',
                    'visible_when' => 'portal',
                    'visible_when_field' => 'home_portal_show_icons',
                    'visible_when_value' => true,
                    'visible_when_field_2' => 'home_card2_icon_type',
                    'visible_when_value_2' => 'citadel',
                ],
                [
                    'name' => 'home_card2_icon_remix',
                    'label' => 'Card 2 Remix Icon',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'Enter a Remix Icon name (e.g., ri-shopping-bag-line)',
                    'visible_when' => 'portal',
                    'visible_when_field' => 'home_portal_show_icons',
                    'visible_when_value' => true,
                    'visible_when_field_2' => 'home_card2_icon_type',
                    'visible_when_value_2' => 'remix',
                ],


                [
                    'name' => 'home_card3_customize',
                    'label' => 'Customize Card 3',
                    'type' => 'checkbox',
                    'default' => false,
                    'description' => 'Override the default Get Started card with custom content',
                    'visible_when' => 'portal',
                    'live' => true,
                ],
                [
                    'name' => 'home_card3_title',
                    'label' => 'Card 3 Title',
                    'type' => 'text',
                    'default' => 'Get Started',
                    'visible_when' => 'portal',
                    'visible_when_field' => 'home_card3_customize',
                    'visible_when_value' => true,
                ],
                [
                    'name' => 'home_card3_description',
                    'label' => 'Card 3 Description',
                    'type' => 'text',
                    'default' => 'Create your account and start using our services today',
                    'visible_when' => 'portal',
                    'visible_when_field' => 'home_card3_customize',
                    'visible_when_value' => true,
                ],
                [
                    'name' => 'home_card3_button_text',
                    'label' => 'Card 3 Button Text',
                    'type' => 'text',
                    'default' => 'Get Started',
                    'visible_when' => 'portal',
                    'visible_when_field' => 'home_card3_customize',
                    'visible_when_value' => true,
                ],
                [
                    'name' => 'home_card3_link',
                    'label' => 'Card 3 Link',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'URL for this card. Leave empty to use the register page.',
                    'visible_when' => 'portal',
                    'visible_when_field' => 'home_card3_customize',
                    'visible_when_value' => true,
                ],
                [
                    'name' => 'home_card3_icon_type',
                    'label' => 'Card 3 Icon Type',
                    'type' => 'select',
                    'options' => [
                        'citadel' => 'Citadel Icons',
                        'remix' => 'Remix Icons',
                    ],
                    'default' => 'citadel',
                    'visible_when' => 'portal',
                    'visible_when_field' => 'home_portal_show_icons',
                    'visible_when_value' => true,
                    'live' => true,
                ],
                [
                    'name' => 'home_card3_icon_citadel',
                    'label' => 'Card 3 Citadel Icon',
                    'type' => 'citadel_icon_picker',
                    'default' => '',
                    'visible_when' => 'portal',
                    'visible_when_field' => 'home_portal_show_icons',
                    'visible_when_value' => true,
                    'visible_when_field_2' => 'home_card3_icon_type',
                    'visible_when_value_2' => 'citadel',
                ],
                [
                    'name' => 'home_card3_icon_remix',
                    'label' => 'Card 3 Remix Icon',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'Enter a Remix Icon name (e.g., ri-rocket-line)',
                    'visible_when' => 'portal',
                    'visible_when_field' => 'home_portal_show_icons',
                    'visible_when_value' => true,
                    'visible_when_field_2' => 'home_card3_icon_type',
                    'visible_when_value_2' => 'remix',
                ],


                [
                    'name' => 'marketing2_title',
                    'label' => 'Hero Title',
                    'type' => 'text',
                    'default' => 'Powerful VPS Hosting and Web Hosting',
                    'description' => 'Main headline text for the hero section. Supports markdown (**bold**, *italic*)',
                    'visible_when' => 'marketing2',
                    'section' => 'Hero Section',
                ],
                [
                    'name' => 'marketing2_title_size',
                    'label' => 'Title Font Size',
                    'type' => 'select',
                    'options' => [
                        'text-3xl sm:text-4xl lg:text-5xl' => 'Small',
                        'text-4xl sm:text-5xl lg:text-6xl' => 'Medium',
                        'text-5xl sm:text-6xl lg:text-7xl' => 'Large (Default)',
                        'text-6xl sm:text-7xl lg:text-8xl' => 'Extra Large',
                    ],
                    'default' => 'text-5xl sm:text-6xl lg:text-7xl',
                    'description' => 'Font size for the hero title',
                    'visible_when' => 'marketing2',
                    'section' => 'Hero Section',
                ],
                [
                    'name' => 'marketing2_description',
                    'label' => 'Hero Description',
                    'type' => 'textarea',
                    'default' => '',
                    'description' => 'Description text below the title. Supports markdown (**bold**, *italic*). Leave empty to hide.',
                    'visible_when' => 'marketing2',
                    'section' => 'Hero Section',
                ],
                [
                    'name' => 'marketing2_description_size',
                    'label' => 'Description Font Size',
                    'type' => 'select',
                    'options' => [
                        'text-sm' => 'Small',
                        'text-base' => 'Medium (Default)',
                        'text-lg' => 'Large',
                        'text-xl' => 'Extra Large',
                    ],
                    'default' => 'text-base',
                    'description' => 'Font size for the hero description',
                    'visible_when' => 'marketing2',
                    'section' => 'Hero Section',
                ],
                [
                    'name' => 'marketing2_hero_right_content',
                    'label' => 'Right Side Content',
                    'type' => 'select',
                    'options' => [
                        'categories' => 'Category Cards',
                        'preset_image' => 'Choose from Preset',
                        'custom_image' => 'Custom Image Upload',
                    ],
                    'default' => 'categories',
                    'description' => 'Choose what to display on the right side of the hero section',
                    'visible_when' => 'marketing2',
                    'section' => 'Hero Section',
                    'live' => true,
                ],
                [
                    'name' => 'marketing2_hero_preset_image',
                    'label' => 'Preset Image',
                    'type' => 'select',
                    'options' => [
                        'hero' => 'Hero (Abstract Shapes - Full Background)',
                        'webhosting' => 'Web Hosting (Side Image)',
                    ],
                    'default' => 'hero',
                    'description' => 'Select a preset image. Hero displays as full background, others display on the right side',
                    'visible_when' => 'marketing2',
                    'visible_when_field' => 'marketing2_hero_right_content',
                    'visible_when_value' => 'preset_image',
                    'section' => 'Hero Section',
                ],
                [
                    'name' => 'marketing2_hero_custom_image',
                    'label' => 'Custom Hero Image',
                    'type' => 'file',
                    'default' => '',
                    'description' => 'Upload a custom image for the right side of the hero',
                    'visible_when' => 'marketing2',
                    'visible_when_field' => 'marketing2_hero_right_content',
                    'visible_when_value' => 'custom_image',
                    'section' => 'Hero Section',
                ],
                [
                    'name' => 'marketing2_show_trustpilot',
                    'label' => 'Show Trustpilot Rating',
                    'type' => 'checkbox',
                    'default' => true,
                    'description' => 'Display the Trustpilot rating badge in the hero section',
                    'visible_when' => 'marketing2',
                    'section' => 'Hero Section',
                    'live' => true,
                ],
                [
                    'name' => 'marketing2_trustpilot_rating',
                    'label' => 'Trustpilot Rating Text',
                    'type' => 'text',
                    'default' => 'Excellent',
                    'description' => 'The rating text displayed next to the Trustpilot badge (e.g., "Excellent", "Great", "5 Stars")',
                    'visible_when' => 'marketing2',
                    'visible_when_field' => 'marketing2_show_trustpilot',
                    'visible_when_value' => true,
                    'section' => 'Hero Section',
                ],
                [
                    'name' => 'marketing2_enable_button',
                    'label' => 'Enable Button',
                    'type' => 'checkbox',
                    'default' => true,
                    'description' => 'Show the call-to-action button in the hero section',
                    'visible_when' => 'marketing2',
                    'section' => 'Hero Section',
                    'live' => true,
                ],
                [
                    'name' => 'marketing2_button_text',
                    'label' => 'Button Text',
                    'type' => 'text',
                    'default' => 'Get Started',
                    'description' => 'Text for the call-to-action button',
                    'visible_when' => 'marketing2',
                    'visible_when_field' => 'marketing2_enable_button',
                    'visible_when_value' => true,
                    'section' => 'Hero Section',
                ],
                [
                    'name' => 'marketing2_button_link',
                    'label' => 'Button Link',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'URL the button links to. Leave empty to link to the first category.',
                    'visible_when' => 'marketing2',
                    'visible_when_field' => 'marketing2_enable_button',
                    'visible_when_value' => true,
                    'section' => 'Hero Section',
                ],
                [
                    'name' => 'marketing2_show_starting_price',
                    'label' => 'Show Starting Price',
                    'type' => 'checkbox',
                    'default' => true,
                    'description' => 'Display the starting price next to the button',
                    'visible_when' => 'marketing2',
                    'visible_when_field' => 'marketing2_enable_button',
                    'visible_when_value' => true,
                    'section' => 'Hero Section',
                    'live' => true,
                ],
                [
                    'name' => 'marketing2_price_prefix',
                    'label' => 'Price Prefix Text',
                    'type' => 'text',
                    'default' => 'Starting at Only',
                    'description' => 'Text shown before the price (e.g., "Starting at Only")',
                    'visible_when' => 'marketing2',
                    'visible_when_field' => 'marketing2_show_starting_price',
                    'visible_when_value' => true,
                    'section' => 'Hero Section',
                ],
                [
                    'name' => 'marketing2_enable_secondary_button',
                    'label' => 'Enable Additional Button',
                    'type' => 'checkbox',
                    'default' => false,
                    'description' => 'Add a secondary button instead of the starting price',
                    'visible_when' => 'marketing2',
                    'visible_when_field' => 'marketing2_show_starting_price',
                    'visible_when_value' => false,
                    'section' => 'Hero Section',
                    'live' => true,
                ],
                [
                    'name' => 'marketing2_secondary_button_text',
                    'label' => 'Additional Button Text',
                    'type' => 'text',
                    'default' => 'View All Plans',
                    'description' => 'Text for the secondary button',
                    'visible_when' => 'marketing2',
                    'visible_when_field' => 'marketing2_enable_secondary_button',
                    'visible_when_value' => true,
                    'section' => 'Hero Section',
                ],
                [
                    'name' => 'marketing2_secondary_button_link',
                    'label' => 'Additional Button Link',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'URL for the secondary button. Leave empty to link to the home page.',
                    'visible_when' => 'marketing2',
                    'visible_when_field' => 'marketing2_enable_secondary_button',
                    'visible_when_value' => true,
                    'section' => 'Hero Section',
                ],


                [
                    'name' => 'marketing2_bento_title',
                    'label' => 'Section Title',
                    'type' => 'text',
                    'default' => 'Hosting features you will love',
                    'description' => 'Main heading for the bento features section',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                ],
                [
                    'name' => 'marketing2_bento_description',
                    'label' => 'Section Description',
                    'type' => 'textarea',
                    'default' => 'Everything you need to power your online presence, backed by enterprise infrastructure.',
                    'description' => 'Short description displayed below the section title',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                ],
                [
                    'name' => 'marketing2_bento1_title',
                    'label' => 'Card 1 Title',
                    'type' => 'text',
                    'default' => 'Lightning Fast Servers',
                    'description' => 'Title for the first bento card (top-left, 2/5 width)',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                ],
                [
                    'name' => 'marketing2_bento1_description',
                    'label' => 'Card 1 Description',
                    'type' => 'textarea',
                    'default' => 'Enterprise-grade NVMe storage and high-frequency processors deliver blazing performance for your applications.',
                    'description' => 'Description for the first bento card (top-left, 2/5 width)',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                ],
                [
                    'name' => 'marketing2_bento1_image_source',
                    'label' => 'Card 1 Image Source',
                    'type' => 'select',
                    'options' => ['none' => 'None', 'preset' => 'Choose from Presets', 'custom' => 'Custom Upload'],
                    'default' => 'none',
                    'description' => 'Choose how to display the image for this card.',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                    'live' => true,
                ],
                [
                    'name' => 'marketing2_bento1_preset',
                    'label' => 'Card 1 Preset Image',
                    'type' => 'select',
                    'options' => ['controlpanel' => 'Control Panel', 'support' => 'Support (Headset)', 'secure' => 'Secure (Shield)', 'ryzen' => 'Ryzen (CPU)', 'intel' => 'Intel (CPU)', 'epic' => 'EPYC (CPU)'],
                    'default' => 'secure',
                    'description' => 'Select a preset illustration. Colors will automatically match your site\'s primary color.',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                    'visible_when_field' => 'marketing2_bento1_image_source',
                    'visible_when_value' => 'preset',
                ],
                [
                    'name' => 'marketing2_bento1_image',
                    'label' => 'Card 1 Custom Image',
                    'type' => 'file',
                    'default' => '',
                    'description' => 'Upload a custom image for this card.',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                    'visible_when_field' => 'marketing2_bento1_image_source',
                    'visible_when_value' => 'custom',
                ],
                [
                    'name' => 'marketing2_bento2_title',
                    'label' => 'Card 2 Title',
                    'type' => 'text',
                    'default' => '99.9% Uptime',
                    'description' => 'Title for the second bento card (top-right, 3/5 width)',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                ],
                [
                    'name' => 'marketing2_bento2_description',
                    'label' => 'Card 2 Description',
                    'type' => 'textarea',
                    'default' => 'Fully redundant infrastructure ensures your services stay online around the clock.',
                    'description' => 'Description for the second bento card (top-right, 3/5 width)',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                ],
                [
                    'name' => 'marketing2_bento2_image_source',
                    'label' => 'Card 2 Image Source',
                    'type' => 'select',
                    'options' => ['none' => 'None', 'preset' => 'Choose from Presets', 'custom' => 'Custom Upload'],
                    'default' => 'none',
                    'description' => 'Choose how to display the image for this card.',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                    'live' => true,
                ],
                [
                    'name' => 'marketing2_bento2_preset',
                    'label' => 'Card 2 Preset Image',
                    'type' => 'select',
                    'options' => ['controlpanel' => 'Control Panel', 'support' => 'Support (Headset)', 'secure' => 'Secure (Shield)', 'ryzen' => 'Ryzen (CPU)', 'intel' => 'Intel (CPU)', 'epic' => 'EPYC (CPU)'],
                    'default' => 'secure',
                    'description' => 'Select a preset illustration. Colors will automatically match your site\'s primary color.',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                    'visible_when_field' => 'marketing2_bento2_image_source',
                    'visible_when_value' => 'preset',
                ],
                [
                    'name' => 'marketing2_bento2_image',
                    'label' => 'Card 2 Custom Image',
                    'type' => 'file',
                    'default' => '',
                    'description' => 'Upload a custom image for this card.',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                    'visible_when_field' => 'marketing2_bento2_image_source',
                    'visible_when_value' => 'custom',
                ],
                [
                    'name' => 'marketing2_bento3_title',
                    'label' => 'Card 3 Title',
                    'type' => 'text',
                    'default' => 'DDoS Protection',
                    'description' => 'Title for the third bento card (bottom-left)',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                ],
                [
                    'name' => 'marketing2_bento3_description',
                    'label' => 'Card 3 Description',
                    'type' => 'textarea',
                    'default' => 'Advanced mitigation keeps your services safe from volumetric and application-layer attacks.',
                    'description' => 'Description for the third bento card (bottom-left)',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                ],
                [
                    'name' => 'marketing2_bento3_image_source',
                    'label' => 'Card 3 Image Source',
                    'type' => 'select',
                    'options' => ['none' => 'None', 'preset' => 'Choose from Presets', 'custom' => 'Custom Upload'],
                    'default' => 'none',
                    'description' => 'Choose how to display the image for this card.',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                    'live' => true,
                ],
                [
                    'name' => 'marketing2_bento3_preset',
                    'label' => 'Card 3 Preset Image',
                    'type' => 'select',
                    'options' => ['controlpanel' => 'Control Panel', 'support' => 'Support (Headset)', 'secure' => 'Secure (Shield)', 'ryzen' => 'Ryzen (CPU)', 'intel' => 'Intel (CPU)', 'epic' => 'EPYC (CPU)'],
                    'default' => 'secure',
                    'description' => 'Select a preset illustration. Colors will automatically match your site\'s primary color.',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                    'visible_when_field' => 'marketing2_bento3_image_source',
                    'visible_when_value' => 'preset',
                ],
                [
                    'name' => 'marketing2_bento3_image',
                    'label' => 'Card 3 Custom Image',
                    'type' => 'file',
                    'default' => '',
                    'description' => 'Upload a custom image for this card.',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                    'visible_when_field' => 'marketing2_bento3_image_source',
                    'visible_when_value' => 'custom',
                ],
                [
                    'name' => 'marketing2_bento4_title',
                    'label' => 'Card 4 Title',
                    'type' => 'text',
                    'default' => '24/7 Expert Support',
                    'description' => 'Title for the fourth bento card (bottom-center)',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                ],
                [
                    'name' => 'marketing2_bento4_description',
                    'label' => 'Card 4 Description',
                    'type' => 'textarea',
                    'default' => 'Our knowledgeable team is always available to help you with any questions or issues.',
                    'description' => 'Description for the fourth bento card (bottom-center)',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                ],
                [
                    'name' => 'marketing2_bento4_image_source',
                    'label' => 'Card 4 Image Source',
                    'type' => 'select',
                    'options' => ['none' => 'None', 'preset' => 'Choose from Presets', 'custom' => 'Custom Upload'],
                    'default' => 'none',
                    'description' => 'Choose how to display the image for this card.',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                    'live' => true,
                ],
                [
                    'name' => 'marketing2_bento4_preset',
                    'label' => 'Card 4 Preset Image',
                    'type' => 'select',
                    'options' => ['controlpanel' => 'Control Panel', 'support' => 'Support (Headset)', 'secure' => 'Secure (Shield)', 'ryzen' => 'Ryzen (CPU)', 'intel' => 'Intel (CPU)', 'epic' => 'EPYC (CPU)'],
                    'default' => 'secure',
                    'description' => 'Select a preset illustration. Colors will automatically match your site\'s primary color.',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                    'visible_when_field' => 'marketing2_bento4_image_source',
                    'visible_when_value' => 'preset',
                ],
                [
                    'name' => 'marketing2_bento4_image',
                    'label' => 'Card 4 Custom Image',
                    'type' => 'file',
                    'default' => '',
                    'description' => 'Upload a custom image for this card.',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                    'visible_when_field' => 'marketing2_bento4_image_source',
                    'visible_when_value' => 'custom',
                ],
                [
                    'name' => 'marketing2_bento5_title',
                    'label' => 'Card 5 Title',
                    'type' => 'text',
                    'default' => 'Global Network',
                    'description' => 'Title for the fifth bento card (bottom-right)',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                ],
                [
                    'name' => 'marketing2_bento5_description',
                    'label' => 'Card 5 Description',
                    'type' => 'textarea',
                    'default' => 'Strategically located data centers around the world ensure low latency for your users.',
                    'description' => 'Description for the fifth bento card (bottom-right)',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                ],
                [
                    'name' => 'marketing2_bento5_image_source',
                    'label' => 'Card 5 Image Source',
                    'type' => 'select',
                    'options' => ['none' => 'None', 'preset' => 'Choose from Presets', 'custom' => 'Custom Upload'],
                    'default' => 'none',
                    'description' => 'Choose how to display the image for this card.',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                    'live' => true,
                ],
                [
                    'name' => 'marketing2_bento5_preset',
                    'label' => 'Card 5 Preset Image',
                    'type' => 'select',
                    'options' => ['controlpanel' => 'Control Panel', 'support' => 'Support (Headset)', 'secure' => 'Secure (Shield)', 'ryzen' => 'Ryzen (CPU)', 'intel' => 'Intel (CPU)', 'epic' => 'EPYC (CPU)'],
                    'default' => 'secure',
                    'description' => 'Select a preset illustration. Colors will automatically match your site\'s primary color.',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                    'visible_when_field' => 'marketing2_bento5_image_source',
                    'visible_when_value' => 'preset',
                ],
                [
                    'name' => 'marketing2_bento5_image',
                    'label' => 'Card 5 Custom Image',
                    'type' => 'file',
                    'default' => '',
                    'description' => 'Upload a custom image for this card.',
                    'visible_when' => 'marketing2',
                    'section' => 'Bento Box Features',
                    'visible_when_field' => 'marketing2_bento5_image_source',
                    'visible_when_value' => 'custom',
                ],


                [
                    'name' => 'marketing2_plans_title',
                    'label' => 'Plans Section Title',
                    'type' => 'text',
                    'default' => 'Simple, Transparent Pricing',
                    'description' => 'Main heading for the pricing/plans section',
                    'visible_when' => 'marketing2',
                    'section' => 'Plans Section',
                ],
                [
                    'name' => 'marketing2_plans_description',
                    'label' => 'Plans Section Description',
                    'type' => 'textarea',
                    'default' => '',
                    'description' => 'Optional description text shown below the title. Leave empty to hide.',
                    'visible_when' => 'marketing2',
                    'section' => 'Plans Section',
                ],
                [
                    'name' => 'marketing2_plans_source',
                    'label' => 'Display Mode',
                    'type' => 'select',
                    'options' => [
                        'top_categories' => 'Top Categories (first 3)',
                        'specific_category' => 'One Specific Category',
                    ],
                    'default' => 'top_categories',
                    'description' => 'Choose whether to show the top 3 categories or plans from a specific category',
                    'visible_when' => 'marketing2',
                    'section' => 'Plans Section',
                    'live' => true,
                ],
                [
                    'name' => 'marketing2_plans_category_id',
                    'label' => 'Select Category',
                    'type' => 'select',
                    'options' => \App\Models\Category::whereNull('parent_id')->orderBy('sort')->pluck('name', 'id')->toArray(),
                    'default' => '',
                    'description' => 'Choose which category\'s plans to display',
                    'visible_when' => 'marketing2',
                    'section' => 'Plans Section',
                    'visible_when_field' => 'marketing2_plans_source',
                    'visible_when_value' => 'specific_category',
                ],
                [
                    'name' => 'marketing2_plans_button_text',
                    'label' => 'Card Button Text',
                    'type' => 'text',
                    'default' => 'Get Started',
                    'description' => 'Text for the button on each plan/category card',
                    'visible_when' => 'marketing2',
                    'section' => 'Plans Section',
                ],
                [
                    'name' => 'marketing2_plans_icon_style',
                    'label' => 'Icon Style',
                    'type' => 'select',
                    'options' => [
                        'none' => 'None',
                        'right' => 'Right (next to name & price)',
                        'top' => 'Top (centered above name)',
                        'background' => 'Background (with gradient overlay)',
                        'corner' => 'Corner (tilted, partially visible)',
                    ],
                    'default' => 'none',
                    'description' => 'How category icons are displayed on plan cards. Uses category image or overridden Citadel icon.',
                    'visible_when' => 'marketing2',
                    'section' => 'Plans Section',
                ],
                [
                    'name' => 'marketing2_plans_popular',
                    'label' => 'Popular Plan',
                    'type' => 'select',
                    'options' => [
                        '' => 'None',
                        '1' => 'Plan 1',
                        '2' => 'Plan 2',
                        '3' => 'Plan 3',
                        '4' => 'Plan 4',
                    ],
                    'default' => '',
                    'description' => 'Select which plan card (by position) to highlight as Popular',
                    'visible_when' => 'marketing2',
                    'section' => 'Plans Section',
                ],


                [
                    'name' => 'marketing2_features_title',
                    'label' => 'Features Section Title',
                    'type' => 'text',
                    'default' => 'Every plan includes everything you need',
                    'description' => 'Main heading for the features section',
                    'visible_when' => 'marketing2',
                    'section' => 'Features Section',
                ],
                [
                    'name' => 'marketing2_features_description',
                    'label' => 'Features Section Description',
                    'type' => 'textarea',
                    'default' => 'Every plan comes fully loaded with all the essentials, powerful performance, reliable support, and zero hidden extras. Just pick your plan and get started.',
                    'description' => 'Description text shown below the features title',
                    'visible_when' => 'marketing2',
                    'section' => 'Features Section',
                ],
                [
                    'name' => 'marketing2_features_icon_bg',
                    'label' => 'Enable Icon Backgrounds',
                    'type' => 'checkbox',
                    'default' => true,
                    'description' => 'Show a background behind the feature icons',
                    'visible_when' => 'marketing2',
                    'section' => 'Features Section',
                ],
                [
                    'name' => 'marketing2_features_data',
                    'label' => 'Features',
                    'type' => 'repeater',
                    'default' => '[]',
                    'database_type' => 'string',
                    'description' => 'Feature cards with icon, title, and description',
                    'visible_when' => 'marketing2',
                    'section' => 'Features Section',
                ],


                [
                    'name' => 'marketing2_reviews_title',
                    'label' => 'Reviews Section Title',
                    'type' => 'text',
                    'default' => 'What our customers say',
                    'description' => 'Main heading for the reviews section',
                    'visible_when' => 'marketing2',
                    'section' => 'Reviews Section',
                ],
                [
                    'name' => 'marketing2_reviews_description',
                    'label' => 'Reviews Section Description',
                    'type' => 'textarea',
                    'default' => 'Trusted by thousands of customers worldwide. Here\'s what they have to say about our services.',
                    'description' => 'Description text shown below the reviews title',
                    'visible_when' => 'marketing2',
                    'section' => 'Reviews Section',
                ],
                [
                    'name' => 'marketing2_reviews_data',
                    'label' => 'Reviews',
                    'type' => 'repeater',
                    'default' => '[]',
                    'database_type' => 'string',
                    'description' => 'Customer reviews with name, review text, and image',
                    'visible_when' => 'marketing2',
                    'section' => 'Reviews Section',
                ],


                [
                    'name' => 'marketing2_faq_title',
                    'label' => 'FAQ Section Title',
                    'type' => 'text',
                    'default' => 'Frequently Asked Questions',
                    'description' => 'Main heading for the FAQ section',
                    'visible_when' => 'marketing2',
                    'section' => 'FAQ Section',
                ],
                [
                    'name' => 'marketing2_faq_description',
                    'label' => 'FAQ Section Description',
                    'type' => 'textarea',
                    'default' => 'Find answers to the most common questions about our services.',
                    'description' => 'Description text shown below the FAQ title',
                    'visible_when' => 'marketing2',
                    'section' => 'FAQ Section',
                ],
                [
                    'name' => 'marketing2_faq_data',
                    'label' => 'FAQs',
                    'type' => 'repeater',
                    'default' => '[]',
                    'database_type' => 'string',
                    'description' => 'FAQ items with question and answer',
                    'visible_when' => 'marketing2',
                    'section' => 'FAQ Section',
                ],


                [
                    'name' => 'marketing2_cta_bg_type',
                    'label' => 'Background Type',
                    'type' => 'select',
                    'options' => [
                        'gradient' => 'Gradient (Primary Color)',
                        'image' => 'Image with Primary Overlay',
                        'custom' => 'Custom HTML',
                    ],
                    'default' => 'gradient',
                    'description' => 'Choose the CTA card background style',
                    'visible_when' => 'marketing2',
                    'section' => 'CTA Section',
                    'live' => true,
                ],
                [
                    'name' => 'marketing2_cta_title',
                    'label' => 'CTA Title',
                    'type' => 'text',
                    'default' => 'Ready to get started?',
                    'description' => 'Main heading for the CTA card',
                    'visible_when' => 'marketing2',
                    'section' => 'CTA Section',
                    'visible_when_field' => 'marketing2_cta_bg_type',
                    'visible_when_value' => 'custom',
                    'visible_when_not' => true,
                ],
                [
                    'name' => 'marketing2_cta_description',
                    'label' => 'CTA Description',
                    'type' => 'textarea',
                    'default' => 'Join thousands of satisfied customers and take your business to the next level today.',
                    'description' => 'Description text shown below the CTA title',
                    'visible_when' => 'marketing2',
                    'section' => 'CTA Section',
                    'visible_when_field' => 'marketing2_cta_bg_type',
                    'visible_when_value' => 'custom',
                    'visible_when_not' => true,
                ],
                [
                    'name' => 'marketing2_cta_btn1_enabled',
                    'label' => 'Enable Button 1',
                    'type' => 'checkbox',
                    'default' => true,
                    'description' => 'Show the first CTA button',
                    'visible_when' => 'marketing2',
                    'section' => 'CTA Section',
                    'visible_when_field' => 'marketing2_cta_bg_type',
                    'visible_when_value' => 'custom',
                    'visible_when_not' => true,
                ],
                [
                    'name' => 'marketing2_cta_btn1_text',
                    'label' => 'Button 1 Text',
                    'type' => 'text',
                    'default' => 'Get Started',
                    'description' => 'Text for the first CTA button',
                    'visible_when' => 'marketing2',
                    'section' => 'CTA Section',
                    'visible_when_field' => 'marketing2_cta_bg_type',
                    'visible_when_value' => 'custom',
                    'visible_when_not' => true,
                ],
                [
                    'name' => 'marketing2_cta_btn1_link',
                    'label' => 'Button 1 Link',
                    'type' => 'text',
                    'default' => '/register',
                    'description' => 'URL for the first CTA button',
                    'visible_when' => 'marketing2',
                    'section' => 'CTA Section',
                    'visible_when_field' => 'marketing2_cta_bg_type',
                    'visible_when_value' => 'custom',
                    'visible_when_not' => true,
                ],
                [
                    'name' => 'marketing2_cta_btn2_enabled',
                    'label' => 'Enable Button 2',
                    'type' => 'checkbox',
                    'default' => false,
                    'description' => 'Show the second CTA button',
                    'visible_when' => 'marketing2',
                    'section' => 'CTA Section',
                    'visible_when_field' => 'marketing2_cta_bg_type',
                    'visible_when_value' => 'custom',
                    'visible_when_not' => true,
                ],
                [
                    'name' => 'marketing2_cta_btn2_text',
                    'label' => 'Button 2 Text',
                    'type' => 'text',
                    'default' => 'Contact Sales',
                    'description' => 'Text for the second CTA button',
                    'visible_when' => 'marketing2',
                    'section' => 'CTA Section',
                    'visible_when_field' => 'marketing2_cta_bg_type',
                    'visible_when_value' => 'custom',
                    'visible_when_not' => true,
                ],
                [
                    'name' => 'marketing2_cta_btn2_link',
                    'label' => 'Button 2 Link',
                    'type' => 'text',
                    'default' => '/contact',
                    'description' => 'URL for the second CTA button',
                    'visible_when' => 'marketing2',
                    'section' => 'CTA Section',
                    'visible_when_field' => 'marketing2_cta_bg_type',
                    'visible_when_value' => 'custom',
                    'visible_when_not' => true,
                ],
                [
                    'name' => 'marketing2_cta_bg_image',
                    'label' => 'Background Image',
                    'type' => 'file',
                    'default' => '',
                    'description' => 'Upload a background image for the CTA card',
                    'visible_when' => 'marketing2',
                    'section' => 'CTA Section',
                    'visible_when_field' => 'marketing2_cta_bg_type',
                    'visible_when_value' => 'image',
                ],
                [
                    'name' => 'marketing2_cta_custom_html',
                    'label' => 'Custom HTML',
                    'type' => 'textarea',
                    'default' => '',
                    'description' => 'Enter custom HTML for the entire CTA section. This replaces the default card.',
                    'visible_when' => 'marketing2',
                    'section' => 'CTA Section',
                    'visible_when_field' => 'marketing2_cta_bg_type',
                    'visible_when_value' => 'custom',
                ],

                [
                    'name' => 'landing_trustpilot_rating',
                    'label' => 'Trustpilot Rating Text',
                    'type' => 'text',
                    'default' => 'Excellent',
                    'description' => 'The rating text displayed on the Trustpilot badge in the hero section (e.g., "Excellent", "Great", "5 Stars")',
                    'visible_when' => 'landing',
                    'section' => 'Hero Section',
                ],
                [
                    'name' => 'landing_hero_title',
                    'label' => 'Hero Title',
                    'type' => 'text',
                    'default' => 'Where Hosting Meets Performance',
                    'description' => 'Main headline text displayed in the hero section',
                    'visible_when' => 'landing',
                    'section' => 'Hero Section',
                ],
                [
                    'name' => 'landing_hero_description',
                    'label' => 'Hero Description',
                    'type' => 'textarea',
                    'default' => 'Where speed meets stability and innovation meets reliability. Citadel gives you the tools, uptime, and performance to power your ideas without limits.',
                    'description' => 'Description text displayed below the hero title',
                    'visible_when' => 'landing',
                    'section' => 'Hero Section',
                ],
                [
                    'name' => 'landing_hero_button1_text',
                    'label' => 'Hero Button 1 Text',
                    'type' => 'text',
                    'default' => 'Get Started',
                    'description' => 'Text for the primary button in the hero section',
                    'visible_when' => 'landing',
                    'section' => 'Hero Section',
                ],
                [
                    'name' => 'landing_hero_button1_link',
                    'label' => 'Hero Button 1 Link',
                    'type' => 'text',
                    'default' => '/products',
                    'description' => 'URL for the primary button',
                    'visible_when' => 'landing',
                    'section' => 'Hero Section',
                ],
                [
                    'name' => 'landing_hero_button2_text',
                    'label' => 'Hero Button 2 Text',
                    'type' => 'text',
                    'default' => 'View All Plans',
                    'description' => 'Text for the secondary button in the hero section',
                    'visible_when' => 'landing',
                    'section' => 'Hero Section',
                ],
                [
                    'name' => 'landing_hero_button2_link',
                    'label' => 'Hero Button 2 Link',
                    'type' => 'text',
                    'default' => '/products',
                    'description' => 'URL for the secondary button',
                    'visible_when' => 'landing',
                    'section' => 'Hero Section',
                ],

                [
                    'name' => 'landing_services_title',
                    'label' => 'Services Section Title',
                    'type' => 'text',
                    'default' => 'Check Our Services',
                    'description' => 'Title text for the services/plans section',
                    'visible_when' => 'landing',
                    'section' => 'Services Section',
                ],
                [
                    'name' => 'landing_services_description',
                    'label' => 'Services Section Description',
                    'type' => 'textarea',
                    'default' => 'Discover the perfect plan tailored to your needs',
                    'description' => 'Description text displayed below the services section title',
                    'visible_when' => 'landing',
                    'section' => 'Services Section',
                ],

                [
                    'name' => 'landing_features_title',
                    'label' => 'Features Section Title',
                    'type' => 'text',
                    'default' => 'Our Features',
                    'description' => 'Title text for the features section',
                    'visible_when' => 'landing',
                    'section' => 'Features Section',
                ],
                [
                    'name' => 'landing_features_description',
                    'label' => 'Features Section Description',
                    'type' => 'textarea',
                    'default' => 'Powerful hosting features designed for your success',
                    'description' => 'Description text displayed below the features section title',
                    'visible_when' => 'landing',
                    'section' => 'Features Section',
                ],

                [
                    'name' => 'landing_feature1_icon',
                    'label' => 'Feature 1 Icon',
                    'type' => 'text',
                    'default' => 'server-fill',
                    'description' => 'Remix Icon name (e.g., "server-fill"). Browse at https://remixicon.com',
                    'visible_when' => 'landing',
                    'section' => 'Feature Cards',
                ],
                [
                    'name' => 'landing_feature1_title',
                    'label' => 'Feature 1 Title',
                    'type' => 'text',
                    'default' => '99.9% Uptime Guarantee',
                    'visible_when' => 'landing',
                    'section' => 'Feature Cards',
                ],
                [
                    'name' => 'landing_feature1_description',
                    'label' => 'Feature 1 Description',
                    'type' => 'textarea',
                    'default' => 'Your servers stay online with our reliable infrastructure and redundant systems ensuring maximum availability.',
                    'visible_when' => 'landing',
                    'section' => 'Feature Cards',
                ],

                [
                    'name' => 'landing_feature2_icon',
                    'label' => 'Feature 2 Icon',
                    'type' => 'text',
                    'default' => 'rocket-fill',
                    'description' => 'Remix Icon name (e.g., "rocket-fill"). Browse at https://remixicon.com',
                    'visible_when' => 'landing',
                    'section' => 'Feature Cards',
                ],
                [
                    'name' => 'landing_feature2_title',
                    'label' => 'Feature 2 Title',
                    'type' => 'text',
                    'default' => 'Instant Deployment',
                    'visible_when' => 'landing',
                    'section' => 'Feature Cards',
                ],
                [
                    'name' => 'landing_feature2_description',
                    'label' => 'Feature 2 Description',
                    'type' => 'textarea',
                    'default' => 'Get your server up and running in seconds with our automated setup process and one-click installations.',
                    'visible_when' => 'landing',
                    'section' => 'Feature Cards',
                ],


                [
                    'name' => 'landing_feature3_icon',
                    'label' => 'Feature 3 Icon',
                    'type' => 'text',
                    'default' => 'flashlight-fill',
                    'description' => 'Remix Icon name (e.g., "flashlight-fill"). Browse at https://remixicon.com',
                    'visible_when' => 'landing',
                    'section' => 'Feature Cards',
                ],
                [
                    'name' => 'landing_feature3_title',
                    'label' => 'Feature 3 Title',
                    'type' => 'text',
                    'default' => 'Lightning Fast Performance',
                    'visible_when' => 'landing',
                    'section' => 'Feature Cards',
                ],
                [
                    'name' => 'landing_feature3_description',
                    'label' => 'Feature 3 Description',
                    'type' => 'textarea',
                    'default' => 'Experience blazing-fast speeds with NVMe SSD storage and optimized server configurations.',
                    'visible_when' => 'landing',
                    'section' => 'Feature Cards',
                ],

                [
                    'name' => 'landing_feature4_icon',
                    'label' => 'Feature 4 Icon',
                    'type' => 'text',
                    'default' => 'cpu-fill',
                    'description' => 'Remix Icon name (e.g., "cpu-fill"). Browse at https://remixicon.com',
                    'visible_when' => 'landing',
                    'section' => 'Feature Cards',
                ],
                [
                    'name' => 'landing_feature4_title',
                    'label' => 'Feature 4 Title',
                    'type' => 'text',
                    'default' => 'Premium Hardware',
                    'visible_when' => 'landing',
                    'section' => 'Feature Cards',
                ],
                [
                    'name' => 'landing_feature4_description',
                    'label' => 'Feature 4 Description',
                    'type' => 'textarea',
                    'default' => 'Powered by enterprise-grade hardware with latest generation processors and unlimited bandwidth.',
                    'visible_when' => 'landing',
                    'section' => 'Feature Cards',
                ],

                [
                    'name' => 'landing_feature5_icon',
                    'label' => 'Feature 5 Icon',
                    'type' => 'text',
                    'default' => 'customer-service-2-fill',
                    'description' => 'Remix Icon name. Browse at https://remixicon.com',
                    'visible_when' => 'landing',
                    'section' => 'Feature Cards',
                ],
                [
                    'name' => 'landing_feature5_title',
                    'label' => 'Feature 5 Title',
                    'type' => 'text',
                    'default' => '24/7 Expert Support',
                    'visible_when' => 'landing',
                    'section' => 'Feature Cards',
                ],
                [
                    'name' => 'landing_feature5_description',
                    'label' => 'Feature 5 Description',
                    'type' => 'textarea',
                    'default' => 'Our dedicated support team is available round the clock to assist you with any questions or issues.',
                    'visible_when' => 'landing',
                    'section' => 'Feature Cards',
                ],

                [
                    'name' => 'landing_feature6_icon',
                    'label' => 'Feature 6 Icon',
                    'type' => 'text',
                    'default' => 'dashboard-fill',
                    'description' => 'Remix Icon name. Browse at https://remixicon.com',
                    'visible_when' => 'landing',
                    'section' => 'Feature Cards',
                ],
                [
                    'name' => 'landing_feature6_title',
                    'label' => 'Feature 6 Title',
                    'type' => 'text',
                    'default' => 'Easy to Use Control Panel',
                    'visible_when' => 'landing',
                    'section' => 'Feature Cards',
                ],
                [
                    'name' => 'landing_feature6_description',
                    'label' => 'Feature 6 Description',
                    'type' => 'textarea',
                    'default' => 'Manage your servers effortlessly with our intuitive control panel designed for simplicity and power.',
                    'visible_when' => 'landing',
                    'section' => 'Feature Cards',
                ],

                [
                    'name' => 'landing_show_cta',
                    'label' => 'Show CTA Section',
                    'type' => 'checkbox',
                    'default' => true,
                    'database_type' => 'boolean',
                    'description' => 'Show or hide the call-to-action section on the landing page',
                    'visible_when' => 'landing',
                    'section' => 'Call to Action',
                ],
                [
                    'name' => 'landing_cta_title',
                    'label' => 'CTA Title',
                    'type' => 'text',
                    'default' => 'Ready to get started?',
                    'description' => 'Call-to-action title displayed in the CTA banner section',
                    'visible_when' => 'landing',
                    'section' => 'Call to Action',
                ],
                [
                    'name' => 'landing_cta_description',
                    'label' => 'CTA Description',
                    'type' => 'textarea',
                    'default' => 'Contact us to get help getting started or if you don\'t see what you are looking for.',
                    'description' => 'Description text displayed below the CTA title',
                    'visible_when' => 'landing',
                    'section' => 'Call to Action',
                ],
                [
                    'name' => 'landing_cta_btn_text',
                    'label' => 'CTA Button Text',
                    'type' => 'text',
                    'default' => 'Get In Touch',
                    'description' => 'Text displayed on the CTA button',
                    'visible_when' => 'landing',
                    'section' => 'Call to Action',
                ],
                [
                    'name' => 'landing_cta_btn_link',
                    'label' => 'CTA Button Link',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'URL for the CTA button. Leave empty to use the contact link, or the register page if no contact link is set.',
                    'visible_when' => 'landing',
                    'section' => 'Call to Action',
                ],
            ],
            'plans' => [
                [
                    'name' => 'pricing_card_icon_style',
                    'label' => 'Pricing Cards Icon Style',
                    'type' => 'image_radio',
                    'options' => [
                        'background' => 'Background',
                        'icon_right' => 'Icon at Right',
                        'icon_top_left' => 'Icon at Top Left',
                        'icon_top' => 'Icon at Top',
                    ],
                    'images' => [
                        'background' => 'assets/admin/plans/icon-background.webp',
                        'icon_right' => 'assets/admin/plans/icon-right.gif',
                        'icon_top_left' => 'assets/admin/plans/icon-left.png',
                        'icon_top' => 'assets/admin/plans/icon-right.png',
                    ],
                    'default' => 'icon_top',
                    'description' => 'Choose how product images/icons are displayed in pricing cards',
                ],
                [
                    'name' => 'override_category_icons',
                    'label' => 'Override Category Icons',
                    'type' => 'checkbox',
                    'default' => false,
                    'database_type' => 'boolean',
                    'description' => 'Enable to override category icons with custom Citadel icons for use in marketing plans sections',
                    'live' => true,
                    'section' => 'Category Icons',
                ],
                [
                    'name' => 'category_icons_data',
                    'label' => 'Category Icon Overrides',
                    'type' => 'repeater',
                    'default' => '[]',
                    'section' => 'Category Icons',
                ],
                [
                    'name' => 'payment_method_style',
                    'label' => 'Payment Method Style',
                    'type' => 'image_radio',
                    'options' => [
                        'dropdown' => 'Dropdown',
                        'cards' => 'Cards (4 per row)',
                        'select' => 'Vertical Select Cards',
                    ],
                    'images' => [
                        'dropdown' => 'assets/admin/cart/gateway/dropdown.webp',
                        'cards' => 'assets/admin/cart/gateway/horizontal.webp',
                        'select' => 'assets/admin/cart/gateway/verticle.webp',
                    ],
                    'columns' => 1,
                    'default' => 'dropdown',
                    'description' => 'Choose how payment methods are displayed in the cart/checkout page',
                    'live' => true,
                ],
                [
                    'name' => 'gateway_card_display',
                    'label' => 'Gateway Card Display Style',
                    'type' => 'image_radio',
                    'options' => [
                        'logo_and_name' => 'Logo and Name',
                        'logo_only' => 'Logo Only',
                        'cover' => 'Cover (Logo as Background)',
                    ],
                    'images' => [
                        'logo_and_name' => 'assets/admin/cart/4cards/logo-name.webp',
                        'logo_only' => 'assets/admin/cart/4cards/logo.webp',
                        'cover' => 'assets/admin/cart/4cards/background.webp',
                    ],
                    'columns' => 1,
                    'default' => 'logo_and_name',
                    'description' => 'Choose how gateway logos and names are displayed in card layouts',
                    'visible_when_field' => 'payment_method_style',
                    'visible_when_value' => 'cards',
                ],
                [
                    'name' => 'show_lowest_term_price',
                    'label' => 'Show Lowest Term Price',
                    'type' => 'checkbox',
                    'default' => false,
                    'database_type' => 'boolean',
                    'description' => 'On plan cards (category pages, home page and custom pages), show the lowest effective price by dividing every billing term down to its per-base-term rate (e.g. a yearly price shown per month) and displaying the cheapest. Best used with the sale badges off.',
                    'section' => 'Lowest Price Display',
                ],
            ],
            'dashboard' => [
                [
                    'name' => 'enable_dashboard_banner',
                    'label' => 'Enable Banner',
                    'type' => 'checkbox',
                    'default' => false,
                    'database_type' => 'boolean',
                    'description' => 'Show a banner section at the top of the dashboard',
                    'live' => true,
                    'section' => 'Dashboard Banner',
                ],
                [
                    'name' => 'dashboard_banner',
                    'label' => 'Banner Type',
                    'type' => 'select',
                    'options' => [
                        'welcome_with_image' => 'Banner',
                        'custom_html' => 'Custom HTML',
                    ],
                    'default' => 'welcome_with_image',
                    'description' => 'Choose what to display in the dashboard banner area',
                    'live' => true,
                    'visible_when_field' => 'enable_dashboard_banner',
                    'visible_when_value' => true,
                    'section' => 'Dashboard Banner',
                ],
                [
                    'name' => 'dashboard_banner_title',
                    'label' => 'Dashboard Banner Title',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'Main title text for the banner',
                    'visible_when_field' => 'enable_dashboard_banner',
                    'visible_when_value' => true,
                    'visible_when_field_2' => 'dashboard_banner',
                    'visible_when_value_2' => 'welcome_with_image',
                    'section' => 'Dashboard Banner',
                ],
                [
                    'name' => 'dashboard_banner_description',
                    'label' => 'Dashboard Banner Description',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'Description text for the banner',
                    'visible_when_field' => 'enable_dashboard_banner',
                    'visible_when_value' => true,
                    'visible_when_field_2' => 'dashboard_banner',
                    'visible_when_value_2' => 'welcome_with_image',
                    'section' => 'Dashboard Banner',
                ],
                [
                    'name' => 'dashboard_banner_button_text',
                    'label' => 'Dashboard Banner Button Text',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'Button text for the banner',
                    'visible_when_field' => 'enable_dashboard_banner',
                    'visible_when_value' => true,
                    'visible_when_field_2' => 'dashboard_banner',
                    'visible_when_value_2' => 'welcome_with_image',
                    'section' => 'Dashboard Banner',
                ],
                [
                    'name' => 'dashboard_banner_button_link',
                    'label' => 'Dashboard Banner Button Link',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'Button link/URL for the banner. Use "/" for home page or any valid route.',
                    'visible_when_field' => 'enable_dashboard_banner',
                    'visible_when_value' => true,
                    'visible_when_field_2' => 'dashboard_banner',
                    'visible_when_value_2' => 'welcome_with_image',
                    'section' => 'Dashboard Banner',
                ],
                [
                    'name' => 'dashboard_banner_image_url',
                    'label' => 'Banner Background Image',
                    'type' => 'file',
                    'default' => '',
                    'description' => 'Upload a background image for the banner (optional)',
                    'visible_when_field' => 'enable_dashboard_banner',
                    'visible_when_value' => true,
                    'visible_when_field_2' => 'dashboard_banner',
                    'visible_when_value_2' => 'welcome_with_image',
                    'section' => 'Dashboard Banner',
                ],
                [
                    'name' => 'dashboard_banner_overlay',
                    'label' => 'Overlay Style',
                    'type' => 'image_radio',
                    'options' => [
                        'primary' => 'Primary Color',
                        'dark' => 'Dark Overlay',
                    ],
                    'images' => [
                        'primary' => 'assets/admin/dashsbord/primerrycolor.webp',
                        'dark' => 'assets/admin/dashsbord/darkoverlay.webp',
                    ],
                    'columns' => 1,
                    'default' => 'primary',
                    'description' => 'Choose the overlay style for the banner background image',
                    'visible_when_field' => 'enable_dashboard_banner',
                    'visible_when_value' => true,
                    'visible_when_field_2' => 'dashboard_banner',
                    'visible_when_value_2' => 'welcome_with_image',
                    'section' => 'Dashboard Banner',
                ],
                [
                    'name' => 'dashboard_banner_button_position',
                    'label' => 'Button Position',
                    'type' => 'image_radio',
                    'options' => [
                        'bottom' => 'Below Text',
                        'right' => 'Right Side',
                    ],
                    'images' => [
                        'bottom' => 'assets/admin/dashsbord/buttonbottom.webp',
                        'right' => 'assets/admin/dashsbord/buttonright.webp',
                    ],
                    'columns' => 1,
                    'default' => 'bottom',
                    'description' => 'Position the button below the text or on the right side',
                    'visible_when_field' => 'enable_dashboard_banner',
                    'visible_when_value' => true,
                    'visible_when_field_2' => 'dashboard_banner',
                    'visible_when_value_2' => 'welcome_with_image',
                    'section' => 'Dashboard Banner',
                ],
                [
                    'name' => 'dashboard_banner_dismissible',
                    'label' => 'Dismissible',
                    'type' => 'checkbox',
                    'default' => false,
                    'database_type' => 'boolean',
                    'description' => 'Allow users to dismiss the banner with a close button',
                    'visible_when_field' => 'enable_dashboard_banner',
                    'visible_when_value' => true,
                    'visible_when_field_2' => 'dashboard_banner',
                    'visible_when_value_2' => 'welcome_with_image',
                    'section' => 'Dashboard Banner',
                ],
                [
                    'name' => 'dashboard_banner_custom_html',
                    'label' => 'Dashboard Banner Custom HTML',
                    'type' => 'textarea',
                    'default' => '',
                    'description' => 'Enter custom HTML content for the banner',
                    'visible_when_field' => 'enable_dashboard_banner',
                    'visible_when_value' => true,
                    'visible_when_field_2' => 'dashboard_banner',
                    'visible_when_value_2' => 'custom_html',
                    'section' => 'Dashboard Banner',
                ],

                [
                    'name' => 'enable_profile_card',
                    'label' => 'Enable Profile Card',
                    'type' => 'checkbox',
                    'default' => true,
                    'database_type' => 'boolean',
                    'description' => 'Show the profile card on the dashboard sidebar',
                    'live' => true,
                    'section' => 'Profile Card',
                ],
                [
                    'name' => 'profile_card_background',
                    'label' => 'Background',
                    'type' => 'image_radio',
                    'options' => [
                        'overlay' => 'Overlay (Subtle gradient)',
                        'solid' => 'Solid Color (Primary)',
                        'gradient' => 'Custom Gradient',
                    ],
                    'images' => [
                        'overlay' => 'assets/admin/dashsbord/overlay.webp',
                        'solid' => 'assets/admin/dashsbord/soldicolor.webp',
                        'gradient' => 'assets/admin/dashsbord/customgradient.webp',
                    ],
                    'columns' => 2,
                    'default' => 'overlay',
                    'description' => 'Choose the background style for the profile card',
                    'live' => true,
                    'visible_when_field' => 'enable_profile_card',
                    'visible_when_value' => true,
                    'section' => 'Profile Card',
                ],
                [
                    'name' => 'profile_card_gradient_angle',
                    'label' => 'Gradient Angle',
                    'type' => 'select',
                    'options' => [
                        '30' => '30°',
                        '45' => '45°',
                        '90' => '90° (Top to Bottom)',
                        '135' => '135°',
                        '180' => '180° (Left to Right)',
                        '-225' => '-225°',
                        '270' => '270°',
                    ],
                    'default' => '30',
                    'description' => 'Angle of the gradient',
                    'visible_when_field' => 'enable_profile_card',
                    'visible_when_value' => true,
                    'visible_when_field_2' => 'profile_card_background',
                    'visible_when_value_2' => 'gradient',
                    'section' => 'Profile Card',
                ],
                [
                    'name' => 'profile_card_gradient_color_1',
                    'label' => 'Gradient Color 1 (Start)',
                    'type' => 'color',
                    'default' => 'hsl(249, 100%, 62%)',
                    'description' => 'Starting color of the gradient',
                    'visible_when_field' => 'enable_profile_card',
                    'visible_when_value' => true,
                    'visible_when_field_2' => 'profile_card_background',
                    'visible_when_value_2' => 'gradient',
                    'section' => 'Profile Card',
                ],
                [
                    'name' => 'profile_card_gradient_color_2',
                    'label' => 'Gradient Color 2',
                    'type' => 'color',
                    'default' => 'hsl(225, 100%, 72%)',
                    'description' => 'Second color of the gradient (33%)',
                    'visible_when_field' => 'enable_profile_card',
                    'visible_when_value' => true,
                    'visible_when_field_2' => 'profile_card_background',
                    'visible_when_value_2' => 'gradient',
                    'section' => 'Profile Card',
                ],
                [
                    'name' => 'profile_card_gradient_color_3',
                    'label' => 'Gradient Color 3',
                    'type' => 'color',
                    'default' => 'hsl(195, 100%, 72%)',
                    'description' => 'Third color of the gradient (66%)',
                    'visible_when_field' => 'enable_profile_card',
                    'visible_when_value' => true,
                    'visible_when_field_2' => 'profile_card_background',
                    'visible_when_value_2' => 'gradient',
                    'section' => 'Profile Card',
                ],
                [
                    'name' => 'profile_card_gradient_color_4',
                    'label' => 'Gradient Color 4 (End)',
                    'type' => 'color',
                    'default' => 'hsl(255, 100%, 62%)',
                    'description' => 'Ending color of the gradient',
                    'visible_when_field' => 'enable_profile_card',
                    'visible_when_value' => true,
                    'visible_when_field_2' => 'profile_card_background',
                    'visible_when_value_2' => 'gradient',
                    'section' => 'Profile Card',
                ],
                [
                    'name' => 'profile_card_text_color',
                    'label' => 'Text Color',
                    'type' => 'select',
                    'options' => [
                        'dark' => 'Dark',
                        'light' => 'Light',
                    ],
                    'default' => 'dark',
                    'description' => 'Choose the text color on the profile card',
                    'visible_when_field' => 'enable_profile_card',
                    'visible_when_value' => true,
                    'section' => 'Profile Card',
                ],

                [
                    'name' => 'profile_card_hide_picture',
                    'label' => 'Hide Profile Picture',
                    'type' => 'checkbox',
                    'default' => false,
                    'database_type' => 'boolean',
                    'description' => 'Hide the user avatar from the profile card',
                    'visible_when_field' => 'enable_profile_card',
                    'visible_when_value' => true,
                    'section' => 'Profile Card Details',
                ],
                [
                    'name' => 'profile_card_hide_details',
                    'label' => 'Hide User Details',
                    'type' => 'checkbox',
                    'default' => false,
                    'database_type' => 'boolean',
                    'description' => 'Hide the user name and email from the profile card',
                    'visible_when_field' => 'enable_profile_card',
                    'visible_when_value' => true,
                    'section' => 'Profile Card Details',
                ],
                [
                    'name' => 'profile_card_hide_address',
                    'label' => 'Hide Address',
                    'type' => 'checkbox',
                    'default' => false,
                    'database_type' => 'boolean',
                    'description' => 'Hide the address section from the profile card',
                    'visible_when_field' => 'enable_profile_card',
                    'visible_when_value' => true,
                    'section' => 'Profile Card Details',
                ],
                [
                    'name' => 'profile_card_hide_balance',
                    'label' => 'Hide Account Balance',
                    'type' => 'checkbox',
                    'default' => false,
                    'database_type' => 'boolean',
                    'description' => 'Hide the account balance section from the profile card',
                    'visible_when_field' => 'enable_profile_card',
                    'visible_when_value' => true,
                    'section' => 'Profile Card Details',
                ],

                [
                    'name' => 'enable_secondary_card',
                    'label' => 'Enable Secondary Card',
                    'type' => 'checkbox',
                    'default' => true,
                    'database_type' => 'boolean',
                    'description' => 'Show secondary cards below the profile card on the dashboard sidebar',
                    'live' => true,
                    'section' => 'Secondary Card',
                ],
                [
                    'name' => 'enable_secondary_multiple',
                    'label' => 'Enable Multiple Cards',
                    'type' => 'checkbox',
                    'default' => false,
                    'database_type' => 'boolean',
                    'description' => 'Allow adding multiple secondary cards below the profile card',
                    'live' => true,
                    'section' => 'Secondary Card',
                ],
                [
                    'name' => 'secondary_card_type',
                    'label' => 'Secondary Card',
                    'type' => 'select',
                    'options' => [
                        'discord' => 'Discord Invite',
                        'custom_html' => 'Custom HTML',
                        'custom_card' => 'Custom Card',
                    ],
                    'default' => 'discord',
                    'description' => 'Choose what to display below the profile card',
                    'live' => true,
                    'visible_when_field' => 'enable_secondary_multiple',
                    'visible_when_value' => false,
                    'section' => 'Secondary Card',
                ],
                [
                    'name' => 'discord_card_design',
                    'label' => 'Discord Card Style',
                    'type' => 'image_radio',
                    'options' => [
                        'classic' => 'Classic (Purple card with icon)',
                        'button' => 'Button (Compact button style)',
                        'glass' => 'Elegant (Bordered card with icon)',
                        'banner' => 'Banner (Decorative SVG banner)',
                        'card' => 'Support Card (Card layout with button)',
                    ],
                    'images' => [
                        'classic' => 'assets/admin/dashsbord/classic.webp',
                        'button' => 'assets/admin/dashsbord/button.webp',
                        'glass' => 'assets/admin/dashsbord/elegant.webp',
                        'banner' => 'assets/admin/dashsbord/banner.webp',
                        'card' => 'assets/admin/dashsbord/classic.webp',
                    ],
                    'columns' => 2,
                    'default' => 'classic',
                    'description' => 'Choose the visual style for the Discord invite card',
                    'visible_when_field' => 'secondary_card_type',
                    'visible_when_value' => 'discord',
                    'visible_when_field_2' => 'enable_secondary_multiple',
                    'visible_when_value_2' => false,
                    'section' => 'Secondary Card',
                ],
                [
                    'name' => 'discord_card_tagline',
                    'label' => 'Support Card - Tagline',
                    'type' => 'text',
                    'default' => 'Join 3,000+ members',
                    'description' => 'Small tagline shown above the title (e.g. "Join 3,000+ members")',
                    'visible_when_field' => 'discord_card_design',
                    'visible_when_value' => 'card',
                    'visible_when_field_2' => 'enable_secondary_multiple',
                    'visible_when_value_2' => false,
                    'section' => 'Secondary Card',
                ],
                [
                    'name' => 'discord_card_title_custom',
                    'label' => 'Support Card - Title',
                    'type' => 'text',
                    'default' => 'Get Support on Discord',
                    'visible_when_field' => 'discord_card_design',
                    'visible_when_value' => 'card',
                    'visible_when_field_2' => 'enable_secondary_multiple',
                    'visible_when_value_2' => false,
                    'section' => 'Secondary Card',
                ],
                [
                    'name' => 'discord_card_desc_custom',
                    'label' => 'Support Card - Description',
                    'type' => 'textarea',
                    'default' => 'Join our community for quick help, updates, and more.',
                    'visible_when_field' => 'discord_card_design',
                    'visible_when_value' => 'card',
                    'visible_when_field_2' => 'enable_secondary_multiple',
                    'visible_when_value_2' => false,
                    'section' => 'Secondary Card',
                ],
                [
                    'name' => 'discord_card_btn_text',
                    'label' => 'Support Card - Button Text',
                    'type' => 'text',
                    'default' => 'Join Our Discord',
                    'visible_when_field' => 'discord_card_design',
                    'visible_when_value' => 'card',
                    'visible_when_field_2' => 'enable_secondary_multiple',
                    'visible_when_value_2' => false,
                    'section' => 'Secondary Card',
                ],
                [
                    'name' => 'secondary_card_custom_html',
                    'label' => 'Custom HTML',
                    'type' => 'textarea',
                    'default' => '',
                    'description' => 'Enter custom HTML content for the secondary card',
                    'visible_when_field' => 'secondary_card_type',
                    'visible_when_value' => 'custom_html',
                    'visible_when_field_2' => 'enable_secondary_multiple',
                    'visible_when_value_2' => false,
                    'section' => 'Secondary Card',
                ],
                [
                    'name' => 'secondary_card_design',
                    'label' => 'Card Design',
                    'type' => 'image_radio',
                    'options' => [
                        'top_border' => 'Top Border',
                        'image_bg' => 'Image Background',
                        'icon_card' => 'Icon Card',
                    ],
                    'images' => [
                        'top_border' => 'assets/admin/dashsbord/topborder.webp',
                        'image_bg' => 'assets/admin/dashsbord/imagebackground.webp',
                        'icon_card' => 'assets/admin/dashsbord/icon.gif',
                    ],
                    'columns' => 2,
                    'default' => 'top_border',
                    'description' => 'Choose the visual design for the custom card',
                    'visible_when_field' => 'secondary_card_type',
                    'visible_when_value' => 'custom_card',
                    'visible_when_field_2' => 'enable_secondary_multiple',
                    'visible_when_value_2' => false,
                    'section' => 'Secondary Card',
                ],
                [
                    'name' => 'secondary_card_title',
                    'label' => 'Card Title',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'Title text for the card',
                    'visible_when_field' => 'secondary_card_type',
                    'visible_when_value' => 'custom_card',
                    'visible_when_field_2' => 'enable_secondary_multiple',
                    'visible_when_value_2' => false,
                    'section' => 'Secondary Card',
                ],
                [
                    'name' => 'secondary_card_description',
                    'label' => 'Card Description',
                    'type' => 'textarea',
                    'default' => '',
                    'description' => 'Description text for the card',
                    'visible_when_field' => 'secondary_card_type',
                    'visible_when_value' => 'custom_card',
                    'visible_when_field_2' => 'enable_secondary_multiple',
                    'visible_when_value_2' => false,
                    'section' => 'Secondary Card',
                ],
                [
                    'name' => 'secondary_card_button_text',
                    'label' => 'Button Text',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'Text for the card link/button',
                    'visible_when_field' => 'secondary_card_type',
                    'visible_when_value' => 'custom_card',
                    'visible_when_field_2' => 'enable_secondary_multiple',
                    'visible_when_value_2' => false,
                    'section' => 'Secondary Card',
                ],
                [
                    'name' => 'secondary_card_button_link',
                    'label' => 'Button Link',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'URL for the card link/button',
                    'visible_when_field' => 'secondary_card_type',
                    'visible_when_value' => 'custom_card',
                    'visible_when_field_2' => 'enable_secondary_multiple',
                    'visible_when_value_2' => false,
                    'section' => 'Secondary Card',
                ],
                [
                    'name' => 'secondary_card_image',
                    'label' => 'Image / Icon',
                    'type' => 'file',
                    'default' => '',
                    'description' => 'Upload an image to use as background or icon depending on the card design',
                    'visible_when_field' => 'secondary_card_type',
                    'visible_when_value' => 'custom_card',
                    'visible_when_field_2' => 'enable_secondary_multiple',
                    'visible_when_value_2' => false,
                    'section' => 'Secondary Card',
                ],
                [
                    'name' => 'secondary_cards_data',
                    'label' => 'Secondary Cards',
                    'type' => 'repeater',
                    'default' => '[]',
                    'database_type' => 'string',
                    'description' => 'Add multiple secondary cards below the profile card',
                    'visible_when_field' => 'enable_secondary_multiple',
                    'visible_when_value' => true,
                    'section' => 'Secondary Card',
                ],

                [
                    'name' => 'dashboard_stat_card_icons',
                    'label' => 'Show Icons on Stat Cards',
                    'type' => 'checkbox',
                    'default' => false,
                    'database_type' => 'boolean',
                    'description' => 'Display a decorative background icon on each of the three stat cards.',
                    'section' => 'Stat Cards',
                ],

                [
                    'name' => 'dashboard_widget_layout',
                    'label' => 'Widget Layout',
                    'type' => 'select',
                    'default' => 'full',
                    'database_type' => 'string',
                    'description' => 'Full Width: each widget takes its own row. Compact: Invoices and Tickets sit side-by-side in one row on desktop.',
                    'options' => [
                        'full'    => 'Full Width Layout',
                        'compact' => 'Compact Layout',
                    ],
                    'section' => 'Dashboard Widgets',
                ],
                [
                    'name' => 'hide_invoices_widget',
                    'label' => 'Remove Invoices',
                    'type' => 'checkbox',
                    'default' => false,
                    'database_type' => 'boolean',
                    'description' => 'Hide the invoices stat card and widget from the dashboard',
                    'section' => 'Dashboard Widgets',
                    'visible_when_field' => 'dashboard_widget_layout',
                    'visible_when_value' => 'full',
                ],
                [
                    'name' => 'hide_tickets_widget',
                    'label' => 'Remove Tickets',
                    'type' => 'checkbox',
                    'default' => false,
                    'database_type' => 'boolean',
                    'description' => 'Hide the tickets stat card and widget from the dashboard',
                    'section' => 'Dashboard Widgets',
                    'visible_when_field' => 'dashboard_widget_layout',
                    'visible_when_value' => 'full',
                ],
            ],
            'announcement' => [
                [
                    'name' => 'announcement_banner_enabled',
                    'label' => 'Banner notification',
                    'type' => 'checkbox',
                    'default' => false,
                    'database_type' => 'boolean',
                    'description' => 'Show a notification banner at the top of every page',
                    'live' => true,
                    'section' => 'Banner Notification',
                ],
                [
                    'name' => 'announcement_banner_text',
                    'label' => 'Banner Text',
                    'type' => 'textarea',
                    'default' => '',
                    'description' => 'Supports Markdown formatting (bold, italic, links, etc). Use <copy>text</copy> tags to make text copyable on click.',
                    'visible_when_field' => 'announcement_banner_enabled',
                    'visible_when_value' => true,
                    'section' => 'Banner Notification',
                ],
                [
                    'name' => 'announcement_banner_icon',
                    'label' => 'Banner Icon',
                    'type' => 'text',
                    'default' => 'megaphone-fill',
                    'description' => 'Remix Icon name for the banner. Browse icons at https://remixicon.com (e.g., "megaphone-fill", "information-fill", "gift-fill")',
                    'visible_when_field' => 'announcement_banner_enabled',
                    'visible_when_value' => true,
                    'section' => 'Banner Notification',
                ],
                [
                    'name' => 'announcement_banner_bg_type',
                    'label' => 'Background Type',
                    'type' => 'select',
                    'options' => [
                        'solid' => 'Solid Color',
                        'gradient' => 'Gradient',
                        'primary_solid' => 'Primary Color',
                        'primary_gradient' => 'Primary Color Gradient',
                    ],
                    'default' => 'solid',
                    'description' => 'Choose between a solid color, gradient, or the site\'s primary color',
                    'visible_when_field' => 'announcement_banner_enabled',
                    'visible_when_value' => true,
                    'live' => true,
                    'section' => 'Banner Notification',
                ],
                [
                    'name' => 'announcement_banner_bg_color',
                    'label' => 'Background Color',
                    'type' => 'color',
                    'default' => 'hsl(229, 100%, 64%)',
                    'description' => 'Background color for the banner',
                    'visible_when_field' => 'announcement_banner_enabled',
                    'visible_when_value' => true,
                    'visible_when_field_2' => 'announcement_banner_bg_type',
                    'visible_when_value_2' => 'solid',
                    'section' => 'Banner Notification',
                ],
                [
                    'name' => 'announcement_banner_gradient_start',
                    'label' => 'Gradient Start Color',
                    'type' => 'color',
                    'default' => 'hsl(229, 100%, 64%)',
                    'description' => 'Starting color of the gradient (left side)',
                    'visible_when_field' => 'announcement_banner_enabled',
                    'visible_when_value' => true,
                    'visible_when_field_2' => 'announcement_banner_bg_type',
                    'visible_when_value_2' => 'gradient',
                    'section' => 'Banner Notification',
                ],
                [
                    'name' => 'announcement_banner_gradient_mid',
                    'label' => 'Gradient Middle Color',
                    'type' => 'color',
                    'default' => 'hsl(270, 100%, 64%)',
                    'description' => 'Middle color of the gradient (optional, leave empty to skip)',
                    'visible_when_field' => 'announcement_banner_enabled',
                    'visible_when_value' => true,
                    'visible_when_field_2' => 'announcement_banner_bg_type',
                    'visible_when_value_2' => 'gradient',
                    'section' => 'Banner Notification',
                ],
                [
                    'name' => 'announcement_banner_gradient_end',
                    'label' => 'Gradient End Color',
                    'type' => 'color',
                    'default' => 'hsl(320, 100%, 64%)',
                    'description' => 'Ending color of the gradient (right side)',
                    'visible_when_field' => 'announcement_banner_enabled',
                    'visible_when_value' => true,
                    'visible_when_field_2' => 'announcement_banner_bg_type',
                    'visible_when_value_2' => 'gradient',
                    'section' => 'Banner Notification',
                ],
                [
                    'name' => 'announcement_banner_gradient_angle',
                    'label' => 'Gradient Angle',
                    'type' => 'select',
                    'options' => [
                        '90deg' => 'Left to Right',
                        '180deg' => 'Top to Bottom',
                        '270deg' => 'Right to Left',
                        '0deg' => 'Bottom to Top',
                        '135deg' => 'Diagonal Down',
                        '45deg' => 'Diagonal Up',
                    ],
                    'default' => '90deg',
                    'description' => 'Direction of the gradient',
                    'visible_when_field' => 'announcement_banner_enabled',
                    'visible_when_value' => true,
                    'visible_when_field_2' => 'announcement_banner_bg_type',
                    'visible_when_value_2' => 'gradient',
                    'section' => 'Banner Notification',
                ],
                [
                    'name' => 'announcement_banner_dismissible',
                    'label' => 'Allow Dismissing Banner',
                    'type' => 'checkbox',
                    'default' => true,
                    'database_type' => 'boolean',
                    'description' => 'Allow users to dismiss/close the banner (remembers choice until next visit)',
                    'visible_when_field' => 'announcement_banner_enabled',
                    'visible_when_value' => true,
                    'section' => 'Banner Notification',
                ],
                [
                    'name' => 'announcement_banner_alignment',
                    'label' => 'Banner Text Alignment',
                    'type' => 'select',
                    'options' => [
                        'center' => 'Center',
                        'left' => 'Left',
                    ],
                    'default' => 'center',
                    'description' => 'Align the banner text to the left or center',
                    'visible_when_field' => 'announcement_banner_enabled',
                    'visible_when_value' => true,
                    'section' => 'Banner Notification',
                ],
                [
                    'name' => 'dashboard_alerts_data',
                    'label' => 'Dashboard Alerts',
                    'type' => 'repeater',
                    'default' => '[]',
                    'database_type' => 'string',
                    'description' => 'Add alert notifications that appear above the dashboard banner',
                    'section' => 'Dashboard Alerts',
                ],
                [
                    'name' => 'unpaid_invoice_notice',
                    'label' => 'Unpaid Invoice Notice',
                    'type' => 'checkbox',
                    'default' => true,
                    'database_type' => 'boolean',
                    'description' => 'Show an alert on the dashboard when the user has unpaid invoices',
                    'section' => 'Smart Notices',
                ],
                [
                    'name' => 'tfa_notification',
                    'label' => '2FA Notification',
                    'type' => 'checkbox',
                    'default' => false,
                    'database_type' => 'boolean',
                    'description' => 'Show an alert encouraging users to enable Two-Factor Authentication if they haven\'t already',
                    'section' => 'Smart Notices',
                ],
            ],
            'discounts' => [
                [
                    'name' => 'sale_enabled',
                    'label' => 'Enable Sale Pricing',
                    'type' => 'checkbox',
                    'default' => false,
                    'database_type' => 'boolean',
                    'description' => 'Master switch for the sale system.',
                    'section' => 'Sale Pricing',
                ],
                [
                    'name' => 'sale_products_data',
                    'label' => 'Products on Sale',
                    'type' => 'repeater',
                    'default' => '[]',
                    'database_type' => 'string',
                    'description' => 'Select every product this sale applies to.',
                    'section' => 'Sale Pricing',
                ],
                [
                    'name' => 'sale_plan_discounts_data',
                    'label' => 'Plan Discounts',
                    'type' => 'repeater',
                    'default' => '[]',
                    'database_type' => 'string',
                    'description' => 'Set a discount percentage for each plan name.',
                    'section' => 'Sale Pricing',
                ],
                [
                    'name' => 'sale_badge_format',
                    'label' => 'Discount Badge Style',
                    'type' => 'select',
                    'options' => [
                        'percentage_off' => 'Percentage off  (e.g. 20% off)',
                        'save_percentage' => 'Save percentage  (e.g. Save 20%)',
                        'amount_off' => 'Amount off  (e.g. $4.00 OFF)',
                        'save_amount' => 'Save amount  (e.g. Save $4.00)',
                    ],
                    'default' => 'percentage_off',
                    'database_type' => 'string',
                    'description' => 'How the discount badge text reads.',
                    'section' => 'Sale Pricing',
                ],
                [
                    'name' => 'sale_checkout_badge_layout',
                    'label' => 'Checkout Badge Layout',
                    'type' => 'select',
                    'options' => [
                        'corner' => 'Corner ribbon (top-right)',
                        'circle' => 'Pill badge (top-right)',
                    ],
                    'default' => 'corner',
                    'database_type' => 'string',
                    'description' => 'How the discount badge appears on the checkout plan cards.',
                    'section' => 'Sale Pricing',
                ],
            ],
            'variables' => [
                [
                    'name' => 'env_var_descriptions_data',
                    'label' => 'Variable Descriptions',
                    'type' => 'repeater',
                    'default' => '[]',
                    'database_type' => 'string',
                    'description' => 'Add descriptions for environment variables shown on checkout and upgrade pages',
                    'section' => 'Variable Descriptions',
                ],
                [
                    'name' => 'tiered_config_options_data',
                    'label' => 'Tiered Config Options',
                    'type' => 'repeater',
                    'default' => '[]',
                    'database_type' => 'string',
                    'description' => 'Group a product config option\'s values into tiers (e.g., Premium / Extreme) on the checkout page.',
                    'section' => 'Tiered Config Options',
                ],
                [
                    'name' => 'hide_variable_plan_names',
                    'label' => 'Hide Plan Names on Radio Cards',
                    'type' => 'checkbox',
                    'default' => false,
                    'database_type' => 'boolean',
                    'description' => 'When enabled, the pricing plan name (e.g. "Standard") will not be shown on config option radio cards, only the price will be displayed.',
                    'section' => 'Tiered Config Options',
                ],
                [
                    'name' => 'out_of_stock_config_options_data',
                    'label' => 'Out of Stock Options',
                    'type' => 'repeater',
                    'default' => '[]',
                    'database_type' => 'string',
                    'description' => 'Mark specific values of a config option as out of stock on the checkout page (shown disabled / not selectable).',
                    'section' => 'Out of Stock Options',
                ],
            ],
            'cards' => [
                [
                    'name' => 'enable_service_cards',
                    'label' => 'Enable Cards',
                    'type' => 'checkbox',
                    'default' => true,
                    'description' => 'Show cards on service pages',
                    'section' => 'Service Page Cards',
                ],
                [
                    'name' => 'service_cards_type',
                    'label' => 'Card Display Type',
                    'type' => 'select',
                    'options' => [
                        'carousel' => 'Carousel',
                        'cards' => 'Cards',
                    ],
                    'default' => 'carousel',
                    'description' => 'Choose how cards are displayed on service pages',
                    'section' => 'Service Page Cards',
                    'visible_when_field' => 'enable_service_cards',
                    'visible_when_value' => true,
                ],
                [
                    'name' => 'service_carousel_data',
                    'label' => 'Carousel Cards',
                    'type' => 'repeater',
                    'default' => '[]',
                    'database_type' => 'string',
                    'description' => 'Add unlimited carousel cards for service pages',
                    'section' => 'Service Page Cards',
                ],
                [
                    'name' => 'service_cards_data',
                    'label' => 'Custom Cards',
                    'type' => 'repeater',
                    'default' => '[]',
                    'database_type' => 'string',
                    'description' => 'Add custom cards for service pages',
                    'section' => 'Service Page Cards',
                ],
            ],
            'seo' => [
                [
                    'name' => 'seo_title',
                    'label' => 'Default Page Title',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'Default title for pages without a specific title. Leave empty to use site name only.',
                    'section' => 'Meta Tags',
                ],
                [
                    'name' => 'seo_description',
                    'label' => 'Meta Description',
                    'type' => 'textarea',
                    'default' => '',
                    'description' => 'Default meta description for SEO (150-160 characters recommended). Falls back to site_description if empty.',
                    'section' => 'Meta Tags',
                ],
                [
                    'name' => 'seo_keywords',
                    'label' => 'Meta Keywords',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'Comma-separated keywords for SEO (e.g., web hosting, vps, dedicated servers)',
                    'section' => 'Meta Tags',
                ],
                [
                    'name' => 'seo_author',
                    'label' => 'Author / Company Name',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'Author or company name for meta tags',
                    'section' => 'Meta Tags',
                ],
                [
                    'name' => 'seo_robots',
                    'label' => 'Robots Meta Tag',
                    'type' => 'select',
                    'options' => [
                        'index, follow' => 'Index, Follow (Default - Allow search engines)',
                        'noindex, follow' => 'No Index, Follow (Don\'t index, but follow links)',
                        'index, nofollow' => 'Index, No Follow (Index page, don\'t follow links)',
                        'noindex, nofollow' => 'No Index, No Follow (Don\'t index or follow)',
                    ],
                    'default' => 'index, follow',
                    'description' => 'Control how search engines crawl and index your site',
                    'section' => 'Meta Tags',
                ],
                [
                    'name' => 'seo_canonical_url',
                    'label' => 'Canonical URL Base',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'Base URL for canonical links. Leave empty to use app URL. Include https:// (e.g., https://example.com)',
                    'section' => 'Meta Tags',
                ],

                [
                    'name' => 'seo_og_image',
                    'label' => 'Open Graph Image URL',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'Default image for social media sharing (1200x630px recommended). Shows when links are shared on social platforms.',
                    'section' => 'Social Sharing',
                ],
                [
                    'name' => 'seo_twitter_card',
                    'label' => 'Twitter Card Type',
                    'type' => 'select',
                    'options' => [
                        'summary' => 'Summary Card',
                        'summary_large_image' => 'Summary Card with Large Image',
                    ],
                    'default' => 'summary_large_image',
                    'description' => 'Twitter card display type for shared links',
                    'section' => 'Social Sharing',
                ],
                [
                    'name' => 'seo_twitter_site',
                    'label' => 'Twitter Username',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'Your Twitter/X username (e.g., @yourcompany) for Twitter Cards',
                    'section' => 'Social Sharing',
                ],
            ],
            'other' => [
                [
                    'name' => 'checkout_support_card_enabled',
                    'label' => 'Enable Support Card on Checkout Pages',
                    'type' => 'checkbox',
                    'default' => false,
                    'database_type' => 'boolean',
                    'description' => 'Show a support card below the order summary on the cart and checkout pages.',
                    'section' => 'Other Settings',
                ],
                [
                    'name' => 'checkout_support_card_tagline',
                    'label' => 'Support Card - Tagline',
                    'type' => 'text',
                    'default' => 'Need help?',
                    'description' => 'Small line shown above the title.',
                    'visible_when_field' => 'checkout_support_card_enabled',
                    'visible_when_value' => true,
                    'section' => 'Other Settings',
                ],
                [
                    'name' => 'checkout_support_card_title',
                    'label' => 'Support Card - Title',
                    'type' => 'text',
                    'default' => 'Get Support on Discord',
                    'description' => 'Main heading of the support card.',
                    'visible_when_field' => 'checkout_support_card_enabled',
                    'visible_when_value' => true,
                    'section' => 'Other Settings',
                ],
                [
                    'name' => 'checkout_support_card_desc',
                    'label' => 'Support Card - Description',
                    'type' => 'textarea',
                    'default' => 'Our team is here to help you with any questions before you complete your order.',
                    'description' => 'Short description shown below the title.',
                    'visible_when_field' => 'checkout_support_card_enabled',
                    'visible_when_value' => true,
                    'section' => 'Other Settings',
                ],
                [
                    'name' => 'checkout_support_card_btn_text',
                    'label' => 'Support Card - Button Text',
                    'type' => 'text',
                    'default' => 'Join Our Discord',
                    'description' => 'Text shown on the Discord button.',
                    'visible_when_field' => 'checkout_support_card_enabled',
                    'visible_when_value' => true,
                    'section' => 'Other Settings',
                ],
                [
                    'name' => 'checkout_support_card_link',
                    'label' => 'Support Card - Discord Invite Link',
                    'type' => 'text',
                    'default' => '',
                    'description' => 'The Discord invite URL. Leave blank to reuse the main Discord invite link.',
                    'visible_when_field' => 'checkout_support_card_enabled',
                    'visible_when_value' => true,
                    'section' => 'Other Settings',
                ],
                [
                    'name' => 'auth_layout',
                    'label' => 'Authentication Page Layout',
                    'type' => 'image_radio',
                    'options' => [
                        'auth1' => 'Default',
                    ],
                    'images' => [
                        'auth1' => 'assets/admin/custom/products/auth1.webp',
                    ],
                    'columns' => 1,
                    'default' => 'auth1',
                    'database_type' => 'string',
                    'description' => 'Choose the layout for the login, register and other authentication pages.',
                    'section' => 'Authentication',
                ],
                [
                    'name' => 'auth_page_image',
                    'label' => 'Authentication Pages Background Image',
                    'type' => 'file',
                    'default' => '',
                    'description' => 'Image for the right side of authentication pages (login, register, etc.). Recommended: High-quality image, minimum 1200x800px.',
                    'section' => 'Authentication',
                ],
                [
                    'name' => 'logo_only_display',
                    'label' => 'Logo Only Display',
                    'type' => 'checkbox',
                    'default' => false,
                    'description' => 'Hide site name everywhere and show only the logo (affects navbar, sidebar, footer, and authentication pages)',
                    'section' => 'Other Settings',
                ],
                [
                    'name' => 'hide_navbar_icons',
                    'label' => 'Hide Navigation Icons',
                    'type' => 'checkbox',
                    'default' => false,
                    'description' => 'Hide icons in navigation dropdowns (Store categories, Support links, etc) and show only text',
                    'section' => 'Other Settings',
                ],
                [
                    'name' => 'quick_actions_use_normal_colors',
                    'label' => 'Use Normal Text Colors for Quick Actions',
                    'type' => 'checkbox',
                    'default' => false,
                    'description' => 'When checked, Quick Actions links will use normal text colors instead of primary/secondary theme colors',
                    'section' => 'Other Settings',
                ],
                [
                    'name' => 'remove_branding',
                    'label' => 'Remove Branding',
                    'type' => 'checkbox',
                    'default' => false,
                    'database_type' => 'boolean',
                    'description' => 'Hide "Powered by Paymenter" branding from the footer',
                    'section' => 'Other Settings',
                ],
                [
                    'name' => 'config_option_monthly_pricing',
                    'label' => 'Show Config Option Prices as Monthly',
                    'type' => 'checkbox',
                    'default' => false,
                    'description' => 'When enabled, config option prices on checkout will be divided by their billing interval to show a per-month equivalent. For example, a yearly price of $120 will display as $10.00/month instead of $120.00/year.',
                    'section' => 'Other Settings',
                ],
                [
                    'name' => 'custom_head_code',
                    'label' => 'Custom Header Code',
                    'type' => 'textarea',
                    'rows' => 8,
                    'default' => '',
                    'description' => 'Code injected inside the <head> tag on every page. Useful for analytics scripts, meta tags, fonts, or any third-party integrations.',
                    'section' => 'Custom Code',
                ],
                [
                    'name' => 'custom_body_code',
                    'label' => 'Custom Body Code',
                    'type' => 'textarea',
                    'rows' => 8,
                    'default' => '',
                    'description' => 'Code injected at the start of the <body> tag on every page. Useful for tracking pixels, tag managers, or other body-level scripts.',
                    'section' => 'Custom Code',
                ],
                [
                    'name' => 'custom_css',
                    'label' => 'Custom CSS',
                    'type' => 'textarea',
                    'rows' => 8,
                    'default' => '',
                    'description' => 'Additional CSS injected into every page inside a <style> tag. Useful for quick visual tweaks without modifying theme files.',
                    'section' => 'Custom Code',
                ],
            ],
        ];
    }

    protected function getHeaderActions(): array
    {
        return [
            Action::make('duplicate_page')
                ->label('Duplicate Page')
                ->icon('ri-file-copy-line')
                ->color('gray')
                ->modalHeading('Duplicate a Custom Page')
                ->modalDescription('All content blocks are copied over. Selected plans inside Products blocks are cleared so you can pick new ones.')
                ->form(function (): array {
                    $pages = $this->cpPages;
                    $pageOptions = [];
                    foreach ($pages as $idx => $page) {
                        $type  = $page['page_type'] ?? 'custom';
                        $title = $page['title'] ?? ('Page ' . ($idx + 1));
                        $label = ($type === 'product' ? '[Product] ' : '[Custom] ') . $title;
                        $pageOptions[(string) $idx] = $label;
                    }

                    $categoryOptions = [];
                    try {
                        $categoryOptions = \App\Models\Category::query()
                            ->whereHas('products', fn ($q) => $q->where('hidden', false))
                            ->orderBy('sort')
                            ->orderBy('name')
                            ->pluck('name', 'id')
                            ->toArray();
                    } catch (\Throwable $e) {}

                    $baseUrl = rtrim(url('/'), '/') . '/';
                    $reservedSlugs = [
                        'login', '2fa', 'register', 'password', 'oauth',
                        'dashboard', 'invoices', 'tickets', 'services', 'account',
                        'email', 'cart', 'products', 'admin', 'api', 'livewire',
                        'storage', 'p', 'home', 'logout', 'verify', 'extensions',
                    ];

                    return [
                        Select::make('source_index')
                            ->label('Page to duplicate')
                            ->options($pageOptions)
                            ->placeholder('select a page')
                            ->required()
                            ->live()
                            ->helperText('Content blocks are copied. Selected plans are cleared.'),

                        TextInput::make('new_title')
                            ->label('New Page Title')
                            ->required()
                            ->visible(fn (callable $get) => $get('source_index') !== null && $get('source_index') !== ''),

                        Select::make('new_category_id')
                            ->label('New Category')
                            ->options($categoryOptions)
                            ->searchable()
                            ->required()
                            ->visible(function (callable $get) {
                                $idx = $get('source_index');
                                if ($idx === null || $idx === '') return false;
                                $pages = $this->cpPages;
                                return ($pages[(int) $idx]['page_type'] ?? 'custom') === 'product';
                            })
                            ->helperText('Pick the category this duplicate will be tied to.'),

                        Radio::make('new_url_strategy')
                            ->label('URL Strategy')
                            ->options([
                                'replace'  => 'Replace the default category page (/products/{slug})',
                                'separate' => 'Serve at a separate root URL (you choose the slug below)',
                            ])
                            ->default('replace')
                            ->required()
                            ->live()
                            ->visible(function (callable $get) {
                                $idx = $get('source_index');
                                if ($idx === null || $idx === '') return false;
                                $pages = $this->cpPages;
                                return ($pages[(int) $idx]['page_type'] ?? 'custom') === 'product';
                            }),

                        TextInput::make('new_slug')
                            ->label('URL Slug')
                            ->prefix($baseUrl)
                            ->required()
                            ->live(onBlur: true)
                            ->afterStateUpdated(fn ($state, callable $set) => $set('new_slug', \Illuminate\Support\Str::slug((string) $state)))
                            ->rule(function () use ($reservedSlugs) {
                                return function (string $attribute, $value, \Closure $fail) use ($reservedSlugs) {
                                    if (in_array(strtolower((string) $value), $reservedSlugs, true)) {
                                        $fail('"' . $value . '" is a reserved slug and cannot be used.');
                                    }
                                };
                            })
                            ->helperText('Lowercase letters, numbers and dashes only.')
                            ->visible(function (callable $get) {
                                $idx = $get('source_index');
                                if ($idx === null || $idx === '') return false;
                                $pages = $this->cpPages;
                                $type = ($pages[(int) $idx]['page_type'] ?? 'custom');
                                if ($type === 'custom') return true;
                                return ($get('new_url_strategy') ?? 'replace') === 'separate';
                            }),
                    ];
                })
                ->action(function (array $data): void {
                    $pages = $this->cpPages;
                    $idx   = (int) $data['source_index'];

                    if (!isset($pages[$idx])) {
                        Notification::make()
                            ->title('Source page not found.')
                            ->danger()
                            ->send();
                        return;
                    }

                    $page = $pages[$idx];


                    if (isset($page['blocks']) && is_array($page['blocks'])) {
                        foreach ($page['blocks'] as &$block) {
                            if (($block['type'] ?? '') === 'products') {
                                $block['product_ids'] = [];
                            }
                        }
                        unset($block);
                    }

                    
                    $page['title'] = $data['new_title'];

                    $type = $page['page_type'] ?? 'custom';

                    if ($type === 'product') {
                        if (!empty($data['new_category_id'])) {
                            $page['category_id'] = $data['new_category_id'];
                        }
                        $strategy = $data['new_url_strategy'] ?? 'replace';
                        $page['url_strategy'] = $strategy;
                        if ($strategy === 'separate') {
                            $page['slug'] = $data['new_slug'] ?? '';
                        } else {
                            unset($page['slug']);
                        }
                    } else {
                        $page['slug'] = $data['new_slug'] ?? '';
                    }

                    
                    $page['enabled'] = false;

                    $this->cpPages[] = $page;
                    $this->cpPages = array_values($this->cpPages);

                    Notification::make()
                        ->title('Page duplicated  it\'s at the bottom of the list, unpublished. Review and save when ready.')
                        ->success()
                        ->send();
                }),
        ];
    }

    public function boot(): void
    {

        $current = trim((string) ini_get('memory_limit'));
        if ($current !== '-1') {
            $bytes = (int) $current;
            $unit = strtolower(substr($current, -1));
            if ($unit === 'g') {
                $bytes *= 1024 * 1024 * 1024;
            } elseif ($unit === 'm') {
                $bytes *= 1024 * 1024;
            } elseif ($unit === 'k') {
                $bytes *= 1024;
            }
            if ($bytes > 0 && $bytes < 512 * 1024 * 1024) {
                @ini_set('memory_limit', '512M');
            }
        }
    }

    public function mount(): void
    {
        $values = [];
        foreach ($this->managedSettings() as $group => $settings) {
            foreach ($settings as $setting) {
                $key = $this->prefix() . $setting['name'];
                $val = config("settings.{$key}", $setting['default'] ?? null);


                if (in_array($setting['type'] ?? '', ['repeater', 'multi_file']) && is_string($val)) {
                    $decoded = json_decode($val, true);
                    $val = is_array($decoded) ? $decoded : [];
                }

                $values[$setting['name']] = $val;
            }
        }

        
        $this->cpPages = (isset($values['custom_pages_data']) && is_array($values['custom_pages_data']))
            ? array_values($values['custom_pages_data'])
            : [];
        $values['custom_pages_data'] = [];
        $values['cp_editing'] = [];

        $this->form->fill($values);
    }

    public function form(Schema $schema): Schema
    {
        $tabs = [];

        foreach ($this->managedSettings() as $tabKey => $settings) {
            $tabs[] = Tab::make($tabKey)
                ->label(ucwords(str_replace('_', ' ', $tabKey)))
                ->icon(match ($tabKey) {
                    'general' => 'ri-settings-3-line',
                    'colors' => 'ri-palette-line',
                    'customization' => 'ri-pencil-ai-line',
                    'custom_pages' => 'ri-file-add-line',
                    'header_footer' => 'ri-layout-2-line',
                    'home_page' => 'ri-home-line',
                    'plans' => 'ri-price-tag-3-line',
                    'dashboard' => 'ri-dashboard-line',
                    'announcement' => 'ri-megaphone-line',
                    'discounts' => 'ri-percent-line',
                    'variables' => 'ri-code-s-slash-line',
                    'cards' => 'ri-bank-card-line',
                    'seo' => 'ri-search-eye-line',
                    'other' => 'ri-more-2-line',
                    default => null,
                })
                ->schema($this->buildTabSchema($tabKey, $settings));
        }

        return $schema
            ->components([
                Form::make([
                    Tabs::make('Tabs')
                        ->tabs($tabs)
                        ->persistTabInQueryString(),
                ])
                    ->livewireSubmitHandler('save')
                    ->footer([
                        Actions::make([
                            Action::make('save')
                                ->submit('save')
                                ->keyBindings(['mod+s']),
                        ]),
                    ]),
            ])
            ->statePath('data');
    }

    /**
     *
     * @return array{0: array<int,string>, 1: array<int,array<int,string>>}
     */
    private function citadelConfigOptionData(): array
    {
        $configOptionLabels = [];
        $configOptionChildren = [];

        try {
            if (class_exists(\App\Models\ConfigOption::class)) {
                $rows = \App\Models\ConfigOption::query()
                    ->whereNull('parent_id')
                    ->whereHas('children')
                    ->with([
                        'children' => function ($q) {
                            $q->select('id', 'parent_id', 'name')->orderBy('sort');
                        },
                        'products:id,name',
                    ])
                    ->orderBy('name')
                    ->get();

                foreach ($rows as $row) {
                    $productNames = $row->products->pluck('name')->filter()->values()->all();
                    $productLabel = empty($productNames)
                        ? 'Global'
                        : (count($productNames) > 1
                            ? $productNames[0] . ' +' . (count($productNames) - 1)
                            : $productNames[0]);

                    $configOptionLabels[$row->id] = "[{$productLabel}] " . ($row->name ?? ('#' . $row->id));

                    $children = [];
                    foreach ($row->children as $child) {
                        $children[$child->id] = $child->name ?? ('#' . $child->id);
                    }
                    $configOptionChildren[$row->id] = $children;
                }
            }
        } catch (\Throwable $e) {
            \Log::warning('CitadelEditor: failed to load ConfigOptions: ' . $e->getMessage());
        }

        return [$configOptionLabels, $configOptionChildren];
    }

    private function buildTabSchema(string $tabKey, array $settings): array
    {
        if ($tabKey === 'home_page') {
            return $this->buildHomePageSchema($settings);
        }

        if ($tabKey === 'colors') {
            return $this->buildColorsSchema($settings);
        }

        if ($tabKey === 'customization') {
            return $this->buildCustomizationSchema($settings);
        }

        if ($tabKey === 'custom_pages') {
            return $this->buildCustomPagesSchema($settings);
        }

        if ($tabKey === 'header_footer') {
            return $this->buildHeaderFooterSchema($settings);
        }

        $hasSections = collect($settings)->contains(fn ($s) => isset($s['section']));

        if (! $hasSections) {
            $inputs = [];

            $tabTitle = match ($tabKey) {
                'general' => 'General Settings',
                'colors' => 'Colors Settings',
                'plans' => 'Plans Settings',
                'dashboard' => 'Dashboard Settings',
                'announcement' => 'Announcement Settings',
                'discounts' => 'Discount Settings',
                'variables' => 'Variable Settings',
                'cards' => 'Services Page Cards',
                'seo' => 'SEO Settings',
                'other' => 'Other Settings',
                default => null,
            };
            if ($tabTitle) {
                $inputs[] = Placeholder::make($tabKey . '_title')
                    ->content(new HtmlString('<h2 style="font-size: 1.25rem; font-weight: 700; margin: 0;">' . $tabTitle . '</h2>'))
                    ->hiddenLabel();
            }

            foreach ($settings as $setting) {
                $inputs[] = $this->buildInput($setting);
            }
            return $inputs;
        }

        $components = [];

        $tabTitle = match ($tabKey) {
            'general' => 'General Settings',
            'colors' => 'Colors Settings',
            'plans' => 'Plans Settings',
            'dashboard' => 'Dashboard Settings',
            'announcement' => 'Announcement Settings',
            'discounts' => 'Discount Settings',
            'variables' => 'Variable Settings',
            'cards' => 'Services Page Cards',
            'seo' => 'SEO Settings',
            'other' => 'Other Settings',
            default => null,
        };
        if ($tabTitle) {
            $components[] = Placeholder::make($tabKey . '_title')
                ->content(new HtmlString('<h2 style="font-size: 1.25rem; font-weight: 700; margin: 0;">' . $tabTitle . '</h2>'))
                ->hiddenLabel();
        }

        $sections = [];
        foreach ($settings as $setting) {
            if (isset($setting['section'])) {
                $sections[$setting['section']][] = $setting;
            } else {
                $components[] = $this->buildInput($setting);
            }
        }

        foreach ($sections as $sectionName => $sectionSettings) {


            if ($sectionName === 'Sale Pricing' && $tabKey === 'discounts') {
                // Build the list of selectable products.
                $productOptions = [];
                try {
                    if (class_exists(\App\Models\Product::class)) {
                        $productOptions = \App\Models\Product::query()
                            ->orderBy('name')
                            ->pluck('name', 'id')
                            ->all();
                    }
                } catch (\Throwable $e) {
                    \Log::warning('CitadelEditor: failed to load Products for Sale Pricing section: ' . $e->getMessage());
                }

                
                $planNameOptions = function (Get $get) {
                    $ids = $get('../../sale_products_data');
                    if (! is_array($ids) || empty($ids)) {
                        return [];
                    }
                    try {
                        return \App\Models\Product::query()
                            ->whereIn('id', $ids)
                            ->get()
                            ->flatMap(fn ($product) => $product->plans->pluck('name'))
                            ->filter()
                            ->unique()
                            ->sort()
                            ->mapWithKeys(fn ($name) => [$name => $name])
                            ->all();
                    } catch (\Throwable $e) {
                        \Log::warning('CitadelEditor: failed to load plan names for Sale Pricing section: ' . $e->getMessage());
                        return [];
                    }
                };

                $sectionInputs = [];

                
                foreach ($sectionSettings as $setting) {
                    if ($setting['name'] === 'sale_enabled') {
                        $sectionInputs[] = $this->buildInput($setting);
                        break;
                    }
                }

                
                $sectionInputs[] = Select::make('sale_products_data')
                    ->label('Products on Sale')
                    ->helperText('Select every product this sale applies to.')
                    ->options($productOptions)
                    ->multiple()
                    ->searchable()
                    ->preload()
                    ->live()
                    ->hidden(fn (Get $get) => ! ((bool) $get('sale_enabled')))
                    ->columnSpanFull();

                
                $sectionInputs[] = Repeater::make('sale_plan_discounts_data')
                    ->label('Plan Discounts')
                    ->addActionLabel('Add Plan Discount')
                    ->helperText('Set a discount percentage for each plan name.')
                    ->schema([
                        Select::make('plan_name')
                            ->label('Plan')
                            ->options($planNameOptions)
                            ->searchable()
                            ->required()
                            ->live(),
                        TextInput::make('percentage')
                            ->label('Discount %')
                            ->numeric()
                            ->minValue(0.01)
                            ->maxValue(99.99)
                            ->step('0.01')
                            ->suffix('%')
                            ->required(),
                    ])
                    ->itemLabel(fn (array $state): ?string => isset($state['plan_name'], $state['percentage'])
                        ? $state['plan_name'] . '  ' . $state['percentage'] . '%'
                        : 'Plan Discount')
                    ->collapsible()
                    ->reorderable()
                    ->hidden(fn (Get $get) => ! ((bool) $get('sale_enabled')))
                    ->columnSpanFull();

                
                foreach ($sectionSettings as $setting) {
                    if ($setting['name'] === 'sale_badge_format') {
                        $input = $this->buildInput($setting);
                        $input = $input->hidden(fn (Get $get) => ! ((bool) $get('sale_enabled')));
                        $sectionInputs[] = $input;
                        break;
                    }
                }

                
                foreach ($sectionSettings as $setting) {
                    if ($setting['name'] === 'sale_checkout_badge_layout') {
                        $input = $this->buildInput($setting);
                        $input = $input->hidden(fn (Get $get) => ! ((bool) $get('sale_enabled')));
                        $sectionInputs[] = $input;
                        break;
                    }
                }

                $components[] = Section::make($sectionName)
                    ->description('Shows a struck-through original price, the real discounted price, and a badge, without changing the prices stored in Paymenter.')
                    ->schema($sectionInputs);

                continue;
            }


            if ($sectionName === 'Secondary Card' && $tabKey === 'dashboard') {
                $sectionInputs = [];


                foreach ($sectionSettings as $setting) {
                    if ($setting['name'] === 'enable_secondary_card') {
                        $sectionInputs[] = $this->buildInput($setting);
                        break;
                    }
                }


                foreach ($sectionSettings as $setting) {
                    if ($setting['name'] === 'secondary_cards_data' || $setting['name'] === 'enable_secondary_card') {
                        continue;
                    }
                    $input = $this->buildInput($setting);
                    $input = $input->hidden(fn (Get $get) => !((bool) $get('enable_secondary_card')));
                    $sectionInputs[] = $input;
                }


                $sectionInputs[] = Repeater::make('secondary_cards_data')
                    ->label('Secondary Cards')
                    ->addActionLabel('Add Card')
                    ->schema([
                        Select::make('type')
                            ->label('Card Type')
                            ->options([
                                'discord' => 'Discord Invite',
                                'custom_html' => 'Custom HTML',
                                'custom_card' => 'Custom Card',
                            ])
                            ->default('discord')
                            ->native(false)
                            ->live()
                            ->required(),
                        Radio::make('discord_card_design')
                            ->label('Discord Card Style')
                            ->options(collect([
                                'classic' => 'Classic',
                                'button' => 'Button',
                                'glass' => 'Elegant',
                                'banner' => 'Banner',
                                'card' => 'Support Card',
                            ])->mapWithKeys(function ($label, $key) {
                                $images = [
                                    'classic' => 'assets/admin/dashsbord/classic.webp',
                                    'button' => 'assets/admin/dashsbord/button.webp',
                                    'glass' => 'assets/admin/dashsbord/elegant.webp',
                                    'banner' => 'assets/admin/dashsbord/banner.webp',
                                    'card' => 'assets/admin/dashsbord/classic.webp',
                                ];
                                $imgUrl = asset($images[$key] ?? '');
                                return [$key => new HtmlString(
                                    '<div class="citadel-image-radio-card">'
                                    . '<img src="' . e($imgUrl) . '" alt="' . e($label) . '" />'
                                    . '<span>' . e($label) . '</span>'
                                    . '</div>'
                                )];
                            })->toArray())
                            ->default('classic')
                            ->columns(2)
                            ->extraAttributes(['class' => 'citadel-image-radio'])
                            ->live()
                            ->visible(fn (Get $get) => $get('type') === 'discord'),
                        TextInput::make('discord_tagline')
                            ->label('Tagline')
                            ->default('Join 3,000+ members')
                            ->maxLength(100)
                            ->helperText('Small badge above the title, e.g. "Join 3,000+ members"')
                            ->visible(fn (Get $get) => $get('type') === 'discord' && $get('discord_card_design') === 'card'),
                        TextInput::make('discord_title_custom')
                            ->label('Title')
                            ->default('Get Support on Discord')
                            ->maxLength(255)
                            ->visible(fn (Get $get) => $get('type') === 'discord' && $get('discord_card_design') === 'card'),
                        Textarea::make('discord_desc_custom')
                            ->label('Description')
                            ->default('Join our community for quick help, updates, and more.')
                            ->rows(2)
                            ->visible(fn (Get $get) => $get('type') === 'discord' && $get('discord_card_design') === 'card'),
                        TextInput::make('discord_btn_text')
                            ->label('Button Text')
                            ->default('Join Our Discord')
                            ->maxLength(100)
                            ->visible(fn (Get $get) => $get('type') === 'discord' && $get('discord_card_design') === 'card'),
                        Textarea::make('custom_html')
                            ->label('Custom HTML')
                            ->rows(4)
                            ->visible(fn (Get $get) => $get('type') === 'custom_html'),
                        Radio::make('card_design')
                            ->label('Card Design')
                            ->options(collect([
                                'top_border' => 'Top Border',
                                'image_bg' => 'Image Background',
                                'icon_card' => 'Icon Card',
                            ])->mapWithKeys(function ($label, $key) {
                                $images = [
                                    'top_border' => 'assets/admin/dashsbord/topborder.webp',
                                    'image_bg' => 'assets/admin/dashsbord/imagebackground.webp',
                                    'icon_card' => 'assets/admin/dashsbord/icon.gif',
                                ];
                                $imgUrl = asset($images[$key] ?? '');
                                return [$key => new HtmlString(
                                    '<div class="citadel-image-radio-card">'
                                    . '<img src="' . e($imgUrl) . '" alt="' . e($label) . '" />'
                                    . '<span>' . e($label) . '</span>'
                                    . '</div>'
                                )];
                            })->toArray())
                            ->default('top_border')
                            ->columns(2)
                            ->extraAttributes(['class' => 'citadel-image-radio'])
                            ->live()
                            ->visible(fn (Get $get) => $get('type') === 'custom_card'),
                        TextInput::make('title')
                            ->label('Card Title')
                            ->maxLength(255)
                            ->live(onBlur: true)
                            ->visible(fn (Get $get) => $get('type') === 'custom_card'),
                        Textarea::make('description')
                            ->label('Card Description')
                            ->rows(2)
                            ->visible(fn (Get $get) => $get('type') === 'custom_card'),
                        TextInput::make('button_text')
                            ->label('Button Text')
                            ->maxLength(255)
                            ->visible(fn (Get $get) => $get('type') === 'custom_card'),
                        TextInput::make('button_link')
                            ->label('Button Link')
                            ->maxLength(500)
                            ->visible(fn (Get $get) => $get('type') === 'custom_card'),
                        FileUpload::make('image')
                            ->label('Image / Icon')
                            ->image()
                            ->imageEditor()
                            ->disk('public')
                            ->directory('citadel/secondary-cards')
                            ->visibility('public')
                            ->nullable()
                            ->visible(fn (Get $get) => $get('type') === 'custom_card'),
                    ])
                    ->itemLabel(fn (array $state): ?string => match ($state['type'] ?? 'discord') {
                        'discord' => 'Discord Invite (' . ($state['discord_card_design'] ?? 'classic') . ')',
                        'custom_html' => 'Custom HTML',
                        'custom_card' => $state['title'] ?? 'Custom Card',
                        default => 'Card',
                    })
                    ->collapsible()
                    ->collapsed()
                    ->cloneable()
                    ->reorderable()
                    ->columnSpanFull()
                    ->visible(fn (Get $get) => (bool) $get('enable_secondary_multiple') && (bool) $get('enable_secondary_card'))
                    ->dehydratedWhenHidden();

                $components[] = Section::make($sectionName)
                    ->schema($sectionInputs);

                continue;
            }


            if ($sectionName === 'Dashboard Alerts' && $tabKey === 'announcement') {
                $sectionInputs = [];

                $sectionInputs[] = Repeater::make('dashboard_alerts_data')
                    ->label('Dashboard Alerts')
                    ->addActionLabel('Add Alert')
                    ->schema([
                        TextInput::make('icon')
                            ->label('Icon')
                            ->default('information-line')
                            ->helperText('Remix Icon name (e.g., "information-line", "alert-line", "checkbox-circle-line")'),
                        TextInput::make('title')
                            ->label('Title')
                            ->maxLength(255)
                            ->live(onBlur: true)
                            ->required(),
                        Textarea::make('description')
                            ->label('Description')
                            ->rows(2),
                        ColorPicker::make('color')
                            ->label('Alert Color')
                            ->hsl()
                            ->default('hsl(229, 100%, 64%)')
                            ->helperText('Color theme for the alert card'),
                        Toggle::make('dismissible')
                            ->label('Allow Dismissing')
                            ->default(true)
                            ->helperText('Allow users to dismiss this alert'),
                        Toggle::make('enable_buttons')
                            ->label('Enable Buttons')
                            ->default(false)
                            ->live()
                            ->helperText('Show action buttons on this alert'),
                        Repeater::make('buttons')
                            ->label('Buttons')
                            ->addActionLabel('Add Button')
                            ->schema([
                                TextInput::make('text')
                                    ->label('Button Text')
                                    ->maxLength(255)
                                    ->required(),
                                TextInput::make('link')
                                    ->label('Button Link')
                                    ->maxLength(500)
                                    ->required(),
                            ])
                            ->columns(2)
                            ->collapsible()
                            ->reorderable()
                            ->defaultItems(1)
                            ->visible(fn (Get $get) => (bool) $get('enable_buttons')),
                    ])
                    ->itemLabel(fn (array $state): ?string => $state['title'] ?? 'Alert')
                    ->collapsible()
                    ->collapsed()
                    ->cloneable()
                    ->reorderable()
                    ->columnSpanFull();

                $components[] = Section::make($sectionName)
                    ->schema($sectionInputs);

                continue;
            }


            if ($sectionName === 'Variable Descriptions' && $tabKey === 'variables') {
                $sectionInputs = [];

                $sectionInputs[] = Repeater::make('env_var_descriptions_data')
                    ->label('Variable Descriptions')
                    ->addActionLabel('Add Variable')
                    ->schema([
                        TextInput::make('name')
                            ->label('Variable Name')
                            ->helperText('Enter the exact environment variable name (e.g., RAM_SIZE, STORAGE_TYPE)')
                            ->maxLength(255)
                            ->live(onBlur: true)
                            ->required(),
                        Textarea::make('description')
                            ->label('Description')
                            ->helperText('Description text to show under the variable on checkout and upgrade pages')
                            ->rows(2),
                    ])
                    ->itemLabel(fn (array $state): ?string => $state['name'] ?? 'Variable')
                    ->collapsible()
                    ->collapsed()
                    ->cloneable()
                    ->reorderable()
                    ->columnSpanFull();

                $components[] = Section::make($sectionName)
                    ->schema($sectionInputs);

                continue;
            }


            if ($sectionName === 'Tiered Config Options' && $tabKey === 'variables') {
                
                $configOptionLabels = [];
                $configOptionChildren = []; 

                try {
                    if (class_exists(\App\Models\ConfigOption::class)) {
                        
                        $rows = \App\Models\ConfigOption::query()
                            ->whereNull('parent_id')
                            ->whereHas('children')
                            ->with([
                                'children' => function ($q) {
                                    $q->select('id', 'parent_id', 'name')->orderBy('sort');
                                },
                                'products:id,name',
                            ])
                            ->orderBy('name')
                            ->get();

                        foreach ($rows as $row) {
                            $productNames = $row->products->pluck('name')->filter()->values()->all();
                            $productLabel = empty($productNames)
                                ? 'Global'
                                : (count($productNames) > 1
                                    ? $productNames[0] . ' +' . (count($productNames) - 1)
                                    : $productNames[0]);

                            $configOptionLabels[$row->id] = "[{$productLabel}] " . ($row->name ?? ('#' . $row->id));

                            $children = [];
                            foreach ($row->children as $child) {
                                $children[$child->id] = $child->name ?? ('#' . $child->id);
                            }
                            $configOptionChildren[$row->id] = $children;
                        }
                    }
                } catch (\Throwable $e) {
                    
                    \Log::warning('CitadelEditor: failed to load ConfigOptions for Tiered Config Options section: ' . $e->getMessage());
                }

                $configOptionAllChildren = [];
                foreach ($configOptionChildren as $__coChildren) {
                    $configOptionAllChildren += $__coChildren;
                }

                $sectionInputs = [];

                
                foreach ($sectionSettings as $setting) {
                    if ($setting['name'] === 'hide_variable_plan_names') {
                        $sectionInputs[] = $this->buildInput($setting);
                    }
                }

                $sectionInputs[] = Repeater::make('tiered_config_options_data')
                    ->label('')
                    ->hiddenLabel()
                    ->addActionLabel('Add Tiered Config Option')
                    ->helperText('Pick a config option, then split its values into tiers. Each tier renders on the product checkout page with its own title and description.')
                    ->schema([
                        Select::make('config_option_id')
                            ->label('Config Option')
                            ->options(fn () => $configOptionLabels)
                            ->searchable()
                            ->preload()
                            ->required()
                            ->live()
                            ->helperText('Only select / radio / slider config options are listed.'),

                        Repeater::make('tiers')
                            ->label('Tiers')
                            ->addActionLabel('Add Tier')
                            ->schema([
                                TextInput::make('title')
                                    ->label('Tier Title')
                                    ->placeholder('e.g. Premium')
                                    ->required()
                                    ->maxLength(120),
                                Textarea::make('description')
                                    ->label('Tier Description')
                                    ->placeholder('Short paragraph shown under the tier title.')
                                    ->rows(2),
                                Textarea::make('tooltip')
                                    ->label('Tier Tooltip')
                                    ->placeholder('Optional  shown as a hoverable (?) icon next to the tier title.')
                                    ->rows(2)
                                    ->helperText('Leave blank to hide the tooltip icon entirely.'),
                                Select::make('option_ids')
                                    ->label('Options in this tier')
                                    ->multiple()
                                    ->searchable()
                                    ->options(function (Get $get) use ($configOptionChildren, $configOptionAllChildren) {
                                        $parentId = $get('../../config_option_id');
                                        $opts = ($parentId && isset($configOptionChildren[$parentId]))
                                            ? $configOptionChildren[$parentId]
                                            : [];
                                        foreach ((array) $get('option_ids') as $__vid) {
                                            if ($__vid !== null && $__vid !== '' && ! isset($opts[$__vid])) {
                                                $opts[$__vid] = $configOptionAllChildren[$__vid] ?? ('#' . $__vid);
                                            }
                                        }
                                        return $opts;
                                    })
                                    ->helperText('Select the values that belong to this tier. Values not assigned to any tier are shown below the tiered groups.')
                                    ->required(),
                            ])
                            ->itemLabel(fn (array $state): ?string => $state['title'] ?? 'Tier')
                            ->collapsible()
                            ->collapsed()
                            ->reorderable()
                            ->defaultItems(1)
                            ->columnSpanFull(),
                    ])
                    ->itemLabel(function (array $state) use ($configOptionLabels): ?string {
                        $id = $state['config_option_id'] ?? null;
                        return $id && isset($configOptionLabels[$id])
                            ? $configOptionLabels[$id]
                            : 'Tiered Config Option';
                    })
                    ->collapsible()
                    ->collapsed()
                    ->cloneable()
                    ->reorderable()
                    ->columnSpanFull();

                $components[] = Section::make($sectionName)
                    ->description('Group an existing product config option\'s values into tiers like "Premium" and "Extreme". The checkout page will display each tier with its title and description.')
                    ->schema($sectionInputs);

                continue;
            }

            if ($sectionName === 'Out of Stock Options' && $tabKey === 'variables') {
                [$configOptionLabels, $configOptionChildren] = $this->citadelConfigOptionData();

                $configOptionAllChildren = [];
                foreach ($configOptionChildren as $__coChildren) {
                    $configOptionAllChildren += $__coChildren;
                }

                $sectionInputs = [];
                $sectionInputs[] = Repeater::make('out_of_stock_config_options_data')
                    ->hiddenLabel()
                    ->addActionLabel('Add Out of Stock Option')
                    ->helperText('Pick a config option, then choose which of its values are out of stock. On the checkout page they show as "Out of stock" and can\'t be selected.')
                    ->schema([
                        Select::make('config_option_id')
                            ->label('Config Option')
                            ->options(fn () => $configOptionLabels)
                            ->searchable()
                            ->preload()
                            ->required()
                            ->live()
                            ->helperText('Only select / radio / slider config options are listed.'),
                        Select::make('option_ids')
                            ->label('Out of stock values')
                            ->multiple()
                            ->searchable()
                            ->options(function (Get $get) use ($configOptionChildren, $configOptionAllChildren) {
                                $parentId = $get('config_option_id');
                                $opts = ($parentId && isset($configOptionChildren[$parentId]))
                                    ? $configOptionChildren[$parentId]
                                    : [];
                                foreach ((array) $get('option_ids') as $__vid) {
                                    if ($__vid !== null && $__vid !== '' && ! isset($opts[$__vid])) {
                                        $opts[$__vid] = $configOptionAllChildren[$__vid] ?? ('#' . $__vid);
                                    }
                                }
                                return $opts;
                            })
                            ->helperText('These values render as "Out of stock" and are not selectable.')
                            ->required(),
                    ])
                    ->itemLabel(function (array $state) use ($configOptionLabels): ?string {
                        $id = $state['config_option_id'] ?? null;
                        return $id && isset($configOptionLabels[$id])
                            ? $configOptionLabels[$id]
                            : 'Out of Stock Option';
                    })
                    ->collapsible()
                    ->collapsed()
                    ->cloneable()
                    ->reorderable()
                    ->columnSpanFull();

                $components[] = Section::make($sectionName)
                    ->description('Mark specific values of a product config option as out of stock. They appear disabled on the checkout page and can\'t be chosen.')
                    ->schema($sectionInputs);

                continue;
            }


            if ($sectionName === 'Service Page Cards' && $tabKey === 'cards') {
                $sectionInputs = [];


                foreach ($sectionSettings as $setting) {
                    if ($setting['name'] === 'enable_service_cards') {
                        $sectionInputs[] = $this->buildInput($setting);
                        break;
                    }
                }


                foreach ($sectionSettings as $setting) {
                    if ($setting['name'] === 'service_cards_type') {
                        $input = $this->buildInput($setting);
                        $input = $input->live()->hidden(fn (Get $get) => !((bool) $get('enable_service_cards')));
                        $sectionInputs[] = $input;
                        break;
                    }
                }


                $sectionInputs[] = Repeater::make('service_carousel_data')
                    ->label('Carousel Cards')
                    ->addActionLabel('Add Carousel Card')
                    ->schema([
                        TextInput::make('title')
                            ->label('Title')
                            ->maxLength(255)
                            ->live(onBlur: true)
                            ->required(),
                        Textarea::make('description')
                            ->label('Description')
                            ->rows(2),
                        TextInput::make('button_text')
                            ->label('Button Text')
                            ->maxLength(255)
                            ->helperText('Leave empty to make entire card clickable'),
                        TextInput::make('button_link')
                            ->label('Link URL')
                            ->maxLength(500),
                        FileUpload::make('background_image')
                            ->label('Background Image')
                            ->image()
                            ->imageEditor()
                            ->disk('public')
                            ->directory('citadel/carousel-cards')
                            ->visibility('public')
                            ->required(),
                        Select::make('overlay_type')
                            ->label('Overlay Type')
                            ->options([
                                'primary' => 'Primary Color',
                                'dark' => 'Dark',
                            ])
                            ->default('primary'),
                        Select::make('text_alignment')
                            ->label('Text Alignment')
                            ->options([
                                'bottom_left' => 'Bottom Left',
                                'top_left' => 'Top Left',
                                'center' => 'Center',
                                'top_right' => 'Top Right',
                            ])
                            ->default('bottom_left'),
                    ])
                    ->itemLabel(fn (array $state): ?string => $state['title'] ?? 'Carousel Card')
                    ->collapsible()
                    ->collapsed()
                    ->cloneable()
                    ->reorderable()
                    ->columnSpanFull()
                    ->visible(fn (Get $get) => (bool) $get('enable_service_cards') && $get('service_cards_type') === 'carousel')
                    ->dehydratedWhenHidden();


                $sectionInputs[] = Repeater::make('service_cards_data')
                    ->label('Custom Cards')
                    ->addActionLabel('Add Card')
                    ->schema([
                        Radio::make('card_design')
                            ->label('Card Design')
                            ->options(collect([
                                'top_border' => 'Top Border',
                                'image_bg' => 'Image Background',
                                'icon_card' => 'Icon Card',
                            ])->mapWithKeys(function ($label, $key) {
                                $images = [
                                    'top_border' => 'assets/admin/dashsbord/topborder.webp',
                                    'image_bg' => 'assets/admin/dashsbord/imagebackground.webp',
                                    'icon_card' => 'assets/admin/dashsbord/icon.gif',
                                ];
                                $imgUrl = asset($images[$key] ?? '');
                                return [$key => new HtmlString(
                                    '<div class="citadel-image-radio-card">'
                                    . '<img src="' . e($imgUrl) . '" alt="' . e($label) . '" />'
                                    . '<span>' . e($label) . '</span>'
                                    . '</div>'
                                )];
                            })->toArray())
                            ->default('top_border')
                            ->columns(2)
                            ->extraAttributes(['class' => 'citadel-image-radio'])
                            ->live(),
                        TextInput::make('title')
                            ->label('Card Title')
                            ->maxLength(255)
                            ->live(onBlur: true),
                        Textarea::make('description')
                            ->label('Card Description')
                            ->rows(2),
                        TextInput::make('button_text')
                            ->label('Button Text')
                            ->maxLength(255),
                        TextInput::make('button_link')
                            ->label('Button Link')
                            ->maxLength(500),
                        FileUpload::make('image')
                            ->label('Image / Icon')
                            ->image()
                            ->imageEditor()
                            ->disk('public')
                            ->directory('citadel/service-cards')
                            ->visibility('public')
                            ->nullable(),
                    ])
                    ->itemLabel(fn (array $state): ?string => $state['title'] ?? 'Custom Card')
                    ->collapsible()
                    ->collapsed()
                    ->cloneable()
                    ->reorderable()
                    ->columnSpanFull()
                    ->visible(fn (Get $get) => (bool) $get('enable_service_cards') && $get('service_cards_type') === 'cards')
                    ->dehydratedWhenHidden();

                $components[] = Section::make($sectionName)
                    ->schema($sectionInputs);

                continue;
            }

            if ($sectionName === 'Category Icons' && $tabKey === 'plans') {
                $sectionInputs = [];

                foreach ($sectionSettings as $setting) {
                    if ($setting['name'] === 'override_category_icons') {
                        $sectionInputs[] = $this->buildInput($setting);
                        break;
                    }
                }

                $allCategories = \App\Models\Category::orderBy('sort')->get();
                $categoryOptions = $allCategories->mapWithKeys(function ($cat) {
                    $prefix = $cat->parent_id ? '  └ ' : '';
                    return [(string) $cat->id => $prefix . $cat->name];
                })->toArray();

                $sectionInputs[] = Repeater::make('category_icons_data')
                    ->label('Category Icon Overrides')
                    ->addActionLabel('Add Category Icon')
                    ->schema([
                        Select::make('category_id')
                            ->label('Category')
                            ->options($categoryOptions)
                            ->required()
                            ->native(false)
                            ->searchable()
                            ->live(onBlur: true),
                        Radio::make('icon')
                            ->label('Citadel Icon')
                            ->options(fn () => $this->getCitadelIcons())
                            ->columns(5)
                            ->extraAttributes(['class' => 'citadel-icon-picker'])
                            ->dehydratedWhenHidden()
                            ->required(),
                    ])
                    ->itemLabel(function (array $state) use ($categoryOptions): ?string {
                        $catId = $state['category_id'] ?? null;
                        $catName = $catId ? ($categoryOptions[$catId] ?? 'Unknown') : 'New';
                        $icon = $state['icon'] ?? '';
                        return trim($catName) . ($icon ? " → {$icon}" : '');
                    })
                    ->collapsible()
                    ->collapsed()
                    ->cloneable()
                    ->reorderable()
                    ->columnSpanFull()
                    ->visible(fn (Get $get) => (bool) $get('override_category_icons'))
                    ->dehydratedWhenHidden();

                $components[] = Section::make($sectionName)
                    ->schema($sectionInputs);

                continue;
            }

            $sectionInputs = [];
            foreach ($sectionSettings as $setting) {
                $sectionInputs[] = $this->buildInput($setting);
            }
            $section = Section::make($sectionName)
                ->schema($sectionInputs);

            if ($tabKey !== 'general' && $tabKey !== 'colors' && $tabKey !== 'dashboard' && $tabKey !== 'announcement' && $tabKey !== 'discounts' && $tabKey !== 'variables' && $tabKey !== 'cards' && $tabKey !== 'seo' && $tabKey !== 'other') {
                $section->collapsible()->collapsed();
            }

            $components[] = $section;
        }

        return $components;
    }

    private function buildCustomizationSchema(array $settings): array
    {
        $components = [];

        $components[] = Placeholder::make('customization_title')
            ->hiddenLabel()
            ->content(new HtmlString('<h2 style="font-size: 1.25rem; font-weight: 700; margin: 0;">Customization</h2>'));

        $components[] = Section::make('Typography')
            ->schema([
                Select::make('font_family')
                    ->label('Font Family')
                    ->options([
                        'Poppins'           => 'Poppins (Default)',
                        'Inter'             => 'Inter',
                        'Nunito'            => 'Nunito',
                        'Roboto'            => 'Roboto',
                        'DM Sans'           => 'DM Sans',
                        'Plus Jakarta Sans' => 'Plus Jakarta Sans',
                        'Outfit'            => 'Outfit',
                        'Manrope'           => 'Manrope',
                        'Figtree'           => 'Figtree',
                        'Sora'              => 'Sora',
                        'Lexend'            => 'Lexend',
                        'Red Hat Display'   => 'Red Hat Display',
                        'Urbanist'          => 'Urbanist',
                        'Space Grotesk'     => 'Space Grotesk',
                        'Be Vietnam Pro'    => 'Be Vietnam Pro',
                        'Mulish'            => 'Mulish',
                        'Lato'              => 'Lato',
                        'Raleway'           => 'Raleway',
                        'Source Sans 3'     => 'Source Sans 3',
                        'Work Sans'         => 'Work Sans',
                    ])
                    ->default('Poppins')
                    ->native(false)
                    ->searchable(),
            ]);

        $components[] = Section::make('Layout')
            ->schema([
                TextInput::make('content_width')
                    ->label('Content Area Max Width')
                    ->default('1440px')
                    ->placeholder('e.g. 1440px, 1280px, 1600px')
                    ->helperText('Sets the maximum width of the main content area across all pages. Use px values (e.g. 1440px).'),
            ]);

        $components[] = Section::make('Border Radius')
            ->schema([
                Slider::make('card_border_radius')
                    ->label('Card Border Radius')
                    ->range(minValue: 0, maxValue: 20)
                    ->step(1)
                    ->default(8)
                    ->fillTrack()
                    ->tooltips()
                    ->live()
                    ->hint(fn (Get $get): string => ($get('card_border_radius') ?? '8') . 'px')
                    ->hintColor('primary')
                    ->helperText('Controls the corner roundness of all cards across the theme (0–20px).'),
                Slider::make('button_border_radius')
                    ->label('Button Border Radius')
                    ->range(minValue: 0, maxValue: 20)
                    ->step(1)
                    ->default(8)
                    ->fillTrack()
                    ->tooltips()
                    ->live()
                    ->hint(fn (Get $get): string => ($get('button_border_radius') ?? '8') . 'px')
                    ->hintColor('primary')
                    ->helperText('Controls the corner roundness of all buttons across the theme (0–20px).'),
            ]);

        $components[] = Section::make('Buttons')
            ->schema([
                Slider::make('button_padding_y')
                    ->label('Button Height')
                    ->range(minValue: 4, maxValue: 20)
                    ->step(1)
                    ->default(10)
                    ->fillTrack()
                    ->tooltips()
                    ->live()
                    ->hint(fn (Get $get): string => ($get('button_padding_y') ?? '10') . 'px')
                    ->hintColor('primary')
                    ->helperText('Vertical padding (height) of all buttons across the theme (4–20px).'),
            ]);

        return $components;
    }


    private function syncProductPagesToCategories($pages): void
    {
        if (is_string($pages)) {
            $pages = json_decode($pages, true);
        }

        if (! is_array($pages)) {
            return;
        }

        foreach ($pages as $page) {
            if (! is_array($page)) {
                continue;
            }
            if (($page['page_type'] ?? null) !== 'product') {
                continue;
            }
            $categoryId = $page['category_id'] ?? null;
            if (! $categoryId) {
                continue;
            }

            try {
                $category = \App\Models\Category::find($categoryId);
                if (! $category) {
                    continue;
                }

                $changed = false;

                if (! empty($page['title']) && $page['title'] !== $category->name) {
                    $category->name = $page['title'];
                    $changed = true;
                }
                if (array_key_exists('description', $page) && (string) $page['description'] !== (string) $category->description) {
                    $category->description = $page['description'];
                    $changed = true;
                }
                if (array_key_exists('image', $page) && $page['image'] !== $category->image) {
                    $category->image = $page['image'] ?: null;
                    $changed = true;
                }

                if ($changed) {
                    $category->save();
                }
            } catch (\Throwable $e) {
                Log::warning('[CitadelEditor] Failed to sync product page to category', [
                    'category_id' => $categoryId,
                    'error' => $e->getMessage(),
                ]);
            }
        }
    }

    private function buildCustomPagesSchema(array $settings): array
    {
        $components = [];

        $components[] = Placeholder::make('custom_pages_title')
            ->hiddenLabel()
            ->content(new HtmlString('<h2 style="font-size: 1.25rem; font-weight: 700; margin: 0;">Custom Pages</h2>'));

        $baseUrl = rtrim(url('/'), '/') . '/';

        
        $reservedSlugs = [
            'login', '2fa', 'register', 'password', 'oauth',
            'dashboard', 'invoices', 'tickets', 'services', 'account',
            'email', 'cart', 'products', 'admin', 'api', 'livewire',
            'storage', 'p', 'home', 'logout', 'verify', 'extensions',
        ];

        
        $categoryOptions = [];
        try {
            $categoryOptions = \App\Models\Category::query()
                ->whereHas('products', fn ($q) => $q->where('hidden', false))
                ->orderBy('sort')
                ->orderBy('name')
                ->pluck('name', 'id')
                ->toArray();
        } catch (\Throwable $e) {

        }

        
        $catSlugs = $this->categorySlugMap();
        $urlFromGet = function (callable $get) use ($baseUrl, $catSlugs): ?string {
            $isProduct = ($get('page_type') ?? 'custom') === 'product';
            if ($isProduct) {
                $strategy = $get('url_strategy') ?? 'replace';
                if ($strategy === 'separate') {
                    $slug = trim((string) ($get('slug') ?? ''));
                    return $slug !== '' ? $baseUrl . $slug : null;
                }
                $catId = $get('category_id');
                $catSlug = $catId ? ($catSlugs[(int) $catId] ?? null) : null;
                return $catSlug ? $baseUrl . 'products/' . $catSlug : null;
            }
            $slug = trim((string) ($get('slug') ?? ''));
            return $slug !== '' ? $baseUrl . $slug : null;
        };

        
        $components[] = Section::make('Pages')
            ->description('click Edit on a card to manage.')
            ->schema([
                View::make('citadel-editor::admin.pages.partials.custom-pages-list'),
            ])
            ->visible(fn (): bool => $this->cpEditingIndex === null);

        
        $components[] = View::make('citadel-editor::admin.pages.partials.custom-page-editor-header')
            ->visible(fn (): bool => $this->cpEditingIndex !== null);

        $components[] = Group::make([
                        Section::make('Page Type')
                            ->description('Choose how this page is built.')
                            ->schema([
                                Select::make('page_type')
                                    ->label('Page Type')
                                    ->hiddenLabel()
                                    ->options([
                                        'custom'  => 'Custom Page (full-width markdown content)',
                                        'product' => 'Product Page (marketing template tied to a category)',
                                    ])
                                    ->default('custom')
                                    ->required()
                                    ->live()
                                    ->dehydrated(),
                            ]),

                        
                        TextInput::make('title')
                            ->label('Page Title')
                            ->placeholder('e.g. About Us')
                            ->required()
                            ->live(onBlur: true)
                            ->afterStateUpdated(function ($state, callable $set, callable $get) {
                                if (! empty($get('slug'))) {
                                    return;
                                }
                                $slug = \Illuminate\Support\Str::slug((string) $state);
                                if ($slug !== '') {
                                    $set('slug', $slug);
                                }
                            })
                            ->visible(fn (callable $get) => ($get('page_type') ?? 'custom') === 'custom'),

                        TextInput::make('slug')
                            ->label('URL Slug')
                            ->placeholder('e.g. about-us')
                            ->prefix($baseUrl)
                            ->required()
                            ->live(onBlur: true)
                            ->rule(function () use ($reservedSlugs) {
                                return function (string $attribute, $value, \Closure $fail) use ($reservedSlugs) {
                                    if (in_array(strtolower((string) $value), $reservedSlugs, true)) {
                                        $fail('"' . $value . '" is a reserved URL and cannot be used. Try a different slug.');
                                    }
                                };
                            })
                            ->afterStateUpdated(fn ($state, callable $set) => $set('slug', \Illuminate\Support\Str::slug((string) $state)))
                            ->helperText('Lowercase letters, numbers and dashes only.')
                            ->visible(fn (callable $get) => ($get('page_type') ?? 'custom') === 'custom'),

                        Textarea::make('description')
                            ->label('Short Description')
                            ->placeholder('Brief summary shown beneath the page title and used for SEO meta description.')
                            ->rows(2)
                            ->maxLength(280)
                            ->visible(fn (callable $get) => ($get('page_type') ?? 'custom') === 'custom'),

                        MarkdownEditor::make('content')
                            ->label('Page Content')
                            ->required()
                            ->disableToolbarButtons([])
                            ->fileAttachmentsDisk('public')
                            ->fileAttachmentsDirectory('citadel/custom-pages')
                            ->columnSpanFull()
                            ->extraAttributes(['style' => 'min-height: 420px; overflow: hidden;'])
                            ->visible(fn (callable $get) => ($get('page_type') ?? 'custom') === 'custom'),

                        
                        Section::make('Category')
                            ->description('Pick which existing category this marketing page is for.')
                            ->schema([
                                Select::make('category_id')
                                    ->label('Category')
                                    ->options($categoryOptions)
                                    ->searchable()
                                    ->required()
                                    ->live()
                                    ->afterStateUpdated(function ($state, callable $set, callable $get) {
                                        if (! $state) {
                                            return;
                                        }
                                        try {
                                            $cat = \App\Models\Category::find($state);
                                            if (! $cat) {
                                                return;
                                            }
                                            
                                            if (empty($get('title'))) {
                                                $set('title', $cat->name);
                                            }
                                            if (empty($get('description'))) {
                                                $set('description', strip_tags((string) $cat->description));
                                            }
                                            if (empty($get('image'))) {
                                                $set('image', $cat->image);
                                            }
                                            if (empty($get('slug'))) {
                                                $set('slug', $cat->slug);
                                            }
                                        } catch (\Throwable $e) {}
                                    })
                                    ->helperText('Only categories that contain at least one visible product appear here.'),

                                Radio::make('url_strategy')
                                    ->label('URL Strategy')
                                    ->options([
                                        'replace'  => 'Replace the default category page (override /products/{slug})',
                                        'separate' => 'Serve at a separate root URL (you choose the slug below)',
                                    ])
                                    ->default('replace')
                                    ->required()
                                    ->live(),

                                TextInput::make('slug')
                                    ->label('Custom URL Slug')
                                    ->placeholder('e.g. vps')
                                    ->prefix($baseUrl)
                                    ->required()
                                    ->live(onBlur: true)
                                    ->rule(function () use ($reservedSlugs) {
                                        return function (string $attribute, $value, \Closure $fail) use ($reservedSlugs) {
                                            if (in_array(strtolower((string) $value), $reservedSlugs, true)) {
                                                $fail('"' . $value . '" is a reserved URL and cannot be used. Try a different slug.');
                                            }
                                        };
                                    })
                                    ->afterStateUpdated(fn ($state, callable $set) => $set('slug', \Illuminate\Support\Str::slug((string) $state)))
                                    ->visible(fn (callable $get) => ($get('url_strategy') ?? 'replace') === 'separate'),
                            ])
                            ->visible(fn (callable $get) => ($get('page_type') ?? 'custom') === 'product')
                            ->columnSpanFull(),

                        Section::make('URL & Navigation')
                            ->schema([
                                TextEntry::make('cp_public_url')
                                    ->label('Public URL')
                                    ->state(fn (callable $get) => $urlFromGet($get) ?? 'Set a slug or category to generate the URL.')
                                    ->copyable()
                                    ->copyMessage('URL copied to clipboard')
                                    ->copyMessageDuration(1500)
                                    ->helperText('This is where the page will be available. Click to copy.'),

                                Toggle::make('hide_from_store')
                                    ->label('Hide from store navigation dropdown')
                                    ->helperText('When on, this page will not appear in the Store menu in the nav bar. Useful when you want to link to it manually.')
                                    ->default(false)
                                    ->live()
                                    ->visible(fn (callable $get) => ($get('page_type') ?? 'custom') === 'product'),
                            ])
                            ->columnSpanFull(),

                        Section::make('Page Blocks')
                            ->description('Add and reorder content blocks. Each block has its own settings.')
                            ->schema([
                                Repeater::make('blocks')
                                    ->label('')
                                    ->hiddenLabel()
                                    ->addActionLabel('Add Block')
                                    ->reorderable()
                                    ->collapsible()
                                    ->collapsed()
                                    ->cloneable()
                                    ->defaultItems(0)
                                    ->itemLabel(function (array $state): ?string {
                                        $type = ucfirst($state['type'] ?? 'block');
                                        $headline = $state['heading'] ?? $state['title'] ?? null;
                                        return $headline ? "{$type}  {$headline}" : $type;
                                    })
                                    ->schema($this->blockSchemaComponents())
                                    ->columns(1),
                            ])
                            ->visible(fn (callable $get) => ($get('page_type') ?? 'custom') === 'product')
                            ->columnSpanFull(),

                        Toggle::make('enabled')
                            ->label('Published')
                            ->helperText('When off, visitors hitting the URL will see a 404.')
                            ->default(true)
                            ->inline(false),
        ])
            ->statePath('cp_editing')
            ->columns(1)
            ->visible(fn (): bool => $this->cpEditingIndex !== null);

        return $components;
    }



    /**
     *
     * @return array<int, mixed>
     */
    private function blockSchemaComponents(array $extraTypeOptions = [], array $extraComponents = [], array $extraStyles = []): array
    {
        return array_merge([
                                        Select::make('type')
                                            ->label('Block Type')
                                            ->options(array_merge([
                                                'hero'     => 'Hero',
                                                'products' => 'Products / Plans grid',
                                                'features' => 'Features grid',
                                                'faq'      => 'FAQ',
                                                'content'  => 'Content',
                                                'cta'      => 'Call to Action',
                                                'custom'   => 'Custom HTML / Hook',
                                            ], $extraTypeOptions))
                                            ->required()
                                            ->live()
                                            ->native(false),

                                        TextInput::make('anchor')
                                            ->label('Anchor (optional)')
                                            ->placeholder('e.g. pricing')
                                            ->helperText('Optional. Names this section so a button can scroll to it. Set a button link to #your-anchor (e.g. #pricing) to jump here. Use letters, numbers and hyphens — no spaces.')
                                            ->visible(fn (callable $get) => filled($get('type'))),

                                        $this->blockLayoutRadio('hero_style', 'Hero Layout', array_merge($this->heroStyles(), $extraStyles['hero_style'] ?? []), 'hero1', 1)
                                            ->helperText('Pick the layout for this hero section.')
                                            ->visible(fn (callable $get) => $get('type') === 'hero'),

                                        TextInput::make('hero_width')
                                            ->label('Hero Width Override')
                                            ->placeholder('e.g. 1200px, 1600px, 100%')
                                            ->helperText('Optional. Sets this hero’s content width, overriding the site base width and the layout’s built-in width. Use any CSS width (e.g. 1200px, 90rem, 100%). Leave empty to use the site content width.')
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && ($get('hero_style') ?? 'hero1') !== 'm2hero'),

                                        TextInput::make('heading')
                                            ->label('Hero Title')
                                            ->placeholder('VPS hosting on DigitalOcean')
                                            ->helperText('Main headline shown in the hero.')
                                            ->visible(fn (callable $get) => $get('type') === 'hero'),
                                        Textarea::make('subheading')
                                            ->label('Hero Description')
                                            ->rows(2)
                                            ->helperText('Short description shown below the title. Leave empty to hide.')
                                            ->visible(fn (callable $get) => $get('type') === 'hero'),
                                        Textarea::make('hero2_list')
                                            ->label('Feature List')
                                            ->rows(4)
                                            ->placeholder("Ultrafast Virtual Servers with Dedicated Resources\nScalable Plans That Grow with Your Needs\n24/7 Expert Support")
                                            ->helperText('One bullet per line, each shown with a check icon. Leave empty to hide.')
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && in_array($get('hero_style') ?? 'hero1', ['hero2', 'hero3'], true)),
                                        TextInput::make('button_text')
                                            ->label('Button Text')
                                            ->placeholder('Get Started')
                                            ->helperText('Leave empty to hide the button.')
                                            ->visible(fn (callable $get) => $get('type') === 'hero'),
                                        TextInput::make('button_link')
                                            ->label('Button Link')
                                            ->placeholder('/cart or https://example.com')
                                            ->helperText('Leave empty to link to the page\'s category.')
                                            ->visible(fn (callable $get) => $get('type') === 'hero'),

                                    
                                        Select::make('button_style')
                                            ->label('Primary Button Style')
                                            ->options([
                                                'primary'   => 'Primary background',
                                                'secondary' => 'Secondary background',
                                                'none'      => 'No background',
                                            ])
                                            ->default('primary')
                                            ->native(false)
                                            ->live()
                                            ->helperText('Background style for the first button. "No background" shows an animated arrow instead of an icon.')
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && in_array($get('hero_style') ?? 'hero1', ['hero2', 'hero3', 'hero4', 'hero5'], true)),
                                        Textarea::make('button_icon')
                                            ->label('Primary Button Icon (SVG)')
                                            ->rows(3)
                                            ->placeholder('<svg ...>...</svg>')
                                            ->helperText('Optional. Paste an SVG to show with the button text.')
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && in_array($get('hero_style') ?? 'hero1', ['hero2', 'hero3', 'hero4', 'hero5'], true) && ($get('button_style') ?? 'primary') !== 'none'),
                                        Select::make('button_icon_position')
                                            ->label('Primary Icon Position')
                                            ->options(['before' => 'Before text', 'after' => 'After text'])
                                            ->default('before')
                                            ->native(false)
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && in_array($get('hero_style') ?? 'hero1', ['hero2', 'hero3', 'hero4', 'hero5'], true) && ($get('button_style') ?? 'primary') !== 'none'),
                                        Toggle::make('button_icon_bg')
                                            ->label('Background behind primary icon')
                                            ->default(false)
                                            ->helperText('Adds a rounded chip (same colour as the hero background) behind the icon.')
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && in_array($get('hero_style') ?? 'hero1', ['hero2', 'hero3', 'hero4', 'hero5'], true) && ($get('button_style') ?? 'primary') !== 'none'),
                                        TextInput::make('button2_text')
                                            ->label('Secondary Button Text')
                                            ->placeholder('Learn More')
                                            ->helperText('Leave empty to hide the second button.')
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && in_array($get('hero_style') ?? 'hero1', ['hero2', 'hero3', 'hero4', 'hero5'], true)),
                                        TextInput::make('button2_link')
                                            ->label('Secondary Button Link')
                                            ->placeholder('/contact or https://example.com')
                                            ->helperText('Leave empty to link to the page\'s category.')
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && in_array($get('hero_style') ?? 'hero1', ['hero2', 'hero3', 'hero4', 'hero5'], true)),
                                        Select::make('button2_style')
                                            ->label('Secondary Button Style')
                                            ->options([
                                                'primary'   => 'Primary background',
                                                'secondary' => 'Secondary background',
                                                'none'      => 'No background',
                                            ])
                                            ->default('secondary')
                                            ->native(false)
                                            ->live()
                                            ->helperText('Background style for the second button. "No background" shows an animated arrow instead of an icon.')
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && in_array($get('hero_style') ?? 'hero1', ['hero2', 'hero3', 'hero4', 'hero5'], true)),
                                        Textarea::make('button2_icon')
                                            ->label('Secondary Button Icon (SVG)')
                                            ->rows(3)
                                            ->placeholder('<svg ...>...</svg>')
                                            ->helperText('Optional. Paste an SVG to show with the button text.')
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && in_array($get('hero_style') ?? 'hero1', ['hero2', 'hero3', 'hero4', 'hero5'], true) && ($get('button2_style') ?? 'secondary') !== 'none'),
                                        Select::make('button2_icon_position')
                                            ->label('Secondary Icon Position')
                                            ->options(['before' => 'Before text', 'after' => 'After text'])
                                            ->default('before')
                                            ->native(false)
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && in_array($get('hero_style') ?? 'hero1', ['hero2', 'hero3', 'hero4', 'hero5'], true) && ($get('button2_style') ?? 'secondary') !== 'none'),
                                        Toggle::make('button2_icon_bg')
                                            ->label('Background behind secondary icon')
                                            ->default(false)
                                            ->helperText('Adds a rounded chip (same colour as the hero background) behind the icon.')
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && in_array($get('hero_style') ?? 'hero1', ['hero2', 'hero3', 'hero4', 'hero5'], true) && ($get('button2_style') ?? 'secondary') !== 'none'),

                                        
                                        Toggle::make('trustpilot_enabled')
                                            ->label('Show Trustpilot Rating')
                                            ->default(false)
                                            ->live()
                                            ->helperText('Show a Trustpilot rating above the title.')
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && in_array($get('hero_style') ?? 'hero1', ['hero2', 'hero3'], true)),
                                        Select::make('trustpilot_style')
                                            ->label('Trustpilot Style')
                                            ->options([
                                                'two_line' => 'Two lines (Trustpilot, then text below)',
                                                'one_line' => 'One line (Rated … on Trustpilot)',
                                            ])
                                            ->default('two_line')
                                            ->native(false)
                                            ->live()
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && in_array($get('hero_style') ?? 'hero1', ['hero2', 'hero3'], true) && $get('trustpilot_enabled')),
                                        TextInput::make('trustpilot_text')
                                            ->label('Rating Text')
                                            ->placeholder('Excellent  4/5 stars')
                                            ->helperText('Two-line: shown under "Trustpilot". One-line: sits between "Rated" and "on Trustpilot"; include a rating like "4/5" or "4.5 stars" and the star graphic is inserted automatically.')
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && in_array($get('hero_style') ?? 'hero1', ['hero2', 'hero3'], true) && $get('trustpilot_enabled')),

                                        
                                        FileUpload::make('hero2_image')
                                            ->label('Side Image')
                                            ->disk('public')
                                            ->directory('citadel/custom-pages/hero')
                                            ->image()
                                            ->imageEditor()
                                            ->maxSize(4096)
                                            ->helperText('Image shown on the right side of the split layout (max 4 MB).')
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && in_array($get('hero_style') ?? 'hero1', ['hero2', 'hero3'], true)),
                                        Select::make('hero2_bg_type')
                                            ->label('Section Background')
                                            ->options([
                                                'primary' => 'Primary (dark with gradient)',
                                                'plain'   => 'Plain color',
                                            ])
                                            ->default('primary')
                                            ->native(false)
                                            ->live()
                                            ->helperText('Background of the hero section.')
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && in_array($get('hero_style') ?? 'hero1', ['hero2', 'hero3'], true)),
                                        ColorPicker::make('hero2_bg_color')
                                            ->label('Background Color')
                                            ->hsl()
                                            ->default('hsl(220, 90%, 41%)')
                                            ->helperText('Used when the background is set to Plain color.')
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && in_array($get('hero_style') ?? 'hero1', ['hero2', 'hero3'], true) && ($get('hero2_bg_type') ?? 'theme') === 'plain'),

                                        Select::make('background_type')
                                            ->label('Background')
                                            ->options([
                                                'none'          => 'No background',
                                                'curved'        => 'Curved gradient',
                                                'image'         => 'Background image',
                                                'image_overlay' => 'Background image with color overlay',
                                            ])
                                            ->default('curved')
                                            ->native(false)
                                            ->live()
                                            ->helperText('Choose how the hero background should be rendered.')
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && ! in_array($get('hero_style') ?? 'hero1', ['hero2', 'hero3', 'hero4', 'hero5', 'm2hero'], true)),
                                        FileUpload::make('background_image')
                                            ->label('Background Image')
                                            ->disk('public')
                                            ->directory('citadel/custom-pages/hero')
                                            ->image()
                                            ->maxSize(4096)
                                            ->helperText('Used when background is set to image or image with overlay (max 4 MB).')
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && ! in_array($get('hero_style') ?? 'hero1', ['hero2', 'hero3', 'hero4', 'hero5', 'm2hero'], true) && in_array($get('background_type') ?? 'curved', ['image', 'image_overlay'], true)),
                                        Select::make('overlay_color')
                                            ->label('Overlay Color')
                                            ->options([
                                                'primary'    => 'Primary color',
                                                'background' => 'Page background color',
                                            ])
                                            ->default('primary')
                                            ->native(false)
                                            ->helperText('Color used for the gradient overlaid on the background image.')
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && ! in_array($get('hero_style') ?? 'hero1', ['hero2', 'hero3', 'hero4', 'hero5', 'm2hero'], true) && ($get('background_type') ?? 'curved') === 'image_overlay'),

                                        
                                        Select::make('hero4_bg_type')
                                            ->label('Background')
                                            ->options([
                                                'custom_color' => 'Custom color',
                                                'primary'      => 'Primary color',
                                                'gradient'     => 'Custom gradient (3 colors)',
                                                'image'        => 'Background image',
                                            ])
                                            ->default('primary')
                                            ->native(false)
                                            ->live()
                                            ->helperText('Background for this hero.')
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && in_array($get('hero_style') ?? 'hero1', ['hero4', 'hero5'], true)),
                                        ColorPicker::make('hero4_bg_color')
                                            ->label('Background Color')
                                            ->hsl()
                                            ->default('hsl(220, 90%, 41%)')
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && in_array($get('hero_style') ?? 'hero1', ['hero4', 'hero5'], true) && ($get('hero4_bg_type') ?? 'primary') === 'custom_color'),
                                        ColorPicker::make('hero4_grad_1')
                                            ->label('Gradient Color 1')
                                            ->hsl()
                                            ->default('hsl(220, 90%, 41%)')
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && in_array($get('hero_style') ?? 'hero1', ['hero4', 'hero5'], true) && ($get('hero4_bg_type') ?? 'primary') === 'gradient'),
                                        ColorPicker::make('hero4_grad_2')
                                            ->label('Gradient Color 2')
                                            ->hsl()
                                            ->default('hsl(265, 85%, 50%)')
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && in_array($get('hero_style') ?? 'hero1', ['hero4', 'hero5'], true) && ($get('hero4_bg_type') ?? 'primary') === 'gradient'),
                                        ColorPicker::make('hero4_grad_3')
                                            ->label('Gradient Color 3')
                                            ->hsl()
                                            ->default('hsl(190, 90%, 45%)')
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && in_array($get('hero_style') ?? 'hero1', ['hero4', 'hero5'], true) && ($get('hero4_bg_type') ?? 'primary') === 'gradient'),
                                        Select::make('hero4_image_source')
                                            ->label('Background Image Source')
                                            ->options([
                                                'category' => 'Category image',
                                                'custom'   => 'Custom image',
                                            ])
                                            ->default('category')
                                            ->native(false)
                                            ->live()
                                            ->helperText('Use the page category\'s image, or upload a custom one.')
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && in_array($get('hero_style') ?? 'hero1', ['hero4', 'hero5'], true) && ($get('hero4_bg_type') ?? 'primary') === 'image'),
                                        FileUpload::make('hero4_image')
                                            ->label('Background Image')
                                            ->disk('public')
                                            ->directory('citadel/custom-pages/hero')
                                            ->image()
                                            ->maxSize(4096)
                                            ->helperText('Used when image source is Custom (max 4 MB). An overlay is applied for readability.')
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && in_array($get('hero_style') ?? 'hero1', ['hero4', 'hero5'], true) && ($get('hero4_bg_type') ?? 'primary') === 'image' && ($get('hero4_image_source') ?? 'category') === 'custom'),
                                        
                                        FileUpload::make('hero5_image')
                                            ->label('Screenshot Image')
                                            ->disk('public')
                                            ->directory('citadel/custom-pages/hero')
                                            ->image()
                                            ->imageEditor()
                                            ->maxSize(6144)
                                            ->helperText('Large image shown beside the text  it overflows off the right edge (max 6 MB).')
                                            ->visible(fn (callable $get) => $get('type') === 'hero' && ($get('hero_style') ?? 'hero1') === 'hero5'),

                                        Placeholder::make('products_domain_registration_notice')
                                            ->hiddenLabel()
                                            ->content(new HtmlString(
                                                '<div style="padding:0.9rem 1.1rem;background:hsl(var(--color-primary) / 0.08);border:1.5px solid hsl(var(--color-primary) / 0.35);border-radius:0.5rem;line-height:1.55;">'
                                                . '<p style="margin:0;font-size:0.9rem;font-weight:600;">Domain Registration category</p>'
                                                . '<p style="margin:0.4rem 0 0;font-size:0.85rem;color:rgba(107,114,128,0.95);">This block has no settings. The frontend will render the domain search bar from the DomainNameAPI extension automatically.</p>'
                                                . '</div>'
                                            ))
                                            ->visible(fn (callable $get) => $get('type') === 'products' && $this->isDomainRegistrationCategoryId($get('../../category_id'))),

                                        Select::make('block_category_id')
                                            ->label('Category')
                                            ->options(fn () => \App\Models\Category::orderBy('sort')->orderBy('name')->pluck('name', 'id')->toArray())
                                            ->searchable()
                                            ->native(false)
                                            ->live()
                                            ->afterStateUpdated(fn (Set $set) => $set('product_ids', []))
                                            ->helperText('Which category\'s products to show. On the home page this is required; on a product custom page, leave empty to use the page\'s category.')
                                            ->visible(fn (callable $get) => $get('type') === 'products' && ($get('grid_style') ?? 'grid1') !== 'm2plans'),

                                        $this->blockLayoutRadio('grid_style', 'Grid Layout', array_merge($this->productGridStyles(), $extraStyles['grid_style'] ?? []), 'grid1', 1)
                                            ->helperText('Pick the layout for this plans grid.')
                                            ->visible(fn (callable $get) => $get('type') === 'products' && ! $this->isDomainRegistrationCategoryId($get('../../category_id'))),

                                        Toggle::make('show_terms')
                                            ->label('Show billing term switcher')
                                            ->helperText('Adds a switcher above the plans so visitors can change billing cycle and see prices update. Only terms available on every shown product are listed.')
                                            ->default(false)
                                            ->visible(fn (callable $get) => $get('type') === 'products' && ($get('grid_style') ?? 'grid1') !== 'm2plans' && ! $this->isDomainRegistrationCategoryId($get('../../category_id'))),

                                        
                                        Select::make('row_front_type')
                                            ->label('Front Box')
                                            ->options([
                                                'product_image'  => 'Product Image',
                                                'location_flags' => 'Location Flags',
                                            ])
                                            ->default('product_image')
                                            ->native(false)
                                            ->live()
                                            ->helperText('What to show in the box on the left of each row.')
                                            ->visible(fn (callable $get) => $get('type') === 'products' && ($get('grid_style') ?? 'grid1') === 'grid2' && ! $this->isDomainRegistrationCategoryId($get('../../category_id'))),
                                        FileUpload::make('row_front_flags')
                                            ->label('Location Flags')
                                            ->multiple()
                                            ->reorderable()
                                            ->image()
                                            ->imageEditor()
                                            ->disk('public')
                                            ->directory('citadel/custom-pages/flags')
                                            ->visibility('public')
                                            ->helperText('Upload flag images for the locations these plans are available in. Shown as overlapping circles.')
                                            ->visible(fn (callable $get) => $get('type') === 'products' && ($get('grid_style') ?? 'grid1') === 'grid2' && ($get('row_front_type') ?? 'product_image') === 'location_flags' && ! $this->isDomainRegistrationCategoryId($get('../../category_id'))),

                                        Textarea::make('row_spec_template')
                                            ->label('Spec Template')
                                            ->rows(4)
                                            ->placeholder("CPU\nRAM\nStorage\nTraffic")
                                            ->helperText('One label per line. For each label we find a matching "Label: value" line in the product description and show it as a spec inside the card. Leave empty to show the description as plain text instead.')
                                            ->visible(fn (callable $get) => $get('type') === 'products' && ($get('grid_style') ?? 'grid1') === 'grid2' && ! $this->isDomainRegistrationCategoryId($get('../../category_id'))),

                                        Select::make('row_price_style')
                                            ->label('Price & Action Style')
                                            ->options([
                                                'style1' => 'Style 1  price left, button right',
                                            ])
                                            ->default('style1')
                                            ->native(false)
                                            ->helperText('Layout of the price/button area on the right of each row.')
                                            ->visible(fn (callable $get) => $get('type') === 'products' && ($get('grid_style') ?? 'grid1') === 'grid2' && ! $this->isDomainRegistrationCategoryId($get('../../category_id'))),

                                        Toggle::make('row_popular_enabled')
                                            ->label('Mark a Plan as Most Popular')
                                            ->helperText('Highlight one row with the primary color, contrasting text, and a "Most Popular" badge.')
                                            ->default(false)
                                            ->live()
                                            ->visible(fn (callable $get) => $get('type') === 'products' && ($get('grid_style') ?? 'grid1') === 'grid2' && ! $this->isDomainRegistrationCategoryId($get('../../category_id'))),
                                        TextInput::make('row_popular_number')
                                            ->label('Popular Plan Number')
                                            ->numeric()
                                            ->minValue(1)
                                            ->default(1)
                                            ->helperText('Which row to highlight, by position (1 = first row shown).')
                                            ->visible(fn (callable $get) => $get('type') === 'products' && ($get('grid_style') ?? 'grid1') === 'grid2' && (bool) $get('row_popular_enabled') && ! $this->isDomainRegistrationCategoryId($get('../../category_id'))),

                                        TextInput::make('heading')
                                            ->label('Plans Section Title')
                                            ->placeholder('Simple, Transparent Pricing')
                                            ->visible(fn (callable $get) => $get('type') === 'products' && ! $this->isDomainRegistrationCategoryId($get('../../category_id'))),
                                        Textarea::make('description')
                                            ->label('Plans Section Description')
                                            ->rows(2)
                                            ->helperText('Optional description shown below the title.')
                                            ->visible(fn (callable $get) => $get('type') === 'products' && ! $this->isDomainRegistrationCategoryId($get('../../category_id'))),
                                        TextInput::make('button_text')
                                            ->label('Card Button Text')
                                            ->placeholder('Get Started')
                                            ->default('Get Started')
                                            ->visible(fn (callable $get) => $get('type') === 'products' && ! $this->isDomainRegistrationCategoryId($get('../../category_id'))),
                                        Select::make('icon_style')
                                            ->label('Icon Style')
                                            ->options([
                                                'none'       => 'None',
                                                'right'      => 'Right (next to name & price)',
                                                'top'        => 'Top (centered above name)',
                                                'background' => 'Background (with gradient overlay)',
                                                'corner'     => 'Corner (tilted, partially visible)',
                                            ])
                                            ->default('none')
                                            ->native(false)
                                            ->helperText('How product/category icons are displayed on plan cards.')
                                            ->visible(fn (callable $get) => $get('type') === 'products' && ($get('grid_style') ?? 'grid1') !== 'grid2' && ! $this->isDomainRegistrationCategoryId($get('../../category_id'))),
                                        Select::make('popular')
                                            ->label('Popular Plan')
                                            ->options([
                                                ''  => 'None',
                                                '1' => 'Plan 1',
                                                '2' => 'Plan 2',
                                                '3' => 'Plan 3',
                                                '4' => 'Plan 4',
                                            ])
                                            ->default('')
                                            ->native(false)
                                            ->helperText('Highlight one card (by position) as Popular.')
                                            ->live()
                                            ->visible(fn (callable $get) => $get('type') === 'products' && ($get('grid_style') ?? 'grid1') !== 'grid2' && ! $this->isDomainRegistrationCategoryId($get('../../category_id'))),
                                        Select::make('popular_style')
                                            ->label('Popular Card Style')
                                            ->options([
                                                'solid'         => 'Plain color',
                                                'gradient'      => 'Gradient',
                                                'dark_gradient' => 'Dark gradient',
                                            ])
                                            ->default('solid')
                                            ->native(false)
                                            ->helperText('Plain color: solid primary background. Gradient: diagonal primary gradient. Dark gradient: dark card with a primary color glow fading in from the top.')
                                            ->visible(fn (callable $get) => $get('type') === 'products' && ($get('grid_style') ?? 'grid1') !== 'grid2' && ! empty($get('popular')) && ! $this->isDomainRegistrationCategoryId($get('../../category_id'))),
                                        Placeholder::make('products_help')
                                            ->hiddenLabel()
                                            ->content(new HtmlString('<p style="font-size:0.8rem;color:rgba(107,114,128,0.9);margin:0;">Choose which products from the selected category to feature. Leave empty to show all visible products (up to 4).</p>'))
                                            ->visible(fn (callable $get) => $get('type') === 'products' && ! $this->isDomainRegistrationCategoryId($get('../../category_id'))),
                                        Select::make('product_ids')
                                            ->label('Featured Products')
                                            ->multiple()
                                            ->searchable()
                                            ->options(function (callable $get) {
                                                $categoryId = $get('block_category_id') ?: $get('../../category_id');
                                                if (! $categoryId) {
                                                    return [];
                                                }
                                                try {
                                                    return \App\Models\Product::where('category_id', $categoryId)
                                                        ->where('hidden', false)
                                                        ->orderBy('sort')
                                                        ->orderBy('name')
                                                        ->pluck('name', 'id')
                                                        ->toArray();
                                                } catch (\Throwable $e) {
                                                    return [];
                                                }
                                            })
                                            ->visible(fn (callable $get) => $get('type') === 'products' && ! $this->isDomainRegistrationCategoryId($get('../../category_id'))),
                                        Toggle::make('bottom_button')
                                            ->label('Bottom Button')
                                            ->helperText('Show a centered button below the plans grid.')
                                            ->default(false)
                                            ->live()
                                            ->visible(fn (callable $get) => $get('type') === 'products' && ! $this->isDomainRegistrationCategoryId($get('../../category_id'))),
                                        TextInput::make('bottom_button_text')
                                            ->label('Bottom Button Text')
                                            ->placeholder('e.g. View All Plans')
                                            ->visible(fn (callable $get) => $get('type') === 'products' && $get('bottom_button') && ! $this->isDomainRegistrationCategoryId($get('../../category_id'))),
                                        TextInput::make('bottom_button_link')
                                            ->label('Bottom Button Link')
                                            ->placeholder('e.g. /store or https://example.com')
                                            ->visible(fn (callable $get) => $get('type') === 'products' && $get('bottom_button') && ! $this->isDomainRegistrationCategoryId($get('../../category_id'))),

                                        Toggle::make('section_footer_enabled')
                                            ->label('Show Section Footer')
                                            ->helperText('A small centered note shown below the plans (e.g. a money-back guarantee).')
                                            ->default(false)
                                            ->live()
                                            ->visible(fn (callable $get) => $get('type') === 'products' && ! $this->isDomainRegistrationCategoryId($get('../../category_id'))),
                                        Select::make('section_footer_icon_type')
                                            ->label('Footer Icon Type')
                                            ->options([
                                                'remix' => 'Remix Icon',
                                                'svg'   => 'Custom SVG',
                                            ])
                                            ->default('remix')
                                            ->native(false)
                                            ->live()
                                            ->visible(fn (callable $get) => $get('type') === 'products' && (bool) $get('section_footer_enabled') && ! $this->isDomainRegistrationCategoryId($get('../../category_id'))),
                                        TextInput::make('section_footer_icon')
                                            ->label('Footer Icon')
                                            ->placeholder('ri-shield-check-line')
                                            ->default('ri-shield-check-line')
                                            ->helperText('Remix Icon name (e.g., ri-shield-check-line). Browse at https://remixicon.com. Leave empty to hide.')
                                            ->visible(fn (callable $get) => $get('type') === 'products' && (bool) $get('section_footer_enabled') && ($get('section_footer_icon_type') ?? 'remix') === 'remix' && ! $this->isDomainRegistrationCategoryId($get('../../category_id'))),
                                        Textarea::make('section_footer_icon_svg')
                                            ->label('Footer Icon SVG')
                                            ->rows(4)
                                            ->placeholder('<svg ...>...</svg>')
                                            ->helperText('Paste raw SVG markup. Use fill="currentColor" inside it to match the theme color.')
                                            ->visible(fn (callable $get) => $get('type') === 'products' && (bool) $get('section_footer_enabled') && ($get('section_footer_icon_type') ?? 'remix') === 'svg' && ! $this->isDomainRegistrationCategoryId($get('../../category_id'))),
                                        TextInput::make('section_footer_title')
                                            ->label('Footer Title')
                                            ->placeholder('30-day money-back guarantee')
                                            ->visible(fn (callable $get) => $get('type') === 'products' && (bool) $get('section_footer_enabled') && ! $this->isDomainRegistrationCategoryId($get('../../category_id'))),
                                        Textarea::make('section_footer_text')
                                            ->label('Footer Text')
                                            ->rows(2)
                                            ->placeholder("Don't like what you got? Cancel within the first 30 days of service and get a full refund.")
                                            ->visible(fn (callable $get) => $get('type') === 'products' && (bool) $get('section_footer_enabled') && ! $this->isDomainRegistrationCategoryId($get('../../category_id'))),

                                        
                                        $this->blockLayoutRadio('feature_style', 'Features Layout', array_merge($this->featureStyles(), $extraStyles['feature_style'] ?? []), 'feature1', 1)
                                            ->helperText('Pick the layout for this features section.')
                                            ->visible(fn (callable $get) => $get('type') === 'features'),
                                        TextInput::make('heading')
                                            ->label('Features Section Title')
                                            ->placeholder('Every plan includes everything you need')
                                            ->visible(fn (callable $get) => $get('type') === 'features'),
                                        Textarea::make('description')
                                            ->label('Features Section Description')
                                            ->rows(2)
                                            ->visible(fn (callable $get) => $get('type') === 'features' && ($get('feature_style') ?? 'feature1') !== 'feature3'),
                                        Toggle::make('icon_bg')
                                            ->label('Enable Icon Backgrounds')
                                            ->default(true)
                                            ->helperText('Show a background behind the feature icons.')
                                            ->visible(fn (callable $get) => $get('type') === 'features' && ($get('feature_style') ?? 'feature1') === 'feature1'),
                                        Repeater::make('items')
                                            ->label('Features')
                                            ->addActionLabel('Add Feature')
                                            ->collapsible()
                                            ->collapsed()
                                            ->reorderable()
                                            ->cloneable()
                                            ->defaultItems(0)
                                            ->itemLabel(fn (array $state): ?string => $state['title'] ?? 'Untitled')
                                            ->schema([
                                                TextInput::make('title')
                                                    ->label('Title')
                                                    ->required()
                                                    ->live(onBlur: true)
                                                    ->maxLength(255),
                                                Textarea::make('description')
                                                    ->label('Description')
                                                    ->rows(2),
                                                Select::make('icon_type')
                                                    ->label('Icon Type')
                                                    ->options([
                                                        'citadel' => 'Citadel Icons',
                                                        'remix'   => 'Remix Icons',
                                                    ])
                                                    ->default('citadel')
                                                    ->native(false)
                                                    ->live(),
                                                Radio::make('icon_citadel')
                                                    ->label('Citadel Icon')
                                                    ->options(fn () => $this->getCitadelIcons())
                                                    ->columns(3)
                                                    ->extraAttributes(['class' => 'citadel-icon-picker citadel-icon-picker--grid-3'])
                                                    ->dehydratedWhenHidden()
                                                    ->visible(fn (callable $get) => ($get('icon_type') ?? 'citadel') === 'citadel'),
                                                TextInput::make('icon_remix')
                                                    ->label('Remix Icon')
                                                    ->helperText('Enter a Remix Icon name (e.g., ri-shield-check-line)')
                                                    ->visible(fn (callable $get) => $get('icon_type') === 'remix'),
                                            ])
                                            ->visible(fn (callable $get) => $get('type') === 'features' && ($get('feature_style') ?? 'feature1') === 'feature1'),

                                        
                                        Select::make('feature2_orientation')
                                            ->label('Image Orientation')
                                            ->options([
                                                'image_left'  => 'Image on left',
                                                'image_right' => 'Image on right',
                                            ])
                                            ->default('image_right')
                                            ->native(false)
                                            ->visible(fn (callable $get) => $get('type') === 'features' && ($get('feature_style') ?? 'feature1') === 'feature2'),
                                        Select::make('feature2_icon_type')
                                            ->label('Point Icons')
                                            ->options([
                                                'remix' => 'Remix Icons',
                                                'svg'   => 'SVG (paste)',
                                            ])
                                            ->default('remix')
                                            ->native(false)
                                            ->live()
                                            ->helperText('Which icon field shows on each point.')
                                            ->visible(fn (callable $get) => $get('type') === 'features' && ($get('feature_style') ?? 'feature1') === 'feature2'),
                                        TextInput::make('feature2_eyebrow')
                                            ->label('Eyebrow')
                                            ->placeholder('Deploy faster')
                                            ->helperText('Small highlighted text shown above the title.')
                                            ->visible(fn (callable $get) => $get('type') === 'features' && ($get('feature_style') ?? 'feature1') === 'feature2'),
                                        Repeater::make('feature2_points')
                                            ->label('Points')
                                            ->addActionLabel('Add Point')
                                            ->collapsible()
                                            ->collapsed()
                                            ->reorderable()
                                            ->defaultItems(0)
                                            ->itemLabel(fn (array $state): ?string => trim(strip_tags($state['text'] ?? '')) ?: 'Point')
                                            ->schema([
                                                RichEditor::make('text')
                                                    ->label('Text')
                                                    ->toolbarButtons(['bold', 'italic'])
                                                    ->helperText('Bold the lead-in (e.g. "Push to deploy.")  it shows as the title; the rest reads as the description.'),
                                                TextInput::make('icon_remix')
                                                    ->label('Remix Icon')
                                                    ->placeholder('ri-checkbox-circle-line')
                                                    ->helperText('Enter a Remix Icon name.')
                                                    ->visible(fn (callable $get) => ($get('../../feature2_icon_type') ?? 'remix') === 'remix'),
                                                Textarea::make('icon_svg')
                                                    ->label('Icon SVG')
                                                    ->rows(3)
                                                    ->placeholder('<svg ...>...</svg>')
                                                    ->visible(fn (callable $get) => ($get('../../feature2_icon_type') ?? 'remix') === 'svg'),
                                            ])
                                            ->visible(fn (callable $get) => $get('type') === 'features' && ($get('feature_style') ?? 'feature1') === 'feature2'),
                                        FileUpload::make('feature2_image')
                                            ->label('Side Image')
                                            ->disk('public')
                                            ->directory('citadel/custom-pages/features')
                                            ->image()
                                            ->imageEditor()
                                            ->maxSize(4096)
                                            ->helperText('Shown on the chosen side. Best a bit wider than tall (~50px).')
                                            ->visible(fn (callable $get) => $get('type') === 'features' && ($get('feature_style') ?? 'feature1') === 'feature2'),

                                        
                                        TextInput::make('feature3_eyebrow')
                                            ->label('Eyebrow')
                                            ->placeholder('Why host with us')
                                            ->helperText('Small highlighted text shown above the title.')
                                            ->visible(fn (callable $get) => $get('type') === 'features' && ($get('feature_style') ?? 'feature1') === 'feature3'),
                                        Repeater::make('feature3_cards')
                                            ->label('Cards')
                                            ->addActionLabel('Add Card')
                                            ->maxItems(5)
                                            ->collapsible()
                                            ->collapsed()
                                            ->reorderable()
                                            ->itemLabel(fn (array $state): ?string => ($state['title'] ?? null) ?: 'Card')
                                            ->default([
                                                ['title' => 'Powered by high-end hardware', 'description' => 'NVMe SSDs, the latest-generation CPUs and DDR5 memory keep your services fast and responsive.'],
                                                ['title' => 'Up and running in minutes', 'description' => 'A simple checkout deploys your server instantly  no complicated setup and no waiting around.'],
                                                ['title' => 'Real humans, 24/7', 'description' => 'Reach our team any time over ticket or Discord and get help from people who actually know hosting.'],
                                                ['title' => 'All your favourite games', 'description' => 'Minecraft, Hytale, FiveM, RedM, Rust, Palworld and many more  one-click installs for all of them.'],
                                                ['title' => 'Low latency, worldwide', 'description' => 'Deploy close to your players with data centres across multiple regions around the globe.'],
                                            ])
                                            ->schema([
                                                TextInput::make('title')
                                                    ->label('Title')
                                                    ->placeholder('Powered by high-end hardware'),
                                                Textarea::make('description')
                                                    ->label('Description')
                                                    ->rows(2),
                                                FileUpload::make('image')
                                                    ->label('Image')
                                                    ->disk('public')
                                                    ->directory('citadel/custom-pages/features')
                                                    ->image()
                                                    ->imageEditor()
                                                    ->maxSize(4096)
                                                    ->helperText('Shown at the bottom of the card. Used for dark mode (and for both modes unless a light-mode image is added below).'),
                                                Toggle::make('image_light_enabled')
                                                    ->label('Separate light-mode image')
                                                    ->live()
                                                    ->helperText('Show a different image when the site is in light mode.'),
                                                FileUpload::make('image_light')
                                                    ->label('Light-mode image')
                                                    ->disk('public')
                                                    ->directory('citadel/custom-pages/features')
                                                    ->image()
                                                    ->imageEditor()
                                                    ->maxSize(4096)
                                                    ->helperText('Used only in light mode.')
                                                    ->visible(fn (callable $get) => (bool) $get('image_light_enabled')),
                                            ])
                                            ->visible(fn (callable $get) => $get('type') === 'features' && ($get('feature_style') ?? 'feature1') === 'feature3'),


                                        $this->blockLayoutRadio('faq_style', 'FAQ Layout', array_merge($this->faqStyles(), $extraStyles['faq_style'] ?? []), 'faq1', 1)
                                            ->helperText('Pick the layout for this FAQ section.')
                                            ->visible(fn (callable $get) => $get('type') === 'faq'),
                                        TextInput::make('heading')
                                            ->label('FAQ Section Title')
                                            ->placeholder('Frequently Asked Questions')
                                            ->visible(fn (callable $get) => $get('type') === 'faq'),
                                        Textarea::make('description')
                                            ->label('FAQ Section Description')
                                            ->rows(2)
                                            ->placeholder('Find answers to the most common questions about our services.')
                                            ->visible(fn (callable $get) => $get('type') === 'faq'),
                                        Repeater::make('items')
                                            ->label('FAQs')
                                            ->addActionLabel('Add FAQ')
                                            ->collapsible()
                                            ->collapsed()
                                            ->reorderable()
                                            ->cloneable()
                                            ->defaultItems(0)
                                            ->itemLabel(fn (array $state): ?string => $state['question'] ?? 'New Question')
                                            ->schema([
                                                TextInput::make('question')
                                                    ->label('Question')
                                                    ->required()
                                                    ->live(onBlur: true)
                                                    ->maxLength(500),
                                                Textarea::make('answer')
                                                    ->label('Answer')
                                                    ->required()
                                                    ->rows(3),
                                            ])
                                            ->visible(fn (callable $get) => $get('type') === 'faq'),

                                        
                                        $this->blockLayoutRadio('content_style', 'Content Layout', array_merge($this->contentStyles(), $extraStyles['content_style'] ?? []), 'content1', 1)
                                            ->helperText('Pick the layout for this content section.')
                                            ->visible(fn (callable $get) => $get('type') === 'content'),
                                        Select::make('content_bg_type')
                                            ->label('Background')
                                            ->options([
                                                'normal'  => 'Normal background',
                                                'primary' => 'Primary color',
                                                'custom'  => 'Custom color',
                                            ])
                                            ->default('normal')
                                            ->native(false)
                                            ->live()
                                            ->helperText('Section background.')
                                            ->visible(fn (callable $get) => $get('type') === 'content'),
                                        ColorPicker::make('content_bg_color')
                                            ->label('Background Color')
                                            ->hsl()
                                            ->visible(fn (callable $get) => $get('type') === 'content' && ($get('content_bg_type') ?? 'normal') === 'custom'),
                                        Select::make('content_orientation')
                                            ->label('Image Orientation')
                                            ->options([
                                                'image_left'  => 'Image on left',
                                                'image_right' => 'Image on right',
                                            ])
                                            ->default('image_right')
                                            ->native(false)
                                            ->visible(fn (callable $get) => $get('type') === 'content' && in_array($get('content_style') ?? 'content1', ['content2', 'content3'], true)),
                                        TextInput::make('content_max_width')
                                            ->label('Section Width')
                                            ->placeholder('e.g. 1152px')
                                            ->helperText('Exact max width, e.g. 1152px or 72rem. Leave blank for the default (72rem).')
                                            ->visible(fn (callable $get) => $get('type') === 'content' && in_array($get('content_style') ?? 'content1', ['content2', 'content3'], true)),
                                        Toggle::make('content_image_flush')
                                            ->label('Flush image to edge')
                                            ->helperText('Extend the image to the screen edge on its outer side (removes the padding/gap there).')
                                            ->visible(fn (callable $get) => $get('type') === 'content' && in_array($get('content_style') ?? 'content1', ['content2', 'content3'], true)),
                                        FileUpload::make('content_image')
                                            ->label('Image')
                                            ->disk('public')
                                            ->directory('citadel/custom-pages/content')
                                            ->image()
                                            ->imageEditor()
                                            ->maxSize(4096)
                                            ->helperText('Shown on the chosen side  just the image, no background.')
                                            ->visible(fn (callable $get) => $get('type') === 'content' && in_array($get('content_style') ?? 'content1', ['content2', 'content3'], true)),
                                        TextInput::make('heading')
                                            ->label('Content Title')
                                            ->placeholder('About Our Services')
                                            ->helperText('Optional heading shown above the content. Leave empty to hide.')
                                            ->visible(fn (callable $get) => $get('type') === 'content'),
                                        Textarea::make('description')
                                            ->label('Short Description')
                                            ->rows(2)
                                            ->helperText('Brief intro shown below the title.')
                                            ->visible(fn (callable $get) => $get('type') === 'content' && ($get('content_style') ?? 'content1') === 'content1'),
                                        MarkdownEditor::make('body')
                                            ->label('Content Body')
                                            ->toolbarButtons(['bold', 'italic', 'link', 'bulletList', 'orderedList', 'heading', 'blockquote', 'codeBlock'])
                                            ->helperText('Main body content. Supports full Markdown.')
                                            ->visible(fn (callable $get) => $get('type') === 'content' && ($get('content_style') ?? 'content1') !== 'm2reviews'),
                                        Select::make('content_icon_type')
                                            ->label('Point Icons')
                                            ->options([
                                                'remix' => 'Remix Icons',
                                                'svg'   => 'SVG (paste)',
                                            ])
                                            ->default('remix')
                                            ->native(false)
                                            ->live()
                                            ->helperText('Which icon field shows on each point.')
                                            ->visible(fn (callable $get) => $get('type') === 'content' && ($get('content_style') ?? 'content1') === 'content3'),
                                        Repeater::make('content_points')
                                            ->label('Points')
                                            ->addActionLabel('Add Point')
                                            ->collapsible()
                                            ->collapsed()
                                            ->reorderable()
                                            ->defaultItems(0)
                                            ->itemLabel(fn (array $state): ?string => trim(strip_tags($state['text'] ?? '')) ?: 'Point')
                                            ->schema([
                                                RichEditor::make('text')
                                                    ->label('Text')
                                                    ->toolbarButtons(['bold', 'italic'])
                                                    ->helperText('Bold the lead-in (e.g. "Push to deploy.")  it shows as the title; the rest reads as the description.'),
                                                TextInput::make('icon_remix')
                                                    ->label('Remix Icon')
                                                    ->placeholder('ri-checkbox-circle-line')
                                                    ->helperText('Enter a Remix Icon name.')
                                                    ->visible(fn (callable $get) => ($get('../../content_icon_type') ?? 'remix') === 'remix'),
                                                Textarea::make('icon_svg')
                                                    ->label('Icon SVG')
                                                    ->rows(3)
                                                    ->placeholder('<svg ...>...</svg>')
                                                    ->visible(fn (callable $get) => ($get('../../content_icon_type') ?? 'remix') === 'svg'),
                                            ])
                                            ->visible(fn (callable $get) => $get('type') === 'content' && ($get('content_style') ?? 'content1') === 'content3'),

                                        
                                        $this->blockLayoutRadio('cta_style', 'Call to Action Layout', $this->ctaStyles(), 'cta1', 1)
                                            ->helperText('Pick the layout for this call-to-action.')
                                            ->visible(fn (callable $get) => $get('type') === 'cta'),
                                        Select::make('cta_orientation')
                                            ->label('Content Orientation')
                                            ->options([
                                                'split'    => 'Text left, buttons right',
                                                'centered' => 'Centered, buttons below',
                                            ])
                                            ->default('split')
                                            ->native(false)
                                            ->visible(fn (callable $get) => $get('type') === 'cta'),
                                        TextInput::make('cta_max_width')
                                            ->label('Card Width')
                                            ->placeholder('e.g. 1152px')
                                            ->helperText('Exact max width of the card, e.g. 1152px or 72rem. Leave blank to match the page width.')
                                            ->visible(fn (callable $get) => $get('type') === 'cta'),
                                        TextInput::make('heading')
                                            ->label('CTA Title')
                                            ->placeholder('Ready to get started?')
                                            ->visible(fn (callable $get) => $get('type') === 'cta'),
                                        Textarea::make('description')
                                            ->label('CTA Description')
                                            ->rows(2)
                                            ->placeholder('Join thousands of satisfied customers and take your business to the next level.')
                                            ->visible(fn (callable $get) => $get('type') === 'cta'),
                                        Select::make('background_type')
                                            ->label('Background Style')
                                            ->options([
                                                'plain'         => 'Plain color',
                                                'gradient'      => 'Gradient',
                                                'image_overlay' => 'Image with gradient overlay',
                                                'image'         => 'Image only',
                                            ])
                                            ->default('gradient')
                                            ->native(false)
                                            ->live()
                                            ->visible(fn (callable $get) => $get('type') === 'cta'),
                                        FileUpload::make('background_image')
                                            ->label('Background Image')
                                            ->disk('public')
                                            ->directory('citadel/custom-pages/cta')
                                            ->image()
                                            ->maxSize(4096)
                                            ->helperText('Max 4 MB. Used when background is Image or Image with overlay.')
                                            ->visible(fn (callable $get) => $get('type') === 'cta' && in_array($get('background_type') ?? 'gradient', ['image', 'image_overlay'], true)),
                                        TextInput::make('btn1_text')
                                            ->label('Button 1 Text')
                                            ->placeholder('Get Started')
                                            ->visible(fn (callable $get) => $get('type') === 'cta'),
                                        TextInput::make('btn1_link')
                                            ->label('Button 1 Link')
                                            ->placeholder('/register')
                                            ->visible(fn (callable $get) => $get('type') === 'cta'),
                                        TextInput::make('btn2_text')
                                            ->label('Button 2 Text (optional)')
                                            ->placeholder('Contact Sales')
                                            ->visible(fn (callable $get) => $get('type') === 'cta'),
                                        TextInput::make('btn2_link')
                                            ->label('Button 2 Link (optional)')
                                            ->placeholder('/tickets')
                                            ->visible(fn (callable $get) => $get('type') === 'cta'),

                                        // ----- Custom HTML / Hook block -----
                                        Textarea::make('custom_html')
                                            ->label('Custom HTML')
                                            ->rows(12)
                                            ->extraInputAttributes(['style' => 'font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; white-space: pre;'])
                                            ->placeholder('<div class="...">Your HTML here</div>')
                                            ->helperText('Raw HTML/CSS/JS, rendered exactly as entered. You can also embed a panel hook inline: put {!! hook(\'my-hook\') !!} anywhere in the HTML and it renders whatever an extension registered to that hook. Only hook() calls are executed — no other Blade/PHP.')
                                            ->visible(fn (callable $get) => $get('type') === 'custom'),
                                        TextInput::make('custom_hook')
                                            ->label('Page Hook Name (optional)')
                                            ->placeholder('e.g. footer, body, my-extension-hook')
                                            ->helperText('Renders a registered hook by name at this position')
                                            ->visible(fn (callable $get) => $get('type') === 'custom'),
        ], $extraComponents);
    }

    /**
     * @return array<string, array<string, string>>
     */
    private function homeBlockExtraStyles(): array
    {
        $base = 'assets/admin/custom/products/';

        return [
            'hero_style'    => ['m2hero' => $base . 'hero-marketing.webp'],
            'grid_style'    => ['m2plans' => $base . 'grid-marketing.webp'],
            'feature_style' => ['m2features' => $base . 'feature-marketing.webp', 'm2bento' => $base . 'bento-marketing.webp'],
            'content_style' => ['m2reviews' => $base . 'reviews-marketing.webp'],
        ];
    }

    /**
     *
     * @return array<int, mixed>
     */
    private function homeBlockExtraComponents(): array
    {
        $bentoPresets = [
            'controlpanel' => 'Control Panel',
            'support'      => 'Support (Headset)',
            'secure'       => 'Secure (Shield)',
            'ryzen'        => 'Ryzen (CPU)',
            'intel'        => 'Intel (CPU)',
            'epic'         => 'EPYC (CPU)',
        ];

        return [
            Textarea::make('description')
                ->label('Reviews Description')
                ->rows(2)
                ->visible(fn (callable $get) => $get('type') === 'content' && ($get('content_style') ?? 'content1') === 'm2reviews'),
            Repeater::make('reviews_data')
                ->label('Reviews')
                ->addActionLabel('Add Review')
                ->collapsible()
                ->collapsed()
                ->reorderable()
                ->cloneable()
                ->itemLabel(fn (array $state): ?string => $state['name'] ?? 'Review')
                ->schema([
                    TextInput::make('name')
                        ->label('Reviewer Name')
                        ->required()
                        ->live(onBlur: true)
                        ->maxLength(255),
                    Textarea::make('review')
                        ->label('Review')
                        ->required()
                        ->rows(3),
                    FileUpload::make('image')
                        ->label('Reviewer Image')
                        ->image()
                        ->imageEditor()
                        ->disk('public')
                        ->directory('citadel/reviews')
                        ->visibility('public'),
                ])
                ->visible(fn (callable $get) => $get('type') === 'content' && ($get('content_style') ?? 'content1') === 'm2reviews'),

            
            Repeater::make('bento_cards')
                ->label('Cards')
                ->addActionLabel('Add Card')
                ->collapsible()
                ->collapsed()
                ->reorderable()
                ->cloneable()
                ->helperText('The first two cards form the wide top row; the rest sit 3-up below.')
                ->itemLabel(fn (array $state): ?string => $state['title'] ?? 'Card')
                ->schema([
                    Select::make('image_source')
                        ->label('Image')
                        ->options(['none' => 'None', 'preset' => 'Preset graphic', 'custom' => 'Custom image'])
                        ->default('preset')
                        ->native(false)
                        ->live(),
                    Select::make('preset')
                        ->label('Preset graphic')
                        ->options($bentoPresets)
                        ->native(false)
                        ->visible(fn (callable $get) => ($get('image_source') ?? 'preset') === 'preset'),
                    FileUpload::make('image')
                        ->label('Custom image')
                        ->image()
                        ->imageEditor()
                        ->disk('public')
                        ->directory('citadel/bento')
                        ->maxSize(4096)
                        ->visible(fn (callable $get) => ($get('image_source') ?? 'preset') === 'custom'),
                    TextInput::make('title')
                        ->label('Title')
                        ->placeholder('Lightning Fast Servers'),
                    Textarea::make('description')
                        ->label('Description')
                        ->rows(2),
                ])
                ->visible(fn (callable $get) => $get('type') === 'features' && ($get('feature_style') ?? 'feature1') === 'm2bento'),


            Select::make('m2_title_size')->label('Title Size')->options(['text-3xl sm:text-4xl lg:text-5xl' => 'Small', 'text-4xl sm:text-5xl lg:text-6xl' => 'Medium', 'text-5xl sm:text-6xl lg:text-7xl' => 'Large', 'text-6xl sm:text-7xl lg:text-8xl' => 'Extra Large'])->native(false)->visible(fn (callable $get) => $get('type') === 'hero' && ($get('hero_style') ?? 'hero1') === 'm2hero'),
            Select::make('m2_description_size')->label('Description Size')->options(['text-sm' => 'Small', 'text-base' => 'Medium', 'text-lg' => 'Large', 'text-xl' => 'Extra Large'])->native(false)->visible(fn (callable $get) => $get('type') === 'hero' && ($get('hero_style') ?? 'hero1') === 'm2hero'),
            Toggle::make('m2_show_trustpilot')->label('Show Trustpilot line')->default(true)->visible(fn (callable $get) => $get('type') === 'hero' && ($get('hero_style') ?? 'hero1') === 'm2hero'),
            TextInput::make('m2_trustpilot_rating')->label('Trustpilot Rating Text')->placeholder('Excellent')->visible(fn (callable $get) => $get('type') === 'hero' && ($get('hero_style') ?? 'hero1') === 'm2hero'),
            Toggle::make('m2_enable_button')->label('Show button')->default(true)->visible(fn (callable $get) => $get('type') === 'hero' && ($get('hero_style') ?? 'hero1') === 'm2hero'),
            Toggle::make('m2_show_starting_price')->label('Show starting price')->default(true)->visible(fn (callable $get) => $get('type') === 'hero' && ($get('hero_style') ?? 'hero1') === 'm2hero'),
            TextInput::make('m2_price_prefix')->label('Price Prefix')->placeholder('Starting at Only')->visible(fn (callable $get) => $get('type') === 'hero' && ($get('hero_style') ?? 'hero1') === 'm2hero'),
            Toggle::make('m2_enable_secondary_button')->label('Show secondary button')->visible(fn (callable $get) => $get('type') === 'hero' && ($get('hero_style') ?? 'hero1') === 'm2hero'),
            TextInput::make('m2_secondary_button_text')->label('Secondary Button Text')->placeholder('View All Plans')->visible(fn (callable $get) => $get('type') === 'hero' && ($get('hero_style') ?? 'hero1') === 'm2hero'),
            TextInput::make('m2_secondary_button_link')->label('Secondary Button Link')->visible(fn (callable $get) => $get('type') === 'hero' && ($get('hero_style') ?? 'hero1') === 'm2hero'),
            Select::make('m2_hero_right_content')->label('Right Side Content')->options(['categories' => 'Category Cards', 'preset_image' => 'Preset Graphic', 'custom_image' => 'Custom Image'])->default('categories')->native(false)->live()->visible(fn (callable $get) => $get('type') === 'hero' && ($get('hero_style') ?? 'hero1') === 'm2hero'),
            Select::make('m2_hero_preset_image')->label('Preset Graphic')->options(['hero' => 'Hero (Abstract Shapes - Full Background)', 'webhosting' => 'Web Hosting (Side Image)'])->default('hero')->native(false)->visible(fn (callable $get) => $get('type') === 'hero' && ($get('hero_style') ?? 'hero1') === 'm2hero' && ($get('m2_hero_right_content') ?? 'categories') === 'preset_image'),
            FileUpload::make('m2_hero_custom_image')->label('Custom Hero Image')->image()->imageEditor()->disk('public')->directory('citadel/hero')->maxSize(4096)->visible(fn (callable $get) => $get('type') === 'hero' && ($get('hero_style') ?? 'hero1') === 'm2hero' && ($get('m2_hero_right_content') ?? 'categories') === 'custom_image'),

            
            Select::make('m2_plans_source')->label('Display Mode')->options(['top_categories' => 'Top Categories (first 3)', 'specific_category' => 'One Specific Category'])->default('top_categories')->native(false)->live()->visible(fn (callable $get) => $get('type') === 'products' && ($get('grid_style') ?? 'grid1') === 'm2plans'),
            Select::make('m2_plans_category_id')->label('Category')->options(fn () => \App\Models\Category::orderBy('sort')->orderBy('name')->pluck('name', 'id')->toArray())->searchable()->native(false)->visible(fn (callable $get) => $get('type') === 'products' && ($get('grid_style') ?? 'grid1') === 'm2plans' && ($get('m2_plans_source') ?? 'top_categories') === 'specific_category'),
            Select::make('m2_plans_popular')->label('Popular Plan')->options(['' => 'None', '1' => 'Plan 1', '2' => 'Plan 2', '3' => 'Plan 3', '4' => 'Plan 4'])->native(false)->visible(fn (callable $get) => $get('type') === 'products' && ($get('grid_style') ?? 'grid1') === 'm2plans'),
            Select::make('m2_plans_icon_style')->label('Icon Style')->options(['none' => 'None', 'right' => 'Right', 'top' => 'Top', 'background' => 'Background', 'corner' => 'Corner'])->default('none')->native(false)->visible(fn (callable $get) => $get('type') === 'products' && ($get('grid_style') ?? 'grid1') === 'm2plans'),

            
            Toggle::make('m2_features_icon_bg')->label('Show icon backgrounds')->default(true)->visible(fn (callable $get) => $get('type') === 'features' && ($get('feature_style') ?? 'feature1') === 'm2features'),
            Repeater::make('m2_features_data')->label('Features')->addActionLabel('Add Feature')->collapsible()->collapsed()->reorderable()->cloneable()
                ->itemLabel(fn (array $state): ?string => $state['title'] ?? 'Feature')
                ->schema([
                    TextInput::make('title')->label('Title')->required()->live(onBlur: true)->maxLength(255),
                    Textarea::make('description')->label('Description')->rows(2),
                    Select::make('icon_type')->label('Icon Type')->options(['citadel' => 'Citadel Icons', 'remix' => 'Remix Icons'])->default('citadel')->native(false)->live(),
                    Radio::make('icon_citadel')->label('Citadel Icon')->options(fn () => $this->getCitadelIcons())->columns(5)->extraAttributes(['class' => 'citadel-icon-picker'])->dehydratedWhenHidden()->visible(fn (callable $get) => ($get('icon_type') ?? 'citadel') === 'citadel'),
                    TextInput::make('icon_remix')->label('Remix Icon')->helperText('e.g. ri-shield-check-line')->visible(fn (callable $get) => $get('icon_type') === 'remix'),
                ])
                ->visible(fn (callable $get) => $get('type') === 'features' && ($get('feature_style') ?? 'feature1') === 'm2features'),
        ];
    }

    private function defaultCustomPage(): array
    {
        return [
            'page_type' => 'custom',
            'title' => '',
            'slug' => '',
            'description' => '',
            'content' => '',
            'blocks' => [],
            'enabled' => true,
        ];
    }


    public function cpAddPage(): void
    {
        $this->cpEditingIndex = count($this->cpPages);
        $this->cpEditingIsNew = true;
        $this->data['cp_editing'] = $this->defaultCustomPage();
        $this->form->fill($this->data);
    }


    public function cpEditPage(int $index): void
    {
        $pages = array_values($this->cpPages);
        if (! array_key_exists($index, $pages)) {
            Notification::make()->title('That page no longer exists.')->warning()->send();

            return;
        }

        $this->cpEditingIndex = $index;
        $this->cpEditingIsNew = false;
        $this->data['cp_editing'] = $pages[$index];
        $this->form->fill($this->data);


        $this->dispatchPreviewUrl($this->customPageUrl($pages[$index], $this->categorySlugMap()));
    }


    public function cpCommitAndBack(): void
    {
        if ($this->cpEditingIndex === null) {
            return;
        }

        try {
            $state = $this->form->getState();
        } catch (ValidationException $e) {
            Notification::make()
                ->title('Please complete the required fields before leaving this page.')
                ->danger()
                ->send();

            return;
        }

        $edited = $state['cp_editing'] ?? ($this->data['cp_editing'] ?? []);
        $pages = array_values($this->cpPages);
        $pages[$this->cpEditingIndex] = $edited;

        $this->cpPages = array_values($pages);
        $this->cpEditingIndex = null;
        $this->cpEditingIsNew = false;
        $this->data['cp_editing'] = [];
        $this->form->fill($this->data);
    }


    public function cpDiscard(): void
    {
        $this->cpEditingIndex = null;
        $this->cpEditingIsNew = false;
        $this->data['cp_editing'] = [];
        $this->form->fill($this->data);
    }


    public function cpDeletePage(int $index): void
    {
        $pages = array_values($this->cpPages);
        if (! array_key_exists($index, $pages)) {
            return;
        }

        array_splice($pages, $index, 1);
        $this->cpPages = array_values($pages);

        Notification::make()->title('Page removed  Save to apply.')->success()->send();
    }


    public function cpTogglePublished(int $index): void
    {
        $pages = array_values($this->cpPages);
        if (! array_key_exists($index, $pages)) {
            return;
        }

        $pages[$index]['enabled'] = ! ($pages[$index]['enabled'] ?? true);
        $this->cpPages = array_values($pages);
    }

    /**
     *
     * @return array<int, string>
     */
    public function categorySlugMap(): array
    {
        try {
            return \App\Models\Category::query()
                ->pluck('slug', 'id')
                ->map(fn ($s) => (string) $s)
                ->toArray();
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     *
     * @return array<int, string>
     */
    public function categoryNameMap(): array
    {
        try {
            return \App\Models\Category::query()
                ->pluck('name', 'id')
                ->map(fn ($n) => (string) $n)
                ->toArray();
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     *
     * @return array<string, string>
     */
    private function productGridStyles(): array
    {
        return [
            'grid1' => 'assets/admin/custom/products/grid1.webp',
            'grid2' => 'assets/admin/custom/products/grid2.webp',
        ];
    }

    /**
     *
     * @return array<string, string>
     */
    private function heroStyles(): array
    {
        return [
            'hero1' => 'assets/admin/custom/products/hero1.webp',
            'hero4' => 'assets/admin/custom/products/hero4.webp',
            'hero5' => 'assets/admin/custom/products/hero5.webp',
            'hero2' => 'assets/admin/custom/products/hero2.webp',
            'hero3' => 'assets/admin/custom/products/hero3.webp',
        ];
    }

    /**
     *
     * @return array<string, string>
     */
    private function featureStyles(): array
    {
        return [
            'feature1' => 'assets/admin/custom/products/feature1.webp',
            'feature2' => 'assets/admin/custom/products/feature2.webp',
            'feature3' => 'assets/admin/custom/products/feature3.webp',
        ];
    }

    /**
     *
     * @return array<string, string>
     */
    private function faqStyles(): array
    {
        return [
            'faq1' => 'assets/admin/custom/products/faq1.webp',
        ];
    }

    /**
     *
     * @return array<string, string>
     */
    private function contentStyles(): array
    {
        return [
            'content1' => 'assets/admin/custom/products/content1.webp',
            'content2' => 'assets/admin/custom/products/content2.webp',
            'content3' => 'assets/admin/custom/products/content3.webp',
        ];
    }

    /**
     *
     * @return array<string, string>
     */
    private function ctaStyles(): array
    {
        return [
            'cta1' => 'assets/admin/custom/products/cta-standard.webp',
        ];
    }

    /**
     *
     * @return array<string, string>
     */
    private function headerStyles(): array
    {
        return [
            'header1' => 'assets/admin/custom/products/header1.webp',
            'header2' => 'assets/admin/custom/products/header2.webp',
        ];
    }

    /**
     *
     * @param array<string, string> $options
     */
    private function blockLayoutRadio(string $name, string $label, array $options, string $default, int $columns = 2): Radio
    {
        return Radio::make($name)
            ->label($label)
            ->options(collect($options)->mapWithKeys(function ($imgPath, $key) {
                $imgUrl = $imgPath ? asset($imgPath) : '';

                return [$key => new HtmlString(
                    '<div class="citadel-image-radio-card">'
                    . ($imgUrl ? '<img src="' . e($imgUrl) . '" alt="' . e($key) . '" />' : '')
                    . '</div>'
                )];
            })->toArray())
            ->default($default)
            ->columns($columns)
            ->extraAttributes(['class' => 'citadel-image-radio'])
            ->live();
    }


    public function customPageUrl(array $page, array $catSlugs): ?string
    {
        $base = rtrim(url('/'), '/');
        $type = ($page['page_type'] ?? 'custom') === 'product' ? 'product' : 'custom';

        if ($type === 'product') {
            $strategy = $page['url_strategy'] ?? 'replace';
            if ($strategy === 'separate') {
                $slug = trim((string) ($page['slug'] ?? ''));

                return $slug !== '' ? $base . '/' . $slug : null;
            }
            $catId = $page['category_id'] ?? null;
            $catSlug = $catId !== null ? ($catSlugs[(int) $catId] ?? null) : null;

            return $catSlug ? $base . '/products/' . $catSlug : null;
        }

        $slug = trim((string) ($page['slug'] ?? ''));

        return $slug !== '' ? $base . '/' . $slug : null;
    }


    private function dispatchPreviewUrl(?string $url): void
    {
        if (! $url) {
            return;
        }

        $this->js('window.dispatchEvent(new CustomEvent("citadel-preview-url", { detail: ' . json_encode(['url' => $url]) . ' }))');
    }



    public function cpAddPageAction(): Action
    {
        return Action::make('cpAddPage')
            ->label('Add Page')
            ->icon('ri-add-line')
            ->color('primary')
            ->action(fn () => $this->cpAddPage());
    }

    public function cpEditPageAction(): Action
    {
        return Action::make('cpEditPage')
            ->label('Edit')
            ->icon('ri-pencil-line')
            ->color('primary')
            ->action(fn (array $arguments) => $this->cpEditPage((int) ($arguments['index'] ?? -1)));
    }

    public function cpPublishAction(): Action
    {
        return Action::make('cpPublish')
            ->label('Publish')
            ->icon('ri-eye-line')
            ->color('gray')
            ->action(fn (array $arguments) => $this->cpTogglePublished((int) ($arguments['index'] ?? -1)));
    }

    public function cpUnpublishAction(): Action
    {
        return Action::make('cpUnpublish')
            ->label('Unpublish')
            ->icon('ri-eye-off-line')
            ->color('gray')
            ->action(fn (array $arguments) => $this->cpTogglePublished((int) ($arguments['index'] ?? -1)));
    }

    public function cpDeletePageAction(): Action
    {
        return Action::make('cpDeletePage')
            ->label('Delete')
            ->icon('ri-delete-bin-line')
            ->color('danger')
            ->requiresConfirmation()
            ->modalHeading('Delete this page?')
            ->modalDescription('This removes the page from the list. You still need to Save to apply the change.')
            ->modalSubmitActionLabel('Delete page')
            ->action(fn (array $arguments) => $this->cpDeletePage((int) ($arguments['index'] ?? -1)));
    }

    public function cpBackAction(): Action
    {
        return Action::make('cpBack')
            ->label('Back to pages')
            ->icon('ri-arrow-left-line')
            ->color('primary')
            ->action(fn () => $this->cpCommitAndBack());
    }

    public function cpDiscardAction(): Action
    {
        return Action::make('cpDiscard')
            ->label('Discard')
            ->icon('ri-close-line')
            ->color('gray')
            ->requiresConfirmation()
            ->modalHeading('Discard changes?')
            ->modalDescription('Any unsaved changes to this page will be lost.')
            ->modalSubmitActionLabel('Discard')
            ->action(fn () => $this->cpDiscard());
    }

    private function buildHeaderFooterSchema(array $settings): array
    {
        $components = [];

        $components[] = Placeholder::make('header_footer_title')
            ->hiddenLabel()
            ->content(new HtmlString('<h2 style="font-size: 1.25rem; font-weight: 700; margin: 0;">Header &amp; Footer</h2>'));

        $hfByName = collect($settings)->keyBy('name');
        $headerStyleSchema = [
            $this->blockLayoutRadio('header_style', 'Header Style', $this->headerStyles(), 'header1', 1)
                ->hiddenLabel(),
        ];
        if ($hfByName->has('header_sticky')) {
            $headerStyleSchema[] = $this->buildInput($hfByName->get('header_sticky'));
        }
        if ($hfByName->has('header_utility_bar')) {
            $headerStyleSchema[] = $this->buildInput($hfByName->get('header_utility_bar'));
        }
        foreach (['header_utility_bar_bg', 'header_utility_bar_bg_dark'] as $utilColorKey) {
            if ($hfByName->has($utilColorKey)) {
                $headerStyleSchema[] = $this->buildInput($hfByName->get($utilColorKey))
                    ->visible(fn (Get $get) => (bool) $get('header_utility_bar'));
            }
        }
        $headerStyleSchema[] = Repeater::make('header_utility_items_data')
            ->label('Utility Bar Items')
            ->helperText('Add your own text/link items shown on the left side of the utility bar.')
            ->addActionLabel('Add Item')
            ->schema([
                TextInput::make('text')
                    ->label('Text')
                    ->placeholder('e.g. Need help?')
                    ->required(),
                TextInput::make('url')
                    ->label('Link URL (optional)')
                    ->placeholder('e.g. /contact or https://example.com'),
                Select::make('icon_type')
                    ->label('Icon Type')
                    ->options([
                        'remix' => 'Remix Icon',
                        'svg'   => 'Custom SVG',
                    ])
                    ->default('remix')
                    ->native(false)
                    ->live(),
                TextInput::make('icon')
                    ->label('Remix Icon (optional)')
                    ->placeholder('e.g. ri-customer-service-2-fill')
                    ->helperText('Remix Icon name (without the x- prefix). Browse: https://remixicon.com')
                    ->visible(fn (Get $get) => ($get('icon_type') ?? 'remix') === 'remix'),
                Textarea::make('icon_svg')
                    ->label('Custom SVG (optional)')
                    ->rows(3)
                    ->placeholder('<svg ...>...</svg>')
                    ->helperText('Paste raw SVG markup. It will be sized to match the bar.')
                    ->extraInputAttributes(['style' => 'font-family: monospace; font-size: 0.8rem;'])
                    ->visible(fn (Get $get) => ($get('icon_type') ?? 'remix') === 'svg'),
                Toggle::make('new_tab')
                    ->label('Open in new tab')
                    ->default(false),
            ])
            ->itemLabel(fn (array $state): ?string => $state['text'] ?? 'Item')
            ->reorderable()
            ->collapsible()
            ->collapsed()
            ->columnSpanFull()
            ->visible(fn (Get $get) => (bool) $get('header_utility_bar'));
        $components[] = Section::make('Header Style')
            ->description('Choose the look of the top header bar.')
            ->schema($headerStyleSchema);


        $components[] = Section::make('Header Navigation')
            ->description('Manage the nav items shown in the top header bar. Drag to reorder. Items that require a login (Dashboard, Support) are only visible to logged-in users.')
            ->schema([
                Repeater::make('nav_items_data')
                    ->label('Navigation Items')
                    ->addActionLabel('Add Nav Item')
                    ->schema([
                        Select::make('type')
                            ->label('Type')
                            ->options([
                                'store'           => 'Store (product categories dropdown)',
                                'dashboard'       => 'Dashboard (requires login)',
                                'support'         => 'Support dropdown (tickets, KB, blog… requires login)',
                                'custom'          => 'Custom Link',
                                'custom_dropdown' => 'Custom Dropdown (multiple links)',
                            ])
                            ->required()
                            ->live(),
                        TextInput::make('custom_label')
                            ->label(fn (Get $get) => $get('type') === 'custom_dropdown' ? 'Dropdown Label' : 'Link Label')
                            ->placeholder('e.g. About Us')
                            ->visible(fn (Get $get) => in_array($get('type'), ['custom', 'custom_dropdown'], true)),
                        TextInput::make('custom_url')
                            ->label('Link URL')
                            ->placeholder('e.g. /about or https://example.com')
                            ->visible(fn (Get $get) => $get('type') === 'custom'),
                        Repeater::make('dropdown_items')
                            ->label(fn (Get $get) => $get('type') === 'support'
                                ? 'Extra Support Dropdown Links (appended after the built-in ones)'
                                : 'Dropdown Links')
                            ->addActionLabel('Add Link')
                            ->schema([
                                TextInput::make('label')
                                    ->label('Label')
                                    ->placeholder('e.g. Documentation')
                                    ->required(),
                                TextInput::make('url')
                                    ->label('URL')
                                    ->placeholder('e.g. /docs or https://example.com'),
                                TextInput::make('icon')
                                    ->label('Icon')
                                    ->placeholder('e.g. ri-book-shelf-fill')
                                    ->helperText('Remix Icon name (without the x- prefix). Browse: https://remixicon.com. Leave empty for a generic link icon.'),
                                Toggle::make('new_tab')
                                    ->label('Open in new tab')
                                    ->default(false),
                            ])
                            ->itemLabel(fn (array $state): ?string => $state['label'] ?? 'Link')
                            ->reorderable()
                            ->collapsible()
                            ->collapsed()
                            ->visible(fn (Get $get) => in_array($get('type'), ['custom_dropdown', 'support'], true))
                            ->columnSpanFull(),
                        Toggle::make('show_on_dashboard')
                            ->label('Show on dashboard pages')
                            ->helperText('Show this item in the navbar when the user is on a dashboard page (sidebar visible).')
                            ->default(true)
                            ->afterStateHydrated(fn ($component, $state) => $component->state($state ?? true))
                            ->visible(fn (Get $get) => in_array($get('type'), ['custom', 'custom_dropdown'], true)),
                        Toggle::make('show_on_front')
                            ->label('Show on front pages')
                            ->helperText('Show this item in the navbar on public/front-facing pages (no sidebar).')
                            ->default(true)
                            ->afterStateHydrated(fn ($component, $state) => $component->state($state ?? true))
                            ->visible(fn (Get $get) => in_array($get('type'), ['custom', 'custom_dropdown'], true)),
                    ])
                    ->itemLabel(fn (array $state): ?string => match ($state['type'] ?? '') {
                        'store'           => 'Store',
                        'dashboard'       => 'Dashboard',
                        'support'         => 'Support',
                        'custom'          => ($state['custom_label'] ?? 'Custom Link') ?: 'Custom Link',
                        'custom_dropdown' => ($state['custom_label'] ?? 'Custom Dropdown') ?: 'Custom Dropdown',
                        default           => 'Nav Item',
                    })
                    ->reorderable()
                    ->collapsible()
                    ->collapsed()
                    ->columnSpanFull(),
            ]);

        
        $footerInfoSchema = [];
        foreach ($settings as $setting) {
            if (in_array($setting['name'], ['site_description', 'copyright_message', 'payment_method_icons', 'footer_payment_disable_bg'])) {
                $footerInfoSchema[] = $this->buildInput($setting);
            }
        }
        if (!empty($footerInfoSchema)) {
            $components[] = Section::make('Footer Info')
                ->description('Site description shown in the footer, copyright message, and payment method icons.')
                ->schema($footerInfoSchema);
        }

        $components[] = Section::make('Footer - Company Column')
            ->description('Links shown in the "Company" column of the footer. Add, remove, or reorder items freely.')
            ->schema([
                Repeater::make('footer_company_items_data')
                    ->label('Company Links')
                    ->addActionLabel('Add Link')
                    ->schema([
                        TextInput::make('label')
                            ->label('Label')
                            ->placeholder('e.g. Services')
                            ->required(),
                        TextInput::make('url')
                            ->label('URL')
                            ->placeholder('e.g. /services or https://example.com/services')
                            ->required(),
                    ])
                    ->itemLabel(fn (array $state): ?string => $state['label'] ?? 'Link')
                    ->reorderable()
                    ->collapsible()
                    ->collapsed()
                    ->columnSpanFull(),
            ]);


        $components[] = Section::make('Footer - Legal Column')
            ->description('Links shown in the "Legal" column of the footer.')
            ->schema([
                Repeater::make('footer_legal_items_data')
                    ->label('Legal Links')
                    ->addActionLabel('Add Link')
                    ->schema([
                        TextInput::make('label')
                            ->label('Label')
                            ->placeholder('e.g. Terms of Service')
                            ->required(),
                        TextInput::make('url')
                            ->label('URL')
                            ->placeholder('e.g. /terms or https://example.com/terms')
                            ->required(),
                    ])
                    ->itemLabel(fn (array $state): ?string => $state['label'] ?? 'Link')
                    ->reorderable()
                    ->collapsible()
                    ->collapsed()
                    ->columnSpanFull(),
            ]);

        
        $socialSchema = [];
        foreach ($settings as $setting) {
            if (in_array($setting['name'], ['social_youtube', 'social_x', 'social_instagram', 'social_tiktok', 'social_linkedin', 'social_github'])) {
                $socialSchema[] = $this->buildInput($setting);
            }
        }
        if (!empty($socialSchema)) {
            $components[] = Section::make('Footer - Social Media')
                ->description('Social media profile links shown as icons in the footer. Leave empty to hide.')
                ->schema($socialSchema);
        }

        
        $sidebarIconOptions = [
            'dashbord' => 'Dashboard',
            'server'   => 'Server / Services',
            'billing'  => 'Billing',
            'store'    => 'Store',
            'support'  => 'Support',
            'account'  => 'Account',
            'Network'  => 'Network / Domains',
        ];

        $sidebarTypeOptions = [
            'dashboard'       => 'Dashboard',
            'services'        => 'Services',
            'billing'         => 'Billing',
            'store'           => 'Store',
            'support'         => 'Support',
            'account'         => 'Account',
            'custom'          => 'Custom Link',
            'custom_dropdown' => 'Custom Dropdown (collapsible group)',
        ];

        $components[] = Section::make('Sidebar')
            ->description('Control which items appear in the client sidebar, their order, labels, and icons. Default built-in items are pre-loaded. Add custom links  or whole custom dropdown groups  at any position.')
            ->schema([
                Repeater::make('sidebar_items_data')
                    ->label('Sidebar Items')
                    ->addActionLabel('Add Sidebar Item')
                    ->schema([
                        Select::make('type')
                            ->label('Type')
                            ->options($sidebarTypeOptions)
                            ->default('custom')
                            ->live()
                            ->required()
                            ->columnSpan(1),
                        TextInput::make('label')
                            ->label('Display Label')
                            ->placeholder('Leave empty to use default label')
                            ->columnSpan(1),
                        Select::make('icon')
                            ->label('Icon')
                            ->options($sidebarIconOptions)
                            ->placeholder('Leave empty to use default icon')
                            ->columnSpan(1),
                        TextInput::make('url')
                            ->label('URL')
                            ->placeholder('e.g. /my-page or https://example.com')
                            ->visible(fn (\Filament\Schemas\Components\Utilities\Get $get): bool => ($get('type') ?? 'custom') === 'custom')
                            ->columnSpan(1),
                        Repeater::make('dropdown_items')
                            ->label(fn (Get $get) => $get('type') === 'support'
                                ? 'Extra Support Links (appended after the built-in ones)'
                                : 'Group Links')
                            ->addActionLabel('Add Link')
                            ->schema([
                                TextInput::make('label')
                                    ->label('Label')
                                    ->placeholder('e.g. Documentation')
                                    ->required(),
                                TextInput::make('url')
                                    ->label('URL')
                                    ->placeholder('e.g. /docs or https://example.com'),
                                TextInput::make('icon')
                                    ->label('Icon')
                                    ->placeholder('e.g. ri-book-shelf-fill')
                                    ->helperText('Remix Icon name (without the x- prefix). Browse: https://remixicon.com. Leave empty for a generic link icon.'),
                                Toggle::make('new_tab')
                                    ->label('Open in new tab')
                                    ->default(false),
                            ])
                            ->itemLabel(fn (array $state): ?string => $state['label'] ?? 'Link')
                            ->reorderable()
                            ->collapsible()
                            ->collapsed()
                            ->visible(fn (Get $get) => in_array($get('type'), ['custom_dropdown', 'support'], true))
                            ->columnSpanFull(),
                        Toggle::make('show_on_dashboard')
                            ->label('Show on dashboard pages')
                            ->helperText('Show this item in the sidebar when the user is on a dashboard page.')
                            ->default(true)
                            ->afterStateHydrated(fn ($component, $state) => $component->state($state ?? true))
                            ->visible(fn (Get $get) => in_array($get('type'), ['custom', 'custom_dropdown'], true))
                            ->columnSpan(1),
                        Toggle::make('show_on_front')
                            ->label('Show on front pages')
                            ->helperText('Show this item in the sidebar on public/front-facing pages (only relevant if the sidebar is set to display on all pages).')
                            ->default(true)
                            ->afterStateHydrated(fn ($component, $state) => $component->state($state ?? true))
                            ->visible(fn (Get $get) => in_array($get('type'), ['custom', 'custom_dropdown'], true))
                            ->columnSpan(1),
                    ])
                    ->columns(2)
                    ->itemLabel(function (array $state) use ($sidebarTypeOptions): ?string {
                        $typeLabel = $sidebarTypeOptions[$state['type'] ?? 'custom'] ?? 'Item';
                        $label = $state['label'] ?? '';
                        return $label ? "{$typeLabel}  {$label}" : $typeLabel;
                    })
                    ->reorderable()
                    ->collapsible()
                    ->collapsed()
                    ->columnSpanFull(),
            ]);

        return $components;
    }

    private function buildColorsSchema(array $settings): array
    {
        $components = [];

        $components[] = Placeholder::make('colors_title')
            ->content(new HtmlString('<h2 style="font-size: 1.25rem; font-weight: 700; margin: 0;">Colors Settings</h2>'))
            ->hiddenLabel();

        
        $sections = [];
        foreach ($settings as $setting) {
            $sections[$setting['section'] ?? 'General'][] = $setting;
        }

        
        $moonIcon = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">'
            . '<path d="M18 2L18.6178 3.23558C18.8833 3.76656 19.016 4.03205 19.1934 4.26211C19.3507 4.46626 19.5337 4.64927 19.7379 4.80664C19.9679 4.98397 20.2334 5.11672 20.7644 5.38221L22 6L20.7644 6.61779C20.2334 6.88328 19.9679 7.01603 19.7379 7.19336C19.5337 7.35073 16.4663 7.35073 16.2621 7.19336C16.0321 7.01603 15.7666 6.88328 15.2356 6.61779L14 6L15.2356 5.38221C15.7666 5.11672 16.0321 4.98397 16.2621 4.80664C16.4663 4.64927 16.6493 4.46626 16.8066 4.26211C16.984 4.03205 17.1167 3.76656 17.3822 3.23558L18 2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>'
            . '<path d="M21 13.3893C19.689 15.689 17.2145 17.2395 14.3779 17.2395C10.1711 17.2395 6.76075 13.8292 6.76075 9.62233C6.76075 6.78554 8.31149 4.31094 10.6115 3C5.77979 3.45812 2 7.52692 2 12.4785C2 17.7371 6.26292 22 11.5215 22C16.4729 22 20.5415 18.2206 21 13.3893Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>'
            . '</svg>';

        $sunIcon = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">'
            . '<path d="M12 2V4M12 20V22M4 12H2M6.31412 6.31412L4.8999 4.8999M17.6859 6.31412L19.1001 4.8999M6.31412 17.69L4.8999 19.1042M17.6859 17.69L19.1001 19.1042M22 12H20M17 12C17 14.7614 14.7614 17 12 17C9.23858 17 7 14.7614 7 12C7 9.23858 9.23858 7 12 7C14.7614 7 17 9.23858 17 12Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>'
            . '</svg>';

        
        $prefInputs = [];
        $themeDesc = collect($sections['Color Preferences'] ?? [])->firstWhere('name', 'default_color_theme')['description'] ?? null;

        $prefInputs[] = Radio::make('default_color_theme')
            ->label('Default Color Theme')
            ->helperText($themeDesc)
            ->options([
                'light' => new HtmlString('<div class="citadel-theme-radio-card"><div class="citadel-theme-radio-icon">' . $sunIcon . '</div><span>Light Mode</span></div>'),
                'dark'  => new HtmlString('<div class="citadel-theme-radio-card"><div class="citadel-theme-radio-icon">' . $moonIcon . '</div><span>Dark Mode</span></div>'),
            ])
            ->default('light')
            ->columns(2)
            ->extraAttributes(['class' => 'citadel-image-radio citadel-theme-radio']);

        foreach ($sections['Color Preferences'] ?? [] as $setting) {
            if ($setting['name'] === 'disable_color_switching') {
                $prefInputs[] = $this->buildInput($setting);
            }
        }

        $components[] = Section::make('Color Preferences')
            ->schema($prefInputs);

        
        $presets = [
            'blue' => [
                'label' => 'Blue',
                'light' => ['primary'=>'hsl(229, 80%, 50%)','secondary'=>'hsl(216, 83%, 37%)','neutral'=>'hsl(0, 0%, 85%)','base'=>'hsl(0, 0%, 0%)','muted'=>'hsl(220, 5%, 13%)','inverted'=>'hsl(100, 100%, 100%)','background'=>'hsl(210, 25%, 97%)','background-secondary'=>'hsl(60, 50%, 99%)'],
                'dark'  => ['primary'=>'hsl(229, 80%, 50%)','secondary'=>'hsl(216, 83%, 37%)','neutral'=>'hsl(210, 6%, 13%)','base'=>'hsl(100, 100%, 100%)','muted'=>'hsl(220, 0%, 80%)','inverted'=>'hsl(220, 14%, 60%)','background'=>'hsl(210, 15%, 5%)','background-secondary'=>'hsl(200, 6%, 10%)'],
            ],
            'red' => [
                'label' => 'Red',
                'light' => ['primary'=>'hsl(11, 88%, 51%)','secondary'=>'hsl(11, 91%, 41%)','neutral'=>'hsl(0, 0%, 89%)','base'=>'hsl(0, 0%, 0%)','muted'=>'hsl(220, 5%, 13%)','inverted'=>'hsl(100, 100%, 100%)','background'=>'hsl(252, 56%, 98%)','background-secondary'=>'hsl(0, 0%, 100%)'],
                'dark'  => ['primary'=>'hsl(11, 88%, 51%)','secondary'=>'hsl(11, 91%, 41%)','neutral'=>'hsl(0, 0%, 16%)','base'=>'hsl(100, 100%, 100%)','muted'=>'hsl(220, 0%, 80%)','inverted'=>'hsl(220, 14%, 60%)','background'=>'hsl(0, 0%, 3%)','background-secondary'=>'hsl(0, 6%, 7%)'],
            ],
            'teal' => [
                'label' => 'Teal',
                'light' => ['primary'=>'hsl(172, 49%, 35%)','secondary'=>'hsl(172, 60%, 23%)','neutral'=>'hsl(0, 0%, 91%)','base'=>'hsl(0, 0%, 0%)','muted'=>'hsl(220, 5%, 13%)','inverted'=>'hsl(100, 100%, 100%)','background'=>'hsl(0, 0%, 100%)','background-secondary'=>'hsl(0, 0%, 96%)'],
                'dark'  => ['primary'=>'hsl(172, 49%, 35%)','secondary'=>'hsl(172, 60%, 23%)','neutral'=>'hsl(202, 18%, 12%)','base'=>'hsl(100, 100%, 100%)','muted'=>'hsl(220, 0%, 80%)','inverted'=>'hsl(220, 14%, 60%)','background'=>'hsl(220, 31%, 6%)','background-secondary'=>'hsl(200, 20%, 12%)'],
            ],
            'gold' => [
                'label' => 'Gold',
                'light' => ['primary'=>'hsl(42, 85%, 53%)','secondary'=>'hsl(45, 59%, 53%)','neutral'=>'hsl(0, 0%, 85%)','base'=>'hsl(0, 0%, 0%)','muted'=>'hsl(220, 5%, 13%)','inverted'=>'hsl(100, 100%, 100%)','background'=>'hsl(0, 0%, 90%)','background-secondary'=>'hsl(0, 0%, 96%)'],
                'dark'  => ['primary'=>'hsl(42, 85%, 53%)','secondary'=>'hsl(45, 59%, 53%)','neutral'=>'hsl(330, 4%, 11%)','base'=>'hsl(100, 100%, 100%)','muted'=>'hsl(220, 0%, 80%)','inverted'=>'hsl(220, 14%, 60%)','background'=>'hsl(0, 0%, 3%)','background-secondary'=>'hsl(0, 6%, 7%)'],
            ],
            'green' => [
                'label' => 'Green',
                'light' => ['primary'=>'hsl(151, 100%, 38%)','secondary'=>'hsl(151, 72%, 29%)','neutral'=>'hsl(0, 0%, 89%)','base'=>'hsl(0, 0%, 0%)','muted'=>'hsl(220, 5%, 13%)','inverted'=>'hsl(100, 100%, 100%)','background'=>'hsl(210, 40%, 98%)','background-secondary'=>'hsl(0, 0%, 100%)'],
                'dark'  => ['primary'=>'hsl(151, 100%, 38%)','secondary'=>'hsl(151, 72%, 29%)','neutral'=>'hsl(175, 35%, 7%)','base'=>'hsl(100, 100%, 100%)','muted'=>'hsl(220, 0%, 80%)','inverted'=>'hsl(220, 14%, 60%)','background'=>'hsl(175, 86%, 3%)','background-secondary'=>'hsl(176, 42%, 7%)'],
            ],
            'purple' => [
                'label' => 'Purple',
                'light' => ['primary'=>'hsl(249, 87%, 73%)','secondary'=>'hsl(248, 79%, 83%)','neutral'=>'hsl(0, 0%, 95%)','base'=>'hsl(0, 0%, 0%)','muted'=>'hsl(220, 5%, 13%)','inverted'=>'hsl(100, 100%, 100%)','background'=>'hsl(252, 45%, 98%)','background-secondary'=>'hsl(0, 0%, 100%)'],
                'dark'  => ['primary'=>'hsl(249, 87%, 73%)','secondary'=>'hsl(248, 79%, 83%)','neutral'=>'hsl(252, 12%, 8%)','base'=>'hsl(100, 100%, 100%)','muted'=>'hsl(220, 0%, 80%)','inverted'=>'hsl(220, 14%, 60%)','background'=>'hsl(0, 0%, 4%)','background-secondary'=>'hsl(234, 22%, 9%)'],
            ],
        ];

        $presetOptions = collect($presets)->mapWithKeys(function ($preset, $key) {
            $d = $preset['dark'];
            return [$key => new HtmlString(
                '<div class="citadel-preset-card">'
                . '<div class="citadel-preset-swatches">'
                . '<div class="citadel-preset-swatch" style="background:' . $d['primary'] . '"></div>'
                . '<div class="citadel-preset-swatch" style="background:' . $d['secondary'] . '"></div>'
                . '<div class="citadel-preset-swatch" style="background:' . $d['background'] . '"></div>'
                . '<div class="citadel-preset-swatch" style="background:' . $d['background-secondary'] . '"></div>'
                . '</div>'
                . '<span>' . e($preset['label']) . '</span>'
                . '</div>'
            )];
        })->toArray();

        $components[] = Section::make('Color Presets')
            ->description('Select a preset to instantly apply a full color scheme to both light and dark modes.')
            ->schema([
                Radio::make('color_preset')
                    ->hiddenLabel()
                    ->options($presetOptions)
                    ->columns(2)
                    ->extraAttributes(['class' => 'citadel-image-radio citadel-preset-radio'])
                    ->live()
                    ->afterStateUpdated(function ($state, callable $set) use ($presets) {
                        if (!$state || !isset($presets[$state])) return;
                        $l = $presets[$state]['light'];
                        $d = $presets[$state]['dark'];
                        $set('primary',              $l['primary']);
                        $set('secondary',            $l['secondary']);
                        $set('neutral',              $l['neutral']);
                        $set('base',                 $l['base']);
                        $set('muted',                $l['muted']);
                        $set('inverted',             $l['inverted']);
                        $set('background',           $l['background']);
                        $set('background-secondary', $l['background-secondary']);
                        $set('dark-primary',              $d['primary']);
                        $set('dark-secondary',            $d['secondary']);
                        $set('dark-neutral',              $d['neutral']);
                        $set('dark-base',                 $d['base']);
                        $set('dark-muted',                $d['muted']);
                        $set('dark-inverted',             $d['inverted']);
                        $set('dark-background',           $d['background']);
                        $set('dark-background-secondary', $d['background-secondary']);
                    }),
            ]);

        
        $lightInputs = [];
        foreach ($sections['Light Mode Colors'] ?? [] as $setting) {
            $lightInputs[] = $this->buildInput($setting);
        }
        if (!empty($lightInputs)) {
            $components[] = Section::make('Light Mode Colors')
                ->schema($lightInputs);
        }

        
        $darkInputs = [];
        foreach ($sections['Dark Mode Colors'] ?? [] as $setting) {
            $darkInputs[] = $this->buildInput($setting);
        }
        if (!empty($darkInputs)) {
            $components[] = Section::make('Dark Mode Colors')
                ->schema($darkInputs);
        }

        return $components;
    }

    private function buildHomePageSchema(array $settings): array
    {

        $components = [];

        $components[] = Placeholder::make('home_page_title')
            ->content(new HtmlString('<h2 style="font-size: 1.25rem; font-weight: 700; margin: 0;">Home Page Settings</h2>'))
            ->hiddenLabel();

        $components[] = $this->buildInput($settings[0]);

        $portalInputs = [];
        foreach ($settings as $setting) {
            if (($setting['visible_when'] ?? null) === 'portal') {
                $portalInputs[] = $this->buildInput($setting);
            }
        }
        $components[] = Section::make('Portal Settings')
            ->description('Configure the welcome message and quick-action cards shown on the portal home page.')
            ->icon('ri-layout-grid-line')
            ->schema($portalInputs)
            ->visible(fn (Get $get) => $get('home_layout') === 'portal')
            ->collapsible();

        $components[] = Placeholder::make('custom_page_info')
            ->hiddenLabel()
            ->content(new HtmlString(
                '<div style="padding: 1.25rem 1.5rem; background: hsl(var(--color-primary) / 0.08); border: 1.5px solid hsl(var(--color-primary) / 0.35); border-radius: 0.6rem; line-height: 1.7;">'
                . '<p style="margin: 0 0 0.6rem; font-size: 0.95rem;">Get a custom landing page built specifically for your brand and goals.</p>'
                . '<p style="margin: 0 0 0.75rem; font-size: 0.95rem;">If you\'re looking for something unique and professionally tailored to your needs, feel free to reach out.</p>'
                . '<p style="margin: 0; font-size: 0.95rem;">'
                . 'Contact us via <a href="https://discord.gg/Ze3cWFJXb5" target="_blank" rel="noopener" style="font-weight: 700; color: hsl(var(--color-primary)); text-decoration: underline;">Discord</a>'
                . ' DM at <strong style="font-weight: 700; color: hsl(var(--color-primary));">@willo1</strong>,'
                . ' or ask in our <a href="https://discord.gg/Ze3cWFJXb5" target="_blank" rel="noopener" style="font-weight: 700; color: hsl(var(--color-primary)); text-decoration: underline;">Discord</a>'
                . ' server to get started.'
                . '</p>'
                . '</div>'
            ))
            ->visible(fn (Get $get) => $get('home_layout') === 'custom');


        $groupedSections = [];
        foreach ($settings as $setting) {
            $visibleWhen = $setting['visible_when'] ?? null;
            if ($visibleWhen && $visibleWhen !== 'portal') {
                $sectionName = $setting['section'] ?? 'General';
                $groupedSections[$visibleWhen][$sectionName][] = $setting;
            }
        }

        $sectionIcons = [
            'Hero Section' => 'ri-megaphone-line',
            'Services Section' => 'ri-shopping-bag-line',
            'Features Section' => 'ri-star-line',
            'Feature Cards' => 'ri-layout-masonry-line',
            'Call to Action' => 'ri-cursor-line',
            'Bento Box Features' => 'ri-layout-grid-line',
            'Plans Section' => 'ri-price-tag-3-line',
            'Reviews Section' => 'ri-chat-quote-line',
            'FAQ Section' => 'ri-question-answer-line',
            'CTA Section' => 'ri-rocket-line',
            'Disabled Home Page' => 'ri-forbid-line',
        ];

        foreach ($groupedSections as $layoutKey => $sections) {
            
            if ($layoutKey === 'marketing2') {
                continue;
            }
            foreach ($sections as $sectionName => $sectionSettings) {
                $visibleLayout = $layoutKey;

                if ($sectionName === 'CTA Section') {
                    $sectionInputs = [];
                    foreach ($sectionSettings as $setting) {
                        $sectionInputs[] = $this->buildInput($setting);
                    }

                    $components[] = Section::make($sectionName)
                        ->icon($sectionIcons[$sectionName] ?? null)
                        ->schema($sectionInputs)
                        ->visible(fn (Get $get) => $get('home_layout') === $visibleLayout)
                        ->collapsible()
                        ->collapsed();

                    continue;
                }

                if ($sectionName === 'FAQ Section') {
                    $sectionInputs = [];

                    foreach ($sectionSettings as $setting) {
                        if (in_array($setting['name'], ['marketing2_faq_title', 'marketing2_faq_description'])) {
                            $sectionInputs[] = $this->buildInput($setting);
                        }
                    }

                    $sectionInputs[] = Repeater::make('marketing2_faq_data')
                        ->label('FAQs')
                        ->addActionLabel('Add FAQ')
                        ->schema([
                            TextInput::make('question')
                                ->label('Question')
                                ->required()
                                ->live(onBlur: true)
                                ->maxLength(500),
                            Textarea::make('answer')
                                ->label('Answer')
                                ->required()
                                ->rows(3),
                        ])
                        ->itemLabel(fn (array $state): ?string => $state['question'] ?? null)
                        ->collapsible()
                        ->collapsed()
                        ->cloneable()
                        ->reorderable()
                        ->columnSpanFull();

                    $components[] = Section::make($sectionName)
                        ->icon($sectionIcons[$sectionName] ?? null)
                        ->schema($sectionInputs)
                        ->visible(fn (Get $get) => $get('home_layout') === $visibleLayout)
                        ->collapsible()
                        ->collapsed();

                    continue;
                }

                if ($sectionName === 'Reviews Section') {
                    $sectionInputs = [];


                    foreach ($sectionSettings as $setting) {
                        if (in_array($setting['name'], ['marketing2_reviews_title', 'marketing2_reviews_description'])) {
                            $sectionInputs[] = $this->buildInput($setting);
                        }
                    }


                    $sectionInputs[] = Repeater::make('marketing2_reviews_data')
                        ->label('Reviews')
                        ->addActionLabel('Add Review')
                        ->schema([
                            TextInput::make('name')
                                ->label('Reviewer Name')
                                ->required()
                                ->live(onBlur: true)
                                ->maxLength(255),
                            Textarea::make('review')
                                ->label('Review')
                                ->required()
                                ->rows(3),
                            FileUpload::make('image')
                                ->label('Reviewer Image')
                                ->image()
                                ->imageEditor()
                                ->disk('public')
                                ->directory('citadel/reviews')
                                ->visibility('public')
                                ->nullable(),
                        ])
                        ->itemLabel(fn (array $state): ?string => $state['name'] ?? null)
                        ->collapsible()
                        ->collapsed()
                        ->cloneable()
                        ->reorderable()
                        ->columnSpanFull();

                    $components[] = Section::make($sectionName)
                        ->icon($sectionIcons[$sectionName] ?? null)
                        ->schema($sectionInputs)
                        ->visible(fn (Get $get) => $get('home_layout') === $visibleLayout)
                        ->collapsible()
                        ->collapsed();

                    continue;
                }

                if ($sectionName === 'Features Section') {
                    $sectionInputs = [];


                    foreach ($sectionSettings as $setting) {
                        if (in_array($setting['name'], ['marketing2_features_title', 'marketing2_features_description', 'marketing2_features_icon_bg'])) {
                            $sectionInputs[] = $this->buildInput($setting);
                        }
                    }


                    $sectionInputs[] = Repeater::make('marketing2_features_data')
                        ->label('Features')
                        ->addActionLabel('Add Feature')
                        ->schema([
                            TextInput::make('title')
                                ->label('Title')
                                ->required()
                                ->live(onBlur: true)
                                ->maxLength(255),
                            Textarea::make('description')
                                ->label('Description')
                                ->rows(2),
                            Select::make('icon_type')
                                ->label('Icon Type')
                                ->options([
                                    'citadel' => 'Citadel Icons',
                                    'remix' => 'Remix Icons',
                                ])
                                ->default('citadel')
                                ->native(false)
                                ->live(),
                            Radio::make('icon_citadel')
                                ->label('Citadel Icon')
                                ->options(fn () => $this->getCitadelIcons())
                                ->columns(5)
                                ->extraAttributes(['class' => 'citadel-icon-picker'])
                                ->dehydratedWhenHidden()
                                ->visible(fn (Get $get) => $get('icon_type') === 'citadel'),
                            TextInput::make('icon_remix')
                                ->label('Remix Icon')
                                ->helperText('Enter a Remix Icon name (e.g., ri-shield-check-line)')
                                ->visible(fn (Get $get) => $get('icon_type') === 'remix'),
                        ])
                        ->itemLabel(fn (array $state): ?string => $state['title'] ?? null)
                        ->collapsible()
                        ->collapsed()
                        ->cloneable()
                        ->reorderable()
                        ->columnSpanFull();

                    $components[] = Section::make($sectionName)
                        ->icon($sectionIcons[$sectionName] ?? null)
                        ->schema($sectionInputs)
                        ->visible(fn (Get $get) => $get('home_layout') === $visibleLayout)
                        ->collapsible()
                        ->collapsed();

                    continue;
                }

                $sectionInputs = [];
                foreach ($sectionSettings as $setting) {
                    $sectionInputs[] = $this->buildInput($setting);
                }
                $visibleLayout = $layoutKey;
                $components[] = Section::make($sectionName)
                    ->icon($sectionIcons[$sectionName] ?? null)
                    ->schema($sectionInputs)
                    ->visible(fn (Get $get) => $get('home_layout') === $visibleLayout)
                    ->collapsible()
                    ->collapsed();
            }
        }

        
        $components[] = Section::make('Home Sections')
            ->description('Add, remove and reorder the sections.')
            ->icon('ri-layout-grid-line')
            ->schema([
                Repeater::make('marketing2_blocks')
                    ->hiddenLabel()
                    ->addActionLabel('Add Section')
                    ->reorderable()
                    ->collapsible()
                    ->collapsed()
                    ->cloneable()
                    ->defaultItems(0)
                    ->itemLabel(function (array $state): ?string {
                        $type = ucfirst($state['type'] ?? 'block');
                        $headline = $state['heading'] ?? $state['title'] ?? null;
                        return $headline ? "{$type}  {$headline}" : $type;
                    })
                    ->schema($this->blockSchemaComponents(
                        [],
                        $this->homeBlockExtraComponents(),
                        $this->homeBlockExtraStyles()
                    )),
            ])
            ->visible(fn (Get $get) => $get('home_layout') === 'marketing2')
            ->collapsible();

        return $components;
    }

    private function buildInput(array $setting)
    {
        $type = $setting['type'] ?? 'text';

        $input = match ($type) {
            'select' => Select::make($setting['name'])
                ->label($setting['label'])
                ->options($setting['options'] ?? [])
                ->default($setting['default'] ?? null)
                ->helperText($setting['description'] ?? null)
                ->native(false)
                ->nullable()
                ->live(condition: $setting['live'] ?? false),

            'checkbox' => Toggle::make($setting['name'])
                ->label($setting['label'])
                ->default($setting['default'] ?? false)
                ->helperText($setting['description'] ?? null)
                ->live(condition: $setting['live'] ?? false),

            'textarea' => Textarea::make($setting['name'])
                ->label($setting['label'])
                ->default($setting['default'] ?? '')
                ->helperText($setting['description'] ?? null)
                ->rows($setting['rows'] ?? 3)
                ->extraInputAttributes(['style' => 'font-family: monospace; font-size: 0.8rem;']),  

            'markdown' => MarkdownEditor::make($setting['name'])
                ->label($setting['label'])
                ->default($setting['default'] ?? '')
                ->helperText($setting['description'] ?? null),

            'file' => FileUpload::make($setting['name'])
                ->label($setting['label'])
                ->helperText($setting['description'] ?? null)
                ->nullable()
                ->visibility('public')
                ->disk('public')
                ->directory('citadel')
                ->image()
                ->imageEditor()
                ->acceptedFileTypes(['image/*']),

            'multi_file' => FileUpload::make($setting['name'])
                ->label($setting['label'])
                ->helperText($setting['description'] ?? null)
                ->multiple()
                ->reorderable()
                ->appendFiles()
                ->nullable()
                ->visibility('public')
                ->disk('public')
                ->directory('citadel/payment-icons')
                ->image()
                ->acceptedFileTypes(['image/svg+xml', 'image/png', 'image/jpeg', 'image/webp'])
                ->maxFiles(20)
                ->panelLayout('grid')
                ->imagePreviewHeight('80'),

            'color' => ColorPicker::make($setting['name'])
                ->label($setting['label'])
                ->helperText($setting['description'] ?? null)
                ->default($setting['default'] ?? '')
                ->hsl()
                ->live()
                ->rules(function () {
                    return function ($attribute, $value, $fail) {
                        try {
                            ColorFactory::fromString(trim($value));
                        } catch (Exception $e) {
                            $fail('The :attribute must be a valid color.');
                        }
                    };
                })
                ->afterStateUpdated(function ($state, callable $set) use ($setting) {
                    try {
                        $set($setting['name'], preg_replace('/,\s*/', ', ', ColorFactory::fromString(trim($state))->toHsl()->__toString()));
                    } catch (Exception $e) {
                    }
                }),

            'citadel_icon_picker' => Radio::make($setting['name'])
                ->label($setting['label'])
                ->helperText($setting['description'] ?? null)
                ->options(fn () => $this->getCitadelIcons())
                ->default($setting['default'] ?? '')
                ->columns(5)
                ->extraAttributes(['class' => 'citadel-icon-picker'])
                ->live(),

            'image_radio' => Radio::make($setting['name'])
                ->label($setting['label'])
                ->helperText($setting['description'] ?? null)
                ->options(collect($setting['options'] ?? [])->mapWithKeys(function ($label, $key) use ($setting) {
                    $imgPath = $setting['images'][$key] ?? '';
                    if (str_starts_with($imgPath, 'ext://')) {
                        $relPath = substr($imgPath, 6);
                        $absPath = __DIR__ . '/../../' . $relPath;
                        try {
                            $content = File::get($absPath);
                            $mime = str_ends_with($relPath, '.svg') ? 'image/svg+xml' : 'image/png';
                            $imgUrl = 'data:' . $mime . ';base64,' . base64_encode($content);
                        } catch (\Throwable $e) {
                            $imgUrl = '';
                        }
                    } else {
                        $imgUrl = $imgPath ? asset($imgPath) : '';
                    }
                    if (!empty($setting['overlay_text'])) {
                        $overlayData = $setting['overlay_options'][$key] ?? [];
                        $overlayTitle = $overlayData['title'] ?? $label;
                        $overlayDesc  = $overlayData['description'] ?? '';
                        return [$key => new HtmlString(
                            '<div class="citadel-image-radio-card citadel-image-radio-card--overlay">'
                            . ($imgUrl ? '<img src="' . e($imgUrl) . '" alt="' . e($label) . '" />' : '')
                            . '<div class="citadel-image-radio-text-overlay">'
                            . '<p class="citadel-overlay-title">' . e($overlayTitle) . '</p>'
                            . ($overlayDesc ? '<p class="citadel-overlay-desc">' . e($overlayDesc) . '</p>' : '')
                            . '</div>'
                            . '</div>'
                        )];
                    }
                    return [$key => new HtmlString(
                        '<div class="citadel-image-radio-card">'
                        . ($imgUrl ? '<img src="' . e($imgUrl) . '" alt="' . e($label) . '" />' : '')
                        . '<span>' . e($label) . '</span>'
                        . '</div>'
                    )];
                })->toArray())
                ->default($setting['default'] ?? '')
                ->columns($setting['columns'] ?? 2)
                ->extraAttributes(['class' => 'citadel-image-radio'])
                ->nullable()
                ->live(),

            default => TextInput::make($setting['name'])
                ->label($setting['label'])
                ->default($setting['default'] ?? '')
                ->helperText($setting['description'] ?? null),
        };

        if (isset($setting['visible_when_field'], $setting['visible_when_value'])) {
            $field = $setting['visible_when_field'];
            $value = $setting['visible_when_value'];
            $field2 = $setting['visible_when_field_2'] ?? null;
            $value2 = $setting['visible_when_value_2'] ?? null;

            if (!empty($setting['visible_when_not'])) {
                if ($field2 !== null) {
                    $input = $input->visible(fn (Get $get) => $get($field) !== $value && $get($field2) === $value2);
                } else {
                    $input = $input->visible(fn (Get $get) => $get($field) !== $value);
                }
            } else {
                if ($field2 !== null) {
                    $input = $input->visible(fn (Get $get) => $get($field) === $value && $get($field2) === $value2);
                } else {
                    $input = $input->visible(fn (Get $get) => $get($field) === $value);
                }
            }

        }

        return $input;
    }

    private function activeTabKey(array $managed): ?string
    {
        $raw = is_string($this->citadelActiveTab) ? trim($this->citadelActiveTab) : '';

        if ($raw === '') {
            return null;
        }

        $key = str_replace('-', '_', $raw);

        return array_key_exists($key, $managed) ? $key : null;
    }

    private function tabSchema(string $tabKey, array $managed): ?Schema
    {
        $index = array_search($tabKey, array_keys($managed), true);

        if ($index === false) {
            return null;
        }

        $tabs = $this->form->getComponent(fn ($component) => $component instanceof Tabs);

        if (! $tabs instanceof Tabs) {
            return null;
        }

        $container = $tabs->getChildSchema();

        if ($container === null) {
            return null;
        }

        $tabComponents = array_values(array_filter(
            $container->getComponents(),
            fn ($component) => $component instanceof Tab
        ));

        $tab = $tabComponents[$index] ?? null;

        return $tab instanceof Tab ? $tab->getChildSchema() : null;
    }

    public function save(): void
    {
        if (! Auth::user()->hasPermission('admin.citadel_editor.update')) {
            Log::warning('[CitadelEditor] Save blocked: user lacks admin.citadel_editor.update permission', [
                'user_id' => Auth::id(),
                'user_email' => Auth::user()->email ?? 'unknown',
            ]);

            Notification::make()
                ->title('You do not have permission to update these settings.')
                ->danger()
                ->send();

            return;
        }

        try {
            $managed = $this->managedSettings();
            $activeKey = $this->activeTabKey($managed);

            $data = null;
            $scopedSettings = $managed;
            $fullSave = true;

            if ($activeKey === 'custom_pages') {
                $data = $this->form->getState();
                $scopedSettings = ['custom_pages' => $managed['custom_pages']];
                $fullSave = false;
            } elseif ($activeKey !== null) {
                try {
                    $tabSchema = $this->tabSchema($activeKey, $managed);

                    if ($tabSchema !== null) {
                        $tabData = $tabSchema->getState();
                        $tabNames = collect($managed[$activeKey])->pluck('name');

                        if ($tabNames->contains(fn ($name) => array_key_exists($name, $tabData))) {
                            $data = $tabData;
                            $scopedSettings = [$activeKey => $managed[$activeKey]];
                            $fullSave = false;
                        }
                    }
                } catch (ValidationException $e) {
                    throw $e;
                } catch (\Throwable $e) {
                    Log::warning('[CitadelEditor] Per-tab save fell back to full save', [
                        'tab' => $activeKey,
                        'error' => $e->getMessage(),
                    ]);

                    $data = null;
                    $scopedSettings = $managed;
                }
            }

            if ($data === null) {
                $data = $this->form->getState();
                $scopedSettings = $managed;
            }

            if (! array_key_exists('custom_pages', $scopedSettings)) {
                $scopedSettings['custom_pages'] = $managed['custom_pages'];
            }

            if (array_key_exists('custom_pages', $scopedSettings)) {
                $pages = array_values($this->cpPages);
                if ($this->cpEditingIndex !== null) {
                    $edited = $data['cp_editing'] ?? ($this->data['cp_editing'] ?? null);
                    if (is_array($edited) && $edited !== []) {
                        $pages[$this->cpEditingIndex] = $edited;
                        $pages = array_values($pages);
                        $this->cpPages = $pages;
                    }
                }
                $data['custom_pages_data'] = $pages;
            }
            unset($data['cp_editing']);

            $definitions = collect($scopedSettings)
                ->flatten(1)
                ->keyBy('name');

            $keys = $definitions->keys()->map(fn ($name) => $this->prefix() . $name)->toArray();
            $existing = Setting::where('settingable_type', null)
                ->whereIn('key', $keys)
                ->get()
                ->keyBy('key');

            $savedCount = 0;
            $errors = [];

            foreach ($data as $name => $value) {
                $def = $definitions[$name] ?? null;
                if (! $def) {
                    continue;
                }

                try {
                    $key = $this->prefix() . $name;
                    $dbType = $def['database_type'] ?? 'string';

                    if (in_array($def['type'] ?? '', ['repeater', 'multi_file']) && is_array($value)) {
                        $value = json_encode(array_values($value));
                    }

                    if ($record = $existing[$key] ?? null) {
                        $record->update([
                            'value' => $value,
                            'type' => $dbType,
                        ]);
                    } else {
                        Setting::create([
                            'key' => $key,
                            'value' => $value,
                            'settingable_type' => null,
                            'type' => $dbType,
                        ]);
                    }

                    $savedCount++;
                } catch (\Throwable $e) {
                    $errors[] = $name;
                    Log::error('[CitadelEditor] Failed to save setting', [
                        'key' => $name,
                        'error' => $e->getMessage(),
                        'trace' => $e->getTraceAsString(),
                    ]);
                }
            }

            if (! empty($errors)) {
                Log::warning('[CitadelEditor] Save completed with errors', [
                    'saved' => $savedCount,
                    'failed' => count($errors),
                    'failed_keys' => $errors,
                    'user_id' => Auth::id(),
                ]);

                Notification::make()
                    ->title('Saved with errors')
                    ->body('Failed to save: ' . implode(', ', $errors) . '. Check logs for details.')
                    ->warning()
                    ->send();
            } else {
                Log::info('[CitadelEditor] Settings saved successfully', [
                    'count' => $savedCount,
                    'user_id' => Auth::id(),
                ]);

                Notification::make()
                    ->title('Saved successfully!')
                    ->success()
                    ->send();
            }


            foreach ($data as $name => $value) {
                config(['settings.' . $this->prefix() . $name => $value]);
            }

            $this->dispatch('citadel-settings-saved', full: $fullSave);

            
            if ($this->cpEditingIndex !== null) {
                $pages = array_values($this->cpPages);
                if (array_key_exists($this->cpEditingIndex, $pages)) {
                    $this->dispatchPreviewUrl($this->customPageUrl($pages[$this->cpEditingIndex], $this->categorySlugMap()));
                }
            }

        } catch (ValidationException $e) {
            $validationErrors = $e->errors();
            $errorMessages = [];
            foreach ($validationErrors as $field => $messages) {
                foreach ($messages as $msg) {
                    $errorMessages[] = "{$field}: {$msg}";
                }
            }

            Log::error('[CitadelEditor] Validation failed during save', [
                'errors' => $validationErrors,
                'error_messages' => $errorMessages,
                'user_id' => Auth::id(),
                'user_email' => Auth::user()->email ?? 'unknown',
            ]);

            Notification::make()
                ->title('Failed to save settings')
                ->body('Validation errors: ' . implode('; ', $errorMessages))
                ->danger()
                ->send();
        } catch (\Throwable $e) {
            Log::error('[CitadelEditor] Critical save failure', [
                'error' => $e->getMessage(),
                'class' => get_class($e),
                'trace' => $e->getTraceAsString(),
                'user_id' => Auth::id(),
                'user_email' => Auth::user()->email ?? 'unknown',
            ]);

            Notification::make()
                ->title('Failed to save settings')
                ->body($e->getMessage())
                ->danger()
                ->send();
        }
    }


    private static ?array $cachedCitadelIcons = null;


    private static ?array $cachedDomainRegCategoryIds = null;


    private function isDomainRegistrationCategoryId($categoryId): bool
    {
        if (! $categoryId) {
            return false;
        }
        if (self::$cachedDomainRegCategoryIds === null) {
            try {
                self::$cachedDomainRegCategoryIds = \App\Models\Category::where('slug', 'domain-registration')
                    ->pluck('id')
                    ->map(fn ($id) => (int) $id)
                    ->all();
            } catch (\Throwable $e) {
                self::$cachedDomainRegCategoryIds = [];
            }
        }
        return in_array((int) $categoryId, self::$cachedDomainRegCategoryIds, true);
    }

    private function getCitadelIcons(): array
    {
        if (self::$cachedCitadelIcons !== null) {
            return self::$cachedCitadelIcons;
        }
        $iconsPath = public_path('assets/icons/citadel');
        if (!File::isDirectory($iconsPath)) {
            return self::$cachedCitadelIcons = [];
        }
        $files = File::files($iconsPath);
        $icons = [];
        foreach ($files as $file) {
            if (strtolower($file->getExtension()) === 'svg') {
                $name = $file->getFilenameWithoutExtension();
                $url = asset('assets/icons/citadel/' . $name . '.svg');
                $icons[$name] = new HtmlString(
                    '<div style="display:flex;align-items:center;justify-content:center;width:56px;height:56px;border-radius:8px;" title="' . e($name) . '">'
                    . '<img src="' . e($url) . '" alt="' . e($name) . '" style="width:40px;height:40px;object-fit:contain;opacity:0.85;" />'
                    . '</div>'
                );
            }
        }
        ksort($icons);
        return self::$cachedCitadelIcons = $icons;
    }
}
